# Vision AI — PPE monitoring

One repository, three parts:

| Folder      | What it is                                                | Where it runs                                              |
|-------------|-----------------------------------------------------------|------------------------------------------------------------|
| `backend/`  | FastAPI + YOLO detection API (`main.py`, `app/`)          | VPS, `visionai-backend.paperlessops.com`, systemd service   |
| `frontend/` | Vite + React dashboard                                    | VPS, `visionai.paperlessops.com` (static files)             |
| `agent/`    | Capture agent that pushes camera frames to the backend    | An always-on office PC that can see the cameras            |
| `deploy/`   | Scripts run on the server to publish `main`               | VPS, via WHM > Terminal                                     |

**`main` branch = what is in production.** Nothing reaches the server except by
merging into `main` and running the deploy script.

## What is deliberately NOT in git

| Item | Why | Where it lives |
|------|-----|----------------|
| `backend/.env` | Secrets (DB password, JWT key, SMTP password) | Only on the server. Template: `backend/.env.example` |
| `*.pt`, `*.onnx`, `*.pkl` | Model weights, large binaries | Server; copy from the pre-deploy backup if ever lost |
| `evidence/`, `email_evidence/`, `recordings/`, `runs/` | Captured video/images (privacy, size) | Server only |
| `monitoring_state.json` | Runtime state | Server only |
| `frontend/node_modules`, `frontend/dist` | Rebuilt from source | — |
| `agent/agent_config.json` | Contains the ingest token | Office PC only. Template: `agent_config.example.json` |

## Run locally (developer)

**Backend**
```
cd backend
python -m venv venv
venv\Scripts\activate            (Windows)   /   source venv/bin/activate (Linux)
pip install -r requirements.txt
copy .env.example .env           then fill in a local DATABASE_URL etc.
uvicorn main:app --reload --port 8000
```

**Frontend**
```
cd frontend
npm install
npm run dev                      -> http://localhost:5173, API at http://localhost:8000
```

## Deploy to production

Both scripts run **on the server** as root in WHM > Terminal. They back up
first, and refuse to restart if the new code does not import/build.

```
bash /home/paperlessops/visionai-repo/deploy/deploy-backend.sh
bash /home/paperlessops/visionai-repo/deploy/deploy-frontend.sh
```

One-time server setup (clone the repo with a read-only deploy key) is
described in `deploy/SERVER-SETUP.md`.

## Working agreement

1. Nobody commits directly to `main`. It is protected.
2. Every change is a branch (`feature/…` or `fix/…`) and a Pull Request.
3. The owner (Ajitesh) reviews and merges. Claude assists with the review.
4. After merging, the owner runs the deploy script(s). Production always
   equals `main`.
5. Alternative designs live on their own branch (e.g.
   `dev/prateek-detection-rewrite`) until agreed — they are never copied over
   the live tree by hand.

## Branches

- `main` — production. First commit = exact server state on 12 Sep 2026
  (update-4 + auth), plus the matching frontend.
- `dev/prateek-detection-rewrite` — the developer's alternative backend
  (`ai_scheduler.py`, `event_worker.py`, `model_registry.py`, his own
  `detection_service.py` / `camera_management.py` / `main.py`). Kept for
  discussion; not merged.
