# Capture agent

Runs on an office PC that can reach the cameras. Grabs one frame per camera
every 2 s and POSTs it to `POST /api/ingest/frame/{camera_id}` on the server.

## Setup
```
pip install opencv-python numpy
copy agent_config.example.json agent_config.json   (Windows)
```
Edit `agent_config.json`: set `ingest_token` to the same value as
`VISIONAI_INGEST_TOKEN` in the server's `.env`. `agent_config.json` is
git-ignored — never commit a real token.

## Run
```
python capture_agent.py
```
