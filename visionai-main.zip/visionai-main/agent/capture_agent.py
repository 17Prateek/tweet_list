"""
VisionAI capture agent.

Runs on a machine inside the camera network - today the laptop that already
carries the Tailscale tunnel, later a small always-on box in the same room.

Why this exists
---------------
The server currently pulls full RTSP video across the internet just to analyse
it, which costs several Mbps per camera continuously and arrives degraded by
the squeeze. This agent sits on the same LAN as the cameras, where bandwidth is
free, grabs one frame per camera every few seconds at full quality, and posts
only those frames to the server.

Roughly 95% less data, and better pictures than the server sees today.

The agent holds no models, no database and no dashboard. Detection stays on the
server. If this process dies, restarting it is the entire recovery.

Usage
-----
    python capture_agent.py --test    capture from every camera, save the
                                      frames locally, print sizes and timings.
                                      Sends nothing. Safe to run before the
                                      server side exists.

    python capture_agent.py --once    one capture-and-send pass, then exit.

    python capture_agent.py           run continuously.

Settings come from agent_config.json beside this file, or from the environment.
"""

import argparse
import json
import os
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

# OpenCV is the only non-standard dependency. It bundles its own FFmpeg, so
# nothing else needs installing:  pip install opencv-python-headless
try:
    import cv2
except ImportError:
    print(
        "OpenCV is missing. Install it with:\n"
        "    pip install opencv-python-headless"
    )
    sys.exit(1)


BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "agent_config.json"

# Low-latency RTSP. Must be set before OpenCV opens its first capture, which is
# why it sits here rather than next to the code that uses it.
os.environ.setdefault(
    "OPENCV_FFMPEG_CAPTURE_OPTIONS",
    "rtsp_transport;tcp|fflags;nobuffer|flags;low_delay|"
    "max_delay;500000|stimeout;5000000",
)

DEFAULTS = {
    # Where the dashboard/API lives.
    "server_url": "https://visionai-backend.paperlessops.com",

    # Seconds between frames for one camera. Detection does not need video -
    # nobody puts a helmet on and takes it off inside two seconds.
    "interval_sec": 2.0,

    # 0 keeps the camera's own resolution. Set e.g. 1280 to shrink before
    # sending, trading detail for bandwidth.
    "max_width": 0,

    # 1-100. 85 is visually near-lossless and still compact.
    "jpeg_quality": 85,

    # How often to re-read the camera list from the server, so cameras added or
    # edited in the dashboard are picked up without restarting the agent.
    "camera_refresh_sec": 60.0,

    # Give up on a camera that produces nothing for this long, and reconnect.
    "read_timeout_sec": 15.0,

    "reconnect_min_sec": 3.0,
    "reconnect_max_sec": 30.0,

    "request_timeout_sec": 20.0,

    # Optional shared secret. Must match VISIONAI_INGEST_TOKEN on the server.
    # Leave empty if the server has none set.
    "ingest_token": "",
}


def log(message):
    print(f"{datetime.now().strftime('%H:%M:%S')}  {message}", flush=True)


def load_config():
    config = dict(DEFAULTS)

    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as handle:
                config.update(json.load(handle))
        except Exception as error:
            log(f"[WARN] Could not read {CONFIG_FILE.name}: {error}")

    # Environment wins, so a service wrapper can override without editing files.
    for key in DEFAULTS:
        env_value = os.getenv("VISIONAI_AGENT_" + key.upper())

        if env_value is None:
            continue

        try:
            config[key] = type(DEFAULTS[key])(env_value)
        except (TypeError, ValueError):
            log(f"[WARN] Ignoring bad value for {key}: {env_value}")

    return config


def mask(url):
    """Never print camera passwords."""
    if not url or "@" not in url:
        return url

    scheme, _, rest = url.partition("//")
    return f"{scheme}//***@{rest.partition('@')[2]}"


def fetch_json(url, timeout, token=""):
    headers = {"Accept": "application/json"}

    if token:
        headers["X-Ingest-Token"] = token

    request = urllib.request.Request(url, headers=headers)

    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read())


def get_cameras(config):
    """
    Ask the server which cameras to capture.

    Uses the agent's own endpoint, authenticated by the ingest token (the
    dashboard's /api/cameras needs a human login). Only RTSP cameras are
    handled - webcam/USB sources belong to whatever machine they are plugged
    into. Cameras excluded from monitoring are skipped so the agent does not
    ship frames nobody will look at.
    """
    base = config["server_url"].rstrip("/")
    timeout = config["request_timeout_sec"]
    token = str(config.get("ingest_token") or "").strip()

    payload = fetch_json(
        f"{base}/api/ingest/cameras?agent={int(time.time())}", timeout, token
    )
    data = payload.get("data") or {}
    cameras = data.get("cameras") or []
    excluded = {int(x) for x in (data.get("excluded_camera_ids") or [])}

    wanted = []

    for camera in cameras:
        if (camera.get("source_type") or "").lower() != "rtsp":
            continue

        if not camera.get("rtsp_url"):
            continue

        if int(camera["id"]) in excluded:
            continue

        wanted.append(camera)

    return wanted


def post_frame(config, camera_id, jpeg_bytes):
    """Send one frame. Raw JPEG body - no multipart, nothing to parse."""
    base = config["server_url"].rstrip("/")
    url = f"{base}/api/ingest/frame/{int(camera_id)}"

    headers = {
        "Content-Type": "image/jpeg",
        "Content-Length": str(len(jpeg_bytes)),
    }

    token = str(config.get("ingest_token") or "").strip()

    if token:
        headers["X-Ingest-Token"] = token

    request = urllib.request.Request(
        url,
        data=jpeg_bytes,
        method="POST",
        headers=headers,
    )

    with urllib.request.urlopen(
        request,
        timeout=config["request_timeout_sec"],
    ) as response:
        return response.status


def encode_frame(frame, config, pixel_aspect=1.0):
    frame = correct_aspect(frame, pixel_aspect)
    max_width = int(config["max_width"])

    if max_width > 0:
        height, width = frame.shape[:2]

        if width > max_width:
            scale = max_width / float(width)
            frame = cv2.resize(
                frame,
                (int(width * scale), int(height * scale)),
            )

    ok, buffer = cv2.imencode(
        ".jpg",
        frame,
        [int(cv2.IMWRITE_JPEG_QUALITY), int(config["jpeg_quality"])],
    )

    if not ok:
        raise RuntimeError("JPEG encode failed")

    return buffer.tobytes(), frame.shape[1], frame.shape[0]


def open_capture(rtsp_url):
    capture = cv2.VideoCapture(rtsp_url, cv2.CAP_FFMPEG)

    try:
        capture.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    except Exception:
        pass

    return capture


def read_pixel_aspect(capture):
    """
    How wide each stored pixel is, relative to its height.

    Some recorders encode anamorphically - 960x1080 stored, meant to be shown
    as 1920x1080. Sending those frames as-is hands the detector people who are
    half as wide as they should be. FFmpeg reports the ratio; 1.0 means normal
    square pixels and nothing needs doing.
    """
    try:
        num = capture.get(cv2.CAP_PROP_SAR_NUM)
        den = capture.get(cv2.CAP_PROP_SAR_DEN)
    except Exception:
        return 1.0

    if num and den and num > 0 and den > 0:
        return float(num) / float(den)

    return 1.0


def correct_aspect(frame, pixel_aspect):
    """Stretch an anamorphic frame out to its true display shape."""
    if pixel_aspect <= 0 or abs(pixel_aspect - 1.0) < 0.01:
        return frame

    height, width = frame.shape[:2]
    display_width = int(round(width * pixel_aspect))

    if display_width % 2:
        display_width += 1

    return cv2.resize(frame, (display_width, height))


class CameraCapture(threading.Thread):
    """
    One thread per camera.

    The RTSP connection is held open and drained continuously - reading and
    discarding frames is what keeps the picture current. Only every Nth frame
    is encoded and sent. Draining costs nothing here because the camera is on
    the same network.
    """

    def __init__(self, camera, config, stop_event, send=True):
        super().__init__(daemon=True, name=f"camera-{camera['id']}")
        self.camera_id = int(camera["id"])
        self.camera_name = str(camera.get("camera_name") or self.camera_id)
        self.rtsp_url = camera["rtsp_url"]
        self.config = config
        self.stop_event = stop_event
        self.send = send

        self.sent = 0
        self.failed = 0
        self.last_bytes = 0
        self.last_size = None
        self.pixel_aspect = 1.0

    def run(self):
        delay = float(self.config["reconnect_min_sec"])

        while not self.stop_event.is_set():
            capture = None

            try:
                log(f"[{self.camera_name}] connecting {mask(self.rtsp_url)}")
                capture = open_capture(self.rtsp_url)

                if not capture.isOpened():
                    raise RuntimeError("could not open stream")

                self.pixel_aspect = read_pixel_aspect(capture)
                log(
                    f"[{self.camera_name}] connected"
                    + (
                        f" (anamorphic, pixel aspect {self.pixel_aspect:g} - correcting)"
                        if abs(self.pixel_aspect - 1.0) > 0.01
                        else ""
                    )
                )
                delay = float(self.config["reconnect_min_sec"])
                self._pump(capture)

            except Exception as error:
                log(f"[{self.camera_name}] {error}")

            finally:
                if capture is not None:
                    capture.release()

            if self.stop_event.wait(delay):
                break

            delay = min(delay * 2, float(self.config["reconnect_max_sec"]))

    def _pump(self, capture):
        interval = float(self.config["interval_sec"])
        timeout = float(self.config["read_timeout_sec"])

        last_sent_at = 0.0
        last_frame_at = time.monotonic()

        while not self.stop_event.is_set():
            ok, frame = capture.read()

            if not ok or frame is None:
                if time.monotonic() - last_frame_at > timeout:
                    raise RuntimeError("no frames, reconnecting")

                time.sleep(0.05)
                continue

            last_frame_at = time.monotonic()

            if last_frame_at - last_sent_at < interval:
                continue

            last_sent_at = last_frame_at
            self._handle(frame)

    def _handle(self, frame):
        try:
            jpeg, width, height = encode_frame(
                frame,
                self.config,
                self.pixel_aspect,
            )
            self.last_bytes = len(jpeg)
            self.last_size = (width, height)

            if not self.send:
                return

            post_frame(self.config, self.camera_id, jpeg)
            self.sent += 1

        except urllib.error.HTTPError as error:
            self.failed += 1

            if error.code == 404:
                log(
                    f"[{self.camera_name}] server has no /api/ingest endpoint "
                    f"yet - run with --test until it does"
                )
            elif error.code == 401:
                log(
                    f"[{self.camera_name}] server rejected the ingest token - "
                    f"check ingest_token in agent_config.json"
                )
            else:
                log(f"[{self.camera_name}] server said {error.code}")

        except Exception as error:
            self.failed += 1
            log(f"[{self.camera_name}] send failed: {error}")


def run_test(config):
    """
    Grab one frame from every camera and save it locally.

    Sends nothing, so this is safe to run before the server can receive frames.
    It answers the questions that decide whether this design is worth building:
    how long a frame takes, how big it is, and what resolution we actually get.
    """
    log("TEST MODE - capturing one frame per camera, sending nothing")

    try:
        cameras = get_cameras(config)
    except Exception as error:
        log(f"Could not read the camera list from the server: {error}")
        if "401" in str(error):
            log("The server rejected the ingest token - check ingest_token in agent_config.json")
        return 1

    if not cameras:
        log("No RTSP cameras returned by the server.")
        return 1

    out_dir = BASE_DIR / "test_frames"
    out_dir.mkdir(exist_ok=True)

    log(f"{len(cameras)} camera(s). Saving to {out_dir}")
    print()

    total_bytes = 0
    captured = 0

    for camera in cameras:
        name = str(camera.get("camera_name") or camera["id"])
        started = time.monotonic()
        capture = None

        try:
            capture = open_capture(camera["rtsp_url"])

            if not capture.isOpened():
                raise RuntimeError("could not open stream")

            frame = None

            # The first frames after connecting are often stale or partial.
            for _ in range(10):
                ok, candidate = capture.read()

                if ok and candidate is not None:
                    frame = candidate

            if frame is None:
                raise RuntimeError("no frame received")

            pixel_aspect = read_pixel_aspect(capture)
            stored_h, stored_w = frame.shape[:2]
            jpeg, width, height = encode_frame(frame, config, pixel_aspect)
            elapsed = time.monotonic() - started

            path = out_dir / f"camera_{camera['id']}.jpg"
            path.write_bytes(jpeg)

            total_bytes += len(jpeg)
            captured += 1

            note = ""

            if abs(pixel_aspect - 1.0) > 0.01:
                note = f"  (stored {stored_w}x{stored_h}, corrected)"

            print(
                f"  {name[:20]:<22} {width}x{height:<6} "
                f"{len(jpeg):>8,} bytes  {elapsed:5.2f}s  -> {path.name}{note}"
            )

        except Exception as error:
            print(f"  {name[:20]:<22} FAILED: {error}")

        finally:
            if capture is not None:
                capture.release()

    print()

    if captured:
        interval = float(config["interval_sec"])
        mbps = (total_bytes * 8) / interval / 1_000_000

        log(f"{captured} camera(s) captured, {total_bytes:,} bytes per cycle")
        log(
            f"At one frame every {interval:g}s that is "
            f"{mbps:.3f} Mbps for all cameras combined"
        )
        log(f"Open the images in {out_dir} and check they look sharp enough")

    return 0 if captured else 1


def run_agent(config, once=False):
    stop_event = threading.Event()

    try:
        cameras = get_cameras(config)
    except Exception as error:
        log(f"Could not read the camera list: {error}")
        if "401" in str(error):
            log("The server rejected the ingest token - check ingest_token in agent_config.json")
        return 1

    if not cameras:
        log("No RTSP cameras to capture.")
        return 1

    log(f"Starting capture for {len(cameras)} camera(s)")
    log(f"Server: {config['server_url']}")
    log(f"One frame per camera every {config['interval_sec']:g}s")

    # camera id -> (camera dict, its capture thread + private stop flag)
    threads = {}

    def start_capture(camera):
        flag = threading.Event()
        thread = CameraCapture(camera, config, flag)
        thread.start()
        threads[int(camera["id"])] = (camera, thread, flag)

    for camera in cameras:
        start_capture(camera)

    def refresh_cameras():
        """
        Re-read the camera list so switching PPE monitoring on or off for a
        camera in the dashboard takes effect here without a restart.
        """
        try:
            wanted = {int(c["id"]): c for c in get_cameras(config)}
        except Exception as error:
            log(f"Camera list refresh failed (keeping current list): {error}")
            return

        for camera_id in list(threads):
            if camera_id not in wanted:
                camera, thread, flag = threads.pop(camera_id)
                flag.set()
                log(f"Stopped capturing {camera.get('camera_name')} - no longer monitored")

        for camera_id, camera in wanted.items():
            if camera_id not in threads:
                log(f"Now capturing {camera.get('camera_name')} - monitoring switched on")
                start_capture(camera)

    refresh_every = float(config.get("camera_refresh_sec") or 60.0)
    last_refresh = time.monotonic()

    try:
        if once:
            time.sleep(float(config["interval_sec"]) + 8)
        else:
            while True:
                time.sleep(30)

                if time.monotonic() - last_refresh >= refresh_every:
                    last_refresh = time.monotonic()
                    refresh_cameras()

                live = [t for (_, t, _) in threads.values()]
                sent = sum(t.sent for t in live)
                failed = sum(t.failed for t in live)
                size = sum(t.last_bytes for t in live)

                log(f"cameras={len(live)} sent={sent} failed={failed} last cycle={size:,} bytes")

    except KeyboardInterrupt:
        log("Stopping")

    finally:
        stop_event.set()

        for (_, thread, flag) in threads.values():
            flag.set()

        for (_, thread, _) in threads.values():
            thread.join(timeout=3)

    return 0


def main():
    parser = argparse.ArgumentParser(description="VisionAI capture agent")
    parser.add_argument(
        "--test",
        action="store_true",
        help="capture one frame per camera locally and report - sends nothing",
    )
    parser.add_argument(
        "--once",
        action="store_true",
        help="run a single capture-and-send pass, then exit",
    )
    args = parser.parse_args()

    config = load_config()

    if args.test:
        return run_test(config)

    return run_agent(config, once=args.once)


if __name__ == "__main__":
    sys.exit(main())
