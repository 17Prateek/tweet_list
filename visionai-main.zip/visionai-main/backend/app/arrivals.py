"""
Expected vehicles: the gate office's list of trucks due today, and where each
one is right now.

    expected -> arrived -> on site (which zone, live from the episode engine) -> departed

A row is linked to the vehicle the cameras see by choosing the open vehicle
episode (a person does this at the gate today; ANPR will do it by plate
later through the same link() call). Linking stamps the plate onto the
episode, so cards and the ledger show "HR 55 AB 1234" instead of "Truck".
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from sqlalchemy import Column, DateTime, Integer, String, Text
from sqlalchemy.sql import func

from app import episodes
from app.auth_dependencies import get_current_user
from app.database import Base, Episode, User, get_db_session

PURPOSES = ("loading", "unloading", "other")


class ExpectedVehicle(Base):
    __tablename__ = "expected_vehicles"

    id = Column(Integer, primary_key=True, index=True)
    date = Column(String(10), nullable=False, index=True)        # YYYY-MM-DD, plant-local day
    plate = Column(String(20), nullable=False)
    transporter = Column(String(150), nullable=True)
    material = Column(String(150), nullable=True)
    purpose = Column(String(20), nullable=False, default="unloading")
    expected_time = Column(String(5), nullable=True)             # HH:MM plant-local
    notes = Column(Text, nullable=True)

    arrived_at = Column(DateTime(timezone=True), nullable=True)
    departed_at = Column(DateTime(timezone=True), nullable=True)
    episode_ids_json = Column(Text, nullable=True)               # vehicle episodes linked, in order

    created_by = Column(String(150), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _epoch(value: Optional[datetime]) -> Optional[float]:
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.timestamp()


def normalise_plate(plate: str) -> str:
    return "".join(ch for ch in str(plate or "").upper() if ch.isalnum())


def _links(row: ExpectedVehicle) -> List[str]:
    try:
        return list(json.loads(row.episode_ids_json)) if row.episode_ids_json else []
    except ValueError:
        return []


def serialize(row: ExpectedVehicle, db) -> Dict[str, Any]:
    ids = _links(row)
    visits = []
    if ids:
        rows = db.query(Episode).filter(Episode.episode_id.in_(ids)).all()
        by_id = {r.episode_id: r for r in rows}
        for eid in ids:
            r = by_id.get(eid)
            if r is None:
                continue
            visits.append({
                "episode_id": r.episode_id,
                "zone_name": r.zone_name or r.camera_name,
                "camera_name": r.camera_name,
                "started_epoch": _epoch(r.started_at),
                "ended_epoch": _epoch(r.ended_at),
                "over_limit": bool((json.loads(r.attributes_json) if r.attributes_json else {}).get("over_limit")),
            })
    open_visits = [v for v in visits if v["ended_epoch"] is None]
    if row.departed_at:
        status = "departed"
    elif open_visits:
        status = "on_site"
    elif row.arrived_at:
        status = "arrived"
    else:
        status = "expected"
    location = (open_visits or visits)[-1] if visits else None
    return {
        "id": row.id, "date": row.date, "plate": row.plate, "transporter": row.transporter,
        "material": row.material, "purpose": row.purpose, "expected_time": row.expected_time,
        "notes": row.notes, "status": status,
        "arrived_epoch": _epoch(row.arrived_at), "departed_epoch": _epoch(row.departed_at),
        "location": location, "visits": visits, "created_by": row.created_by,
    }


def link(db, row: ExpectedVehicle, episode_id: str, user_label: str) -> Optional[Dict[str, Any]]:
    """Attach a vehicle episode to this arrival; stamp the plate on the episode."""
    ep = db.query(Episode).filter(Episode.episode_id == episode_id).first()
    if ep is None:
        return None
    ids = _links(row)
    if episode_id not in ids:
        ids.append(episode_id)
        row.episode_ids_json = json.dumps(ids)
    if row.arrived_at is None:
        row.arrived_at = ep.started_at
    row.departed_at = None
    db.commit()
    episodes.tag_episode(episode_id, {"plate": row.plate, "transporter": row.transporter, "arrival_id": row.id,
                                      "linked_by": user_label})
    return serialize(row, db)


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------

router = APIRouter(prefix="/api/arrivals", tags=["arrivals"])


def _who(user: User) -> str:
    return (getattr(user, "full_name", None) or getattr(user, "email", None) or "user")


class ArrivalBody(BaseModel):
    date: str
    plate: str
    transporter: str = ""
    material: str = ""
    purpose: str = "unloading"
    expected_time: str = ""
    notes: str = ""


class LinkBody(BaseModel):
    episode_id: str


def _clean(body: ArrivalBody) -> Dict[str, Any]:
    plate = normalise_plate(body.plate)
    if len(plate) < 4:
        raise ValueError("Enter the number plate")
    if len(body.date) != 10:
        raise ValueError("Date must be YYYY-MM-DD")
    return {
        "date": body.date, "plate": plate,
        "transporter": body.transporter.strip()[:150] or None,
        "material": body.material.strip()[:150] or None,
        "purpose": body.purpose if body.purpose in PURPOSES else "other",
        "expected_time": body.expected_time.strip()[:5] or None,
        "notes": body.notes.strip() or None,
    }


@router.get("", dependencies=[Depends(get_current_user)])
def list_arrivals(date: str):
    db = get_db_session()
    try:
        rows = (db.query(ExpectedVehicle).filter(ExpectedVehicle.date == date)
                .order_by(ExpectedVehicle.expected_time.asc().nullslast(), ExpectedVehicle.id.asc()).all())
        return JSONResponse({"ok": True, "data": [serialize(r, db) for r in rows]})
    finally:
        db.close()


@router.post("")
def create_arrival(body: ArrivalBody, user: User = Depends(get_current_user)):
    try:
        fields = _clean(body)
    except ValueError as exc:
        return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
    db = get_db_session()
    try:
        row = ExpectedVehicle(created_by=_who(user), **fields)
        db.add(row)
        db.commit()
        return JSONResponse({"ok": True, "data": serialize(row, db)})
    finally:
        db.close()


@router.put("/{arrival_id}")
def update_arrival(arrival_id: int, body: ArrivalBody, user: User = Depends(get_current_user)):
    try:
        fields = _clean(body)
    except ValueError as exc:
        return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
    db = get_db_session()
    try:
        row = db.query(ExpectedVehicle).get(arrival_id)
        if row is None:
            return JSONResponse({"ok": False, "message": "Not found"}, status_code=404)
        for k, v in fields.items():
            setattr(row, k, v)
        db.commit()
        return JSONResponse({"ok": True, "data": serialize(row, db)})
    finally:
        db.close()


@router.delete("/{arrival_id}", dependencies=[Depends(get_current_user)])
def delete_arrival(arrival_id: int):
    db = get_db_session()
    try:
        row = db.query(ExpectedVehicle).get(arrival_id)
        if row is None:
            return JSONResponse({"ok": False, "message": "Not found"}, status_code=404)
        db.delete(row)
        db.commit()
        return JSONResponse({"ok": True})
    finally:
        db.close()


@router.post("/{arrival_id}/arrived")
def mark_arrived(arrival_id: int, user: User = Depends(get_current_user)):
    db = get_db_session()
    try:
        row = db.query(ExpectedVehicle).get(arrival_id)
        if row is None:
            return JSONResponse({"ok": False, "message": "Not found"}, status_code=404)
        row.arrived_at = row.arrived_at or _utcnow()
        row.departed_at = None
        db.commit()
        return JSONResponse({"ok": True, "data": serialize(row, db)})
    finally:
        db.close()


@router.post("/{arrival_id}/departed")
def mark_departed(arrival_id: int, user: User = Depends(get_current_user)):
    db = get_db_session()
    try:
        row = db.query(ExpectedVehicle).get(arrival_id)
        if row is None:
            return JSONResponse({"ok": False, "message": "Not found"}, status_code=404)
        row.arrived_at = row.arrived_at or _utcnow()
        row.departed_at = _utcnow()
        db.commit()
        return JSONResponse({"ok": True, "data": serialize(row, db)})
    finally:
        db.close()


@router.post("/{arrival_id}/link")
def link_episode(arrival_id: int, body: LinkBody, user: User = Depends(get_current_user)):
    db = get_db_session()
    try:
        row = db.query(ExpectedVehicle).get(arrival_id)
        if row is None:
            return JSONResponse({"ok": False, "message": "Not found"}, status_code=404)
        data = link(db, row, body.episode_id, _who(user))
        if data is None:
            return JSONResponse({"ok": False, "message": "Episode not found"}, status_code=404)
        return JSONResponse({"ok": True, "data": data})
    finally:
        db.close()
