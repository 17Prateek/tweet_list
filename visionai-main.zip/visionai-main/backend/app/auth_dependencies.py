from __future__ import annotations

from fastapi import (
    Depends,
    HTTPException,
    Query,
    status,
)
from fastapi.security import (
    HTTPAuthorizationCredentials,
    HTTPBearer,
)
from jose import JWTError, jwt
from sqlalchemy.orm import Session

from app.auth_service import (
    JWT_SECRET_KEY,
    JWT_ALGORITHM,
)

from app.database import (
    User,
    get_db,
)


# =========================================================
# Bearer token reader
# =========================================================

# auto_error=False is intentional.
#
# Isse missing Authorization header par hum apna
# clean 401 response return kar sakte hain.
bearer_scheme = HTTPBearer(
    auto_error=False
)


# =========================================================
# Common 401 error
# =========================================================

def authentication_error(
    message: str = "Authentication required",
) -> HTTPException:
    """
    Standard authentication error.

    Used for:
      - missing token
      - malformed token
      - expired token
      - wrong token purpose
      - deleted/non-existing user
    """

    return HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail=message,
        headers={
            "WWW-Authenticate": "Bearer",
        },
    )


# =========================================================
# Current authenticated user
# =========================================================

def user_from_access_token(token: str, db: Session) -> User:
    """
    The one place that turns an access JWT into the current database User.
    Used by the Authorization-header path and by the ?token= path for the
    live stream (EventSource cannot send headers).
    """
    try:
        payload = jwt.decode(token, JWT_SECRET_KEY, algorithms=[JWT_ALGORITHM])
    except JWTError:
        raise authentication_error("Invalid or expired access token")

    purpose = str(payload.get("purpose") or "").strip().lower()
    if purpose != "access":
        raise authentication_error("Invalid access token")

    email = str(payload.get("sub") or payload.get("email") or "").strip().lower()
    if not email:
        raise authentication_error("Invalid access token")

    user = db.query(User).filter(User.email == email).first()
    if user is None:
        raise authentication_error("User account no longer exists")

    if not bool(user.is_active):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="User account is inactive")

    role = str(user.role or "").strip().lower()
    if role not in {"user", "super_admin"}:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="User role is not authorized")

    return user


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(
        bearer_scheme
    ),
    db: Session = Depends(get_db),
) -> User:
    """
    Validate login access JWT and return the CURRENT
    user from PostgreSQL.

    Security flow:

        Authorization header
                ↓
        Bearer token available?
                ↓
        JWT signature valid?
                ↓
        Token expired?
                ↓
        purpose == "access"?
                ↓
        email/sub available?
                ↓
        user exists in database?
                ↓
        user active?
                ↓
        return database User
    """

    # -----------------------------------------------------
    # 1. Authorization header missing
    # -----------------------------------------------------

    if credentials is None:
        raise authentication_error(
            "Authentication required"
        )

    # -----------------------------------------------------
    # 2. Authentication scheme must be Bearer
    # -----------------------------------------------------

    scheme = str(
        credentials.scheme or ""
    ).strip().lower()

    if scheme != "bearer":
        raise authentication_error(
            "Invalid authentication scheme"
        )

    # -----------------------------------------------------
    # 3. Extract token
    # -----------------------------------------------------

    token = str(
        credentials.credentials or ""
    ).strip()

    if not token:
        raise authentication_error(
            "Access token is missing"
        )

    return user_from_access_token(token, db)


def get_current_user_from_query(
    token: str = Query(..., description="Access token, for clients that cannot send headers (EventSource)"),
    db: Session = Depends(get_db),
) -> User:
    if not token:
        raise authentication_error("Access token is missing")
    return user_from_access_token(token, db)


# =========================================================
# Super Admin authorization
# =========================================================

def require_super_admin(
    current_user: User = Depends(
        get_current_user
    ),
) -> User:
    """
    Allow only current database users whose role is:

        super_admin

    Normal authenticated users receive HTTP 403.
    """

    role = str(
        current_user.role or ""
    ).strip().lower()

    if role != "super_admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Super Admin access required",
        )

    return current_user