from __future__ import annotations

import os
import secrets

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

from dotenv import load_dotenv
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from app.database import LoginOTP, User
from app.email_service import (
    send_forgot_password_otp_email_service,
    send_login_otp_email_service,
)
from app.user_management_service import (
    hash_password,
    verify_password,
)


# =========================================================
# Environment
# =========================================================

load_dotenv()


JWT_SECRET_KEY = os.getenv(
    "JWT_SECRET_KEY",
    "",
).strip()

JWT_ALGORITHM = os.getenv(
    "JWT_ALGORITHM",
    "HS256",
).strip()

JWT_EXPIRE_MINUTES = max(
    1,
    int(
        os.getenv(
            "JWT_EXPIRE_MINUTES",
            "60",
        )
    ),
)

LOGIN_OTP_EXPIRE_MINUTES = max(
    1,
    int(
        os.getenv(
            "LOGIN_OTP_EXPIRE_MINUTES",
            "5",
        )
    ),
)

PASSWORD_RESET_TOKEN_EXPIRE_MINUTES = max(
    1,
    int(
        os.getenv(
            "PASSWORD_RESET_TOKEN_EXPIRE_MINUTES",
            "10",
        )
    ),
)


if not JWT_SECRET_KEY:
    raise RuntimeError(
        "JWT_SECRET_KEY not found in .env file"
    )


# =========================================================
# Constants
# =========================================================

OTP_PURPOSE_LOGIN = "login"
OTP_PURPOSE_FORGOT_PASSWORD = "forgot_password"


# =========================================================
# OTP password context
# =========================================================

otp_context = CryptContext(
    schemes=["pbkdf2_sha256"],
    deprecated="auto",
)


# =========================================================
# Common helpers
# =========================================================

def normalize_email(email: str) -> str:
    return str(
        email or ""
    ).strip().lower()


def utc_now() -> datetime:
    return datetime.now(
        timezone.utc
    )


def normalize_database_datetime(
    value: datetime,
) -> datetime:
    """
    PostgreSQL normally returns timezone-aware datetime values.

    This fallback keeps development databases safe if a naive datetime
    is returned.
    """

    if value.tzinfo is None:
        return value.replace(
            tzinfo=timezone.utc
        )

    return value


def generate_login_otp() -> str:
    """
    Generate a cryptographically secure 6-digit OTP.
    """

    return str(
        secrets.randbelow(900000)
        + 100000
    )


def hash_login_otp(
    otp: str,
) -> str:
    return otp_context.hash(
        str(otp)
    )


def verify_login_otp_hash(
    otp: str,
    otp_hash: str,
) -> bool:
    try:
        return otp_context.verify(
            str(otp),
            otp_hash,
        )
    except Exception:
        return False


def validate_otp_value(
    otp: str,
) -> Optional[str]:
    otp_value = str(
        otp or ""
    ).strip()

    if (
        len(otp_value) != 6
        or not otp_value.isdigit()
    ):
        return (
            "Please enter a valid 6-digit OTP"
        )

    return None


# =========================================================
# Password validation
# =========================================================

def validate_new_password(
    password: str,
) -> Optional[str]:
    value = str(
        password or ""
    )

    if len(value) < 8:
        return (
            "Password must be at least 8 characters."
        )

    if not any(
        char.isupper()
        for char in value
    ):
        return (
            "Password must contain at least "
            "one uppercase letter."
        )

    if not any(
        char.islower()
        for char in value
    ):
        return (
            "Password must contain at least "
            "one lowercase letter."
        )

    if not any(
        char.isdigit()
        for char in value
    ):
        return (
            "Password must contain at least one number."
        )

    special_characters = (
        "!@#$%^&*()_-+=[]{};:'\",.<>/?\\|`~"
    )

    if not any(
        char in special_characters
        for char in value
    ):
        return (
            "Password must contain at least "
            "one special character."
        )

    return None


# =========================================================
# User serialization for authentication
# =========================================================

def serialize_authenticated_user(
    user: User,
) -> Dict[str, Any]:
    return {
        "email": user.email,
        "employeeId": user.employee_id,
        "fullName": user.full_name,
        "mobile": user.mobile,
        "department": user.department,
        "role": user.role,
        "isActive": bool(
            user.is_active
        ),
        "lastLogin": (
            user.last_login.isoformat()
            if user.last_login
            else None
        ),
    }


# =========================================================
# JWT - normal access token
# =========================================================

def create_access_token(
    user: User,
) -> str:
    now = utc_now()

    expires_at = (
        now
        + timedelta(
            minutes=JWT_EXPIRE_MINUTES
        )
    )

    payload = {
        "sub": user.email,
        "email": user.email,
        "role": user.role,
        "name": user.full_name,
        "purpose": "access",
        "iat": now,
        "exp": expires_at,
    }

    return jwt.encode(
        payload,
        JWT_SECRET_KEY,
        algorithm=JWT_ALGORITHM,
    )


# =========================================================
# JWT - password reset token
# =========================================================

def create_password_reset_token(
    *,
    user: User,
    otp_record: LoginOTP,
) -> str:
    now = utc_now()

    expires_at = (
        now
        + timedelta(
            minutes=PASSWORD_RESET_TOKEN_EXPIRE_MINUTES
        )
    )

    payload = {
        "sub": user.email,
        "email": user.email,
        "purpose": "password_reset",
        "otp_id": otp_record.id,
        "jti": secrets.token_urlsafe(16),
        "iat": now,
        "exp": expires_at,
    }

    return jwt.encode(
        payload,
        JWT_SECRET_KEY,
        algorithm=JWT_ALGORITHM,
    )


# =========================================================
# Find user
# =========================================================

def get_auth_user_by_email(
    db: Session,
    email: str,
) -> Optional[User]:
    normalized_email = normalize_email(
        email
    )

    if not normalized_email:
        return None

    return (
        db.query(User)
        .filter(
            User.email
            == normalized_email
        )
        .first()
    )


# =========================================================
# OTP database helpers
# =========================================================

def invalidate_previous_otps(
    db: Session,
    *,
    email: str,
    purpose: str,
) -> None:
    """
    Mark unused OTPs for a specific purpose as used.

    Login OTP and forgot-password OTP are kept separate.
    """

    normalized_email = normalize_email(
        email
    )

    (
        db.query(LoginOTP)
        .filter(
            LoginOTP.email
            == normalized_email,
            LoginOTP.purpose
            == purpose,
            LoginOTP.is_used.is_(False),
        )
        .update(
            {
                LoginOTP.is_used: True
            },
            synchronize_session=False,
        )
    )


def delete_previous_forgot_password_otps(
    db: Session,
    *,
    email: str,
) -> None:
    """
    Remove all previous forgot-password OTP records.

    This also invalidates any previously-issued reset token because a
    reset token is tied to its OTP record id.
    """

    normalized_email = normalize_email(
        email
    )

    (
        db.query(LoginOTP)
        .filter(
            LoginOTP.email
            == normalized_email,
            LoginOTP.purpose
            == OTP_PURPOSE_FORGOT_PASSWORD,
        )
        .delete(
            synchronize_session=False
        )
    )


def get_latest_unused_otp(
    db: Session,
    *,
    email: str,
    purpose: str,
) -> Optional[LoginOTP]:
    normalized_email = normalize_email(
        email
    )

    return (
        db.query(LoginOTP)
        .filter(
            LoginOTP.email
            == normalized_email,
            LoginOTP.purpose
            == purpose,
            LoginOTP.is_used.is_(
                False
            ),
        )
        .order_by(
            LoginOTP.created_at.desc(),
            LoginOTP.id.desc(),
        )
        .first()
    )


# =========================================================
# LOGIN - VERIFY EMAIL/PASSWORD + SEND OTP
# =========================================================

def request_login_otp_service(
    db: Session,
    *,
    email: str,
    password: str,
) -> Dict[str, Any]:
    normalized_email = normalize_email(
        email
    )

    password_value = str(
        password or ""
    )

    if not normalized_email:
        return {
            "success": False,
            "status_code": 400,
            "message": (
                "Email address is required"
            ),
        }

    if not password_value:
        return {
            "success": False,
            "status_code": 400,
            "message": (
                "Password is required"
            ),
        }

    user = get_auth_user_by_email(
        db,
        normalized_email,
    )

    # Same response for wrong email / wrong password.
    if not user:
        return {
            "success": False,
            "status_code": 401,
            "message": (
                "Invalid email or password"
            ),
        }

    if not user.is_active:
        return {
            "success": False,
            "status_code": 403,
            "message": (
                "Your account is inactive. "
                "Please contact administrator."
            ),
        }

    try:
        password_valid = verify_password(
            password_value,
            user.password_hash,
        )
    except Exception:
        password_valid = False

    if not password_valid:
        return {
            "success": False,
            "status_code": 401,
            "message": (
                "Invalid email or password"
            ),
        }

    otp = generate_login_otp()

    expires_at = (
        utc_now()
        + timedelta(
            minutes=LOGIN_OTP_EXPIRE_MINUTES
        )
    )

    try:
        # Only previous LOGIN OTPs are invalidated.
        invalidate_previous_otps(
            db,
            email=normalized_email,
            purpose=OTP_PURPOSE_LOGIN,
        )

        login_otp = LoginOTP(
            email=normalized_email,
            purpose=OTP_PURPOSE_LOGIN,
            otp_hash=hash_login_otp(
                otp
            ),
            expires_at=expires_at,
            is_used=False,
        )

        db.add(
            login_otp
        )

        # Create row inside transaction before sending email.
        db.flush()

        email_result = (
            send_login_otp_email_service(
                email=user.email,
                full_name=user.full_name,
                otp=otp,
                expiry_minutes=(
                    LOGIN_OTP_EXPIRE_MINUTES
                ),
            )
        )

        if not email_result.get(
            "success"
        ):
            db.rollback()

            return {
                "success": False,
                "status_code": (
                    email_result.get(
                        "status_code",
                        500,
                    )
                ),
                "message": (
                    email_result.get(
                        "message"
                    )
                    or
                    "Could not send login OTP"
                ),
            }

        db.commit()

        return {
            "success": True,
            "status_code": 200,
            "message": (
                "OTP sent successfully "
                "to your registered email address"
            ),
            "email": user.email,
            "expiresInMinutes": (
                LOGIN_OTP_EXPIRE_MINUTES
            ),
        }

    except Exception as error:
        db.rollback()

        print(
            "[ERROR] Login OTP request failed:",
            error,
        )

        return {
            "success": False,
            "status_code": 500,
            "message": (
                "Could not process login request"
            ),
        }


# =========================================================
# LOGIN OTP VERIFY
# =========================================================

def verify_login_otp_service(
    db: Session,
    *,
    email: str,
    otp: str,
) -> Dict[str, Any]:
    normalized_email = normalize_email(
        email
    )

    otp_value = str(
        otp or ""
    ).strip()

    if not normalized_email:
        return {
            "success": False,
            "status_code": 400,
            "message": (
                "Email address is required"
            ),
        }

    otp_error = validate_otp_value(
        otp_value
    )

    if otp_error:
        return {
            "success": False,
            "status_code": 400,
            "message": otp_error,
        }

    user = get_auth_user_by_email(
        db,
        normalized_email,
    )

    if not user:
        return {
            "success": False,
            "status_code": 401,
            "message": (
                "Invalid login request"
            ),
        }

    if not user.is_active:
        return {
            "success": False,
            "status_code": 403,
            "message": (
                "Your account is inactive. "
                "Please contact administrator."
            ),
        }

    otp_record = get_latest_unused_otp(
        db,
        email=normalized_email,
        purpose=OTP_PURPOSE_LOGIN,
    )

    if not otp_record:
        return {
            "success": False,
            "status_code": 400,
            "message": (
                "OTP not found or already used. "
                "Please request a new OTP."
            ),
        }

    otp_expires_at = (
        normalize_database_datetime(
            otp_record.expires_at
        )
    )

    if utc_now() > otp_expires_at:
        otp_record.is_used = True

        try:
            db.commit()
        except Exception:
            db.rollback()

        return {
            "success": False,
            "status_code": 400,
            "message": (
                "OTP has expired. "
                "Please request a new OTP."
            ),
        }

    otp_valid = verify_login_otp_hash(
        otp_value,
        otp_record.otp_hash,
    )

    if not otp_valid:
        return {
            "success": False,
            "status_code": 400,
            "message": (
                "Invalid OTP. "
                "Please try again."
            ),
        }

    try:
        # One-time use.
        otp_record.is_used = True

        user.last_login = utc_now()

        db.commit()
        db.refresh(
            user
        )

        access_token = create_access_token(
            user
        )

        return {
            "success": True,
            "status_code": 200,
            "message": (
                "Login successful"
            ),
            "accessToken": (
                access_token
            ),
            "tokenType": "bearer",
            "expiresInMinutes": (
                JWT_EXPIRE_MINUTES
            ),
            "user": (
                serialize_authenticated_user(
                    user
                )
            ),
        }

    except Exception as error:
        db.rollback()

        print(
            "[ERROR] Login OTP verification failed:",
            error,
        )

        return {
            "success": False,
            "status_code": 500,
            "message": (
                "Could not complete login"
            ),
        }


# =========================================================
# FORGOT PASSWORD - SEND / RESEND OTP
# =========================================================

def request_forgot_password_otp_service(
    db: Session,
    *,
    email: str,
) -> Dict[str, Any]:
    """
    Used for both:
      - first Forgot Password OTP
      - Resend Forgot Password OTP

    A resend automatically invalidates all previous forgot-password
    OTP/reset sessions for the same email.
    """

    normalized_email = normalize_email(
        email
    )

    if not normalized_email:
        return {
            "success": False,
            "status_code": 400,
            "message": (
                "Email address is required"
            ),
        }

    user = get_auth_user_by_email(
        db,
        normalized_email,
    )

    if not user:
        return {
            "success": False,
            "status_code": 404,
            "message": (
                "No account found with this email address"
            ),
        }

    if not user.is_active:
        return {
            "success": False,
            "status_code": 403,
            "message": (
                "Your account is inactive. "
                "Please contact administrator."
            ),
        }

    otp = generate_login_otp()

    expires_at = (
        utc_now()
        + timedelta(
            minutes=LOGIN_OTP_EXPIRE_MINUTES
        )
    )

    try:
        # Delete all previous forgot-password OTP records.
        # This makes resend invalidate old OTPs and old reset tokens.
        delete_previous_forgot_password_otps(
            db,
            email=normalized_email,
        )

        otp_record = LoginOTP(
            email=normalized_email,
            purpose=(
                OTP_PURPOSE_FORGOT_PASSWORD
            ),
            otp_hash=hash_login_otp(
                otp
            ),
            expires_at=expires_at,
            is_used=False,
        )

        db.add(
            otp_record
        )

        db.flush()

        email_result = (
            send_forgot_password_otp_email_service(
                email=user.email,
                full_name=user.full_name,
                otp=otp,
                expiry_minutes=(
                    LOGIN_OTP_EXPIRE_MINUTES
                ),
            )
        )

        if not email_result.get(
            "success"
        ):
            db.rollback()

            return {
                "success": False,
                "status_code": (
                    email_result.get(
                        "status_code",
                        500,
                    )
                ),
                "message": (
                    email_result.get(
                        "message"
                    )
                    or
                    "Could not send password reset OTP"
                ),
            }

        db.commit()

        return {
            "success": True,
            "status_code": 200,
            "message": (
                "Password reset OTP sent successfully "
                "to your registered email address"
            ),
            "email": user.email,
            "expiresInMinutes": (
                LOGIN_OTP_EXPIRE_MINUTES
            ),
        }

    except Exception as error:
        db.rollback()

        print(
            "[ERROR] Forgot password OTP request failed:",
            error,
        )

        return {
            "success": False,
            "status_code": 500,
            "message": (
                "Could not process password reset request"
            ),
        }


# =========================================================
# FORGOT PASSWORD - VERIFY OTP
# =========================================================

def verify_forgot_password_otp_service(
    db: Session,
    *,
    email: str,
    otp: str,
) -> Dict[str, Any]:
    normalized_email = normalize_email(
        email
    )

    otp_value = str(
        otp or ""
    ).strip()

    if not normalized_email:
        return {
            "success": False,
            "status_code": 400,
            "message": (
                "Email address is required"
            ),
        }

    otp_error = validate_otp_value(
        otp_value
    )

    if otp_error:
        return {
            "success": False,
            "status_code": 400,
            "message": otp_error,
        }

    user = get_auth_user_by_email(
        db,
        normalized_email,
    )

    if not user:
        return {
            "success": False,
            "status_code": 404,
            "message": (
                "User not found"
            ),
        }

    if not user.is_active:
        return {
            "success": False,
            "status_code": 403,
            "message": (
                "Your account is inactive. "
                "Please contact administrator."
            ),
        }

    otp_record = get_latest_unused_otp(
        db,
        email=normalized_email,
        purpose=(
            OTP_PURPOSE_FORGOT_PASSWORD
        ),
    )

    if not otp_record:
        return {
            "success": False,
            "status_code": 400,
            "message": (
                "OTP not found or already used. "
                "Please request a new OTP."
            ),
        }

    otp_expires_at = (
        normalize_database_datetime(
            otp_record.expires_at
        )
    )

    if utc_now() > otp_expires_at:
        otp_record.is_used = True

        try:
            db.commit()
        except Exception:
            db.rollback()

        return {
            "success": False,
            "status_code": 400,
            "message": (
                "OTP has expired. "
                "Please request a new OTP."
            ),
        }

    otp_valid = verify_login_otp_hash(
        otp_value,
        otp_record.otp_hash,
    )

    if not otp_valid:
        return {
            "success": False,
            "status_code": 400,
            "message": (
                "Invalid OTP. "
                "Please try again."
            ),
        }

    try:
        # OTP becomes unusable immediately after successful verification.
        otp_record.is_used = True

        db.commit()
        db.refresh(
            otp_record
        )

        reset_token = (
            create_password_reset_token(
                user=user,
                otp_record=otp_record,
            )
        )

        return {
            "success": True,
            "status_code": 200,
            "message": (
                "OTP verified successfully"
            ),
            "resetToken": (
                reset_token
            ),
            "expiresInMinutes": (
                PASSWORD_RESET_TOKEN_EXPIRE_MINUTES
            ),
        }

    except Exception as error:
        db.rollback()

        print(
            "[ERROR] Forgot password OTP verification failed:",
            error,
        )

        return {
            "success": False,
            "status_code": 500,
            "message": (
                "Could not verify password reset OTP"
            ),
        }


# =========================================================
# FORGOT PASSWORD - RESET PASSWORD
# =========================================================

def reset_forgot_password_service(
    db: Session,
    *,
    reset_token: str,
    new_password: str,
) -> Dict[str, Any]:
    token_value = str(
        reset_token or ""
    ).strip()

    password_value = str(
        new_password or ""
    )

    if not token_value:
        return {
            "success": False,
            "status_code": 400,
            "message": (
                "Password reset token is required"
            ),
        }

    password_error = validate_new_password(
        password_value
    )

    if password_error:
        return {
            "success": False,
            "status_code": 400,
            "message": password_error,
        }

    try:
        payload = jwt.decode(
            token_value,
            JWT_SECRET_KEY,
            algorithms=[
                JWT_ALGORITHM
            ],
        )

    except JWTError:
        return {
            "success": False,
            "status_code": 401,
            "message": (
                "Password reset session is invalid "
                "or has expired"
            ),
        }

    if (
        payload.get("purpose")
        != "password_reset"
    ):
        return {
            "success": False,
            "status_code": 401,
            "message": (
                "Invalid password reset token"
            ),
        }

    normalized_email = normalize_email(
        payload.get("sub")
    )

    otp_id = payload.get(
        "otp_id"
    )

    if (
        not normalized_email
        or not otp_id
    ):
        return {
            "success": False,
            "status_code": 401,
            "message": (
                "Invalid password reset token"
            ),
        }

    user = get_auth_user_by_email(
        db,
        normalized_email,
    )

    if not user:
        return {
            "success": False,
            "status_code": 404,
            "message": (
                "User not found"
            ),
        }

    if not user.is_active:
        return {
            "success": False,
            "status_code": 403,
            "message": (
                "Your account is inactive. "
                "Please contact administrator."
            ),
        }

    verified_otp = (
        db.query(LoginOTP)
        .filter(
            LoginOTP.id == otp_id,
            LoginOTP.email
            == normalized_email,
            LoginOTP.purpose
            == OTP_PURPOSE_FORGOT_PASSWORD,
            LoginOTP.is_used.is_(
                True
            ),
        )
        .first()
    )

    if not verified_otp:
        return {
            "success": False,
            "status_code": 401,
            "message": (
                "Password reset session is no longer valid"
            ),
        }

    # Prevent changing to the same password.
    try:
        same_as_old = verify_password(
            password_value,
            user.password_hash,
        )
    except Exception:
        same_as_old = False

    if same_as_old:
        return {
            "success": False,
            "status_code": 400,
            "message": (
                "New password must be different "
                "from your current password."
            ),
        }

    try:
        user.password_hash = hash_password(
            password_value
        )

        # Delete every password-reset OTP/session for this email.
        (
            db.query(LoginOTP)
            .filter(
                LoginOTP.email
                == normalized_email,
                LoginOTP.purpose
                == OTP_PURPOSE_FORGOT_PASSWORD,
            )
            .delete(
                synchronize_session=False
            )
        )

        # Invalidate any pending login OTP created before password reset.
        (
            db.query(LoginOTP)
            .filter(
                LoginOTP.email
                == normalized_email,
                LoginOTP.purpose
                == OTP_PURPOSE_LOGIN,
                LoginOTP.is_used.is_(
                    False
                ),
            )
            .update(
                {
                    LoginOTP.is_used: True
                },
                synchronize_session=False,
            )
        )

        db.commit()

        return {
            "success": True,
            "status_code": 200,
            "message": (
                "Password updated successfully. "
                "Please login with your new password."
            ),
        }

    except Exception as error:
        db.rollback()

        print(
            "[ERROR] Password reset failed:",
            error,
        )

        return {
            "success": False,
            "status_code": 500,
            "message": (
                "Could not update password"
            ),
        }
