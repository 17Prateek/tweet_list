import json
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.database import Camera, CameraCurrentIssue, get_db_session


def now_utc():
    return datetime.now(timezone.utc)


def format_time(value):
    if not value:
        return "-"

    return value.strftime("%d %b %Y %I:%M %p")


def get_issue_content(issue_type: str, camera=None, extra: dict | None = None):
    extra = extra or {}
    camera_name = getattr(camera, "camera_name", "Camera")

    issue_map = {
        "camera_connecting": {
            "severity": "info",
            "title": "Camera Connecting",
            "description": f"{camera_name} is trying to connect.",
            "recommendation": "Wait for connection. If it takes too long, check camera power, network, and source configuration.",
        },
        "camera_offline": {
            "severity": "critical",
            "title": "Camera Offline",
            "description": f"{camera_name} is not sending video frames.",
            "recommendation": "Check camera power, network cable/WiFi, RTSP URL, username/password, and camera availability.",
        },
        "camera_reconnected": {
            "severity": "info",
            "title": "Camera Reconnected",
            "description": f"{camera_name} is online again.",
            "recommendation": "No action required.",
        },
        "recording_started": {
            "severity": "info",
            "title": "Recording Started",
            "description": f"Recording started for {camera_name}.",
            "recommendation": "No action required.",
        },
        "recording_stopped": {
            "severity": "info",
            "title": "Recording Stopped",
            "description": f"Recording stopped for {camera_name}.",
            "recommendation": "No action required.",
        },
        "recording_failed": {
            "severity": "critical",
            "title": "Recording Failed",
            "description": extra.get("error") or f"Recording failed for {camera_name}.",
            "recommendation": "Check camera stream, recording folder permission, disk space, and VideoWriter codec support.",
        },
        "low_fps": {
            "severity": "warning",
            "title": "Low FPS",
            "description": f"{camera_name} stream FPS is below expected level.",
            "recommendation": "Check network bandwidth, camera resolution, CPU/GPU load, and detection model performance.",
        },
        "stream_unstable": {
            "severity": "warning",
            "title": "Stream Unstable",
            "description": f"{camera_name} stream is unstable or frames are dropping.",
            "recommendation": "Check network stability, RTSP transport, camera load, and switch/router connection.",
        },
        "detection_stopped": {
            "severity": "critical",
            "title": "Detection Service Stopped",
            "description": extra.get("error") or f"Detection service stopped for {camera_name}.",
            "recommendation": "Restart detection stream and check backend logs/model errors.",
        },
    }

    return issue_map.get(
        issue_type,
        {
            "severity": "info",
            "title": "Camera Issue",
            "description": f"Issue detected for {camera_name}.",
            "recommendation": "Check camera details and backend logs.",
        },
    )


def upsert_camera_issue(
    camera_id: int,
    issue_type: str,
    extra: dict | None = None,
    status: str = "open",
):
    db = get_db_session()

    try:
        camera = (
            db.query(Camera)
            .filter(Camera.id == camera_id, Camera.is_active == True)
            .first()
        )

        if not camera:
            return

        content = get_issue_content(issue_type, camera, extra)

        issue = (
            db.query(CameraCurrentIssue)
            .filter(CameraCurrentIssue.camera_id == camera_id)
            .first()
        )

        if not issue:
            issue = CameraCurrentIssue(camera_id=camera_id)
            db.add(issue)

        issue.issue_type = issue_type
        issue.severity = content["severity"]
        issue.title = content["title"]
        issue.description = content["description"]
        issue.recommendation = content["recommendation"]
        issue.status = status
        issue.details = json.dumps(extra or {})
        issue.updated_at = now_utc()

        db.commit()

    finally:
        db.close()


def clear_camera_issue(camera_id: int):
    db = get_db_session()

    try:
        issue = (
            db.query(CameraCurrentIssue)
            .filter(CameraCurrentIssue.camera_id == camera_id)
            .first()
        )

        if issue:
            db.delete(issue)
            db.commit()

    finally:
        db.close()


def serialize_issue(issue: CameraCurrentIssue):
    camera = issue.camera

    details = {}

    if issue.details:
        try:
            details = json.loads(issue.details)
        except Exception:
            details = {}

    return {
        "id": issue.id,
        "camera_id": issue.camera_id,
        "camera_name": camera.camera_name if camera else "-",
        "group": camera.group.name if camera and camera.group else "-",
        "location": camera.location if camera else "-",
        "source_type": camera.source_type if camera else "-",
        "status": camera.status if camera else "-",
        "recording_status": "REC" if camera and camera.is_recording else "OFF",
        "last_seen": format_time(camera.last_seen_at) if camera else "-",
        "issue_type": issue.issue_type,
        "severity": issue.severity,
        "title": issue.title,
        "description": issue.description,
        "recommendation": issue.recommendation,
        "issue_status": issue.status,
        "details": details,
        "first_detected_at": format_time(issue.first_detected_at),
        "updated_at": format_time(issue.updated_at),
    }


def get_camera_issues_service(db: Session):
    issues = (
        db.query(CameraCurrentIssue)
        .join(Camera, Camera.id == CameraCurrentIssue.camera_id)
        .filter(Camera.is_active == True)
        .filter(CameraCurrentIssue.status == "open")
        .order_by(CameraCurrentIssue.updated_at.desc())
        .all()
    )

    return [serialize_issue(issue) for issue in issues]


def get_camera_issue_service(db: Session, camera_id: int):
    issue = (
        db.query(CameraCurrentIssue)
        .join(Camera, Camera.id == CameraCurrentIssue.camera_id)
        .filter(Camera.is_active == True)
        .filter(CameraCurrentIssue.camera_id == camera_id)
        .first()
    )

    if not issue:
        return None

    return serialize_issue(issue)