import os
import time
import json
import shutil
import select
import subprocess
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from urllib.parse import quote, unquote

from fastapi import HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.database import Camera, CameraGroup, get_db_session
from app.camera_issue_service import upsert_camera_issue, clear_camera_issue


# ---------------------------------------------------------------------------
# OpenCV / RTSP setup
# ---------------------------------------------------------------------------
# Keep OpenCV's own FFmpeg configuration simple.
# IMPORTANT: this must be set BEFORE importing cv2.
# Windows/local keeps using OpenCV by default, while Linux/VPS can use the
# system FFmpeg reader below.
os.environ.setdefault("OPENCV_FFMPEG_CAPTURE_OPTIONS", "rtsp_transport;tcp")

import cv2
import numpy as np

# Prevent OpenCV from creating a large native worker pool. This is especially
# important on cPanel/VPS accounts with a low NPROC/task limit.
try:
    cv2.setNumThreads(int(os.getenv("OPENCV_NUM_THREADS", "1")))
except Exception:
    cv2.setNumThreads(1)


STREAM_FRAME_WIDTH = int(os.getenv("VISIONAI_STREAM_WIDTH", "640"))
JPEG_QUALITY = int(os.getenv("VISIONAI_JPEG_QUALITY", "70"))

CAMERA_RECONNECT_MIN_SEC = float(os.getenv("VISIONAI_CAMERA_RECONNECT_MIN_SEC", "3.0"))
CAMERA_RECONNECT_MAX_SEC = float(os.getenv("VISIONAI_CAMERA_RECONNECT_MAX_SEC", "30.0"))
CAMERA_READ_FAILURE_LIMIT = int(os.getenv("VISIONAI_CAMERA_READ_FAILURE_LIMIT", "15"))
CAMERA_FRAME_WAIT_TIMEOUT_SEC = float(os.getenv("VISIONAI_CAMERA_FRAME_WAIT_TIMEOUT_SEC", "0.5"))

# A camera worker holds an RTSP connection open and decodes every frame, which
# costs bandwidth on the camera's network and CPU here. Stop a worker once
# nothing has asked it for a frame for this long. Anything that needs the
# camera - a browser watching the stream, detection, recording, face
# enrolment - counts as demand, so a monitored camera never goes idle.
# Set to 0 to keep every worker running forever (the old behaviour).
CAMERA_IDLE_STOP_SEC = float(os.getenv("VISIONAI_CAMERA_IDLE_STOP_SEC", "120"))
CAMERA_IDLE_CHECK_SEC = float(os.getenv("VISIONAI_CAMERA_IDLE_CHECK_SEC", "15"))

# ---------------------------------------------------------------------------
# Pushed frames
#
# A capture agent on the camera's own network can POST single frames to
# /api/ingest/frame/{camera_id} instead of this server pulling continuous video
# across the internet. Detection reads those frames first and only falls back
# to opening the RTSP stream itself when none have arrived recently.
#
# Live viewing is unaffected - opening a tile still streams real video.
# ---------------------------------------------------------------------------

# A pushed frame older than this is treated as missing. With the agent sending
# every 2s, 10s means "the agent has clearly stopped".
PUSHED_FRAME_MAX_AGE_SEC = float(os.getenv("VISIONAI_PUSHED_FRAME_MAX_AGE_SEC", "10"))

# When no pushed frame is fresh, pull RTSP ourselves so monitoring never goes
# blind. Set to 0 to insist on pushed frames only.
INGEST_FALLBACK_TO_RTSP = os.getenv("VISIONAI_INGEST_FALLBACK_TO_RTSP", "1").strip() not in ("0", "false", "no")

# Refuse absurd uploads. A 1080p JPEG at high quality is well under 1 MB.
INGEST_MAX_BYTES = int(os.getenv("VISIONAI_INGEST_MAX_BYTES", str(8 * 1024 * 1024)))

# Optional shared secret. If set, the agent must send it as X-Ingest-Token.
INGEST_TOKEN = os.getenv("VISIONAI_INGEST_TOKEN", "").strip()

_pushed_frames = {}
_pushed_frames_lock = threading.RLock()
_pushed_sequence = 0


def store_pushed_frame(camera_id, frame):
    """Keep the newest frame the capture agent sent for this camera."""
    global _pushed_sequence

    camera_id = int(camera_id)

    with _pushed_frames_lock:
        _pushed_sequence += 1
        _pushed_frames[camera_id] = {
            "frame": frame,
            "received_at": time.monotonic(),
            "received_wall": datetime.now(timezone.utc),
            "sequence": _pushed_sequence,
            "shape": tuple(frame.shape[:2]),
        }
        return _pushed_sequence


def get_pushed_frame(camera_id, max_age_sec=None):
    """Latest pushed frame for a camera, or None if there isn't a fresh one."""
    if max_age_sec is None:
        max_age_sec = PUSHED_FRAME_MAX_AGE_SEC

    with _pushed_frames_lock:
        entry = _pushed_frames.get(int(camera_id))

        if entry is None:
            return None

        if time.monotonic() - entry["received_at"] > max_age_sec:
            return None

        return entry["frame"].copy()


def decode_pushed_jpeg(body):
    """
    Turn a raw JPEG body into a BGR frame, or None if it is not a valid image.

    Kept here so main.py never needs to import OpenCV or NumPy itself.
    """
    if not body:
        return None

    try:
        array = np.frombuffer(body, dtype=np.uint8)
        frame = cv2.imdecode(array, cv2.IMREAD_COLOR)
    except Exception:
        return None

    if frame is None or frame.size == 0:
        return None

    return frame


def get_ingest_status():
    """Per-camera view of what the agent has delivered, for /api/ingest/status."""
    now = time.monotonic()

    with _pushed_frames_lock:
        cameras = []

        for camera_id, entry in sorted(_pushed_frames.items()):
            age = now - entry["received_at"]
            height, width = entry["shape"]
            cameras.append(
                {
                    "camera_id": camera_id,
                    "age_sec": round(age, 1),
                    "fresh": age <= PUSHED_FRAME_MAX_AGE_SEC,
                    "width": int(width),
                    "height": int(height),
                    "last_received": entry["received_wall"].isoformat(),
                    "sequence": entry["sequence"],
                }
            )

    return {
        "max_age_sec": PUSHED_FRAME_MAX_AGE_SEC,
        "fallback_to_rtsp": INGEST_FALLBACK_TO_RTSP,
        "token_required": bool(INGEST_TOKEN),
        "cameras": cameras,
        "fresh_count": sum(1 for c in cameras if c["fresh"]),
    }

RTSP_OPEN_TIMEOUT_MSEC = int(os.getenv("VISIONAI_RTSP_OPEN_TIMEOUT_MSEC", "5000"))
RTSP_READ_TIMEOUT_MSEC = int(os.getenv("VISIONAI_RTSP_READ_TIMEOUT_MSEC", "5000"))

# System FFmpeg reader settings for Linux/VPS.
SYSTEM_FFMPEG_PROBE_TIMEOUT_SEC = float(os.getenv("VISIONAI_FFPROBE_TIMEOUT_SEC", "8"))
SYSTEM_FFMPEG_FRAME_TIMEOUT_SEC = float(os.getenv("VISIONAI_FFMPEG_FRAME_TIMEOUT_SEC", "5"))
SYSTEM_FFMPEG_THREADS = max(1, int(os.getenv("VISIONAI_FFMPEG_THREADS", "1")))

# On Linux/VPS, reducing the decoded RTSP stream before it enters Python avoids
# huge raw BGR pipes (for example 1080p -> ~6 MB per frame) and greatly reduces
# latency/resource usage. This does NOT affect the Windows/OpenCV path. Set 0
# to keep the camera's original resolution.
SYSTEM_FFMPEG_DECODE_WIDTH = max(0, int(os.getenv("VISIONAI_RTSP_DECODE_WIDTH", "640")))

# Limit the server-side decoded frame rate. 10 FPS remains smooth for live
# monitoring while avoiding a backlog in the raw-video pipe. Set 0 to preserve
# the source frame rate. This also only affects the system-FFmpeg path.
SYSTEM_FFMPEG_OUTPUT_FPS = max(0.0, float(os.getenv("VISIONAI_RTSP_OUTPUT_FPS", "10")))

# RTSP backend selection:
#   auto   -> Windows: OpenCV; non-Windows: system FFmpeg if available,
#             otherwise OpenCV fallback.
#   ffmpeg -> Force system FFmpeg/ffprobe for RTSP.
#   opencv -> Force OpenCV VideoCapture for RTSP.
#
# Optional .env / service setting:
#   VISIONAI_RTSP_BACKEND=auto
RTSP_BACKEND_MODE = os.getenv("VISIONAI_RTSP_BACKEND", "auto").strip().lower()
if RTSP_BACKEND_MODE not in {"auto", "ffmpeg", "opencv"}:
    RTSP_BACKEND_MODE = "auto"


# One worker per physical/logical camera ID.
_camera_workers = {}
_camera_workers_lock = threading.RLock()

# Cache RTSP dimensions by normalized URL. FFprobe is therefore executed only
# once per URL for the lifetime of this Python process, not on every reconnect.
# This directly prevents repeated ffprobe process creation during unstable RTSP
# reconnect loops.
_rtsp_probe_cache = {}
_rtsp_probe_cache_lock = threading.RLock()


def now_utc():
    return datetime.now(timezone.utc)


def format_last_seen(value):
    if not value:
        return "-"

    return value.strftime("%d %b %Y %I:%M %p")


def update_camera_runtime_status(camera_id: int, status: str):
    db = get_db_session()

    try:
        camera = (
            db.query(Camera)
            .filter(Camera.id == camera_id, Camera.is_active == True)
            .first()
        )

        if camera:
            camera.status = status

            if status == "online":
                camera.last_seen_at = now_utc()

            db.commit()

    finally:
        db.close()

    if status == "connecting":
        upsert_camera_issue(camera_id, "camera_connecting")

    elif status == "offline":
        upsert_camera_issue(camera_id, "camera_offline")

    elif status == "online":
        clear_camera_issue(camera_id)


def update_camera_recording_status(camera_id: int, is_recording: bool):
    db = get_db_session()

    try:
        camera = (
            db.query(Camera)
            .filter(Camera.id == camera_id, Camera.is_active == True)
            .first()
        )

        if camera:
            camera.is_recording = is_recording
            camera.last_seen_at = now_utc()
            db.commit()

    finally:
        db.close()


def get_camera_by_id_service(db: Session, camera_id: int):
    return (
        db.query(Camera)
        .filter(Camera.id == camera_id, Camera.is_active == True)
        .first()
    )


def resize_frame(frame, width=STREAM_FRAME_WIDTH):
    h, w = frame.shape[:2]

    if w <= width:
        return frame

    scale = width / float(w)
    return cv2.resize(frame, (int(w * scale), int(h * scale)))


def build_rtsp_url(
    username: str,
    password: str,
    camera_ip: str,
    path: str,
    port: int = 554,
) -> str:
    """Build an RTSP URL and safely encode username/password."""
    encoded_username = quote(username, safe="")
    encoded_password = quote(password, safe="")
    clean_path = path.lstrip("/")

    return (
        f"rtsp://{encoded_username}:{encoded_password}"
        f"@{camera_ip}:{port}/{clean_path}"
    )


def normalize_rtsp_url(url: str) -> str:
    """
    Normalize credentials in a complete RTSP URL.

    Supports already-encoded passwords (for example %40) and raw passwords
    containing special characters such as @, #, : or spaces.
    """
    value = (url or "").strip()

    if not value:
        raise ValueError("RTSP URL is empty")

    if not value.lower().startswith("rtsp://"):
        raise ValueError("RTSP URL must start with rtsp://")

    scheme, remainder = value.split("://", 1)

    # Split at the final @ so raw @ characters inside the password are handled.
    if "@" not in remainder:
        return value

    credentials, host_and_path = remainder.rsplit("@", 1)

    if ":" not in credentials:
        return value

    username, password = credentials.split(":", 1)

    encoded_username = quote(unquote(username), safe="")
    encoded_password = quote(unquote(password), safe="")

    return (
        f"{scheme}://{encoded_username}:{encoded_password}"
        f"@{host_and_path}"
    )


def mask_rtsp_url(url: str) -> str:
    """Return a log-safe RTSP URL without exposing the password."""
    try:
        scheme, remainder = url.split("://", 1)

        if "@" not in remainder:
            return url

        credentials, host_and_path = remainder.rsplit("@", 1)
        username = credentials.split(":", 1)[0]
        return f"{scheme}://{username}:***@{host_and_path}"
    except Exception:
        return "<invalid RTSP URL>"


@dataclass(frozen=True)
class CameraSourceConfig:
    camera_id: int
    camera_name: str
    source_type: str
    rtsp_url: str | None = None
    webcam_index: int | None = None
    usb_index: int | None = None

    @classmethod
    def from_camera(cls, camera):
        return cls(
            camera_id=int(camera.id),
            camera_name=str(camera.camera_name),
            source_type=str(camera.source_type).lower().strip(),
            rtsp_url=getattr(camera, "rtsp_url", None),
            webcam_index=getattr(camera, "webcam_index", None),
            usb_index=getattr(camera, "usb_index", None),
        )

    @property
    def source_signature(self):
        return (
            self.source_type,
            self.rtsp_url,
            self.webcam_index,
            self.usb_index,
        )


def _configure_local_capture(cap):
    """Apply safe preview settings to webcam/USB captures."""
    try:
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        cap.set(cv2.CAP_PROP_FPS, 15)
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    except Exception as error:
        print(f"[WARN] Could not configure local camera: {error}")

    return cap


def _open_windows_local_capture(index: int):
    """
    Prefer DirectShow on Windows because MSMF can fail when a device is
    reopened or accessed by more than one capture object.
    """
    cap = cv2.VideoCapture(index, cv2.CAP_DSHOW)

    if cap is not None and cap.isOpened():
        return _configure_local_capture(cap)

    if cap is not None:
        cap.release()

    print(
        f"[WARN] DirectShow could not open local camera index {index}; "
        "trying MSMF fallback"
    )

    cap = cv2.VideoCapture(index, cv2.CAP_MSMF)
    return _configure_local_capture(cap)


def _open_linux_local_capture(index: int):
    """
    Prefer V4L2 on Linux/VPS for directly attached webcam/USB devices.
    Fall back to CAP_ANY if V4L2 is unavailable or cannot open the device.
    """
    cap = None

    if hasattr(cv2, "CAP_V4L2"):
        cap = cv2.VideoCapture(index, cv2.CAP_V4L2)

        if cap is not None and cap.isOpened():
            return _configure_local_capture(cap)

        if cap is not None:
            cap.release()

    cap = cv2.VideoCapture(index)
    return _configure_local_capture(cap)


def _open_local_capture(index: int):
    """Cross-platform webcam/USB opener."""
    if os.name == "nt":
        return _open_windows_local_capture(index)

    return _open_linux_local_capture(index)


def _parse_sample_aspect_ratio(value):
    """
    ffprobe reports sample_aspect_ratio as "num:den" (for example "2:1"), or
    "0:1" / "N/A" when it is unknown. Anything unusable is treated as square
    pixels, which is the safe assumption.
    """
    try:
        num_text, separator, den_text = str(value or "").partition(":")

        if not separator:
            return 1.0

        num = float(num_text)
        den = float(den_text)

        if num > 0 and den > 0:
            return num / den

    except (TypeError, ValueError):
        pass

    return 1.0


def _system_ffmpeg_available():
    return bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


def _should_use_system_ffmpeg_for_rtsp():
    if RTSP_BACKEND_MODE == "ffmpeg":
        return True

    if RTSP_BACKEND_MODE == "opencv":
        return False

    # auto:
    # Preserve the user's known-good Windows/local OpenCV behavior.
    # Prefer the proven system FFmpeg stack on Linux/VPS.
    return os.name != "nt" and _system_ffmpeg_available()


class FFmpegRTSPCapture:
    """
    Minimal cv2.VideoCapture-compatible RTSP reader using system FFmpeg.

    Linux/VPS goals:
      * one FFmpeg process per shared camera worker
      * one FFmpeg decode thread initially
      * low-latency raw-frame delivery
      * ffprobe cached so reconnects do not repeatedly spawn ffprobe
      * optional server-side downscale/FPS cap before frames enter Python

    Methods used by SharedCameraWorker:
        isOpened()
        read()
        release()
        set()
    """

    def __init__(
        self,
        url: str,
        probe_timeout_sec: float = SYSTEM_FFMPEG_PROBE_TIMEOUT_SEC,
        frame_timeout_sec: float = SYSTEM_FFMPEG_FRAME_TIMEOUT_SEC,
    ):
        self.url = url
        self.probe_timeout_sec = float(probe_timeout_sec)
        self.frame_timeout_sec = float(frame_timeout_sec)

        self.process = None

        # Original source dimensions reported by ffprobe.
        self.source_width = None
        self.source_height = None

        # Pixel shape reported by ffprobe. 1.0 means square pixels. Some
        # cameras encode anamorphically - for example 960x1080 with a 2:1
        # sample aspect ratio, which is really 1920x1080 on screen.
        self.source_sar = 1.0

        # Actual raw BGR dimensions emitted by FFmpeg to pipe:1.
        self.width = None
        self.height = None
        self.frame_size = None

        self._opened = False
        self._state_lock = threading.RLock()

        self._load_or_probe_stream()
        self._configure_output_dimensions()
        self._start_ffmpeg()

    @property
    def pid(self):
        process = self.process
        if process is None or process.poll() is not None:
            return None
        return process.pid

    def _load_or_probe_stream(self):
        with _rtsp_probe_cache_lock:
            cached = _rtsp_probe_cache.get(self.url)

        if cached is not None:
            # Older cache entries held only (width, height). Treat those as
            # square pixels rather than crashing on unpack.
            if len(cached) == 3:
                self.source_width, self.source_height, self.source_sar = cached
            else:
                self.source_width, self.source_height = cached
                self.source_sar = 1.0

            print(
                f"Using cached RTSP dimensions: "
                f"{self.source_width}x{self.source_height} "
                f"sar={self.source_sar:.4g}"
            )
            return

        self._probe_stream()

        with _rtsp_probe_cache_lock:
            _rtsp_probe_cache[self.url] = (
                self.source_width,
                self.source_height,
                self.source_sar,
            )

    def _probe_stream(self):
        ffprobe_path = shutil.which("ffprobe")

        if not ffprobe_path:
            raise RuntimeError("ffprobe is not installed or not available in PATH")

        command = [
            ffprobe_path,
            "-v",
            "error",
            "-rtsp_transport",
            "tcp",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=width,height,sample_aspect_ratio",
            "-of",
            "json",
            self.url,
        ]

        print("Probing RTSP stream with system ffprobe...")

        try:
            result = subprocess.run(
                command,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=self.probe_timeout_sec,
                check=False,
            )
        except subprocess.TimeoutExpired as error:
            raise RuntimeError(
                f"ffprobe timed out after {self.probe_timeout_sec:.1f}s"
            ) from error

        if result.returncode != 0:
            error_text = (result.stderr or "").strip()
            raise RuntimeError(
                f"ffprobe could not open RTSP stream: "
                f"{error_text or 'unknown ffprobe error'}"
            )

        try:
            payload = json.loads(result.stdout)
            streams = payload.get("streams") or []

            if not streams:
                raise ValueError("No video stream reported")

            self.source_width = int(streams[0]["width"])
            self.source_height = int(streams[0]["height"])
            self.source_sar = _parse_sample_aspect_ratio(
                streams[0].get("sample_aspect_ratio")
            )

        except Exception as error:
            raise RuntimeError(
                f"Could not determine RTSP dimensions: {error}"
            ) from error

        if self.source_width <= 0 or self.source_height <= 0:
            raise RuntimeError(
                f"Invalid RTSP dimensions: "
                f"{self.source_width}x{self.source_height}"
            )

        print(
            f"RTSP probe successful: "
            f"{self.source_width}x{self.source_height} "
            f"sar={self.source_sar:.4g}"
        )

    def _configure_output_dimensions(self):
        # Correct anamorphic streams before doing anything else. A 960x1080
        # stream with sar 2:1 is really 1920x1080 on screen; scaling its stored
        # pixels directly produces a vertically stretched picture, wastes
        # bandwidth on pixels nobody wants, and hands the detector distorted
        # people to recognise.
        sar = self.source_sar if self.source_sar > 0 else 1.0

        width = max(2, int(round(int(self.source_width) * sar)))
        height = max(2, int(self.source_height))

        if (
            SYSTEM_FFMPEG_DECODE_WIDTH > 0
            and width > SYSTEM_FFMPEG_DECODE_WIDTH
        ):
            output_width = SYSTEM_FFMPEG_DECODE_WIDTH
            output_height = int(round(height * output_width / float(width)))

            # yuv/rawvideo pipelines are happier with even dimensions.
            if output_height % 2:
                output_height += 1

            width = max(2, output_width)
            height = max(2, output_height)

        # rawvideo pipelines are happier with even dimensions on both axes.
        if width % 2:
            width += 1

        if height % 2:
            height += 1

        self.width = width
        self.height = height
        self.frame_size = self.width * self.height * 3

    def _build_video_filter(self):
        filters = []

        if (
            self.width != self.source_width
            or self.height != self.source_height
        ):
            filters.append(f"scale={self.width}:{self.height}")

        # After correcting an anamorphic source the frame is square-pixel, so
        # say so explicitly. Without this the sar travels downstream and the
        # picture gets stretched again by whatever displays it.
        if abs(self.source_sar - 1.0) > 0.01:
            filters.append("setsar=1")

        if SYSTEM_FFMPEG_OUTPUT_FPS > 0:
            # `fps` intentionally drops source frames before they enter Python.
            filters.append(f"fps={SYSTEM_FFMPEG_OUTPUT_FPS:g}")

        return ",".join(filters) if filters else None

    def _start_ffmpeg(self):
        ffmpeg_path = shutil.which("ffmpeg")

        if not ffmpeg_path:
            raise RuntimeError("ffmpeg is not installed or not available in PATH")

        command = [
            ffmpeg_path,
            "-hide_banner",
            "-loglevel",
            "error",
            # Input-side low latency. Avoid aggressive probesize/analyzeduration
            # values because many NVRs need normal stream negotiation.
            "-fflags",
            "nobuffer",
            "-flags",
            "low_delay",
            "-rtsp_transport",
            "tcp",
            # Apply a conservative decoder thread limit before the input.
            "-threads",
            str(SYSTEM_FFMPEG_THREADS),
            "-i",
            self.url,
            "-map",
            "0:v:0",
            "-an",
        ]

        video_filter = self._build_video_filter()
        if video_filter:
            command.extend(["-vf", video_filter])

        command.extend(
            [
                "-pix_fmt",
                "bgr24",
                "-f",
                "rawvideo",
                "pipe:1",
            ]
        )

        print(
            f"Starting system FFmpeg RTSP reader "
            f"source={self.source_width}x{self.source_height} "
            f"output={self.width}x{self.height} "
            f"fps_cap={SYSTEM_FFMPEG_OUTPUT_FPS or 'source'} "
            f"threads={SYSTEM_FFMPEG_THREADS}"
        )

        try:
            self.process = subprocess.Popen(
                command,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                # Avoid a stderr pipe filling and blocking FFmpeg. Runtime
                # failures are surfaced through worker reconnect behavior.
                stderr=subprocess.DEVNULL,
                bufsize=0,
            )
        except Exception as error:
            self.process = None
            raise RuntimeError(
                f"Could not start system FFmpeg: {error}"
            ) from error

        time.sleep(0.1)

        if self.process.poll() is not None:
            return_code = self.process.returncode
            self.release()
            raise RuntimeError(
                f"FFmpeg exited immediately with code {return_code}"
            )

        with self._state_lock:
            self._opened = True

    def isOpened(self):
        with self._state_lock:
            return (
                self._opened
                and self.process is not None
                and self.process.poll() is None
                and self.process.stdout is not None
            )

    def _read_exact_frame_bytes(self):
        """
        Read exactly one raw BGR frame from FFmpeg.

        select() is used on Linux so a dead camera does not block the worker
        forever. The server-side FPS cap/downscale keeps this pipe small enough
        that old frames do not build up into many seconds of latency.
        """
        process = self.process

        if (
            process is None
            or process.stdout is None
            or process.poll() is not None
        ):
            return None

        fd = process.stdout.fileno()
        remaining = self.frame_size
        chunks = []
        deadline = time.monotonic() + self.frame_timeout_sec

        while remaining > 0:
            if process.poll() is not None:
                return None

            wait_time = deadline - time.monotonic()

            if wait_time <= 0:
                return None

            try:
                readable, _, _ = select.select([fd], [], [], wait_time)
            except (OSError, ValueError):
                return None

            if not readable:
                return None

            try:
                chunk = os.read(fd, remaining)
            except OSError:
                return None

            if not chunk:
                return None

            chunks.append(chunk)
            remaining -= len(chunk)

        return b"".join(chunks)

    def read(self):
        if not self.isOpened():
            return False, None

        raw_frame = self._read_exact_frame_bytes()

        if raw_frame is None or len(raw_frame) != self.frame_size:
            return False, None

        try:
            frame = np.frombuffer(
                raw_frame,
                dtype=np.uint8,
            ).reshape(
                (
                    self.height,
                    self.width,
                    3,
                )
            )

            return True, frame.copy()

        except Exception as error:
            print(
                f"[WARN] FFmpeg frame conversion error: {error}"
            )
            return False, None

    def set(self, *_args, **_kwargs):
        # Compatibility with the subset of cv2.VideoCapture used here.
        return False

    def release(self):
        with self._state_lock:
            process = self.process
            self.process = None
            self._opened = False

        if process is None:
            return

        try:
            if process.stdout:
                process.stdout.close()
        except Exception:
            pass

        try:
            if process.poll() is None:
                process.terminate()

                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=2)
        except Exception as error:
            print(
                f"[WARN] Could not stop FFmpeg process: {error}"
            )

def _open_opencv_rtsp_capture(url: str):
    """
    Open RTSP through OpenCV's FFmpeg backend.

    This preserves the known-good local Windows behavior.
    """
    capture_params = []

    if hasattr(cv2, "CAP_PROP_OPEN_TIMEOUT_MSEC"):
        capture_params.extend(
            [
                cv2.CAP_PROP_OPEN_TIMEOUT_MSEC,
                RTSP_OPEN_TIMEOUT_MSEC,
            ]
        )

    if hasattr(cv2, "CAP_PROP_READ_TIMEOUT_MSEC"):
        capture_params.extend(
            [
                cv2.CAP_PROP_READ_TIMEOUT_MSEC,
                RTSP_READ_TIMEOUT_MSEC,
            ]
        )

    try:
        if capture_params:
            return cv2.VideoCapture(
                url,
                cv2.CAP_FFMPEG,
                capture_params,
            )

        return cv2.VideoCapture(url, cv2.CAP_FFMPEG)

    except TypeError:
        # Older OpenCV builds may not support the params overload.
        return cv2.VideoCapture(url, cv2.CAP_FFMPEG)


def open_camera_capture(camera):
    """
    Open one physical camera capture.

    RTSP:
      - Windows/local: OpenCV FFmpeg by default.
      - Linux/VPS: system FFmpeg by default when ffmpeg+ffprobe are present.
      - Override with VISIONAI_RTSP_BACKEND=opencv or ffmpeg.

    Webcam/USB:
      - Windows: DirectShow -> MSMF fallback.
      - Linux: V4L2 -> CAP_ANY fallback.

    This function is called by SharedCameraWorker and can also safely be used
    by code that needs a VideoCapture-like object.
    """
    config = (
        camera
        if isinstance(camera, CameraSourceConfig)
        else CameraSourceConfig.from_camera(camera)
    )

    source_type = config.source_type

    if source_type == "rtsp":
        if not config.rtsp_url:
            raise ValueError("RTSP URL is required")

        url = normalize_rtsp_url(config.rtsp_url)

        print(
            f"Opening RTSP camera: {config.camera_name} | "
            f"{mask_rtsp_url(url)}"
        )

        if _should_use_system_ffmpeg_for_rtsp():
            if not _system_ffmpeg_available():
                if RTSP_BACKEND_MODE == "ffmpeg":
                    raise RuntimeError(
                        "VISIONAI_RTSP_BACKEND=ffmpeg but ffmpeg/ffprobe "
                        "are not available in PATH"
                    )

                print(
                    "[WARN] System FFmpeg is unavailable; "
                    "falling back to OpenCV RTSP"
                )
            else:
                print(
                    f"RTSP backend: system FFmpeg | "
                    f"camera={config.camera_name}"
                )
                return FFmpegRTSPCapture(url)

        print(
            f"RTSP backend: OpenCV FFmpeg | "
            f"camera={config.camera_name}"
        )
        return _open_opencv_rtsp_capture(url)

    if source_type == "webcam":
        if config.webcam_index is None:
            raise ValueError("Webcam index is required")

        index = int(config.webcam_index)
        print(f"Opening webcam: {config.camera_name} | index={index}")
        return _open_local_capture(index)

    if source_type == "usb":
        if config.usb_index is None:
            raise ValueError("USB camera index is required")

        index = int(config.usb_index)
        print(f"Opening USB camera: {config.camera_name} | index={index}")
        return _open_local_capture(index)

    raise HTTPException(status_code=400, detail="Invalid camera source type")


class SharedCameraWorker:
    """
    Exactly one capture/read thread for one camera ID.

    Multiple HTTP subscribers read the same latest JPEG/raw frame. A camera
    failure is contained inside this worker and cannot stop other workers or
    the FastAPI process.
    """

    def __init__(self, camera):
        self.config = CameraSourceConfig.from_camera(camera)
        self.camera_id = self.config.camera_id
        self.camera_name = self.config.camera_name

        self._capture = None
        self._running = True
        self._status = "connecting"
        self._last_error = None

        self._latest_frame = None
        self._latest_jpeg = None
        self._frame_sequence = 0
        self._last_frame_at = 0.0
        self._subscriber_count = 0

        # When a frame was last actually wanted by anybody. Used to retire
        # workers nobody is using.
        self._last_demand_at = time.monotonic()

        # Debug/health counters. These make it easy to tell whether the camera
        # worker is still producing fresh frames even if the browser appears
        # frozen behind a proxy/cPanel layer.
        self._debug_frame_count = 0
        self._debug_last_log_at = time.monotonic()

        self._condition = threading.Condition(threading.RLock())
        self._thread = threading.Thread(
            target=self._capture_loop,
            daemon=True,
            name=f"shared-camera-{self.camera_id}",
        )
        self._thread.start()

    @property
    def source_signature(self):
        return self.config.source_signature

    @property
    def is_running(self):
        return self._running and self._thread.is_alive()

    @property
    def status(self):
        with self._condition:
            return self._status

    @property
    def last_error(self):
        with self._condition:
            return self._last_error

    @property
    def subscriber_count(self):
        with self._condition:
            return self._subscriber_count

    @property
    def last_frame_age_sec(self):
        with self._condition:
            last_frame_at = self._last_frame_at

        if not last_frame_at:
            return None

        return max(0.0, time.monotonic() - last_frame_at)

    @property
    def capture_pid(self):
        capture = self._capture
        return getattr(capture, "pid", None) if capture is not None else None

    @property
    def capture_backend(self):
        capture = self._capture
        if isinstance(capture, FFmpegRTSPCapture):
            return "system_ffmpeg"
        if capture is not None:
            return "opencv"
        return None

    def _safe_update_runtime_status(self, status: str):
        with self._condition:
            if self._status == status:
                return
            self._status = status

        try:
            update_camera_runtime_status(self.camera_id, status)
        except Exception as error:
            # Database/issue-service errors must not kill the camera thread.
            print(
                f"[WARN] Camera {self.camera_name} status update failed: "
                f"{error}"
            )

    def _release_capture(self):
        cap = self._capture
        self._capture = None

        if cap is not None:
            try:
                cap.release()
            except Exception as error:
                print(
                    f"[WARN] Camera {self.camera_name} release failed: "
                    f"{error}"
                )

    def _set_error(self, error):
        with self._condition:
            self._last_error = str(error)
            self._latest_frame = None
            self._latest_jpeg = None
            self._condition.notify_all()

    def _publish_frame(self, frame):
        # Resizing and JPEG-encoding is the expensive half of this loop, and
        # only browser subscribers ever read the JPEG. Detection, recording and
        # face enrolment take the raw frame instead. So when nobody is watching
        # this camera, skip the encode entirely and just keep the raw frame
        # fresh - monitoring carries on, the wasted work does not.
        with self._condition:
            has_viewers = self._subscriber_count > 0

        jpeg_bytes = None

        if has_viewers:
            preview_frame = resize_frame(frame)

            ok, buffer = cv2.imencode(
                ".jpg",
                preview_frame,
                [int(cv2.IMWRITE_JPEG_QUALITY), JPEG_QUALITY],
            )

            if ok:
                jpeg_bytes = buffer.tobytes()
            else:
                print(
                    f"[WARN] JPEG encode failed: "
                    f"{self.camera_name} camera_id={self.camera_id}"
                )

        with self._condition:
            # Keep the original frame for detection/recording consumers.
            self._latest_frame = frame.copy()

            if jpeg_bytes is not None:
                self._latest_jpeg = jpeg_bytes

            self._frame_sequence += 1
            self._last_frame_at = time.monotonic()
            self._last_error = None
            self._condition.notify_all()

        # Lightweight health log every ~5 seconds. If these values keep moving
        # while the browser image is frozen, the camera/FFmpeg worker is healthy
        # and the remaining issue is likely HTTP proxy buffering/stream delivery.
        self._debug_frame_count += 1
        now = time.monotonic()
        elapsed = now - self._debug_last_log_at

        if elapsed >= 5.0:
            fps = self._debug_frame_count / elapsed

            with self._condition:
                sequence = self._frame_sequence
                subscribers = self._subscriber_count

            print(
                f"[CAMERA LIVE] "
                f"camera={self.camera_name} "
                f"id={self.camera_id} "
                f"fps={fps:.1f} "
                f"sequence={sequence} "
                f"subscribers={subscribers}"
            )

            self._debug_frame_count = 0
            self._debug_last_log_at = now

    def _capture_loop(self):
        reconnect_delay = CAMERA_RECONNECT_MIN_SEC

        while self._running:
            try:
                self._safe_update_runtime_status("connecting")
                self._release_capture()

                self._capture = open_camera_capture(self.config)

                if self._capture is None or not self._capture.isOpened():
                    raise RuntimeError("Camera could not be opened")

                self._safe_update_runtime_status("online")
                reconnect_delay = CAMERA_RECONNECT_MIN_SEC
                consecutive_read_failures = 0

                print(
                    f"Shared camera connected: {self.camera_name} "
                    f"(camera_id={self.camera_id})"
                )

                while self._running:
                    try:
                        ok, frame = self._capture.read()
                    except Exception as error:
                        raise RuntimeError(
                            f"Camera read exception: {error}"
                        ) from error

                    if not ok or frame is None:
                        consecutive_read_failures += 1

                        if consecutive_read_failures < CAMERA_READ_FAILURE_LIMIT:
                            time.sleep(0.05)
                            continue

                        raise RuntimeError(
                            "Camera returned no frame "
                            f"{consecutive_read_failures} times"
                        )

                    consecutive_read_failures = 0
                    self._publish_frame(frame)

            except Exception as error:
                self._set_error(error)
                self._safe_update_runtime_status("offline")

                # Prevent all channels from the same NVR reconnecting at the
                # exact same moment. The stagger is deterministic per camera.
                reconnect_stagger = (self.camera_id % 5) * 0.5
                retry_delay = min(
                    reconnect_delay + reconnect_stagger,
                    CAMERA_RECONNECT_MAX_SEC,
                )

                print(
                    f"[ERROR] Shared camera failure: {self.camera_name} "
                    f"(camera_id={self.camera_id}) | {error} | "
                    f"retry_in={retry_delay:.1f}s"
                )

                self._release_capture()

                # Interruptible sleep so stop() can end quickly.
                end_time = time.monotonic() + retry_delay
                while self._running and time.monotonic() < end_time:
                    time.sleep(0.1)

                reconnect_delay = min(
                    reconnect_delay * 2,
                    CAMERA_RECONNECT_MAX_SEC,
                )

        self._release_capture()
        self._safe_update_runtime_status("offline")

        with self._condition:
            self._condition.notify_all()

        print(
            f"Shared camera worker stopped: {self.camera_name} "
            f"(camera_id={self.camera_id})"
        )

    def note_demand(self):
        """
        Record that something wanted a frame from this camera just now.

        Called by every consumer - browser streams, detection, recording and
        face enrolment - so an idle worker can be told apart from a busy one.
        """
        self._last_demand_at = time.monotonic()

    @property
    def idle_seconds(self):
        """
        Seconds since anything last needed this camera. A worker with live
        subscribers is never idle.
        """
        with self._condition:
            if self._subscriber_count > 0:
                return 0.0

        return max(0.0, time.monotonic() - self._last_demand_at)

    def get_latest_frame(self, copy=True):
        self.note_demand()

        with self._condition:
            if self._latest_frame is None:
                return None

            return (
                self._latest_frame.copy()
                if copy
                else self._latest_frame
            )

    def wait_for_frame(self, timeout=CAMERA_FRAME_WAIT_TIMEOUT_SEC):
        self.note_demand()
        deadline = time.monotonic() + max(float(timeout), 0.0)

        with self._condition:
            while self._running and self._latest_frame is None:
                remaining = deadline - time.monotonic()

                if remaining <= 0:
                    return None

                self._condition.wait(timeout=remaining)

            if self._latest_frame is None:
                return None

            return self._latest_frame.copy()

    def wait_for_jpeg(
        self,
        previous_sequence=0,
        timeout=CAMERA_FRAME_WAIT_TIMEOUT_SEC,
    ):
        self.note_demand()
        deadline = time.monotonic() + max(float(timeout), 0.0)

        with self._condition:
            while (
                self._running
                and (
                    self._latest_jpeg is None
                    or self._frame_sequence <= previous_sequence
                )
            ):
                remaining = deadline - time.monotonic()

                if remaining <= 0:
                    return None, previous_sequence

                self._condition.wait(timeout=remaining)

            if self._latest_jpeg is None:
                return None, previous_sequence

            return self._latest_jpeg, self._frame_sequence

    def add_subscriber(self):
        self.note_demand()

        with self._condition:
            self._subscriber_count += 1
            count = self._subscriber_count

        print(
            f"Camera subscriber added: {self.camera_name} "
            f"(camera_id={self.camera_id}, subscribers={count})"
        )
        return count

    def remove_subscriber(self):
        # Start the idle clock from the moment the last viewer leaves.
        self.note_demand()

        with self._condition:
            self._subscriber_count = max(
                0,
                self._subscriber_count - 1,
            )
            count = self._subscriber_count

        print(
            f"Camera subscriber removed: {self.camera_name} "
            f"(camera_id={self.camera_id}, subscribers={count})"
        )
        return count

    def stop(self, join_timeout=3.0):
        self._running = False
        self._release_capture()

        with self._condition:
            self._condition.notify_all()

        if (
            self._thread.is_alive()
            and threading.current_thread() is not self._thread
        ):
            self._thread.join(timeout=join_timeout)

        if self._thread.is_alive():
            print(
                f"[WARN] Camera worker thread did not exit within "
                f"{join_timeout:.1f}s: camera_id={self.camera_id}"
            )


_camera_reaper_thread = None
_camera_reaper_lock = threading.Lock()


def _reap_idle_camera_workers():
    """
    Stop camera workers nothing has needed for a while.

    A worker holds an RTSP connection open and decodes every frame it receives,
    which costs bandwidth on the camera's network and CPU on this machine. That
    is worth paying for a camera being watched, recorded or monitored - and
    pure waste for one nobody is using. Workers are recreated on demand, so
    stopping one is not destructive.
    """
    if CAMERA_IDLE_STOP_SEC <= 0:
        return

    with _camera_workers_lock:
        candidates = list(_camera_workers.items())

    for camera_id, worker in candidates:
        try:
            if not worker.is_running:
                continue

            idle = worker.idle_seconds

            if idle < CAMERA_IDLE_STOP_SEC:
                continue

            # Only retire the worker still registered under this ID, so a
            # replacement created in the meantime is never stopped.
            with _camera_workers_lock:
                if _camera_workers.get(camera_id) is not worker:
                    continue

                _camera_workers.pop(camera_id, None)

            print(
                f"Stopping idle camera worker: {worker.camera_name} "
                f"(camera_id={camera_id}, idle={idle:.0f}s)"
            )
            worker.stop()

        except Exception as error:
            print(
                f"[WARN] Could not retire idle camera worker "
                f"{camera_id}: {error}"
            )


def _camera_reaper_loop():
    while True:
        time.sleep(CAMERA_IDLE_CHECK_SEC)

        try:
            _reap_idle_camera_workers()
        except Exception as error:
            print(f"[WARN] Idle camera reaper error: {error}")


def _ensure_camera_reaper_running():
    global _camera_reaper_thread

    if CAMERA_IDLE_STOP_SEC <= 0:
        return

    with _camera_reaper_lock:
        if (
            _camera_reaper_thread is not None
            and _camera_reaper_thread.is_alive()
        ):
            return

        _camera_reaper_thread = threading.Thread(
            target=_camera_reaper_loop,
            name="camera-idle-reaper",
            daemon=True,
        )
        _camera_reaper_thread.start()

        print(
            f"Idle camera reaper started "
            f"(stop after {CAMERA_IDLE_STOP_SEC:.0f}s unused, "
            f"checked every {CAMERA_IDLE_CHECK_SEC:.0f}s)"
        )


def get_or_create_camera_worker(camera):
    """
    Return the shared worker for this camera.

    If camera source settings changed, the old worker is stopped and replaced.
    """
    _ensure_camera_reaper_running()

    camera_id = int(camera.id)
    config = CameraSourceConfig.from_camera(camera)

    with _camera_workers_lock:
        worker = _camera_workers.get(camera_id)

        if (
            worker is not None
            and worker.is_running
            and worker.source_signature == config.source_signature
        ):
            return worker

        if worker is not None:
            worker.stop()
            _camera_workers.pop(camera_id, None)

        worker = SharedCameraWorker(camera)
        _camera_workers[camera_id] = worker
        return worker


def get_shared_camera_worker(camera):
    return get_or_create_camera_worker(camera)


def get_shared_camera_frame(
    camera,
    wait_timeout=CAMERA_FRAME_WAIT_TIMEOUT_SEC,
):
    """
    Used by detection_service.py.

    Returns a copy of the latest raw frame from the same capture worker used by
    normal Dashboard/Live Monitoring streams.
    """
    camera_id = int(camera.id)

    # 1. If someone is watching this camera live, video is already flowing -
    #    use it, so the annotated view stays smooth while a tile is open.
    with _camera_workers_lock:
        existing = _camera_workers.get(camera_id)

    if (
        existing is not None
        and existing.is_running
        and existing.subscriber_count > 0
    ):
        frame = existing.get_latest_frame(copy=True)

        if frame is not None:
            return frame

    # 2. Otherwise prefer a frame the capture agent pushed in. This is the
    #    cheap path: no video crosses the internet for monitoring at all.
    pushed = get_pushed_frame(camera_id)

    if pushed is not None:
        return pushed

    # 3. Nothing pushed recently. Pull the stream ourselves so monitoring does
    #    not go blind - unless told to rely on the agent only.
    if not INGEST_FALLBACK_TO_RTSP:
        return None

    worker = get_or_create_camera_worker(camera)
    frame = worker.get_latest_frame(copy=True)

    if frame is not None:
        return frame

    return worker.wait_for_frame(timeout=wait_timeout)


def stop_camera_worker(camera_id: int):
    camera_id = int(camera_id)

    with _camera_workers_lock:
        worker = _camera_workers.pop(camera_id, None)

    if worker is not None:
        worker.stop()
        return True

    return False


def shutdown_all_camera_workers():
    with _camera_workers_lock:
        workers = list(_camera_workers.values())
        _camera_workers.clear()

    for worker in workers:
        try:
            worker.stop()
        except Exception as error:
            print(
                f"[WARN] Could not stop camera worker "
                f"{worker.camera_id}: {error}"
            )


def get_camera_worker_status(camera_id: int):
    """
    Lightweight runtime diagnostics. It does not open a camera or spawn ffprobe.
    """
    camera_id = int(camera_id)

    with _camera_workers_lock:
        worker = _camera_workers.get(camera_id)

    if worker is None:
        return {
            "camera_id": camera_id,
            "running": False,
            "status": "offline",
            "backend": None,
            "ffmpeg_pid": None,
            "subscribers": 0,
            "last_frame_age_sec": None,
            "last_error": None,
        }

    last_frame_age = worker.last_frame_age_sec

    return {
        "camera_id": camera_id,
        "running": worker.is_running,
        "status": worker.status,
        "backend": worker.capture_backend,
        "ffmpeg_pid": worker.capture_pid,
        "subscribers": worker.subscriber_count,
        "last_frame_age_sec": (
            round(last_frame_age, 3)
            if last_frame_age is not None
            else None
        ),
        "last_error": worker.last_error,
    }


def check_camera_live(camera):
    """
    Check through the shared worker instead of opening a second capture.
    """
    try:
        worker = get_or_create_camera_worker(camera)
        frame = worker.wait_for_frame(timeout=5.0)
        return frame is not None
    except Exception as error:
        print(
            f"Camera live check error: "
            f"{getattr(camera, 'camera_name', camera.id)} | {error}"
        )
        return False


def refresh_camera_status(db: Session, camera: Camera):
    is_live = check_camera_live(camera)

    camera.status = "online" if is_live else "offline"

    if is_live:
        camera.last_seen_at = now_utc()

    db.commit()
    db.refresh(camera)

    return camera


def generate_camera_stream_service(camera):
    """
    MJPEG subscriber generator.

    This function never opens a second camera. It reads JPEG frames already
    produced by the one shared camera worker.
    """
    worker = get_or_create_camera_worker(camera)
    camera_name = str(camera.camera_name)
    last_sequence = 0

    worker.add_subscriber()

    print(
        f"Normal stream subscriber connected: {camera_name} "
        f"(camera_id={camera.id})"
    )

    try:
        while True:
            jpeg, last_sequence = worker.wait_for_jpeg(
                previous_sequence=last_sequence,
                timeout=CAMERA_FRAME_WAIT_TIMEOUT_SEC,
            )

            if jpeg is None:
                # Worker may be reconnecting. Keep this HTTP stream alive.
                time.sleep(0.05)
                continue

            yield (
                b"--frame\r\n"
                b"Content-Type: image/jpeg\r\n\r\n"
                + jpeg
                + b"\r\n"
            )

    except GeneratorExit:
        pass
    except Exception as error:
        # Subscriber failure must not stop the shared worker or other streams.
        print(
            f"[WARN] Normal stream subscriber error: {camera_name} | "
            f"{error}"
        )
    finally:
        worker.remove_subscriber()
        print(
            f"Normal stream subscriber closed: {camera_name} "
            f"(camera_id={camera.id})"
        )


def create_camera_group_service(
    db: Session,
    name: str,
    description: str | None = None,
):
    existing_group = (
        db.query(CameraGroup)
        .filter(CameraGroup.name == name)
        .first()
    )

    if existing_group:
        if existing_group.is_active:
            return {
                "success": False,
                "status_code": 400,
                "message": "Camera group already exists",
            }

        existing_group.is_active = True
        existing_group.description = description

        db.commit()
        db.refresh(existing_group)

        return {
            "success": True,
            "data": {
                "id": existing_group.id,
                "name": existing_group.name,
                "description": existing_group.description,
            },
        }

    group = CameraGroup(name=name, description=description)

    db.add(group)
    db.commit()
    db.refresh(group)

    return {
        "success": True,
        "data": {
            "id": group.id,
            "name": group.name,
            "description": group.description,
        },
    }


def get_camera_groups_service(db: Session):
    groups = (
        db.query(
            CameraGroup.id,
            CameraGroup.name,
            CameraGroup.description,
            func.count(Camera.id).label("camera_count"),
        )
        .outerjoin(
            Camera,
            (Camera.group_id == CameraGroup.id) & (Camera.is_active == True),
        )
        .filter(CameraGroup.is_active == True)
        .group_by(CameraGroup.id)
        .order_by(CameraGroup.id.desc())
        .all()
    )

    data = []

    for group in groups:
        data.append(
            {
                "id": group.id,
                "name": group.name,
                "description": group.description,
                "camera_count": group.camera_count,
            }
        )

    return data


def delete_camera_group_service(db: Session, group_id: int):
    group = (
        db.query(CameraGroup)
        .filter(CameraGroup.id == group_id, CameraGroup.is_active == True)
        .first()
    )

    if not group:
        return {
            "success": False,
            "status_code": 404,
            "message": "Camera group not found",
        }

    group.is_active = False

    cameras = (
        db.query(Camera)
        .filter(Camera.group_id == group_id, Camera.is_active == True)
        .all()
    )

    for camera in cameras:
        camera.group_id = None

    db.commit()

    return {
        "success": True,
        "message": "Camera group deleted successfully",
    }


def create_camera_service(
    db: Session,
    camera_name: str,
    source_type: str,
    rtsp_url: str | None,
    webcam_index: int | None,
    usb_index: int | None,
    group_id: int | None,
    location: str | None,
    is_recording: bool = False,
):
    source_type = source_type.lower().strip()

    if source_type not in ["rtsp", "webcam", "usb"]:
        return {
            "success": False,
            "status_code": 400,
            "message": "source_type must be rtsp, webcam or usb",
        }

    if source_type == "rtsp" and not rtsp_url:
        return {
            "success": False,
            "status_code": 400,
            "message": "RTSP URL is required",
        }

    if source_type == "webcam" and webcam_index is None:
        return {
            "success": False,
            "status_code": 400,
            "message": "Webcam index is required",
        }

    if source_type == "usb" and usb_index is None:
        return {
            "success": False,
            "status_code": 400,
            "message": "USB camera index is required",
        }

    if group_id:
        group = (
            db.query(CameraGroup)
            .filter(CameraGroup.id == group_id, CameraGroup.is_active == True)
            .first()
        )

        if not group:
            return {
                "success": False,
                "status_code": 404,
                "message": "Camera group not found",
            }

    normalized_rtsp_url = (
        normalize_rtsp_url(rtsp_url) if source_type == "rtsp" else None
    )

    camera = Camera(
        camera_name=camera_name,
        source_type=source_type,
        rtsp_url=normalized_rtsp_url,
        webcam_index=webcam_index if source_type == "webcam" else None,
        usb_index=usb_index if source_type == "usb" else None,
        group_id=group_id,
        location=location,
        status="offline",
        is_recording=False,
        last_seen_at=None,
    )

    db.add(camera)
    db.commit()
    db.refresh(camera)

    return {
        "success": True,
        "data": serialize_camera(camera),
    }


def update_camera_service(
    db: Session,
    camera_id: int,
    camera_name: str,
    source_type: str,
    rtsp_url: str | None,
    webcam_index: int | None,
    usb_index: int | None,
    group_id: int | None,
    location: str | None,
):
    camera = get_camera_by_id_service(db, camera_id)

    if not camera:
        return {
            "success": False,
            "status_code": 404,
            "message": "Camera not found",
        }

    source_type = source_type.lower().strip()

    if source_type not in ["rtsp", "webcam", "usb"]:
        return {
            "success": False,
            "status_code": 400,
            "message": "source_type must be rtsp, webcam or usb",
        }

    if source_type == "rtsp" and not rtsp_url:
        return {
            "success": False,
            "status_code": 400,
            "message": "RTSP URL is required",
        }

    if source_type == "webcam" and webcam_index is None:
        return {
            "success": False,
            "status_code": 400,
            "message": "Webcam index is required",
        }

    if source_type == "usb" and usb_index is None:
        return {
            "success": False,
            "status_code": 400,
            "message": "USB camera index is required",
        }

    if group_id:
        group = (
            db.query(CameraGroup)
            .filter(CameraGroup.id == group_id, CameraGroup.is_active == True)
            .first()
        )

        if not group:
            return {
                "success": False,
                "status_code": 404,
                "message": "Camera group not found",
            }

    normalized_rtsp_url = (
        normalize_rtsp_url(rtsp_url) if source_type == "rtsp" else None
    )

    camera.camera_name = camera_name
    camera.source_type = source_type
    camera.rtsp_url = normalized_rtsp_url
    camera.webcam_index = webcam_index if source_type == "webcam" else None
    camera.usb_index = usb_index if source_type == "usb" else None
    camera.group_id = group_id
    camera.location = location

    camera.status = "offline"
    camera.last_seen_at = None

    db.commit()
    db.refresh(camera)

    # Source configuration may have changed. The next subscriber will create
    # one fresh worker with the new settings.
    stop_camera_worker(camera_id)
    clear_camera_issue(camera_id)

    return {
        "success": True,
        "data": serialize_camera(camera),
    }


def serialize_camera(cam: Camera):
    return {
        "id": cam.id,
        "camera_name": cam.camera_name,
        "source_type": cam.source_type,

        # Kept for compatibility with the current frontend.
        # SECURITY TODO: move RTSP credentials to backend-only storage and
        # return a masked/credential-free value to the browser.
        "rtsp_url": cam.rtsp_url,

        "webcam_index": cam.webcam_index,
        "usb_index": cam.usb_index,
        "group_id": cam.group_id,
        "group": cam.group.name if cam.group else None,
        "location": cam.location,
        "status": cam.status or "offline",
        "is_recording": bool(cam.is_recording),
        "recording_status": "REC" if cam.is_recording else "OFF",
        "last_seen": format_last_seen(cam.last_seen_at),
        "last_seen_at": (
            cam.last_seen_at.isoformat()
            if cam.last_seen_at
            else None
        ),
    }


def get_cameras_service(db: Session):
    cameras = (
        db.query(Camera)
        .filter(Camera.is_active == True)
        .order_by(Camera.id.desc())
        .all()
    )

    return [serialize_camera(cam) for cam in cameras]


def delete_camera_service(db: Session, camera_id: int):
    camera = (
        db.query(Camera)
        .filter(Camera.id == camera_id, Camera.is_active == True)
        .first()
    )

    if not camera:
        return {
            "success": False,
            "status_code": 404,
            "message": "Camera not found",
        }

    camera.is_active = False
    camera.status = "offline"
    camera.is_recording = False
    camera.last_seen_at = now_utc()

    db.commit()

    # Release the physical device/RTSP connection immediately.
    stop_camera_worker(camera_id)
    clear_camera_issue(camera_id)

    return {
        "success": True,
        "message": "Camera deleted successfully",
    }
