from __future__ import annotations

import os
import time
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from threading import Lock
from uuid import uuid4

import cv2
from ultralytics import YOLO

from app.database import (
    Camera,
    CameraCountingLine,
    CountingSetting,
    CountingSummary,
    get_db_session,
)
from app.camera_management import get_shared_camera_frame


# =============================================================================
# CONFIGURATION
# =============================================================================

ALLOWED_INTERVALS = {5, 10, 15, 30, 60}
_PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _first_existing_path(env_name: str, candidates: list[Path]) -> str:
    configured = os.getenv(env_name, "").strip()
    if configured:
        return configured

    for candidate in candidates:
        if candidate.exists():
            return str(candidate)

    return str(candidates[0])


# -----------------------------------------------------------------------------
# CUSTOM BOX MODEL
# -----------------------------------------------------------------------------

# Checked lazily in get_box_model(), not here: this module is imported by
# main.py at startup, so raising at import time takes the whole backend down
# (every camera, PPE and face alerts included) just because counting is not
# configured yet. Counting Management fails on its own instead.
BOX_MODEL_PATH = os.getenv("VISIONAI_BOX_MODEL_PATH", "").strip()

BOX_CLASS_ID = int(os.getenv("VISIONAI_BOX_CLASS_ID", "0"))
BOX_CONF = float(os.getenv("VISIONAI_BOX_CONF", "0.15"))
BOX_IMGSZ = int(os.getenv("VISIONAI_BOX_IMGSZ", "640"))



# -----------------------------------------------------------------------------
# DETECTION / STREAM SETTINGS
# -----------------------------------------------------------------------------

COUNTING_DETECTION_INTERVAL_SEC = float(
    os.getenv("VISIONAI_COUNTING_DETECTION_INTERVAL_SEC", "0.25")
)
# Frames come from the shared bus, which returns the LATEST frame without
# blocking. Uncapped (0) the worker therefore re-copies, re-draws and re-encodes
# the same frame ~100x/sec per camera, which starves PPE detection on this
# CPU-only server. 8 fps is smooth enough for the counting view.
# ponytail: fixed cap; make it per-camera only if one camera needs a faster view.
COUNTING_TARGET_FPS = float(os.getenv("VISIONAI_COUNTING_FPS", "8"))
COUNTING_JPEG_QUALITY = int(os.getenv("VISIONAI_COUNTING_JPEG_QUALITY", "75"))


# -----------------------------------------------------------------------------
# LINE CROSSING SETTINGS
# -----------------------------------------------------------------------------
# IMPORTANT:
# Line coordinates and direction are NOT hardcoded here anymore.
# They are loaded from CameraCountingLine in the database.
#
# COUNT_LINE_DEADBAND only controls jitter around the configured line.
# Direction is NOT used by the current counting decision. A box is counted when
# its tracked center clearly moves from one stable side of the line to the other.
# -----------------------------------------------------------------------------

COUNT_LINE_DEADBAND = float(
    os.getenv("VISIONAI_COUNT_LINE_DEADBAND", "0.015")
)


COUNTING_LINE_REFRESH_SEC = float(
    os.getenv("VISIONAI_COUNTING_LINE_REFRESH_SEC", "2.0")
)


# -----------------------------------------------------------------------------
# BOX TRACKING SETTINGS
# -----------------------------------------------------------------------------
# Counting is now BOX-only.
# Only the custom BOX model is used. Person detection is intentionally disabled.
# A box must be tracked and its CENTER must cross a configured line.
# Direction (ltr / rtl) is stored for future use but is intentionally ignored by
# the current counting decision.
# -----------------------------------------------------------------------------

BOX_TRACK_MAX_DISTANCE = float(
    os.getenv("VISIONAI_COUNT_BOX_TRACK_MAX_DISTANCE", "450")
)
BOX_TRACK_MAX_MISSED_FRAMES = int(
    os.getenv("VISIONAI_COUNT_BOX_TRACK_MAX_MISSED", "45")
)

# =============================================================================
# EVIDENCE
# =============================================================================

EVIDENCE_ROOT = Path(
    os.getenv(
        "VISIONAI_EVIDENCE_DIR",
        str(_PROJECT_ROOT / "counting_evidence"),
    )
)
EVIDENCE_ROOT.mkdir(parents=True, exist_ok=True)


# =============================================================================
# GENERAL HELPERS
# =============================================================================


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _clamp01(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


def _normalize_direction(value: str) -> str:
    direction = str(value or "").strip().lower()
    if direction not in {"ltr", "rtl"}:
        raise ValueError("Direction must be 'ltr' or 'rtl'.")
    return direction


def _direction_label(direction: str) -> str:
    return "Left -> Right" if direction == "ltr" else "Right -> Left"


def _hex_to_bgr(value: str, fallback=(255, 131, 22)):
    try:
        text = str(value or "").strip().lstrip("#")
        if len(text) != 6:
            return fallback
        r = int(text[0:2], 16)
        g = int(text[2:4], 16)
        b = int(text[4:6], 16)
        return (b, g, r)
    except Exception:
        return fallback


# =============================================================================
# COUNTING LINE CRUD / DATABASE ACCESS
# =============================================================================
# Routes will live in main.py. These service functions contain the database
# logic so no extra counting_lines_api.py file is required.
# =============================================================================


def _serialize_counting_line(row: CameraCountingLine) -> dict:
    return {
        "id": row.id,
        "camera_id": row.camera_id,
        "name": row.name,
        "points": [
            [float(row.x1), float(row.y1)],
            [float(row.x2), float(row.y2)],
        ],
        "direction": row.direction,
        "color": row.color or "#1683ff",
        "width": int(row.line_width or 4),
        "show_arrows": bool(row.show_arrows),
        "show_label": bool(row.show_label),
        "is_active": bool(row.is_active),
        "created_at": row.created_at.isoformat() if row.created_at else None,
        "updated_at": row.updated_at.isoformat() if row.updated_at else None,
    }


def _validate_line_payload(payload: dict, *, partial: bool = False) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("Line payload must be an object.")

    cleaned: dict = {}

    if not partial or "camera_id" in payload:
        camera_id = payload.get("camera_id")
        if camera_id is None:
            raise ValueError("camera_id is required.")
        cleaned["camera_id"] = int(camera_id)

    if not partial or "name" in payload:
        name = str(payload.get("name") or "").strip()
        if not name:
            raise ValueError("Line name is required.")
        cleaned["name"] = name[:150]

    if not partial or "points" in payload:
        points = payload.get("points")
        if not isinstance(points, list) or len(points) != 2:
            raise ValueError("Line must contain exactly two points.")

        normalized_points = []
        for point in points:
            if not isinstance(point, (list, tuple)) or len(point) != 2:
                raise ValueError("Each line point must be [x, y].")

            x = float(point[0])
            y = float(point[1])

            if not (0.0 <= x <= 1.0 and 0.0 <= y <= 1.0):
                raise ValueError("Line coordinates must be between 0 and 1.")

            normalized_points.append([x, y])

        if normalized_points[0] == normalized_points[1]:
            raise ValueError("Line start and end points cannot be the same.")

        cleaned["points"] = normalized_points

    if not partial or "direction" in payload:
        cleaned["direction"] = _normalize_direction(
            payload.get("direction", "ltr")
        )

    if "color" in payload or not partial:
        color = str(payload.get("color") or "#1683ff").strip()
        cleaned["color"] = color[:20]

    if "width" in payload or "line_width" in payload or not partial:
        width = int(payload.get("width", payload.get("line_width", 4)))
        cleaned["line_width"] = max(1, min(width, 20))

    if "show_arrows" in payload or not partial:
        cleaned["show_arrows"] = bool(payload.get("show_arrows", True))

    if "show_label" in payload or not partial:
        cleaned["show_label"] = bool(payload.get("show_label", True))

    if "is_active" in payload or not partial:
        cleaned["is_active"] = bool(payload.get("is_active", True))

    return cleaned


def get_counting_lines(
    camera_id: int | None = None,
    *,
    include_inactive: bool = False,
) -> list[dict]:
    db = get_db_session()
    try:
        query = db.query(CameraCountingLine)

        if camera_id is not None:
            query = query.filter(CameraCountingLine.camera_id == int(camera_id))

        if not include_inactive:
            query = query.filter(CameraCountingLine.is_active == True)

        rows = query.order_by(CameraCountingLine.id.asc()).all()
        return [_serialize_counting_line(row) for row in rows]
    finally:
        db.close()


def get_counting_line(line_id: int) -> dict | None:
    db = get_db_session()
    try:
        row = (
            db.query(CameraCountingLine)
            .filter(CameraCountingLine.id == int(line_id))
            .first()
        )
        return _serialize_counting_line(row) if row else None
    finally:
        db.close()


def create_counting_line(payload: dict) -> dict:
    data = _validate_line_payload(payload, partial=False)
    db = get_db_session()

    try:
        camera = (
            db.query(Camera)
            .filter(
                Camera.id == data["camera_id"],
                Camera.is_active == True,
            )
            .first()
        )
        if camera is None:
            raise ValueError("Camera not found or inactive.")

        (x1, y1), (x2, y2) = data["points"]

        row = CameraCountingLine(
            camera_id=data["camera_id"],
            name=data["name"],
            x1=x1,
            y1=y1,
            x2=x2,
            y2=y2,
            direction=data["direction"],
            color=data["color"],
            line_width=data["line_width"],
            show_arrows=data["show_arrows"],
            show_label=data["show_label"],
            is_active=data["is_active"],
        )

        db.add(row)
        db.commit()
        db.refresh(row)
        return _serialize_counting_line(row)

    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def update_counting_line(line_id: int, payload: dict) -> dict:
    data = _validate_line_payload(payload, partial=True)
    db = get_db_session()

    try:
        row = (
            db.query(CameraCountingLine)
            .filter(CameraCountingLine.id == int(line_id))
            .first()
        )
        if row is None:
            raise ValueError("Counting line not found.")

        if "camera_id" in data:
            camera = (
                db.query(Camera)
                .filter(
                    Camera.id == data["camera_id"],
                    Camera.is_active == True,
                )
                .first()
            )
            if camera is None:
                raise ValueError("Camera not found or inactive.")
            row.camera_id = data["camera_id"]

        if "name" in data:
            row.name = data["name"]

        if "points" in data:
            (x1, y1), (x2, y2) = data["points"]
            row.x1 = x1
            row.y1 = y1
            row.x2 = x2
            row.y2 = y2

        if "direction" in data:
            row.direction = data["direction"]
        if "color" in data:
            row.color = data["color"]
        if "line_width" in data:
            row.line_width = data["line_width"]
        if "show_arrows" in data:
            row.show_arrows = data["show_arrows"]
        if "show_label" in data:
            row.show_label = data["show_label"]
        if "is_active" in data:
            row.is_active = data["is_active"]

        db.commit()
        db.refresh(row)
        return _serialize_counting_line(row)

    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def delete_counting_line(line_id: int) -> dict:
    """
    Soft-delete a counting line.

    Keeping the row avoids breaking old CountingSummary.line_id references.
    Frontend GET calls return active lines only, so the deleted line disappears
    from the editor normally.
    """
    db = get_db_session()
    try:
        row = (
            db.query(CameraCountingLine)
            .filter(CameraCountingLine.id == int(line_id))
            .first()
        )
        if row is None:
            raise ValueError("Counting line not found.")

        row.is_active = False
        db.commit()
        return {"id": int(line_id), "deleted": True}

    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


# =============================================================================
# COUNTING SETTINGS
# =============================================================================


def get_counting_setting() -> dict:
    db = get_db_session()
    try:
        setting = (
            db.query(CountingSetting)
            .filter(CountingSetting.id == 1)
            .first()
        )

        if not setting:
            setting = CountingSetting(id=1, interval_minutes=5)
            db.add(setting)
            db.commit()
            db.refresh(setting)

        return {"interval_minutes": int(setting.interval_minutes)}
    finally:
        db.close()


def update_counting_setting(interval_minutes: int) -> dict:
    interval_minutes = int(interval_minutes)
    if interval_minutes not in ALLOWED_INTERVALS:
        raise ValueError("Interval must be 5, 10, 15, 30, or 60 minutes.")

    db = get_db_session()
    try:
        setting = (
            db.query(CountingSetting)
            .filter(CountingSetting.id == 1)
            .first()
        )

        if not setting:
            setting = CountingSetting(id=1, interval_minutes=interval_minutes)
            db.add(setting)
        else:
            setting.interval_minutes = interval_minutes

        db.commit()
        return {"interval_minutes": interval_minutes}
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def _get_interval_minutes() -> int:
    return int(get_counting_setting()["interval_minutes"])


# =============================================================================
# LIVE COUNT STATE
# =============================================================================

_camera_states: dict[int, dict] = {}
_state_lock = Lock()


def _new_state(camera_id: int, interval_minutes: int) -> dict:
    now = _utcnow()
    return {
        "camera_id": int(camera_id),

        # Current Labor Carry Event interval window.
        "start_time": now,
        "end_time": now + timedelta(minutes=int(interval_minutes)),
        "interval_minutes": int(interval_minutes),

        # SESSION TOTALS = frontend realtime cards.
        # These DO NOT reset when the 5/10/15/... minute table interval closes.
        # They reset only when Monitoring is stopped and started again.
        "bag_count": 0,
        "box_count": 0,
        "total_count": 0,

        # INTERVAL TOTALS = Labor Carry Event table only.
        "interval_bag_count": 0,
        "interval_box_count": 0,
        "interval_total_count": 0,

        # Keep duplicate protection for the whole Monitoring ON session.
        "counted_track_ids": set(),

        # Evidence/line information for the current table interval.
        "evidence_image": None,
        "direction": None,
        "line_id": None,
        "line_name": None,
    }


def _reset_camera_state(camera_id: int) -> dict:
    state = _new_state(camera_id, _get_interval_minutes())
    with _state_lock:
        _camera_states[int(camera_id)] = state
    return state


def _ensure_camera_state(camera_id: int) -> dict:
    camera_id = int(camera_id)
    with _state_lock:
        state = _camera_states.get(camera_id)

    if state is not None:
        return state

    return _reset_camera_state(camera_id)


def _serialize_live_state(state: dict, *, monitoring: bool | None = None) -> dict:
    result = {
        "camera_id": state["camera_id"],
        "start_time": state["start_time"].isoformat(),
        "end_time": state["end_time"].isoformat(),
        "interval_minutes": state["interval_minutes"],

        # Frontend realtime cards use these SESSION totals.
        "bag_count": int(state.get("bag_count", 0)),
        "box_count": int(state.get("box_count", 0)),
        "total_count": int(state.get("total_count", 0)),

        # Optional debugging/table-window values.
        "interval_bag_count": int(state.get("interval_bag_count", 0)),
        "interval_box_count": int(state.get("interval_box_count", 0)),
        "interval_total_count": int(state.get("interval_total_count", 0)),

        "direction": state.get("direction"),
        "line_id": state.get("line_id"),
        "line_name": state.get("line_name"),
        "evidence_image": state.get("evidence_image"),
    }
    if monitoring is not None:
        result["monitoring"] = bool(monitoring)
    return result


def _start_next_interval_in_place(state: dict, interval_minutes: int) -> None:
    """Reset only the Labor Carry Event interval, never the session cards."""
    now = _utcnow()
    state["start_time"] = now
    state["end_time"] = now + timedelta(minutes=int(interval_minutes))
    state["interval_minutes"] = int(interval_minutes)
    state["interval_bag_count"] = 0
    state["interval_box_count"] = 0
    state["interval_total_count"] = 0
    state["evidence_image"] = None
    state["direction"] = None
    state["line_id"] = None
    state["line_name"] = None


def _camera_worker_running(camera_id: int) -> bool:
    # _counting_workers is defined later in this module. At request time the
    # module is already loaded, so this is safe and keeps live-count behavior
    # correct while monitoring is OFF.
    workers = globals().get("_counting_workers", {})
    lock = globals().get("_counting_workers_lock")

    if lock is None:
        return False

    with lock:
        worker = workers.get(int(camera_id))
        return bool(worker is not None and worker.is_running)


def get_live_count(camera_id: int) -> dict:
    camera_id = int(camera_id)
    running = _camera_worker_running(camera_id)

    if running:
        finalize_expired_window(camera_id)

    with _state_lock:
        state = _camera_states.get(camera_id)

    if state is None:
        # Do not create persistent counting state while Monitoring is OFF.
        state = _new_state(camera_id, _get_interval_minutes())

    with _state_lock:
        return _serialize_live_state(state, monitoring=running)


def get_all_live_counts() -> list[dict]:
    with _counting_workers_lock:
        camera_ids = [
            camera_id
            for camera_id, worker in _counting_workers.items()
            if worker.is_running
        ]

    return [get_live_count(camera_id) for camera_id in camera_ids]


# =============================================================================
# CROSSING REGISTRATION
# =============================================================================


def register_crossing(
    camera_id: int,
    object_type: str,
    track_id: int | str,
    *,
    line_id: int,
    line_name: str,
    evidence_image: str | None = None,
) -> dict:
    """Register one valid BOX line crossing.

    Current temporary counting rule:
      - object must be a tracked box
      - box movement is proven by its center changing stable line side
      - box center must cross the configured line
      - direction is intentionally ignored
      - same tracked box is counted once per line per monitoring session
    """

    if str(object_type).strip().lower() != "box":
        return get_live_count(camera_id)

    if not _camera_worker_running(camera_id):
        # Hard safety: no count can be created while Monitoring is OFF.
        return get_live_count(camera_id)

    finalize_expired_window(camera_id)
    state = _ensure_camera_state(camera_id)

    track_key = f"line:{int(line_id)}:box:{track_id}"

    with _state_lock:
        if track_key in state["counted_track_ids"]:
            return _serialize_live_state(state, monitoring=True)

        state["counted_track_ids"].add(track_key)

        # SESSION totals for realtime cards.
        state["box_count"] += 1
        state["total_count"] += 1

        # Current Labor Carry Event interval totals.
        state["interval_box_count"] += 1
        state["interval_total_count"] += 1

        state["direction"] = None
        state["line_id"] = int(line_id)
        state["line_name"] = str(line_name or "")

        if evidence_image:
            state["evidence_image"] = evidence_image

        return _serialize_live_state(state, monitoring=True)


# =============================================================================
# SUMMARY / INTERVAL
# =============================================================================


def finalize_expired_window(camera_id: int) -> dict | None:
    camera_id = int(camera_id)

    with _state_lock:
        state = _camera_states.get(camera_id)
        if not state:
            return None
        expired = _utcnow() >= state["end_time"]

    if not expired:
        return None

    return finalize_window(camera_id)


def finalize_window(camera_id: int) -> dict | None:
    camera_id = int(camera_id)

    with _state_lock:
        state = _camera_states.get(camera_id)
        if not state:
            return None

        snapshot = {
            "camera_id": state["camera_id"],
            "start_time": state["start_time"],
            "end_time": state["end_time"],
            "interval_minutes": state["interval_minutes"],
            "bag_count": int(state.get("interval_bag_count", 0)),
            "box_count": int(state.get("interval_box_count", 0)),
            "total_count": int(state.get("interval_total_count", 0)),
            "direction": state.get("direction"),
            "line_id": state.get("line_id"),
            "line_name": state.get("line_name"),
            "evidence_image": state.get("evidence_image"),
        }

    # Empty interval: no table row, but realtime SESSION cards must continue.
    if int(snapshot["total_count"] or 0) <= 0:
        with _state_lock:
            current = _camera_states.get(camera_id)
            if current is state:
                _start_next_interval_in_place(
                    current,
                    _get_interval_minutes(),
                )
        return None

    db = get_db_session()
    try:
        camera = db.query(Camera).filter(Camera.id == camera_id).first()
        if not camera:
            raise ValueError(f"Camera {camera_id} not found.")

        record = CountingSummary(
            record_id=(
                "CNT-"
                + snapshot["start_time"].strftime("%Y%m%d%H%M%S")
                + f"-{camera_id}-"
                + uuid4().hex[:6].upper()
            ),
            camera_id=camera.id,
            camera_name=camera.camera_name,
            camera_location=camera.location,
            line_id=snapshot["line_id"],
            line_name=snapshot["line_name"],
            start_time=snapshot["start_time"],
            end_time=snapshot["end_time"],
            interval_minutes=snapshot["interval_minutes"],
            bag_count=snapshot["bag_count"],
            box_count=snapshot["box_count"],
            total_count=snapshot["total_count"],
            direction=None,
            status="Completed",
            evidence_image=snapshot["evidence_image"],
        )

        # face_image intentionally not handled yet.
        db.add(record)
        db.commit()
        db.refresh(record)

        # IMPORTANT: reset only the table interval.
        # session box_count / total_count continue increasing for cards.
        with _state_lock:
            current = _camera_states.get(camera_id)
            if current is state:
                _start_next_interval_in_place(
                    current,
                    _get_interval_minutes(),
                )

        return _serialize_summary(record)

    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def _serialize_summary(row: CountingSummary) -> dict:
    return {
        "id": row.id,
        "record_id": row.record_id,
        "camera_id": row.camera_id,
        "camera_name": row.camera_name,
        "camera_location": row.camera_location,
        "line_id": row.line_id,
        "line_name": row.line_name,
        "start_time": row.start_time.isoformat() if row.start_time else None,
        "end_time": row.end_time.isoformat() if row.end_time else None,
        "interval_minutes": row.interval_minutes,
        "bag_count": row.bag_count,
        "box_count": row.box_count,
        "total_count": row.total_count,
        "direction": row.direction,
        "status": row.status,
        "evidence_image": row.evidence_image,
        "created_at": row.created_at.isoformat() if row.created_at else None,
    }


def get_counting_summaries(
    limit: int = 100,
    camera_id: int | None = None,
) -> list[dict]:
    db = get_db_session()
    try:
        query = db.query(CountingSummary)

        if camera_id is not None:
            query = query.filter(CountingSummary.camera_id == int(camera_id))

        rows = (
            query.order_by(CountingSummary.start_time.desc())
            .limit(max(1, min(int(limit), 500)))
            .all()
        )

        return [_serialize_summary(row) for row in rows]
    finally:
        db.close()


# =============================================================================
# YOLO MODELS
# =============================================================================

_box_model = None
_box_model_lock = threading.RLock()

def get_box_model():
    global _box_model

    with _box_model_lock:
        if _box_model is not None:
            return _box_model

        if not BOX_MODEL_PATH:
            raise RuntimeError(
                "VISIONAI_BOX_MODEL_PATH is not set in backend/.env - "
                "Counting Management cannot start."
            )

        if not os.path.exists(BOX_MODEL_PATH):
            raise FileNotFoundError(
                f"Counting Box model not found: {BOX_MODEL_PATH}"
            )

        print("[COUNTING] Loading custom Box model:", BOX_MODEL_PATH)
        _box_model = YOLO(BOX_MODEL_PATH)
        print("[COUNTING] Box model loaded.")
        return _box_model


# =============================================================================
# COUNTING LINE GEOMETRY
# =============================================================================


def _line_pixels(line: dict, frame):
    height, width = frame.shape[:2]
    points = line.get("points") or []
    if len(points) != 2:
        raise ValueError("Counting line must contain exactly two points.")

    x1 = int(_clamp01(points[0][0]) * width)
    y1 = int(_clamp01(points[0][1]) * height)
    x2 = int(_clamp01(points[1][0]) * width)
    y2 = int(_clamp01(points[1][1]) * height)

    if x1 == x2 and y1 == y2:
        x2 = min(width - 1, x1 + 1)

    return (x1, y1), (x2, y2)


def _signed_line_distance(point, line_start, line_end) -> float:
    px, py = point
    x1, y1 = line_start
    x2, y2 = line_end
    dx = x2 - x1
    dy = y2 - y1
    line_length = max((dx * dx + dy * dy) ** 0.5, 1.0)
    return (dx * (py - y1) - dy * (px - x1)) / line_length


def _line_side(point, line_start, line_end, frame) -> int:
    height, width = frame.shape[:2]
    distance_pixels = _signed_line_distance(point, line_start, line_end)
    deadband_pixels = COUNT_LINE_DEADBAND * max(width, height)

    if abs(distance_pixels) <= deadband_pixels:
        return 0

    return 1 if distance_pixels > 0 else -1


def _crossed_line(previous_side: int, current_side: int) -> bool:
    return (
        previous_side != 0
        and current_side != 0
        and previous_side != current_side
    )


# =============================================================================
# BOX TRACKER
# =============================================================================


class CentroidBoxTracker:
    """Robust BOX-only tracker for small, medium, and large boxes.

    Matching is not based on centroid distance alone.  For every candidate pair
    we also use predicted motion, bounding-box size similarity, and IoU.  This
    keeps a small/fast box on the same track while it crosses the counting line.

    Each track keeps:
      - current / previous center
      - simple velocity and predicted next center
      - current bbox
      - stable line side per configured line
      - line ids already counted in this monitoring session
    """

    def __init__(
        self,
        max_distance: float = BOX_TRACK_MAX_DISTANCE,
        max_missed: int = BOX_TRACK_MAX_MISSED_FRAMES,
    ):
        self.max_distance = float(max_distance)
        self.max_missed = int(max_missed)
        self.next_track_id = 1
        self.tracks: dict[int, dict] = {}

    @staticmethod
    def _distance(point_a, point_b) -> float:
        dx = float(point_a[0]) - float(point_b[0])
        dy = float(point_a[1]) - float(point_b[1])
        return (dx * dx + dy * dy) ** 0.5

    @staticmethod
    def _bbox_area(bbox) -> float:
        x1, y1, x2, y2 = bbox
        return max(1.0, float(x2 - x1)) * max(1.0, float(y2 - y1))

    @staticmethod
    def _bbox_diagonal(bbox) -> float:
        x1, y1, x2, y2 = bbox
        width = max(1.0, float(x2 - x1))
        height = max(1.0, float(y2 - y1))
        return (width * width + height * height) ** 0.5

    @staticmethod
    def _bbox_iou(a, b) -> float:
        ax1, ay1, ax2, ay2 = a
        bx1, by1, bx2, by2 = b

        ix1 = max(ax1, bx1)
        iy1 = max(ay1, by1)
        ix2 = min(ax2, bx2)
        iy2 = min(ay2, by2)

        iw = max(0.0, float(ix2 - ix1))
        ih = max(0.0, float(iy2 - iy1))
        intersection = iw * ih
        if intersection <= 0:
            return 0.0

        area_a = CentroidBoxTracker._bbox_area(a)
        area_b = CentroidBoxTracker._bbox_area(b)
        union = max(1.0, area_a + area_b - intersection)
        return intersection / union

    @staticmethod
    def _size_ratio(a, b) -> float:
        area_a = CentroidBoxTracker._bbox_area(a)
        area_b = CentroidBoxTracker._bbox_area(b)
        return min(area_a, area_b) / max(area_a, area_b)

    @staticmethod
    def _predicted_center(track):
        cx, cy = track["center"]
        vx, vy = track.get("velocity", (0.0, 0.0))
        # If detections were missed, project a little farther ahead.
        steps = min(3.0, 1.0 + float(track.get("missed", 0)))
        return (float(cx) + vx * steps, float(cy) + vy * steps)

    def _candidate_score(self, track: dict, detection: dict):
        predicted = self._predicted_center(track)
        distance = self._distance(predicted, detection["center"])

        # The absolute gate is intentionally generous for small/fast boxes.
        # Box-size based allowance also helps when bbox shape changes abruptly.
        adaptive_gate = max(
            self.max_distance,
            3.0 * self._bbox_diagonal(track["bbox"]),
            3.0 * self._bbox_diagonal(detection["bbox"]),
        )

        if distance > adaptive_gate:
            return None

        iou = self._bbox_iou(track["bbox"], detection["bbox"])
        size_ratio = self._size_ratio(track["bbox"], detection["bbox"])

        # Very different sizes are probably different physical boxes when
        # several boxes are present at once.  Keep this permissive so perspective
        # change and small detections do not break the track.
        if size_ratio < 0.08 and iou <= 0.0:
            return None

        distance_term = distance / max(adaptive_gate, 1.0)
        size_penalty = 1.0 - size_ratio
        iou_penalty = 1.0 - iou

        # Lower score is a better match. Distance remains the strongest signal.
        score = (
            distance_term * 0.65
            + size_penalty * 0.20
            + iou_penalty * 0.15
        )
        return score, distance

    def update(self, detections: list[dict]) -> list[dict]:
        for track in self.tracks.values():
            track["matched"] = False

        unmatched = set(range(len(detections)))
        candidate_pairs = []

        for track_id, track in self.tracks.items():
            for detection_index, detection in enumerate(detections):
                candidate = self._candidate_score(track, detection)
                if candidate is None:
                    continue
                score, distance = candidate
                candidate_pairs.append(
                    (score, distance, track_id, detection_index)
                )

        candidate_pairs.sort(key=lambda item: (item[0], item[1]))
        used_tracks = set()
        used_detections = set()

        for _, _, track_id, detection_index in candidate_pairs:
            if track_id in used_tracks or detection_index in used_detections:
                continue

            track = self.tracks.get(track_id)
            if track is None:
                continue

            detection = detections[detection_index]
            old_center = track["center"]
            new_center = detection["center"]

            raw_vx = float(new_center[0]) - float(old_center[0])
            raw_vy = float(new_center[1]) - float(old_center[1])
            old_vx, old_vy = track.get("velocity", (0.0, 0.0))

            # Smoothed velocity makes prediction less sensitive to YOLO bbox jitter.
            velocity = (
                old_vx * 0.35 + raw_vx * 0.65,
                old_vy * 0.35 + raw_vy * 0.65,
            )

            track["previous_center"] = old_center
            track["center"] = new_center
            track["velocity"] = velocity
            track["bbox"] = detection["bbox"]
            track["conf"] = detection["conf"]
            track["missed"] = 0
            track["matched"] = True
            track["age"] = int(track.get("age", 1)) + 1

            detection["track_id"] = track_id
            detection["previous_center"] = old_center

            used_tracks.add(track_id)
            used_detections.add(detection_index)
            unmatched.discard(detection_index)

        # Brand-new box detection -> brand-new track.
        for detection_index in sorted(unmatched):
            detection = detections[detection_index]
            track_id = self.next_track_id
            self.next_track_id += 1

            self.tracks[track_id] = {
                "center": detection["center"],
                "previous_center": detection["center"],
                "velocity": (0.0, 0.0),
                "bbox": detection["bbox"],
                "conf": detection["conf"],
                "missed": 0,
                "matched": True,
                "age": 1,
                "stable_sides": {},
                "stable_points": {},
                "counted_line_ids": set(),
            }

            detection["track_id"] = track_id
            detection["previous_center"] = detection["center"]

        stale_ids = []
        for track_id, track in self.tracks.items():
            if not track.get("matched"):
                track["missed"] += 1
                if track["missed"] > self.max_missed:
                    stale_ids.append(track_id)

        for track_id in stale_ids:
            self.tracks.pop(track_id, None)

        return detections


# =============================================================================
# COUNTING WORKERS
# =============================================================================

_counting_workers: dict[int, "CountingWorker"] = {}
_counting_workers_lock = threading.RLock()


class CountingWorker:
    def __init__(self, camera):
        self.camera_id = int(camera.id)
        self.camera_name = str(camera.camera_name)

        self._running = True
        self._last_error = None
        self._latest_jpeg = None
        self._frame_sequence = 0

        self._condition = threading.Condition(threading.RLock())
        self._box_tracker = CentroidBoxTracker()
        self._result_lock = threading.RLock()
        self._detection_running = False
        self._last_detection_time = 0.0
        self._last_boxes: list[dict] = []

        self._counting_lines: list[dict] = []
        self._last_line_refresh_time = 0.0

        self.session_id = uuid4().hex

        self._thread = threading.Thread(
            target=self._run,
            daemon=True,
            name=f"counting-camera-{self.camera_id}",
        )
        self._thread.start()

    @property
    def is_running(self) -> bool:
        return self._running and self._thread.is_alive()

    @property
    def last_error(self):
        with self._condition:
            return self._last_error

    def _load_camera(self):
        db = get_db_session()
        try:
            camera = (
                db.query(Camera)
                .filter(
                    Camera.id == self.camera_id,
                    Camera.is_active == True,
                )
                .first()
            )
            if camera is None:
                raise ValueError(
                    f"Camera {self.camera_id} not found or inactive."
                )
            db.expunge(camera)
            return camera
        finally:
            db.close()

    def _refresh_counting_lines(self, *, force: bool = False):
        now = time.monotonic()
        if (
            not force
            and now - self._last_line_refresh_time < COUNTING_LINE_REFRESH_SEC
        ):
            return

        self._last_line_refresh_time = now
        self._counting_lines = get_counting_lines(self.camera_id)

    # =========================================================================
    # DETECTION
    # =========================================================================

    def _detect_boxes(self, frame) -> list[dict]:
        model = get_box_model()
        with _box_model_lock:
            results = model.predict(
                source=frame,
                conf=BOX_CONF,
                imgsz=BOX_IMGSZ,
                classes=[BOX_CLASS_ID],
                verbose=False,
            )

        detections = []
        for result in results:
            if result.boxes is None:
                continue

            for box in result.boxes:
                if int(box.cls[0].item()) != BOX_CLASS_ID:
                    continue

                confidence = float(box.conf[0].item())
                x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                if x2 <= x1 or y2 <= y1:
                    continue

                detections.append(
                    {
                        "bbox": (x1, y1, x2, y2),
                        "center": (
                            int((x1 + x2) / 2),
                            int((y1 + y2) / 2),
                        ),
                        "conf": confidence,
                    }
                )

        return detections


    # =========================================================================
    # EVIDENCE
    # =========================================================================

    def _save_crossing_evidence(self, frame, track_id: int) -> str | None:
        """Save evidence exactly where main.py evidence API expects it."""
        try:
            timestamp = _utcnow().strftime("%Y%m%d_%H%M%S_%f")
            filename = f"CNT_CAM{self.camera_id}_BOX{track_id}_{timestamp}.jpg"

            camera_folder = EVIDENCE_ROOT / f"camera_{self.camera_id}"
            camera_folder.mkdir(parents=True, exist_ok=True)
            full_path = camera_folder / filename

            success = cv2.imwrite(str(full_path), frame)
            if not success:
                return None

            # main.py only needs a non-empty stored path; it safely extracts the
            # filename and resolves it inside camera_<id>.
            return filename

        except Exception as error:
            print(
                "[COUNTING EVIDENCE ERROR] "
                f"camera={self.camera_id} track={track_id} | {error}"
            )
            return None

    # =========================================================================
    # LINE CROSSING
    # =========================================================================

    def _process_crossings(self, frame, tracked_boxes):
        """Count a tracked BOX when its CENTER crosses a configured line.

        Current temporary rule:
          - no person model / no person-carry association
          - NO ltr / rtl direction enforcement
          - BOX center must be observed on one stable side of the line
          - later the SAME box track must be observed on the other stable side
          - the line deadband absorbs jitter near the line
          - the same box track counts only once per line per monitoring session

        Important: there is no separate short-frame movement gate here. A real
        stable-side change already proves that the box center moved across the
        line. This avoids missing a crossing when one detection falls inside the
        line deadband and the next detection appears just outside it.
        """
        lines = list(self._counting_lines)
        if not lines:
            return

        for box in tracked_boxes:
            track_id = box.get("track_id")
            if track_id is None:
                continue

            track = self._box_tracker.tracks.get(track_id)
            if track is None:
                continue

            current_point = box["center"]

            for line in lines:
                line_id = int(line["id"])
                line_start, line_end = _line_pixels(line, frame)

                current_side = _line_side(
                    current_point,
                    line_start,
                    line_end,
                    frame,
                )

                stable_sides = track.setdefault("stable_sides", {})
                stable_points = track.setdefault("stable_points", {})
                previous_side = int(stable_sides.get(line_id, 0))
                previous_stable_point = stable_points.get(line_id)

                # Inside the line deadband: do NOT overwrite the last stable side.
                # Wait until the box center is clearly visible on either side.
                if current_side == 0:
                    continue

                # First stable observation for this box/line. This establishes
                # the starting side; it is not a crossing yet.
                if previous_side == 0:
                    stable_sides[line_id] = current_side
                    stable_points[line_id] = current_point
                    continue

                already_counted = line_id in track.setdefault(
                    "counted_line_ids",
                    set(),
                )

                crossed = _crossed_line(previous_side, current_side)

                if crossed and not already_counted:
                    # Movement distance is only diagnostic now. Crossing from one
                    # stable side to the opposite side is itself the movement proof.
                    move_distance = 0.0
                    if previous_stable_point is not None:
                        dx = float(current_point[0]) - float(previous_stable_point[0])
                        dy = float(current_point[1]) - float(previous_stable_point[1])
                        move_distance = (dx * dx + dy * dy) ** 0.5

                    evidence_frame = self._draw_annotated_frame(
                        frame,
                        tracked_boxes,
                    )
                    evidence_path = self._save_crossing_evidence(
                        evidence_frame,
                        track_id,
                    )

                    unique_track_id = f"{self.session_id}:box:{track_id}"

                    live_state = register_crossing(
                        camera_id=self.camera_id,
                        object_type="box",
                        track_id=unique_track_id,
                        line_id=line_id,
                        line_name=line["name"],
                        evidence_image=evidence_path,
                    )

                    track["counted_line_ids"].add(line_id)

                    print(
                        "[COUNTING] BOX CENTER CROSSED LINE | "
                        f"camera={self.camera_name} "
                        f"id={self.camera_id} "
                        f"line={line['name']} "
                        f"line_id={line_id} "
                        f"box_track={track_id} "
                        f"side={previous_side}->{current_side} "
                        f"move_px={move_distance:.1f} "
                        f"box_count={live_state['box_count']}"
                    )

                # Update the last stable side/point only after evaluating crossing.
                stable_sides[line_id] = current_side
                stable_points[line_id] = current_point

    # =========================================================================
    # ASYNC AI
    # =========================================================================

    def _detect_async(self, inference_frame):
        try:
            self._refresh_counting_lines()

            # Custom BOX model is the only AI model used by Counting Management.
            raw_boxes = self._detect_boxes(inference_frame)
            tracked_boxes = self._box_tracker.update(raw_boxes)

            self._process_crossings(
                inference_frame,
                tracked_boxes,
            )

            boxes_copy = [dict(item) for item in tracked_boxes]
            with self._result_lock:
                self._last_boxes = boxes_copy

        except Exception as error:
            with self._condition:
                self._last_error = str(error)
                self._condition.notify_all()

            print(
                "[COUNTING INFERENCE ERROR] "
                f"camera={self.camera_name} id={self.camera_id} | {error}"
            )
        finally:
            self._detection_running = False

    # =========================================================================
    # DRAW ANNOTATED STREAM
    # =========================================================================

    def _draw_annotated_frame(self, frame, boxes):
        annotated = frame.copy()

        # Database-configured counting lines.
        # Direction is intentionally NOT displayed/enforced in this temporary mode.
        for line in list(self._counting_lines):
            try:
                line_start, line_end = _line_pixels(line, annotated)
            except Exception:
                continue

            color = _hex_to_bgr(line.get("color"))
            line_width = max(1, min(int(line.get("width", 4)), 20))

            cv2.line(
                annotated,
                line_start,
                line_end,
                color,
                line_width,
            )

            midpoint = (
                int((line_start[0] + line_end[0]) / 2),
                int((line_start[1] + line_end[1]) / 2),
            )

            if line.get("show_label", True):
                cv2.putText(
                    annotated,
                    str(line.get("name") or "Counting Line"),
                    (
                        max(5, midpoint[0] - 70),
                        max(22, midpoint[1] - 8),
                    ),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.50,
                    color,
                    2,
                )

        # Tracked BOX detections: YELLOW.
        for box in boxes:
            bx1, by1, bx2, by2 = box["bbox"]
            track_id = box.get("track_id")
            color = (0, 255, 255)  # BGR = yellow

            cv2.rectangle(
                annotated,
                (bx1, by1),
                (bx2, by2),
                color,
                2,
            )

            label = f"BOX #{track_id} {box['conf']:.2f}" if track_id is not None else f"BOX {box['conf']:.2f}"
            cv2.putText(
                annotated,
                label,
                (bx1, max(20, by1 - 8)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.50,
                color,
                2,
            )

            cx, cy = box["center"]
            cv2.circle(
                annotated,
                (int(cx), int(cy)),
                5,
                color,
                -1,
            )

        live = get_live_count(self.camera_id)

        # Real-time values used by the frontend cards are box_count / total_count.
        cv2.putText(
            annotated,
            f"BOX COUNT: {live['box_count']}",
            (15, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.75,
            (255, 255, 255),
            2,
        )
        cv2.putText(
            annotated,
            f"TOTAL ITEMS: {live['total_count']}",
            (15, 60),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (255, 255, 255),
            2,
        )
        cv2.putText(
            annotated,
            f"INTERVAL: {live['interval_minutes']} MIN",
            (15, 88),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 255, 255),
            2,
        )

        return annotated

    # =========================================================================
    # JPEG / WORKER LOOP
    # =========================================================================

    def _publish(self, frame):
        success, encoded = cv2.imencode(
            ".jpg",
            frame,
            [
                int(cv2.IMWRITE_JPEG_QUALITY),
                COUNTING_JPEG_QUALITY,
            ],
        )
        if not success:
            return

        jpeg = encoded.tobytes()
        with self._condition:
            self._latest_jpeg = jpeg
            self._frame_sequence += 1
            self._last_error = None
            self._condition.notify_all()

    def _run(self):
        frame_delay = (
            1.0 / COUNTING_TARGET_FPS
            if COUNTING_TARGET_FPS > 0
            else 0.0
        )

        try:
            # Models are loaded only because Monitoring has been started and a
            # CountingWorker now exists. Only the custom BOX YOLO is loaded.
            # Normal camera streaming does not start the counting model.
            get_box_model()

            camera = self._load_camera()
            self._refresh_counting_lines(force=True)

            if not self._counting_lines:
                raise ValueError(
                    "No active counting line configured for this camera."
                )

            _ensure_camera_state(self.camera_id)

            print(
                "[COUNTING] Worker started | "
                f"camera={self.camera_name} id={self.camera_id} "
                f"lines={len(self._counting_lines)}"
            )

            while self._running:
                loop_started = time.monotonic()

                try:
                    finalize_expired_window(self.camera_id)
                    self._refresh_counting_lines()

                    frame = get_shared_camera_frame(
                        camera,
                        wait_timeout=2.0,
                    )
                    if frame is None:
                        time.sleep(0.03)
                        continue

                    now = time.monotonic()
                    if (
                        self._counting_lines
                        and now - self._last_detection_time
                        >= COUNTING_DETECTION_INTERVAL_SEC
                        and not self._detection_running
                    ):
                        self._last_detection_time = now
                        self._detection_running = True
                        inference_frame = frame.copy()

                        threading.Thread(
                            target=self._detect_async,
                            args=(inference_frame,),
                            daemon=True,
                            name=f"counting-inference-{self.camera_id}",
                        ).start()

                    with self._result_lock:
                        boxes = [dict(item) for item in self._last_boxes]

                    annotated = self._draw_annotated_frame(
                        frame,
                        boxes,
                    )
                    self._publish(annotated)

                except Exception as error:
                    with self._condition:
                        self._last_error = str(error)
                        self._condition.notify_all()

                    print(
                        "[COUNTING ERROR] "
                        f"camera={self.camera_name} id={self.camera_id} | {error}"
                    )
                    time.sleep(0.25)

                if frame_delay > 0:
                    elapsed = time.monotonic() - loop_started
                    remaining = frame_delay - elapsed
                    if remaining > 0:
                        time.sleep(remaining)
                else:
                    time.sleep(0.01)

        except Exception as error:
            with self._condition:
                self._last_error = str(error)
                self._condition.notify_all()

            print(
                "[COUNTING START ERROR] "
                f"camera={self.camera_name} id={self.camera_id} | {error}"
            )

        finally:
            self._running = False
            with self._condition:
                self._condition.notify_all()

            print(
                "[COUNTING] Worker stopped | "
                f"camera={self.camera_name} id={self.camera_id}"
            )

    def wait_for_jpeg(
        self,
        previous_sequence: int = 0,
        timeout: float = 1.0,
    ):
        deadline = time.monotonic() + max(float(timeout), 0.0)

        with self._condition:
            while (
                self._running
                and (
                    self._latest_jpeg is None
                    or self._frame_sequence <= previous_sequence
                )
            ):
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return None, previous_sequence
                self._condition.wait(timeout=remaining)

            if self._latest_jpeg is None:
                return None, previous_sequence

            return self._latest_jpeg, self._frame_sequence

    def stop(self, join_timeout: float = 3.0):
        self._running = False
        with self._condition:
            self._condition.notify_all()

        if (
            self._thread.is_alive()
            and threading.current_thread() is not self._thread
        ):
            self._thread.join(timeout=join_timeout)


# =============================================================================
# WORKER CONTROL
# =============================================================================


def _get_camera_for_counting(camera_id: int):
    db = get_db_session()
    try:
        camera = (
            db.query(Camera)
            .filter(
                Camera.id == int(camera_id),
                Camera.is_active == True,
            )
            .first()
        )

        if camera is None:
            raise ValueError(
                f"Camera {camera_id} not found or inactive."
            )

        db.expunge(camera)
        return camera
    finally:
        db.close()


def start_counting_camera(camera_id: int) -> dict:
    camera_id = int(camera_id)

    with _counting_workers_lock:
        existing = _counting_workers.get(camera_id)
        if existing is not None and existing.is_running:
            return {
                "camera_id": camera_id,
                "monitoring": True,
                "running": True,
                "message": "Counting already running.",
            }

    # No hardcoded fallback. Monitoring cannot start until at least one active
    # line is configured for the selected camera.
    lines = get_counting_lines(camera_id)
    if not lines:
        raise ValueError(
            f"No active counting line configured for camera {camera_id}. "
            "Create a line in Zones & Lines first."
        )

    camera = _get_camera_for_counting(camera_id)

    # Every Monitoring ON session begins with fresh live cards. Previous history
    # remains in CountingSummary.
    _reset_camera_state(camera_id)

    worker = CountingWorker(camera)

    with _counting_workers_lock:
        old_worker = _counting_workers.get(camera_id)
        if old_worker is not None and old_worker is not worker:
            old_worker.stop()
        _counting_workers[camera_id] = worker

    return {
        "camera_id": camera_id,
        "monitoring": True,
        "running": worker.is_running,
        "line_count": len(lines),
        "message": "Counting monitoring started.",
    }


def stop_counting_camera(camera_id: int) -> dict:
    camera_id = int(camera_id)

    with _counting_workers_lock:
        worker = _counting_workers.pop(camera_id, None)

    if worker is not None:
        worker.stop()

    # Save a partial interval only when it contains at least one valid crossing.
    try:
        with _state_lock:
            state = _camera_states.get(camera_id)
            has_count = bool(state and int(state.get("interval_total_count", 0)) > 0)

        if has_count:
            finalize_window(camera_id)
    finally:
        # After Monitoring OFF the live cards are no longer an active session.
        with _state_lock:
            _camera_states.pop(camera_id, None)

    return {
        "camera_id": camera_id,
        "monitoring": False,
        "running": False,
        "message": "Counting monitoring stopped.",
    }


def start_counting_monitoring(camera_ids: list[int]) -> dict:
    selected = []
    seen = set()

    for value in camera_ids or []:
        camera_id = int(value)
        if camera_id in seen:
            continue
        seen.add(camera_id)
        selected.append(camera_id)

    selected_set = set(selected)

    with _counting_workers_lock:
        current_set = set(_counting_workers.keys())

    # Stop cameras removed from the current Monitoring selection.
    for camera_id in current_set - selected_set:
        stop_counting_camera(camera_id)

    camera_results = []
    for camera_id in selected:
        camera_results.append(start_counting_camera(camera_id))

    active_camera_ids = [
        item["camera_id"]
        for item in camera_results
        if item.get("running")
    ]

    return {
        "monitoring": bool(active_camera_ids),
        "camera_ids": active_camera_ids,
        "camera_count": len(active_camera_ids),
        "cameras": camera_results,
    }


def stop_counting_monitoring(
    camera_ids: list[int] | None = None,
) -> dict:
    if camera_ids is None or len(camera_ids) == 0:
        with _counting_workers_lock:
            targets = list(_counting_workers.keys())
    else:
        targets = list(
            dict.fromkeys(int(value) for value in camera_ids)
        )

    for camera_id in targets:
        stop_counting_camera(camera_id)

    with _counting_workers_lock:
        active_camera_ids = [
            camera_id
            for camera_id, worker in _counting_workers.items()
            if worker.is_running
        ]

    return {
        "monitoring": bool(active_camera_ids),
        "stopped_camera_ids": targets,
        "active_camera_ids": active_camera_ids,
    }


def get_counting_monitoring_status() -> dict:
    with _counting_workers_lock:
        workers = list(_counting_workers.items())

    cameras = []
    for camera_id, worker in workers:
        cameras.append(
            {
                "camera_id": camera_id,
                "camera_name": worker.camera_name,
                "running": worker.is_running,
                "last_error": worker.last_error,
                "line_count": len(worker._counting_lines),
            }
        )

    active_camera_ids = [
        item["camera_id"]
        for item in cameras
        if item["running"]
    ]

    return {
        "monitoring": bool(active_camera_ids),
        "active_camera_ids": active_camera_ids,
        "cameras": cameras,
    }


# =============================================================================
# MJPEG COUNTING STREAM
# =============================================================================


def generate_counting_stream(camera_id: int):
    camera_id = int(camera_id)

    with _counting_workers_lock:
        worker = _counting_workers.get(camera_id)

    if worker is None or not worker.is_running:
        raise RuntimeError(
            "Counting monitoring is not active "
            f"for camera {camera_id}."
        )

    previous_sequence = 0

    try:
        while True:
            jpeg, previous_sequence = worker.wait_for_jpeg(
                previous_sequence=previous_sequence,
                timeout=1.0,
            )

            if jpeg is None:
                if not worker.is_running:
                    break
                time.sleep(0.05)
                continue

            yield (
                b"--frame\r\n"
                b"Content-Type: image/jpeg\r\n\r\n"
                + jpeg
                + b"\r\n"
            )

    except GeneratorExit:
        pass


# =============================================================================
# SHUTDOWN
# =============================================================================


def shutdown_all_counting_workers():
    with _counting_workers_lock:
        workers = list(_counting_workers.values())
        _counting_workers.clear()

    for worker in workers:
        try:
            worker.stop()
        except Exception as error:
            print(
                "[WARN] Could not stop Counting worker "
                f"{worker.camera_id}: {error}"
            )
