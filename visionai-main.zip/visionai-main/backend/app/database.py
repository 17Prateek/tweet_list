from __future__ import annotations

import logging
import os
from contextlib import contextmanager
from typing import Generator

from dotenv import load_dotenv
from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    create_engine,
    text,
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker
from sqlalchemy.sql import func


# =========================================================
# Environment / logging
# =========================================================

load_dotenv()

logger = logging.getLogger(__name__)


# =========================================================
# Database URL
# =========================================================

DATABASE_URL = os.getenv("DATABASE_URL", "").strip()

if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL not found in .env file")


# =========================================================
# Engine
# =========================================================

def _build_engine():
    """
    Build an engine that works for:
      - local SQLite development
      - MySQL/PostgreSQL production/server

    pool_pre_ping=True:
        checks pooled connections before use and helps recover
        stale/disconnected DB connections.

    pool_recycle:
        useful for MySQL/cPanel/VPS environments where idle
        connections may be dropped by the server.
    """

    common_kwargs = {
        "pool_pre_ping": True,
        "future": True,
    }

    # ---------------------------------------------
    # SQLite local development
    # ---------------------------------------------
    if DATABASE_URL.lower().startswith("sqlite"):
        return create_engine(
            DATABASE_URL,
            connect_args={
                "check_same_thread": False,
            },
            **common_kwargs,
        )

    # ---------------------------------------------
    # Server databases
    # ---------------------------------------------
    pool_size = max(
        1,
        int(
            os.getenv(
                "DB_POOL_SIZE",
                "10",
            )
        ),
    )

    max_overflow = max(
        0,
        int(
            os.getenv(
                "DB_MAX_OVERFLOW",
                "20",
            )
        ),
    )

    pool_timeout = max(
        1,
        int(
            os.getenv(
                "DB_POOL_TIMEOUT_SEC",
                "30",
            )
        ),
    )

    pool_recycle = max(
        60,
        int(
            os.getenv(
                "DB_POOL_RECYCLE_SEC",
                "1800",
            )
        ),
    )

    return create_engine(
        DATABASE_URL,
        pool_size=pool_size,
        max_overflow=max_overflow,
        pool_timeout=pool_timeout,
        pool_recycle=pool_recycle,
        **common_kwargs,
    )


engine = _build_engine()


# =========================================================
# Session factory
# =========================================================

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    expire_on_commit=False,
    bind=engine,
)


Base = declarative_base()


# =========================================================
# Models
# =========================================================

class User(Base):
    __tablename__ = "users"

    email = Column(String(150), primary_key=True, index=True)
    employee_id = Column(String(80), nullable=False)
    full_name = Column(String(150), nullable=False)
    mobile = Column(String(20), nullable=False)
    department = Column(String(100), nullable=False)
    password_hash = Column(String(255), nullable=False)

    role = Column(
        String(30),
        nullable=False,
        default="user",
        index=True,
    )

    is_active = Column(
        Boolean,
        nullable=False,
        default=True,
    )

    last_login = Column(
        DateTime(timezone=True),
        nullable=True,
    )

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
    )

    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
    )


class LoginOTP(Base):
    __tablename__ = "login_otps"

    id = Column(
        Integer,
        primary_key=True,
        index=True,
    )

    email = Column(
        String(150),
        nullable=False,
        index=True,
    )

    purpose = Column(
        String(30),
        nullable=False,
        default="login",
        server_default="login",
        index=True,
    )

    otp_hash = Column(
        String(255),
        nullable=False,
    )

    expires_at = Column(
        DateTime(timezone=True),
        nullable=False,
    )

    is_used = Column(
        Boolean,
        nullable=False,
        default=False,
        server_default="false",
        index=True,
    )

    created_at = Column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )


class CameraGroup(Base):
    __tablename__ = "camera_groups"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False)
    description = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    cameras = relationship(
        "Camera",
        back_populates="group",
    )


class Camera(Base):
    __tablename__ = "cameras"

    id = Column(Integer, primary_key=True, index=True)
    camera_name = Column(String(150), nullable=False)
    source_type = Column(String(20), nullable=False)

    rtsp_url = Column(Text, nullable=True)
    webcam_index = Column(Integer, nullable=True)
    usb_index = Column(Integer, nullable=True)

    group_id = Column(
        Integer,
        ForeignKey("camera_groups.id"),
        nullable=True,
    )

    location = Column(String(150), nullable=True)
    status = Column(String(30), default="offline")
    is_recording = Column(Boolean, default=False)
    last_seen_at = Column(DateTime(timezone=True), nullable=True)
    is_active = Column(Boolean, default=True)

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
    )

    updated_at = Column(
        DateTime(timezone=True),
        onupdate=func.now(),
    )

    group = relationship(
        "CameraGroup",
        back_populates="cameras",
    )


class Department(Base):
    __tablename__ = "departments"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class RoleAccess(Base):
    __tablename__ = "role_access"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class FaceEnrollmentPerson(Base):
    __tablename__ = "face_enrollment_persons"

    id = Column(Integer, primary_key=True, index=True)

    full_name = Column(String(150), nullable=False, index=True)
    employee_id = Column(String(80), unique=True, nullable=False, index=True)

    department = Column(String(100), nullable=False, index=True)
    role = Column(String(100), nullable=False, index=True)

    mobile = Column(String(30), nullable=True)
    email = Column(String(150), nullable=True)

    # SQL <-> face_db.pkl connection key
    pickle_key = Column(
        String(100),
        unique=True,
        nullable=False,
        index=True,
    )

    camera_id = Column(Integer, nullable=True)
    camera_name = Column(String(150), nullable=True)

    total_images = Column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
    )

    primary_quality_score = Column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
    )

    primary_face_path = Column(Text, nullable=True)

    # Active / inactive
    is_active = Column(
        Boolean,
        nullable=False,
        default=True,
        server_default="true",
        index=True,
    )

    # For Enrolled Persons later
    is_archived = Column(
        Boolean,
        nullable=False,
        default=False,
        server_default="false",
        index=True,
    )

    archived_at = Column(
        DateTime(timezone=True),
        nullable=True,
    )

    last_seen_at = Column(
        DateTime(timezone=True),
        nullable=True,
    )

    recognition_count = Column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
    )

    created_at = Column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        index=True,
    )

    updated_at = Column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        onupdate=func.now(),
    )


class EmailAlertHistory(Base):
    __tablename__ = "email_alert_history"

    id = Column(Integer, primary_key=True, index=True)

    camera_id = Column(Integer, nullable=False)
    camera_name = Column(String(150), nullable=False)
    camera_location = Column(String(150), nullable=True)

    person_name = Column(String(150), nullable=True)
    employee_id = Column(String(80), nullable=True)

    event_type = Column(String(100), nullable=False)

    helmet = Column(Boolean, nullable=False)
    vest = Column(Boolean, nullable=False)

    evidence_image = Column(Text, nullable=True)

    recipients = Column(Text, nullable=False)

    email_status = Column(
        String(30),
        nullable=False,
        default="Sent",
    )

    email_sent_at = Column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        index=True,
    )

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
    )

class CameraCurrentIssue(Base):
    __tablename__ = "camera_current_issues"

    id = Column(Integer, primary_key=True, index=True)

    camera_id = Column(
        Integer,
        ForeignKey("cameras.id"),
        nullable=False,
    )

    issue_type = Column(String(80), nullable=False)
    severity = Column(String(30), nullable=False)
    title = Column(String(150), nullable=False)
    description = Column(Text, nullable=True)
    recommendation = Column(Text, nullable=True)
    status = Column(String(30), default="open")
    details = Column(Text, nullable=True)

    first_detected_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
    )

    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
    )

    camera = relationship("Camera")

    __table_args__ = (
        UniqueConstraint(
            "camera_id",
            name="uq_camera_current_issue_camera_id",
        ),
    )


class EmailRecipient(Base):
    __tablename__ = "email_recipients"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(150), nullable=False)
    name = Column(String(150), nullable=False)
    position = Column(String(150), nullable=False)

    alert_type = Column(
        String(80),
        nullable=False,
        default="All Alerts",
    )

    status = Column(
        String(30),
        nullable=False,
        default="Active",
    )

    is_active = Column(Boolean, default=True)

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
    )

    updated_at = Column(
        DateTime(timezone=True),
        onupdate=func.now(),
    )


class EmailAlertSetting(Base):
    __tablename__ = "email_alert_settings"

    id = Column(Integer, primary_key=True, default=1)

    enabled = Column(
        Boolean,
        nullable=False,
        default=True,
    )

    frequency_minutes = Column(
        Integer,
        nullable=False,
        default=5,
    )

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
    )

    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
    )


class LiveEvent(Base):
    __tablename__ = "live_events"

    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(String(80), unique=True, nullable=False)

    camera_id = Column(
        Integer,
        ForeignKey("cameras.id"),
        nullable=False,
    )

    frame_id = Column(Integer, nullable=False)
    camera_name = Column(String(150), nullable=False)
    camera_location = Column(String(150), nullable=True)
    event_type = Column(String(100), nullable=False)

    person_name = Column(String(150), nullable=True)
    person_id = Column(String(80), nullable=True)

    helmet = Column(String(10), nullable=False, default="No")
    vest = Column(String(10), nullable=False, default="No")
    face_match = Column(String(10), nullable=False, default="No")

    evidence_image = Column(Text, nullable=True)

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
    )

    camera = relationship("Camera")


class CameraZone(Base):
    """
    A named area drawn on one camera's picture: gate, weighbridge, yard,
    a loading bay, a restricted area. polygon_json holds [[x, y], ...] with
    x/y as fractions 0..1 of the frame, so it survives resolution changes.
    limit_sec is the "too long" threshold for that zone (None = no limit).
    """
    __tablename__ = "camera_zones"

    id = Column(Integer, primary_key=True, index=True)
    site_id = Column(Integer, nullable=True)
    camera_id = Column(Integer, ForeignKey("cameras.id"), nullable=False, index=True)
    name = Column(String(150), nullable=False)
    zone_type = Column(String(40), nullable=False, default="custom")
    polygon_json = Column(Text, nullable=False)
    limit_sec = Column(Integer, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class Episode(Base):
    """
    One thing-in-progress seen by a camera: a PPE violation, a person in a
    restricted zone, a vehicle sitting in a bay, a camera gone offline.
    Exactly one row per episode; started_at..ended_at is its life on camera,
    status is the human side (open -> acknowledged -> resolved / false_positive).
    """
    __tablename__ = "episodes"

    id = Column(Integer, primary_key=True, index=True)
    episode_id = Column(String(80), unique=True, nullable=False, index=True)
    site_id = Column(Integer, nullable=True)

    camera_id = Column(Integer, ForeignKey("cameras.id"), nullable=False, index=True)
    camera_name = Column(String(150), nullable=False)
    camera_location = Column(String(150), nullable=True)
    zone_id = Column(Integer, nullable=True)
    zone_name = Column(String(150), nullable=True)

    kind = Column(String(40), nullable=False, index=True)
    title = Column(String(200), nullable=False)
    subject_type = Column(String(20), nullable=False, default="unknown")
    subject_label = Column(String(150), nullable=False, default="Unknown")
    subject_id = Column(String(80), nullable=True)

    severity = Column(String(20), nullable=False, default="warning", index=True)
    status = Column(String(20), nullable=False, default="open", index=True)

    started_at = Column(DateTime(timezone=True), nullable=False, index=True)
    last_seen_at = Column(DateTime(timezone=True), nullable=False)
    ended_at = Column(DateTime(timezone=True), nullable=True)

    acknowledged_by = Column(String(150), nullable=True)
    acknowledged_at = Column(DateTime(timezone=True), nullable=True)
    resolved_by = Column(String(150), nullable=True)
    resolved_at = Column(DateTime(timezone=True), nullable=True)
    resolve_note = Column(Text, nullable=True)

    evidence_first = Column(Text, nullable=True)
    evidence_last = Column(Text, nullable=True)
    people_count = Column(Integer, nullable=False, default=1)
    attributes_json = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    camera = relationship("Camera")


class CountingSetting(Base):
    __tablename__ = "counting_settings"

    id = Column(Integer, primary_key=True, default=1)
    interval_minutes = Column(Integer, nullable=False, default=5, server_default="5")
    updated_at = Column(DateTime(timezone=True), nullable=False, server_default=func.now(), onupdate=func.now())


class CountingSummary(Base):
    __tablename__ = "counting_summaries"

    id = Column(
        Integer,
        primary_key=True,
        index=True,
    )

    record_id = Column(
        String(100),
        unique=True,
        nullable=False,
        index=True,
    )

    # -----------------------------------------------------
    # Camera
    # -----------------------------------------------------

    camera_id = Column(
        Integer,
        ForeignKey("cameras.id"),
        nullable=False,
        index=True,
    )

    camera_name = Column(
        String(150),
        nullable=False,
    )

    camera_location = Column(
        String(150),
        nullable=True,
    )

    # -----------------------------------------------------
    # Counting line used
    # -----------------------------------------------------

    line_id = Column(
        Integer,
        ForeignKey("camera_counting_lines.id"),
        nullable=True,
        index=True,
    )

    line_name = Column(
        String(150),
        nullable=True,
    )

    # -----------------------------------------------------
    # Interval
    # -----------------------------------------------------

    start_time = Column(
        DateTime(timezone=True),
        nullable=False,
        index=True,
    )

    end_time = Column(
        DateTime(timezone=True),
        nullable=False,
        index=True,
    )

    interval_minutes = Column(
        Integer,
        nullable=False,
        default=5,
        server_default="5",
    )

    # -----------------------------------------------------
    # Counts
    # -----------------------------------------------------

    bag_count = Column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
    )

    box_count = Column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
    )

    total_count = Column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
    )

    # -----------------------------------------------------
    # Crossing direction
    #
    # ltr = Left -> Right
    # rtl = Right -> Left
    # -----------------------------------------------------

    direction = Column(
        String(30),
        nullable=True,
    )

    # -----------------------------------------------------
    # Face image
    #
    # Store face crop image path/URL.
    # Frontend Labor Carry Events "Face" column can use this.
    # -----------------------------------------------------

    face_image = Column(
        Text,
        nullable=True,
    )

    # -----------------------------------------------------
    # Evidence image
    #
    # Full frame at/around crossing.
    # -----------------------------------------------------

    evidence_image = Column(
        Text,
        nullable=True,
    )

    status = Column(
        String(30),
        nullable=False,
        default="Completed",
        server_default="Completed",
        index=True,
    )

    created_at = Column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        index=True,
    )

    camera = relationship(
        "Camera"
    )

    line = relationship(
        "CameraCountingLine"
    )

    __table_args__ = (
        UniqueConstraint(
            "camera_id",
            "start_time",
            "end_time",
            name="uq_counting_summary_camera_window",
        ),
    )


class CameraCountingLine(Base):
    """
    Directional counting line configured for one camera.

    Coordinates are normalized 0.0 -> 1.0 so the line keeps the
    same position even when the camera/frame resolution changes.

    direction:
        ltr = Left -> Right
        rtl = Right -> Left
    """

    __tablename__ = "camera_counting_lines"

    id = Column(
        Integer,
        primary_key=True,
        index=True,
    )

    camera_id = Column(
        Integer,
        ForeignKey("cameras.id"),
        nullable=False,
        index=True,
    )

    name = Column(
        String(150),
        nullable=False,
    )

    # Normalized line points
    x1 = Column(
        Float,
        nullable=False,
    )

    y1 = Column(
        Float,
        nullable=False,
    )

    x2 = Column(
        Float,
        nullable=False,
    )

    y2 = Column(
        Float,
        nullable=False,
    )

    # ltr = Left -> Right
    # rtl = Right -> Left
    direction = Column(
        String(10),
        nullable=False,
        default="ltr",
        server_default="ltr",
        index=True,
    )

    # Frontend line appearance
    color = Column(
        String(20),
        nullable=False,
        default="#1683ff",
        server_default="#1683ff",
    )

    line_width = Column(
        Integer,
        nullable=False,
        default=4,
        server_default="4",
    )

    show_arrows = Column(
        Boolean,
        nullable=False,
        default=True,
        server_default="1",
    )

    show_label = Column(
        Boolean,
        nullable=False,
        default=True,
        server_default="1",
    )

    is_active = Column(
        Boolean,
        nullable=False,
        default=True,
        server_default="1",
        index=True,
    )

    created_at = Column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    updated_at = Column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        onupdate=func.now(),
    )

    camera = relationship("Camera")




class FaceRecognitionEvent(Base):
    __tablename__ = "face_recognition_events"

    id = Column(Integer, primary_key=True, index=True)

    event_type = Column(
        String(50),
        nullable=False,
        index=True,
    )

    person_id = Column(
        Integer,
        ForeignKey("face_enrollment_persons.id"),
        nullable=True,
    )

    person_name = Column(String(150), nullable=True)
    employee_id = Column(String(80), nullable=True)

    camera_id = Column(
        Integer,
        ForeignKey("cameras.id"),
        nullable=True,
    )

    camera_name = Column(String(150), nullable=True)

    similarity_score = Column(Float, nullable=True)
    confidence = Column(Float, nullable=True)
    quality_score = Column(Integer, nullable=True)

    reason = Column(Text, nullable=True)

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
    )


# =========================================================
# Table creation
# ====================================================

def create_tables():
    """
    Create missing tables.

    NOTE:
    main.py should catch exceptions around startup create_tables()
    if you want FastAPI to remain alive while the DB is temporarily
    unavailable.
    """
    Base.metadata.create_all(
        bind=engine
    )


# =========================================================
# Session helpers
# =========================================================

def get_db_session():
    """
    Return a new DB session.

    Existing service code can continue using:

        db = get_db_session()
        try:
            ...
        finally:
            db.close()
    """
    return SessionLocal()


def safe_rollback(db) -> None:
    """
    Best-effort rollback.

    Database transaction failure should remain local to that request/
    worker instead of cascading into unrelated services.
    """
    if db is None:
        return

    try:
        db.rollback()
    except Exception:
        logger.exception(
            "Database rollback failed"
        )


def safe_close(db) -> None:
    """
    Best-effort session close.
    """
    if db is None:
        return

    try:
        db.close()
    except Exception:
        logger.exception(
            "Database session close failed"
        )


@contextmanager
def db_session_scope() -> Generator:
    """
    Optional context-managed session.

    Example:

        with db_session_scope() as db:
            db.add(...)

    Commit is automatic on success.
    Rollback is automatic on exception.
    """
    db = SessionLocal()

    try:
        yield db
        db.commit()

    except Exception:
        safe_rollback(db)
        raise

    finally:
        safe_close(db)


def get_db():
    """
    Optional FastAPI dependency.

    Example:

        def endpoint(db=Depends(get_db)):
            ...
    """
    db = SessionLocal()

    try:
        yield db
    finally:
        safe_close(db)


# =========================================================
# Database health
# =========================================================

def check_database_health() -> dict:
    """
    Lightweight DB health check.

    Returns a dictionary instead of crashing the application.
    """

    db = SessionLocal()

    try:
        db.execute(
            text("SELECT 1")
        )

        return {
            "ok": True,
            "error": None,
        }

    except Exception as exc:
        logger.exception(
            "Database health check failed"
        )

        safe_rollback(db)

        return {
            "ok": False,
            "error": str(exc),
        }

    finally:
        safe_close(db)