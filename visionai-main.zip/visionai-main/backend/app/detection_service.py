import os

from dotenv import load_dotenv

# Load environment configuration before importing ML/native libraries.
# This keeps the same code compatible with local Windows and Linux/VPS.
load_dotenv()

# Conservative defaults for low-process/thread hosting. Values explicitly set
# in .env or the service environment are preserved.
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("TF_NUM_INTRAOP_THREADS", "1")
os.environ.setdefault("TF_NUM_INTEROP_THREADS", "1")

import time
import json
import math
import pickle
import shutil
import threading
from pathlib import Path
from datetime import datetime
from collections import deque, Counter
from typing import Dict, List, Tuple, Optional

import cv2
import numpy as np
import torch
import tensorflow as tf

# Keep native library thread pools small on the VPS/cPanel account.
try:
    cv2.setNumThreads(int(os.getenv("OPENCV_NUM_THREADS", "1")))
except Exception:
    cv2.setNumThreads(1)

try:
    torch.set_num_threads(int(os.getenv("TORCH_NUM_THREADS", "1")))
except Exception as error:
    print(f"[WARN] Could not set torch num threads: {error}")

try:
    torch.set_num_interop_threads(int(os.getenv("TORCH_NUM_INTEROP_THREADS", "1")))
except RuntimeError:
    # PyTorch only allows this before inter-op work has started.
    pass
except Exception as error:
    print(f"[WARN] Could not set torch interop threads: {error}")

try:
    tf.config.threading.set_intra_op_parallelism_threads(
        int(os.getenv("TF_NUM_INTRAOP_THREADS", "1"))
    )
    tf.config.threading.set_inter_op_parallelism_threads(
        int(os.getenv("TF_NUM_INTEROP_THREADS", "1"))
    )
except RuntimeError:
    # TensorFlow may already be initialized if this module is imported late.
    pass
except Exception as error:
    print(f"[WARN] Could not set TensorFlow thread limits: {error}")

from ultralytics import YOLO

from app import face_model
from app.camera_management import (
    get_shared_camera_frame,
    update_camera_recording_status,
)
from app.camera_issue_service import upsert_camera_issue, clear_camera_issue
from app.database import get_db_session, Camera
from app.live_event_service import save_evidence_image, EVIDENCE_DIR
from app.email_service import process_violation_observation
from app import episodes
from app import yard

BASE_DIR = Path(__file__).resolve().parent.parent


# =========================================================
# Models
# =========================================================
PERSON_MODEL_PATH = os.getenv("PERSON_MODEL_PATH")
PPE_MODEL_PATH = os.getenv("PPE_MODEL_PATH")
YUNET_MODEL_PATH = os.getenv("YUNET_MODEL_PATH")
FACE_DB_PATH = os.getenv("FACE_DB_PATH")


def validate_model_paths():
    required_paths = {
        "PERSON_MODEL_PATH": PERSON_MODEL_PATH,
        "PPE_MODEL_PATH": PPE_MODEL_PATH,
        "YUNET_MODEL_PATH": YUNET_MODEL_PATH,
        "FACE_DB_PATH": FACE_DB_PATH,
    }

    missing_env = [
        name
        for name, path in required_paths.items()
        if not path
    ]

    if missing_env:
        raise RuntimeError(
            "Missing model path environment variables: "
            + ", ".join(missing_env)
        )


validate_model_paths()

# =========================================================
# Detection settings
# =========================================================
# How sure YOLO must be to call something a person / a helmet or vest.
# Tunable from .env so detection can be tightened or loosened without a deploy.
PERSON_CONF = float(os.getenv("PERSON_CONF", "0.70"))
PPE_CONF = float(os.getenv("PPE_CONF", "0.15"))

# When on, run the person model at a lower floor and log EVERY candidate with
# its confidence, while still only acting on those >= PERSON_CONF. This shows
# what score the people we are missing actually get, so PERSON_CONF can be set
# from real data. Off by default (noisy).
DETECT_DEBUG_SCORES = os.getenv("DETECT_DEBUG_SCORES", "0").strip() in ("1", "true", "yes")
DETECT_DEBUG_FLOOR = float(os.getenv("DETECT_DEBUG_FLOOR", "0.15"))

IMG_SIZE = 640
STREAM_WIDTH = 640
JPEG_QUALITY = 70

# AI runs independently from the live camera stream. The camera can remain
# smooth while inference runs at a lower rate. Values can be tuned in .env.
DETECTION_INTERVAL_SEC = float(os.getenv("DETECTION_INTERVAL_SEC", "0.7"))
FACE_INTERVAL_SEC = float(os.getenv("FACE_INTERVAL_SEC", "1.0"))
FACE_RECOGNITION_ALWAYS = os.getenv("FACE_RECOGNITION_ALWAYS", "0").strip() in ("1", "true", "yes")
# When on, log each face's best match score + threshold + result, for tuning
# RECOGNITION_THRESHOLD from real data. Off by default (noisy).
FACE_DEBUG_SCORES = os.getenv("FACE_DEBUG_SCORES", "0").strip() in ("1", "true", "yes")

# Classes
PERSON_CLASS_ID = 0

# COCO vehicle classes the person model already recognises. Kept from the
# same inference pass (no second model) and handed to the yard engine.
VEHICLE_CLASS_IDS = {2: "car", 3: "motorcycle", 5: "bus", 7: "truck"}
VEHICLE_CONF = float(os.getenv("VEHICLE_CONF", "0.50"))
VEST_CLASS_ID = 0
HELMET_CLASS_ID = 1

# PPE matching logic
PERSON_BOX_PAD = 0.08
IOU_THRESHOLD = 0.15

# Face recognition settings
FACE_CONF_THRESHOLD = 0.80
FACE_NMS_THRESHOLD = 0.3
FACE_TOP_K = 5000
TARGET_FACE_SIZE = 160
FACE_PADDING_RATIO = 0.15
MIN_FACE_WIDTH = 40
MIN_FACE_HEIGHT = 40
MIN_BLUR_SCORE = 20.0
# SFace cosine "same person" cut-off. OpenCV's reference is 0.363; 0.38 is a
# touch stricter (fewer false matches). Tune in .env without a code change.
RECOGNITION_THRESHOLD = float(os.getenv("RECOGNITION_THRESHOLD", "0.38"))
RECOGNIZE_EVERY_N_FRAMES = 1
UNKNOWN_LABEL = "Monitoring"

# Face track stability
HISTORY_SIZE = 6
MIN_VOTES_FOR_STABLE = 1
TRACK_MAX_MISSING_FRAMES = 20
TRACK_MATCH_DISTANCE_PX = 120

# Recording. Recording reuses the central shared camera worker instead of
# opening a second RTSP/FFmpeg capture.
RECORDING_FPS = float(os.getenv("RECORDING_FPS", "10"))
RECORDINGS_DIR = BASE_DIR / "recordings"
RECORDINGS_DIR.mkdir(parents=True, exist_ok=True)

# =========================================================
# Globals
# =========================================================
person_model = None
ppe_model = None
face_embedder = None
face_database = None
face_database_mtime = None
face_detector = None

# Keep your YOLO behavior safe
model_lock = threading.Lock()

# Separate face lock so face recognition does not block YOLO
face_model_lock = threading.Lock()

# camera_id -> stats
detection_stats = {}

# Per-frame detection control.
# Key: (camera_id, frame_id)
# True  -> YOLO + face recognition + event/email processing enabled
# False -> camera stream stays live, but all detection side effects are disabled
detection_control_states = {}
detection_control_lock = threading.RLock()

# Only one physical camera may run YOLO + face recognition at a time.
# All other connected cameras continue streaming raw frames.
active_detection_camera_id = None
active_detection_frame_id = None

# Shared detection output workers.
# Key: (camera_id, frame_id, ppe_filter)
shared_detection_workers = {}
shared_detection_workers_lock = threading.RLock()

# camera_id -> recording state
recording_states = {}
recording_workers = {}
recording_locks = {}

# Violation incidents - two events per episode, not one per frame.
#
# The first frame where a person is seen without PPE on a camera opens an
# "incident" and saves ONE live event with a picture. While that violation
# keeps being seen nothing else is written. Once the camera has not seen it
# for INCIDENT_GRACE_SEC (the person left, or put the PPE on, or the detector
# blinked) the incident closes and ONE closing event is saved carrying the
# total duration and the last picture. A violation that comes back after the
# grace period is a new incident.
INCIDENT_GRACE_SEC = float(os.getenv("VISIONAI_INCIDENT_GRACE_SEC", "120"))
INCIDENT_SWEEP_SEC = 5.0

# A violation must be seen continuously for this long before an incident
# opens. Two reasons: a one-frame flicker (shadow, reflection) never becomes
# an alert, and face recognition gets a couple of passes in first, so the
# opening alert usually carries the person's name instead of "Unknown".
INCIDENT_CONFIRM_SEC = float(os.getenv("VISIONAI_INCIDENT_CONFIRM_SEC", "3"))
INCIDENT_CONFIRM_GAP_SEC = 2.0
_pending_incidents = {}

# After a failed database save, wait this long before trying that incident
# again. Retrying on the very next frame is what filled the disk on 11 Sep.
EVENT_SAVE_RETRY_SEC = 30.0

# Severity given to PPE episodes on the Ops Board ("critical" | "warning" | "notice").
PPE_EPISODE_SEVERITY = os.getenv("VISIONAI_PPE_SEVERITY", "warning").strip().lower() or "warning"

# live_events.frame_id is an integer column; the 24/7 monitor has no tile
# number, so its events are stored under frame 0.
MONITOR_DB_FRAME_ID = 0

# Evidence retention. Pictures older than EVIDENCE_KEEP_DAYS are removed by
# an hourly sweep, and no new picture is written when free disk space drops
# under EVIDENCE_MIN_FREE_GB - the event row is still saved, just without an
# image, so alerts keep flowing while the disk is protected.
EVIDENCE_KEEP_DAYS = int(os.getenv("VISIONAI_EVIDENCE_KEEP_DAYS", "14"))
EVIDENCE_MIN_FREE_GB = float(os.getenv("VISIONAI_EVIDENCE_MIN_FREE_GB", "10"))
EVIDENCE_SWEEP_SEC = 3600.0

# (camera_id, person key) -> open incident
_incidents = {}
_incidents_lock = threading.Lock()
_incident_sweeper_started = False
_event_save_failures = {}
_last_evidence_sweep = 0.0

# Email alert evidence snapshots. Each active violation reuses one file,
# refreshed at a controlled interval so the video loop is not writing a JPEG
# on every frame.
EMAIL_EVIDENCE_DIR = BASE_DIR / "email_evidence"
EMAIL_EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
EMAIL_EVIDENCE_REFRESH_SEC = 2.0
email_evidence_times = {}
email_evidence_lock = threading.Lock()


# =========================================================
# Model loading
# =========================================================
def get_models():
    global person_model, ppe_model

    with model_lock:
        if person_model is None:
            print("[INFO] Loading person model:", PERSON_MODEL_PATH)
            person_model = YOLO(str(PERSON_MODEL_PATH))
            print("[INFO] Person model classes:", person_model.names)

        if ppe_model is None:
            print("[INFO] Loading PPE model:", PPE_MODEL_PATH)
            ppe_model = YOLO(str(PPE_MODEL_PATH))
            print("[INFO] PPE model classes:", ppe_model.names)

    return person_model, ppe_model


def get_face_models():
    global face_embedder
    global face_database
    global face_database_mtime
    global face_detector

    with face_model_lock:
        if face_embedder is None:
            print("[INFO] Loading SFace recognizer...")
            face_embedder = face_model.get_recognizer()
            print("[INFO] SFace recognizer loaded")

        current_mtime = None

        if FACE_DB_PATH and os.path.exists(FACE_DB_PATH):
            try:
                current_mtime = os.path.getmtime(FACE_DB_PATH)
            except OSError:
                current_mtime = None

        should_reload_face_db = (
            face_database is None
            or current_mtime != face_database_mtime
        )

        if should_reload_face_db:
            print("[INFO] Loading face database:", FACE_DB_PATH)

            if not FACE_DB_PATH or not os.path.exists(FACE_DB_PATH):
                print("[WARN] face_db.pkl not found. Face DB is empty.")
                face_database = {}
                face_database_mtime = None

            else:
                try:
                    with open(FACE_DB_PATH, "rb") as f:
                        loaded_db = pickle.load(f)

                    if not isinstance(loaded_db, dict):
                        raise ValueError(
                            "face_db.pkl must contain a dictionary"
                        )

                    face_database = loaded_db
                    face_database_mtime = current_mtime

                except Exception as error:
                    print(
                        "[WARN] Could not reload face_db.pkl:",
                        error,
                    )

                    # Keep old in-memory DB if reload fails.
                    if face_database is None:
                        face_database = {}

            print(f"[INFO] Face DB loaded: {len(face_database)} people")

        if face_detector is None:
            print("[INFO] Loading YuNet face detector:", YUNET_MODEL_PATH)

            if not os.path.exists(YUNET_MODEL_PATH):
                raise FileNotFoundError(
                    f"YuNet model not found: {YUNET_MODEL_PATH}"
                )

            face_detector = cv2.FaceDetectorYN.create(
                str(YUNET_MODEL_PATH),
                "",
                (320, 320),
                score_threshold=FACE_CONF_THRESHOLD,
                nms_threshold=FACE_NMS_THRESHOLD,
                top_k=FACE_TOP_K,
            )

            print("[INFO] YuNet detector loaded")

    return face_embedder, face_database, face_detector


# =========================================================
# Camera latest frame reader
# =========================================================
class LatestFrameCamera:
    """Compatibility wrapper backed by the central shared camera worker.

    It does not open its own VideoCapture/FFmpeg process. If legacy code still
    creates LatestFrameCamera, it simply refreshes from get_shared_camera_frame.
    """

    def __init__(self, camera):
        self.camera = camera
        self.latest_frame = None
        self.running = True
        self.lock = threading.Lock()

        self.thread = threading.Thread(
            target=self._reader,
            daemon=True,
            name=f"latest-frame-{int(camera.id)}",
        )
        self.thread.start()

    def _reader(self):
        while self.running:
            frame = get_shared_camera_frame(self.camera, wait_timeout=0.5)

            if frame is None:
                time.sleep(0.03)
                continue

            with self.lock:
                self.latest_frame = frame

            time.sleep(0.01)

    def read(self):
        with self.lock:
            if self.latest_frame is None:
                return None
            return self.latest_frame.copy()

    def release(self):
        self.running = False

        if (
            self.thread.is_alive()
            and threading.current_thread() is not self.thread
        ):
            self.thread.join(timeout=2.0)


# =========================================================
# Common helpers
# =========================================================
def resize_frame(frame, width=STREAM_WIDTH):
    h, w = frame.shape[:2]

    if w <= width:
        return frame

    scale = width / float(w)

    return cv2.resize(
        frame,
        (int(w * scale), int(h * scale)),
    )


def clip_box(box, frame_shape):
    h, w = frame_shape[:2]
    x1, y1, x2, y2 = box

    x1 = max(0, min(int(x1), w - 1))
    y1 = max(0, min(int(y1), h - 1))
    x2 = max(0, min(int(x2), w - 1))
    y2 = max(0, min(int(y2), h - 1))

    return x1, y1, x2, y2


def expand_box(box, frame_shape, pad_ratio=PERSON_BOX_PAD):
    x1, y1, x2, y2 = box

    bw = x2 - x1
    bh = y2 - y1

    pad_x = int(bw * pad_ratio)
    pad_y = int(bh * pad_ratio)

    return clip_box(
        (x1 - pad_x, y1 - pad_y, x2 + pad_x, y2 + pad_y),
        frame_shape,
    )


def get_center(box):
    x1, y1, x2, y2 = box
    return ((x1 + x2) // 2, (y1 + y2) // 2)


def point_inside_box(px, py, box):
    x1, y1, x2, y2 = box
    return x1 <= px <= x2 and y1 <= py <= y2


def iou(box_a, box_b):
    ax1, ay1, ax2, ay2 = box_a
    bx1, by1, bx2, by2 = box_b

    inter_x1 = max(ax1, bx1)
    inter_y1 = max(ay1, by1)
    inter_x2 = min(ax2, bx2)
    inter_y2 = min(ay2, by2)

    inter_w = max(0, inter_x2 - inter_x1)
    inter_h = max(0, inter_y2 - inter_y1)
    inter_area = inter_w * inter_h

    area_a = max(0, ax2 - ax1) * max(0, ay2 - ay1)
    area_b = max(0, bx2 - bx1) * max(0, by2 - by1)

    denom = area_a + area_b - inter_area

    if denom <= 0:
        return 0.0

    return inter_area / denom


def box_center_distance(box_a, box_b):
    ax, ay = get_center(box_a)
    bx, by = get_center(box_b)

    return math.sqrt((ax - bx) ** 2 + (ay - by) ** 2)


# =========================================================
# Coordinate scaling helpers
# =========================================================
def scale_box_from_shape(box, src_shape, dst_shape):
    """
    Convert a box from one frame coordinate system to another.

    Example:
        face model runs on original frame 1920x1080
        display frame is 640x360
        face box must be scaled before drawing/matching on display frame.
    """
    src_h, src_w = src_shape[:2]
    dst_h, dst_w = dst_shape[:2]

    if src_w <= 0 or src_h <= 0:
        return box

    scale_x = dst_w / float(src_w)
    scale_y = dst_h / float(src_h)

    x1, y1, x2, y2 = box

    return clip_box(
        (
            int(x1 * scale_x),
            int(y1 * scale_y),
            int(x2 * scale_x),
            int(y2 * scale_y),
        ),
        dst_shape,
    )


def scale_point_from_shape(point, src_shape, dst_shape):
    src_h, src_w = src_shape[:2]
    dst_h, dst_w = dst_shape[:2]

    if src_w <= 0 or src_h <= 0:
        return point

    scale_x = dst_w / float(src_w)
    scale_y = dst_h / float(src_h)

    px, py = point

    return int(px * scale_x), int(py * scale_y)


def scale_face_tracks_to_frame(face_tracks, src_shape, dst_shape):
    """
    Face tracker stays in original/full-frame coordinates.
    This function creates a display-copy in 640-frame coordinates.
    Do not mutate original tracker data, otherwise tracking becomes wrong.
    """
    scaled_tracks = {}

    for track_id, track in face_tracks.items():
        scaled_track = dict(track)

        if track.get("box"):
            scaled_track["box"] = scale_box_from_shape(
                track["box"],
                src_shape,
                dst_shape,
            )

        if track.get("center"):
            scaled_track["center"] = scale_point_from_shape(
                track["center"],
                src_shape,
                dst_shape,
            )

        scaled_tracks[track_id] = scaled_track

    return scaled_tracks


# =========================================================
# PPE/person YOLO
# =========================================================
def run_yolo_detection(frame):
    """Persons + PPE, as always. Vehicles are dropped here; the monitor uses _full."""
    persons, ppe_objects, _vehicles = run_yolo_detection_full(frame)
    return persons, ppe_objects


def run_yolo_detection_full(frame, camera_id=None):
    person_model, ppe_model = get_models()

    persons = []
    ppe_objects = []
    vehicles = []

    total_start = time.perf_counter()

    lock_wait_start = time.perf_counter()

    with model_lock:
        lock_acquired_at = time.perf_counter()

        lock_wait_seconds = (
            lock_acquired_at - lock_wait_start
        )

        person_start = time.perf_counter()

        # One floor for the model; each class is then filtered against its
        # own cut-off below (PERSON_CONF for people, VEHICLE_CONF for
        # vehicles). Running at conf=PERSON_CONF here used to hide every
        # vehicle between VEHICLE_CONF and PERSON_CONF.
        person_results = person_model.predict(
            source=frame,
            conf=min(
                PERSON_CONF,
                VEHICLE_CONF,
                DETECT_DEBUG_FLOOR if DETECT_DEBUG_SCORES else 1.0,
            ),
            imgsz=IMG_SIZE,
            classes=[PERSON_CLASS_ID, *VEHICLE_CLASS_IDS],
            verbose=False,
        )

        person_prediction_seconds = (
            time.perf_counter() - person_start
        )

        ppe_start = time.perf_counter()

        ppe_results = ppe_model.predict(
            source=frame,
            conf=PPE_CONF,
            imgsz=IMG_SIZE,
            verbose=False,
        )

        ppe_prediction_seconds = (
            time.perf_counter() - ppe_start
        )

    postprocess_start = time.perf_counter()

    debug_person_seen = [] if DETECT_DEBUG_SCORES else None

    for result in person_results:
        if result.boxes is None:
            continue

        for box in result.boxes:
            conf = float(box.conf[0].item())
            cls_id = int(box.cls[0].item())

            x1, y1, x2, y2 = map(
                int,
                box.xyxy[0].tolist(),
            )

            if cls_id != PERSON_CLASS_ID:
                if cls_id in VEHICLE_CLASS_IDS and conf >= VEHICLE_CONF:
                    vehicles.append(
                        {
                            "cls": VEHICLE_CLASS_IDS[cls_id],
                            "conf": conf,
                            "box": (x1, y1, x2, y2),
                        }
                    )
                continue

            if debug_person_seen is not None:
                debug_person_seen.append(
                    f"{conf:.2f}({x2 - x1}x{y2 - y1})"
                )

            # Below the real cut-off: only ever seen for debugging, never acted on.
            if conf < PERSON_CONF:
                continue

            persons.append(
                {
                    "label": "Person",
                    "conf": conf,
                    "box": (x1, y1, x2, y2),
                    "helmet": False,
                    "vest": False,
                    "face_name": UNKNOWN_LABEL,
                    "employee_id": "N/A",
                    "face_score": -1.0,
                }
            )

    if debug_person_seen is not None:
        print(
            f"[DETECT] persons kept={len(persons)} (conf>={PERSON_CONF:.2f}) | "
            f"all candidates: {', '.join(debug_person_seen) if debug_person_seen else 'none'}"
        )

    for result in ppe_results:
        if result.boxes is None:
            continue

        for box in result.boxes:
            cls_id = int(box.cls[0].item())
            conf = float(box.conf[0].item())

            x1, y1, x2, y2 = map(
                int,
                box.xyxy[0].tolist(),
            )

            if cls_id == HELMET_CLASS_ID:
                label = "Helmet"
                color = (0, 255, 0)

            elif cls_id == VEST_CLASS_ID:
                label = "Vest"
                color = (255, 0, 0)

            else:
                continue

            ppe_objects.append(
                {
                    "label": label,
                    "conf": conf,
                    "box": (x1, y1, x2, y2),
                    "color": color,
                }
            )

    persons = assign_ppe_to_persons(
        persons=persons,
        ppe_objects=ppe_objects,
        frame_shape=frame.shape,
    )

    postprocess_seconds = (
        time.perf_counter() - postprocess_start
    )

    total_seconds = (
        time.perf_counter() - total_start
    )

    actual_prediction_seconds = (
        person_prediction_seconds
        + ppe_prediction_seconds
    )

    print(
        "[YOLO TIMING] "
        f"thread={threading.current_thread().name} | "
        f"lock_wait={lock_wait_seconds:.3f}s | "
        f"person_predict={person_prediction_seconds:.3f}s | "
        f"ppe_predict={ppe_prediction_seconds:.3f}s | "
        f"prediction_total={actual_prediction_seconds:.3f}s | "
        f"postprocess={postprocess_seconds:.3f}s | "
        f"total={total_seconds:.3f}s"
    )

    return persons, ppe_objects, vehicles


def assign_ppe_to_persons(persons, ppe_objects, frame_shape):
    for person in persons:
        person_box = expand_box(person["box"], frame_shape)

        px1, py1, px2, py2 = person_box

        head_region = (
            px1,
            py1,
            px2,
            py1 + max(1, (py2 - py1) // 3),
        )

        helmet_found = False
        vest_found = False

        for obj in ppe_objects:
            obj_box = obj["box"]
            cx, cy = get_center(obj_box)

            if obj["label"] == "Helmet":
                if (
                    point_inside_box(cx, cy, head_region)
                    or iou(obj_box, head_region) > IOU_THRESHOLD
                ):
                    helmet_found = True

            elif obj["label"] == "Vest":
                if (
                    point_inside_box(cx, cy, person_box)
                    or iou(obj_box, person_box) > IOU_THRESHOLD
                ):
                    vest_found = True

        person["helmet"] = helmet_found
        person["vest"] = vest_found

    return persons


# =========================================================
# Face recognition helpers from your test code
# =========================================================
def clamp_face_box(x1, y1, x2, y2, frame_w, frame_h):
    x1 = max(0, min(int(x1), frame_w - 1))
    y1 = max(0, min(int(y1), frame_h - 1))
    x2 = max(1, min(int(x2), frame_w))
    y2 = max(1, min(int(y2), frame_h))
    return x1, y1, x2, y2


def build_square_crop_box(
    fx1,
    fy1,
    fx2,
    fy2,
    frame_w,
    frame_h,
    padding_ratio,
):
    bw = fx2 - fx1
    bh = fy2 - fy1

    cx = (fx1 + fx2) / 2.0
    cy = (fy1 + fy2) / 2.0

    side = int(max(bw, bh) * (1.0 + 2.0 * padding_ratio))
    side = max(side, TARGET_FACE_SIZE)

    x1 = int(cx - side / 2)
    y1 = int(cy - side / 2)
    x2 = x1 + side
    y2 = y1 + side

    if x1 < 0:
        x2 -= x1
        x1 = 0
    if y1 < 0:
        y2 -= y1
        y1 = 0
    if x2 > frame_w:
        shift = x2 - frame_w
        x1 -= shift
        x2 = frame_w
    if y2 > frame_h:
        shift = y2 - frame_h
        y1 -= shift
        y2 = frame_h

    return clamp_face_box(x1, y1, x2, y2, frame_w, frame_h)


def variance_of_laplacian(image_bgr):
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
    return float(cv2.Laplacian(gray, cv2.CV_64F).var())


def extract_landmarks(face_row):
    pts = []
    for i in range(4, 14, 2):
        pts.append((int(face_row[i]), int(face_row[i + 1])))

    return pts


def align_face_by_eyes(face_bgr, landmarks_global, crop_x1, crop_y1):
    if len(landmarks_global) < 2:
        return face_bgr

    right_eye_global = landmarks_global[0]
    left_eye_global = landmarks_global[1]

    rx = right_eye_global[0] - crop_x1
    ry = right_eye_global[1] - crop_y1
    lx = left_eye_global[0] - crop_x1
    ly = left_eye_global[1] - crop_y1

    dx = lx - rx
    dy = ly - ry

    if dx == 0 and dy == 0:
        return face_bgr

    angle = math.degrees(math.atan2(dy, dx))
    h, w = face_bgr.shape[:2]
    center = (w // 2, h // 2)

    rot_mat = cv2.getRotationMatrix2D(center, angle, 1.0)

    return cv2.warpAffine(
        face_bgr,
        rot_mat,
        (w, h),
        flags=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_REPLICATE,
    )


def preprocess_face_for_facenet(face_bgr, input_size=TARGET_FACE_SIZE):
    face_rgb = cv2.cvtColor(face_bgr, cv2.COLOR_BGR2RGB)

    return cv2.resize(
        face_rgb,
        (input_size, input_size),
        interpolation=cv2.INTER_CUBIC,
    )


def cosine_similarity(a, b):
    a = np.asarray(a, dtype=np.float32).flatten()
    b = np.asarray(b, dtype=np.float32).flatten()

    denom = np.linalg.norm(a) * np.linalg.norm(b)

    if denom == 0:
        return -1.0

    return float(np.dot(a, b) / denom)


def normalize_database_entry(employee_id, person_data):
    if isinstance(person_data, dict):
        embeddings = person_data.get("embeddings", [])
        label = (
            person_data.get("full_name")
            or person_data.get("employee_id")
            or employee_id
        )

        return {
            "employee_id": person_data.get("employee_id", employee_id),
            "full_name": label,
            "department": person_data.get("department"),
            "role": person_data.get("role"),
            "is_active": person_data.get("is_active", True),
            "embeddings": embeddings,
        }

    if isinstance(person_data, list):
        return {
            "employee_id": employee_id,
            "full_name": employee_id,
            "department": None,
            "role": None,
            "is_active": True,
            "embeddings": person_data,
        }

    return {
        "employee_id": employee_id,
        "full_name": employee_id,
        "department": None,
        "role": None,
        "is_active": True,
        "embeddings": [],
    }


def recognize_face(test_embedding, database, threshold):
    best_person = None
    best_score = -1.0

    test_embedding = np.asarray(test_embedding, dtype=np.float32).flatten()
    test_dim = test_embedding.size

    for employee_id, person_data in database.items():
        person = normalize_database_entry(employee_id, person_data)

        if not person.get("is_active", True):
            continue

        embeddings = person.get("embeddings", [])

        if not embeddings:
            continue

        local_best = -1.0

        for ref_emb in embeddings:
            try:
                ref_emb = np.asarray(ref_emb, dtype=np.float32).flatten()

                if ref_emb.size == 0:
                    continue

                # Skip embeddings of a different length (e.g. leftover 512-dim
                # FaceNet vectors after the SFace swap). Comparing across models
                # is meaningless; those people must be re-embedded once.
                if ref_emb.size != test_dim:
                    continue

                score = cosine_similarity(test_embedding, ref_emb)

                if score > local_best:
                    local_best = score

            except Exception as error:
                print(f"[WARN] Bad embedding skipped for {employee_id}: {error}")
                continue

        if local_best > best_score:
            best_score = local_best
            best_person = person

    if best_person is not None and best_score >= threshold:
        return best_person, best_score

    return None, best_score


def get_face_center(box):
    x1, y1, x2, y2 = box

    return ((x1 + x2) // 2, (y1 + y2) // 2)


def face_distance(p1, p2):
    return math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)


class SimpleFaceTracker:
    def __init__(
        self,
        max_missing_frames=TRACK_MAX_MISSING_FRAMES,
        match_distance_px=TRACK_MATCH_DISTANCE_PX,
    ):
        self.max_missing_frames = max_missing_frames
        self.match_distance_px = match_distance_px
        self.next_track_id = 1
        self.tracks = {}

    def _create_track(self, det, frame_index):
        track_id = self.next_track_id
        self.next_track_id += 1

        self.tracks[track_id] = {
            "box": det["box"],
            "center": det["center"],
            "missing": 0,
            "history": deque(maxlen=HISTORY_SIZE),
            "label": UNKNOWN_LABEL,
            "employee_id": "N/A",
            "score": -1.0,
            "last_blur": -1.0,
            "last_det_score": det.get("det_score", -1.0),
            "last_face_size": det.get("face_size", (0, 0)),
            "last_seen_frame": frame_index,
        }

    def update(self, detections, frame_index):
        for track_id in self.tracks:
            self.tracks[track_id]["missing"] += 1

        unmatched_detection_indices = set(range(len(detections)))
        track_ids = list(self.tracks.keys())

        pairs = []

        for track_id in track_ids:
            track_center = self.tracks[track_id]["center"]

            for det_idx, det in enumerate(detections):
                det_center = det["center"]
                dist = face_distance(track_center, det_center)
                pairs.append((dist, track_id, det_idx))

        pairs.sort(key=lambda x: x[0])

        used_tracks = set()
        used_dets = set()

        for dist, track_id, det_idx in pairs:
            if dist > self.match_distance_px:
                continue
            if track_id in used_tracks or det_idx in used_dets:
                continue
            if track_id not in self.tracks:
                continue

            det = detections[det_idx]

            self.tracks[track_id]["box"] = det["box"]
            self.tracks[track_id]["center"] = det["center"]
            self.tracks[track_id]["missing"] = 0
            self.tracks[track_id]["last_det_score"] = det.get("det_score", -1.0)
            self.tracks[track_id]["last_face_size"] = det.get("face_size", (0, 0))
            self.tracks[track_id]["last_seen_frame"] = frame_index

            used_tracks.add(track_id)
            used_dets.add(det_idx)
            unmatched_detection_indices.discard(det_idx)

        for det_idx in unmatched_detection_indices:
            det = detections[det_idx]
            self._create_track(det, frame_index)

        stale_ids = [
            tid
            for tid, tr in self.tracks.items()
            if tr["missing"] > self.max_missing_frames
        ]

        for tid in stale_ids:
            del self.tracks[tid]

        return self.tracks


def parse_faces_to_detections(faces, frame_w, frame_h):
    detections = []

    if faces is None or len(faces) == 0:
        return detections

    for face in faces:
        x, y, bw, bh = face[0:4]
        det_score = float(face[-1])

        if det_score < FACE_CONF_THRESHOLD:
            continue

        fx1 = max(0, int(x))
        fy1 = max(0, int(y))
        fx2 = min(frame_w, int(x + bw))
        fy2 = min(frame_h, int(y + bh))

        face_w = fx2 - fx1
        face_h = fy2 - fy1

        if face_w <= 0 or face_h <= 0:
            continue

        detections.append(
            {
                "face_row": face,
                "box": (fx1, fy1, fx2, fy2),
                "center": get_face_center((fx1, fy1, fx2, fy2)),
                "det_score": det_score,
                "face_size": (face_w, face_h),
            }
        )

    return detections


def assign_face_rows_to_tracks(tracks, detections):
    result = {}

    for track_id, track in tracks.items():
        tcenter = track["center"]

        best_idx = -1
        best_dist = float("inf")

        for i, det in enumerate(detections):
            dcenter = det["center"]
            dist = face_distance(tcenter, dcenter)

            if dist < best_dist:
                best_dist = dist
                best_idx = i

        if best_idx >= 0:
            result[track_id] = detections[best_idx]

    return result


def run_face_recognition(frame, tracker, frame_index):
    embedder, database, detector = get_face_models()

    clean_frame = frame.copy()
    frame_h, frame_w = clean_frame.shape[:2]

    with face_model_lock:
        detector.setInputSize((frame_w, frame_h))

        try:
            _, faces = detector.detect(clean_frame)
        except Exception as exc:
            print("[WARN] Face detection error:", exc)
            faces = None

        detections = parse_faces_to_detections(
            faces,
            frame_w,
            frame_h,
        )

        tracks = tracker.update(
            detections,
            frame_index,
        )

        track_to_det = assign_face_rows_to_tracks(
            tracks,
            detections,
        )

        for track_id, det in track_to_det.items():
            track = tracks[track_id]

            if track["missing"] > 0:
                continue

            face_row = det["face_row"]
            fx1, fy1, fx2, fy2 = det["box"]
            face_w, face_h = det["face_size"]
            det_score = det["det_score"]
            landmarks = extract_landmarks(face_row)

            track["last_det_score"] = det_score
            track["last_face_size"] = (face_w, face_h)

            if face_w < MIN_FACE_WIDTH or face_h < MIN_FACE_HEIGHT:
                track["label"] = UNKNOWN_LABEL
                track["employee_id"] = "N/A"
                track["score"] = -1.0
                track["last_blur"] = -1.0
                continue

            crop_x1, crop_y1, crop_x2, crop_y2 = build_square_crop_box(
                fx1,
                fy1,
                fx2,
                fy2,
                frame_w,
                frame_h,
                FACE_PADDING_RATIO,
            )

            raw_crop = clean_frame[crop_y1:crop_y2, crop_x1:crop_x2]

            if raw_crop.size == 0:
                track["label"] = UNKNOWN_LABEL
                track["employee_id"] = "N/A"
                track["score"] = -1.0
                track["last_blur"] = -1.0
                continue

            blur_score = variance_of_laplacian(raw_crop)
            track["last_blur"] = blur_score

            if blur_score >= MIN_BLUR_SCORE and frame_index % RECOGNIZE_EVERY_N_FRAMES == 0:
                # SFace aligns the face itself from the YuNet landmarks in the
                # raw face row (full-frame coordinates), so it takes the clean
                # frame + row directly - no manual crop/align/resize needed.
                try:
                    emb = face_model.embed_from_row(clean_frame, face_row)

                    pred_person, pred_score = recognize_face(
                        emb,
                        database,
                        threshold=RECOGNITION_THRESHOLD,
                    )

                    if pred_person:
                        pred_name = (
                            pred_person.get("full_name")
                            or pred_person.get("employee_id")
                            or UNKNOWN_LABEL
                        )
                        pred_employee_id = (
                            pred_person.get("employee_id")
                            or pred_person.get("employeeId")
                            or "N/A"
                        )
                    else:
                        pred_name = UNKNOWN_LABEL
                        pred_employee_id = "N/A"

                    if FACE_DEBUG_SCORES:
                        print(
                            f"[FACE] track {track_id} best={pred_score:.3f} "
                            f"thr={RECOGNITION_THRESHOLD:.2f} -> {pred_name} "
                            f"(face {face_w}x{face_h}, blur {blur_score:.0f})"
                        )

                    track["history"].append((pred_name, pred_employee_id, pred_score))

                except Exception as exc:
                    print(f"[WARN] Face recognition error on track {track_id}: {exc}")

            if len(track["history"]) > 0:
                names = [p[0] for p in track["history"]]
                most_common_name, vote_count = Counter(names).most_common(1)[0]
                same_name_scores = [
                    p[2] for p in track["history"] if p[0] == most_common_name
                ]
                same_name_employee_ids = [
                    p[1] for p in track["history"] if p[0] == most_common_name and p[1]
                ]

                avg_score = (
                    sum(same_name_scores) / len(same_name_scores)
                    if same_name_scores
                    else -1.0
                )

                if most_common_name != UNKNOWN_LABEL and vote_count >= MIN_VOTES_FOR_STABLE:
                    track["label"] = most_common_name
                    track["employee_id"] = same_name_employee_ids[0] if same_name_employee_ids else "N/A"
                    track["score"] = avg_score
                else:
                    track["label"] = UNKNOWN_LABEL
                    track["employee_id"] = "N/A"
                    track["score"] = avg_score
            else:
                track["label"] = UNKNOWN_LABEL
                track["employee_id"] = "N/A"
                track["score"] = -1.0

    return tracks


def assign_face_to_persons(persons, face_tracks):
    if not persons or not face_tracks:
        return persons

    for person in persons:
        person.setdefault("face_name", UNKNOWN_LABEL)
        person.setdefault("employee_id", "N/A")
        person.setdefault("face_score", -1.0)

    for _, track in face_tracks.items():
        if track.get("missing", 0) > 0:
            continue

        face_box = track.get("box")
        label = track.get("label", UNKNOWN_LABEL)
        employee_id = track.get("employee_id", "N/A")
        score = float(track.get("score", -1.0))

        if not face_box:
            continue

        best_idx = -1
        best_score = -1e9

        for idx, person in enumerate(persons):
            person_box = person["box"]

            fx, fy = get_center(face_box)

            inside_score = 1000 if point_inside_box(fx, fy, person_box) else 0
            dist_score = -box_center_distance(face_box, person_box)

            match_score = inside_score + dist_score

            if match_score > best_score:
                best_score = match_score
                best_idx = idx

        if best_idx >= 0:
            persons[best_idx]["face_name"] = label
            persons[best_idx]["employee_id"] = employee_id if label != UNKNOWN_LABEL else "N/A"
            persons[best_idx]["face_score"] = score

    return persons


# =========================================================
# Counts and drawing
# =========================================================
def calculate_counts(persons, ppe_filter="all"):
    """
    Count PPE violations only.

    Face-recognition status does not affect the violation count:
        helmet=True,  vest=True  -> compliant
        helmet=True,  vest=False -> violation
        helmet=False, vest=True  -> violation
        helmet=False, vest=False -> violation
    """
    persons_count = len(persons)
    violations_count = 0

    for person in persons:
        has_helmet = bool(person.get("helmet"))
        has_vest = bool(person.get("vest"))

        if not has_helmet or not has_vest:
            violations_count += 1

    return persons_count, violations_count



# =========================================================
# Live event saving helpers
# =========================================================
def get_event_type(person):
    """Return event type from PPE status only. Face status is not used."""
    has_helmet = bool(person.get("helmet"))
    has_vest = bool(person.get("vest"))

    if has_helmet and has_vest:
        return "Compliant"

    if has_helmet and not has_vest:
        return "Vest Violation"

    if not has_helmet and has_vest:
        return "Helmet Violation"

    return "Helmet and Vest Violation"


def normalize_event_person_name(face_name):
    """Return a stable person name used for duplicate-event comparison."""
    if face_name is None:
        return "unknown person"

    normalized_name = str(face_name).strip().lower()

    if not normalized_name or normalized_name in {
        str(UNKNOWN_LABEL).strip().lower(),
        "unknown",
        "unknown person",
        "monitoring",
        "n/a",
        "none",
        "null",
    }:
        return "unknown person"

    return normalized_name


def _db_frame_id(frame_id):
    """live_events.frame_id is an integer; the monitor's label is not."""
    try:
        return int(frame_id)
    except (TypeError, ValueError):
        return MONITOR_DB_FRAME_ID


def _evidence_disk_ok():
    try:
        usage = shutil.disk_usage(str(BASE_DIR))
    except OSError:
        return True

    return usage.free >= EVIDENCE_MIN_FREE_GB * (1024 ** 3)


def _format_duration(seconds):
    seconds = int(max(0, seconds))
    hours, rest = divmod(seconds, 3600)
    minutes, secs = divmod(rest, 60)

    if hours:
        return f"{hours}h {minutes:02d}m"

    if minutes:
        return f"{minutes}m {secs:02d}s"

    return f"{secs}s"


# Static "person" suppression - a person moves, a curtain does not.
#
# At night in infrared, curtain folds, coats on hooks, posters and mannequins
# can score as a person at the very same spot for minutes. Track each person
# box per camera; if a box stays in place AND the pixels inside it do not
# change for STATIC_PERSON_SEC, it is treated as furniture and ignored for
# alerts until it moves. A real worker standing at a bench still breathes,
# turns and shifts - the pixel test catches that even when the box does not.
STATIC_PERSON_SEC = float(os.getenv("VISIONAI_STATIC_PERSON_SEC", "45"))
STATIC_PERSON_IOU = 0.90
STATIC_PERSON_MOTION = float(os.getenv("VISIONAI_STATIC_PERSON_MOTION", "6.0"))
STATIC_TRACK_FORGET_SEC = 10.0
_static_tracks = {}
_static_lock = threading.Lock()


def _box_iou(a, b):
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    iw = max(0, min(ax2, bx2) - max(ax1, bx1))
    ih = max(0, min(ay2, by2) - max(ay1, by1))
    inter = iw * ih

    if inter <= 0:
        return 0.0

    union = (ax2 - ax1) * (ay2 - ay1) + (bx2 - bx1) * (by2 - by1) - inter
    return inter / union if union > 0 else 0.0


def _box_signature(frame, box):
    """Small grayscale thumbnail of the inner part of a box, for motion checks."""
    try:
        h, w = frame.shape[:2]
        x1, y1, x2, y2 = [int(v) for v in box]
        bw, bh = x2 - x1, y2 - y1

        if bw < 8 or bh < 8:
            return None

        # Inner 70% - avoids the box edge and any label drawn near the top.
        ix1 = max(0, x1 + int(bw * 0.15)); ix2 = min(w, x2 - int(bw * 0.15))
        iy1 = max(0, y1 + int(bh * 0.15)); iy2 = min(h, y2 - int(bh * 0.15))

        if ix2 - ix1 < 4 or iy2 - iy1 < 4:
            return None

        crop = frame[iy1:iy2, ix1:ix2]
        gray = crop.mean(axis=2) if crop.ndim == 3 else crop
        sy = max(1, gray.shape[0] // 64)
        sx = max(1, gray.shape[1] // 32)
        return gray[::sy, ::sx].astype(np.float32)
    except Exception:
        return None


def _signature_motion(a, b):
    if a is None or b is None or a.shape != b.shape:
        return None

    return float(np.mean(np.abs(a - b)))


def filter_static_persons(camera_id, persons, frame):
    """
    Return only the detections that are (or recently were) moving.
    Suppressed ones get person["static"] = True and are left out.
    """
    if not persons or frame is None or STATIC_PERSON_SEC <= 0:
        return persons

    now = time.monotonic()
    kept = []

    with _static_lock:
        tracks = _static_tracks.setdefault(int(camera_id), [])
        tracks[:] = [t for t in tracks if now - t["last"] <= STATIC_TRACK_FORGET_SEC]

        for person in persons:
            box = person.get("box")

            if not box:
                kept.append(person)
                continue

            match = None

            for track in tracks:
                if _box_iou(track["box"], box) >= STATIC_PERSON_IOU:
                    match = track
                    break

            signature = _box_signature(frame, box)

            if match is None:
                tracks.append({
                    "box": box,
                    "sig": signature,
                    "last": now,
                    "still_since": now,
                })
                kept.append(person)
                continue

            match["last"] = now
            motion = _signature_motion(signature, match["sig"])

            if motion is None or motion > STATIC_PERSON_MOTION:
                # Something changed inside the box - it is alive.
                match["still_since"] = now
                match["sig"] = signature
                match["box"] = box
                kept.append(person)
            elif now - match["still_since"] >= STATIC_PERSON_SEC:
                person["static"] = True
            else:
                kept.append(person)

    return kept


# Best evidence frame. A picture taken the instant an alert is confirmed can
# show the person half out of the frame; so while a violation is pending we
# keep the frame where the person is largest and not cut off at a side, and
# while it is open we keep the best frame of the last EVIDENCE_WINDOW_SEC.
EVIDENCE_WINDOW_SEC = 5.0
_pending_best = {}   # key -> (score, frame)


def _evidence_score(box, frame_shape=None):
    """Bigger is better; a box touching the left/right edge counts for much less."""
    try:
        x1, y1, x2, y2 = box
    except (TypeError, ValueError):
        return 0.0
    area = float(max(0, x2 - x1) * max(0, y2 - y1))
    if frame_shape is not None and len(frame_shape) >= 2 and frame_shape[1]:
        width = float(frame_shape[1])
        margin = max(2.0, width * 0.01)
        if x1 <= margin or x2 >= width - margin:
            area *= 0.3
    return area


def _ppe_title(event_type):
    """Plain-English episode title from the PPE event type."""
    text = str(event_type or "")
    lower = text.lower()
    if "helmet" in lower and "vest" in lower:
        return "Helmet and vest missing"
    if "helmet" in lower:
        return "Helmet missing"
    if "vest" in lower:
        return "Vest missing"
    return text


def _incident_key(camera_id, person_name):
    return (int(camera_id), normalize_event_person_name(person_name))


def camera_has_open_incident(camera_id):
    camera_id = int(camera_id)

    with _incidents_lock:
        return any(key[0] == camera_id for key in _incidents)


def _violation_confirmed(key, now_mono):
    """
    True once this violation has been seen continuously for
    INCIDENT_CONFIRM_SEC. Must be called with _incidents_lock held.
    """
    first_seen, last_seen = _pending_incidents.get(key, (None, None))

    # "Continuously" means no gap longer than a couple of seconds - a missed
    # frame or two is fine, a flicker minutes apart is not.
    if first_seen is None or now_mono - last_seen > INCIDENT_CONFIRM_GAP_SEC:
        _pending_incidents[key] = (now_mono, now_mono)
        return INCIDENT_CONFIRM_SEC <= 0

    _pending_incidents[key] = (first_seen, now_mono)
    return now_mono - first_seen >= INCIDENT_CONFIRM_SEC


def _close_incident(key, incident):
    duration = time.monotonic() - incident["opened_mono"]
    event_type = (
        f"{incident['event_type']} ended after {_format_duration(duration)}"
    )

    print(
        f"[INCIDENT] closed on {incident['camera_name']}: "
        f"{event_type} ({incident['person_name']})"
    )

    episode_id = incident.get("episode_id")
    if episode_id:
        episodes.close_episode(
            episode_id,
            frame=incident.get("last_frame") if _evidence_disk_ok() else None,
        )


def _sweep_incidents():
    """Close every incident whose violation has not been seen for a while."""
    now = time.monotonic()
    to_close = []

    with _incidents_lock:
        for key, (_, last_seen) in list(_pending_incidents.items()):
            if now - last_seen > INCIDENT_CONFIRM_GAP_SEC:
                _pending_incidents.pop(key, None)
                _pending_best.pop(key, None)

        for key, incident in list(_incidents.items()):
            if now - incident["last_seen_mono"] >= INCIDENT_GRACE_SEC:
                to_close.append((key, incident))
                _incidents.pop(key, None)

    for key, incident in to_close:
        try:
            _close_incident(key, incident)
        except Exception as exc:
            print("Incident close error:", exc)


def _sweep_evidence():
    """
    Hourly: delete evidence pictures older than EVIDENCE_KEEP_DAYS, except
    the pictures of episodes a person marked "keep" on the Ops Board.
    """
    global _last_evidence_sweep

    now = time.monotonic()

    if _last_evidence_sweep and now - _last_evidence_sweep < EVIDENCE_SWEEP_SEC:
        return

    _last_evidence_sweep = now
    cutoff = time.time() - EVIDENCE_KEEP_DAYS * 86400
    removed = 0

    try:
        kept = tuple(episodes.kept_episode_ids())
    except Exception as exc:
        # If the database is not reachable, keep everything - never delete blind.
        print("Evidence sweep skipped, could not read kept episodes:", exc)
        return

    try:
        for path in Path(EVIDENCE_DIR).glob("*.jpg"):
            try:
                if kept and path.name.startswith(kept):
                    continue
                if path.stat().st_mtime < cutoff:
                    path.unlink()
                    removed += 1
            except OSError:
                continue
    except Exception as exc:
        print("Evidence sweep error:", exc)
        return

    if removed:
        print(
            f"[EVIDENCE] removed {removed} picture(s) older than "
            f"{EVIDENCE_KEEP_DAYS} days"
        )


def _incident_sweeper_loop():
    while True:
        time.sleep(INCIDENT_SWEEP_SEC)

        try:
            _sweep_incidents()
        except Exception as exc:
            print("Incident sweep error:", exc)

        try:
            _sweep_evidence()
        except Exception as exc:
            print("Evidence sweep error:", exc)

        try:
            _reap_idle_detection_workers()
        except Exception as exc:
            print("Tile worker sweep error:", exc)

        try:
            yard.sweep_yard()
        except Exception as exc:
            print("Yard sweep error:", exc)

        # Camera-offline "Notice" episodes, only while monitoring is on and
        # only for cameras that are expected to be running.
        try:
            if is_monitoring_enabled():
                episodes.sweep_camera_health(is_watched=is_camera_monitored)
        except Exception as exc:
            print("Camera health sweep error:", exc)


def _ensure_incident_sweeper():
    global _incident_sweeper_started

    with _incidents_lock:
        if _incident_sweeper_started:
            return

        _incident_sweeper_started = True

    threading.Thread(
        target=_incident_sweeper_loop,
        daemon=True,
        name="incident-sweeper",
    ).start()


def get_open_incidents():
    """Currently open violation incidents, for /api/monitoring/status."""
    now = time.monotonic()

    with _incidents_lock:
        items = list(_incidents.items())

    return [
        {
            "camera_id": key[0],
            "camera_name": incident["camera_name"],
            "person_name": incident["person_name"],
            "event_type": incident["event_type"],
            "opened_at": incident["opened_at"].isoformat(),
            "duration_sec": int(now - incident["opened_mono"]),
        }
        for key, incident in items
    ]


def save_latest_email_evidence(
    camera_id,
    person_name,
    employee_id,
    helmet,
    vest,
    frame,
):
    """
    Save/refresh a stable JPEG path for the active email violation.

    The same camera/person/PPE combination overwrites the same file. This gives
    the background email worker a recent screenshot without blocking SMTP in
    the detection loop or creating unlimited files.
    """
    normalized_name = normalize_event_person_name(person_name)
    identity = (
        str(employee_id).strip().lower()
        if normalized_name != "unknown person" and employee_id and str(employee_id).strip() != "N/A"
        else normalized_name
    )
    safe_identity = "".join(
        ch if ch.isalnum() or ch in {"-", "_"} else "_"
        for ch in identity
    ).strip("_") or "unknown_person"

    evidence_key = (
        int(camera_id),
        identity,
        bool(helmet),
        bool(vest),
    )
    now = time.monotonic()

    with email_evidence_lock:
        last_saved = email_evidence_times.get(evidence_key)
        file_path = EMAIL_EVIDENCE_DIR / (
            f"camera_{int(camera_id)}_{safe_identity}_"
            f"helmet_{int(bool(helmet))}_vest_{int(bool(vest))}.jpg"
        )

        if (
            last_saved is not None
            and now - last_saved < EMAIL_EVIDENCE_REFRESH_SEC
            and file_path.exists()
        ):
            return str(file_path)

        try:
            ok = cv2.imwrite(str(file_path), frame)
            if not ok:
                print(f"[WARN] Could not save email evidence: {file_path}")
                return str(file_path) if file_path.exists() else None

            email_evidence_times[evidence_key] = now
            return str(file_path)

        except Exception as exc:
            print(f"[WARN] Email evidence save error: {exc}")
            return str(file_path) if file_path.exists() else None


def save_detection_events(camera, persons, frame, frame_id, frame_shape=None):
    """
    Feed every detected person into the email-alert tracker (unchanged) and
    into the incident model: one opening event when a violation starts on a
    camera, one closing event when it ends. Nothing is written in between,
    and compliant people are not logged at all.

    SMTP is never executed here. process_violation_observation() only updates
    state and queues a job when its 60-second rule is satisfied.
    """
    camera_id = int(camera.id)
    camera_name = camera.camera_name
    camera_location = camera.location or "N/A"
    now_mono = time.monotonic()
    violators_by_key = Counter()

    _ensure_incident_sweeper()

    for person in persons:
        face_name = person.get("face_name", UNKNOWN_LABEL)
        employee_id = person.get("employee_id", "N/A")
        helmet_status = bool(person.get("helmet"))
        vest_status = bool(person.get("vest"))
        normalized_name = normalize_event_person_name(face_name)
        is_recognized = normalized_name != "unknown person"
        event_type = get_event_type(person)

        is_ppe_violation = not helmet_status or not vest_status
        evidence_path = None

        if is_ppe_violation:
            evidence_path = save_latest_email_evidence(
                camera_id=camera_id,
                person_name=face_name,
                employee_id=employee_id,
                helmet=helmet_status,
                vest=vest_status,
                frame=frame,
            )

        # Always report the current PPE observation. A compliant observation
        # closes any previous active violation for this camera/person.
        # Face recognition only supplies person details; it never changes
        # the PPE event type or decides whether an email should be sent.
        try:
            process_violation_observation(
                camera_id=camera_id,
                camera_name=camera_name,
                camera_location=camera_location,
                person_name=(
                    face_name if is_recognized else "Unknown Person"
                ),
                employee_id=(
                    employee_id if is_recognized else "N/A"
                ),
                helmet=helmet_status,
                vest=vest_status,
                event_type=(event_type if is_ppe_violation else None),
                alert_type=("PPE Alerts" if is_ppe_violation else None),
                evidence_path=evidence_path,
            )
        except Exception as exc:
            # Email tracking must never stop the camera stream.
            print("Email violation observation error:", exc)

        if not is_ppe_violation:
            continue

        key = _incident_key(camera_id, face_name)
        person_name = face_name if is_recognized else "Unknown Person"
        person_id = employee_id if is_recognized else "N/A"
        violators_by_key[key] += 1
        score = _evidence_score(person.get("box"), frame_shape)

        still_going = False
        still_going_episode = None

        with _incidents_lock:
            incident = _incidents.get(key)

            if incident is not None:
                # Still going - remember the time, and the best recent picture
                # (not simply the latest, which may show the person leaving).
                incident["last_seen_mono"] = now_mono
                if (
                    now_mono - incident.get("best_mono", 0.0) > EVIDENCE_WINDOW_SEC
                    or score >= incident.get("best_score", 0.0)
                ):
                    incident["best_score"] = score
                    incident["best_mono"] = now_mono
                    incident["last_frame"] = frame
                still_going = True
                still_going_episode = incident.get("episode_id")

            else:
                # Keep tracking the pending violation even while a failed save
                # is backing off, so the incident opens as soon as the back-off ends.
                confirmed = _violation_confirmed(key, now_mono)
                failed_at = _event_save_failures.get(key)

                best = _pending_best.get(key)
                if best is None or score >= best[0]:
                    _pending_best[key] = (score, frame)

                if (
                    failed_at is not None
                    and now_mono - failed_at < EVENT_SAVE_RETRY_SEC
                ):
                    continue

                if not confirmed:
                    continue

                _pending_incidents.pop(key, None)
                best_score, best_frame = _pending_best.pop(key, (score, frame))
                if best_frame is None:
                    best_frame = frame

                # Register the incident before the (slow) database save so a
                # second detection thread on the same camera does not open it too.
                incident = {
                    "frame_id": frame_id,
                    "camera_name": camera_name,
                    "camera_location": camera_location,
                    "event_type": event_type,
                    "person_name": person_name,
                    "person_id": person_id,
                    "helmet": helmet_status,
                    "vest": vest_status,
                    "face_match": is_recognized,
                    "opened_at": datetime.now(),
                    "opened_mono": now_mono,
                    "last_seen_mono": now_mono,
                    "last_frame": best_frame,
                    "best_score": best_score,
                    "best_mono": now_mono,
                    "person_baseline": None,
                    "low_since": None,
                    "episode_id": None,
                }
                _incidents[key] = incident

        if still_going:
            # Touch outside the lock: a slow database must never stall
            # every camera thread waiting on _incidents_lock.
            if still_going_episode:
                episodes.touch_episode(still_going_episode)
            continue

        # The episode is the record (the old live_events row is gone; the
        # Live Events table reads episodes). Database row first, picture
        # second - see episodes.open_episode.
        episode_id = episodes.open_episode(
            camera_id=camera_id,
            camera_name=camera_name,
            camera_location=camera_location,
            kind="ppe_violation",
            title=_ppe_title(event_type),
            subject_type="person" if is_recognized else "unknown",
            subject_label=person_name,
            subject_id=person_id if is_recognized else None,
            severity=PPE_EPISODE_SEVERITY,
            frame=best_frame if _evidence_disk_ok() else None,
            attributes={"helmet": helmet_status, "vest": vest_status},
        )

        if episode_id:
            print(
                f"[INCIDENT] opened on {camera_name}: {event_type} "
                f"({person_name}) -> {episode_id}"
            )
            with _incidents_lock:
                if key in _incidents:
                    _incidents[key]["episode_id"] = episode_id
            continue

        # Save failed: forget the incident and back off before retrying.
        with _incidents_lock:
            _incidents.pop(key, None)
            _event_save_failures[key] = now_mono

    _record_new_arrivals(camera_id, frame_id, violators_by_key, frame, now_mono)


def _record_new_arrivals(camera_id, frame_id, violators_by_key, frame, now_mono):
    """
    One extra picture when another violator joins an open incident.

    The opening picture shows whoever was there at the start; someone who
    arrives later (and may leave again before the incident closes) would
    otherwise never be photographed. So: when the number of violators on the
    camera rises above the number in the last picture, save one event with
    a fresh picture. Bounded by arrivals, never by time or frames.

    Detector flicker is ignored: a drop in the count only lowers the
    baseline after it has held for INCIDENT_GRACE_SEC, so one person being
    missed for a few frames and re-found is not "a new arrival".
    """
    for key, count in violators_by_key.items():
        with _incidents_lock:
            incident = _incidents.get(key)

            if incident is None:
                continue

            baseline = incident.get("person_baseline")

            if baseline is None:
                # Just opened - the opening picture already shows this many.
                incident["person_baseline"] = count
                continue

            if count < baseline:
                if incident["low_since"] is None:
                    incident["low_since"] = now_mono
                elif now_mono - incident["low_since"] >= INCIDENT_GRACE_SEC:
                    incident["person_baseline"] = count
                    incident["low_since"] = None
                continue

            incident["low_since"] = None

            if count <= baseline:
                continue

            incident["person_baseline"] = count
            snapshot = dict(incident)

        event_type = f"{snapshot['event_type']} - {count} people now"

        print(f"[INCIDENT] {snapshot['camera_name']}: {event_type}")

        episode_id = snapshot.get("episode_id")
        if episode_id:
            episodes.touch_episode(
                episode_id,
                frame=frame if _evidence_disk_ok() else None,
                people_count=count,
            )


def draw_text_white_bg(
    frame,
    text,
    origin,
    font_scale=0.42,
    thickness=1,
    padding=4,
):
    """
    Draw readable black text on white background.
    """
    x, y = origin
    font = cv2.FONT_HERSHEY_SIMPLEX

    (text_w, text_h), baseline = cv2.getTextSize(
        text,
        font,
        font_scale,
        thickness,
    )

    frame_h, frame_w = frame.shape[:2]

    x = max(0, min(int(x), frame_w - text_w - (padding * 2) - 1))
    y = max(text_h + padding + 1, min(int(y), frame_h - baseline - padding - 1))

    bg_x1 = x
    bg_y1 = y - text_h - padding
    bg_x2 = x + text_w + (padding * 2)
    bg_y2 = y + baseline + padding

    cv2.rectangle(
        frame,
        (bg_x1, bg_y1),
        (bg_x2, bg_y2),
        (255, 255, 255),
        -1,
    )

    cv2.putText(
        frame,
        text,
        (x + padding, y),
        font,
        font_scale,
        (0, 0, 0),
        thickness,
        cv2.LINE_AA,
    )


def draw_detections(frame, persons, ppe_objects=None, ppe_filter="all", face_tracks=None):
    PERSON_BOX_COLOR = (255, 0, 0)  # Blue
    FACE_BOX_COLOR = (0, 255, 0)    # Green

    BOX_THICKNESS = 1
    FONT_SCALE = 0.50
    TEXT_THICKNESS = 1
    TEXT_PADDING = 2

    for person in persons:
        x1, y1, x2, y2 = person["box"]

        has_helmet = bool(person.get("helmet"))
        has_vest = bool(person.get("vest"))

        face_name = str(person.get("face_name", UNKNOWN_LABEL)).title()
        helmet_status = "Yes" if has_helmet else "No"
        vest_status = "Yes" if has_vest else "No"

        label = (
            f"Helmet:{helmet_status} | "
            f"Vest:{vest_status}"
        )

        cv2.rectangle(
            frame,
            (x1, y1),
            (x2, y2),
            PERSON_BOX_COLOR,
            BOX_THICKNESS,
        )

        draw_text_white_bg(
            frame,
            label,
            (x1, max(20, y1 - 6)),
            font_scale=FONT_SCALE,
            thickness=TEXT_THICKNESS,
            padding=TEXT_PADDING,
        )

    if face_tracks:
        for _, track in face_tracks.items():
            if track.get("missing", 0) > 0:
                continue

            face_box = track.get("box")
            if not face_box:
                continue

            x1, y1, x2, y2 = face_box
            name = str(track.get("label", UNKNOWN_LABEL)).title()

            cv2.rectangle(
                frame,
                (x1, y1),
                (x2, y2),
                FACE_BOX_COLOR,
                BOX_THICKNESS,
            )

            text_y = min(frame.shape[0] - 5, y2 + 14)

            draw_text_white_bg(
                frame,
                name,
                (x1, text_y),
                font_scale=FONT_SCALE,
                thickness=TEXT_THICKNESS,
                padding=TEXT_PADDING,
            )

    return frame


def draw_top_stats(frame, persons_count, violations_count, fps, recording):
    text = (
        f"Persons:{persons_count} | "
        f"Violations:{violations_count} | "
        f"FPS:{fps:.1f} | "
        f"REC:{'ON' if recording else 'OFF'}"
    )

    draw_text_white_bg(
        frame,
        text,
        (20, 25),
        font_scale=0.48,
        thickness=1,
        padding=5,
    )

    return frame


# =========================================================
# Per-frame detection control
# =========================================================
# ---------------------------------------------------------------------------
# Continuous monitoring
#
# Detection used to be exclusive: enabling one camera switched every other one
# off, because several YOLO loops at once would swamp a CPU-only machine. That
# is wrong for a site with cameras covering different areas - an alert from an
# unwatched camera is exactly the alert that matters.
#
# Instead, every monitored camera gets a worker, and they take turns through a
# single shared inference lock. One camera at a time still runs the model, so
# the CPU is never oversubscribed, but attention rotates across all of them
# instead of being pinned to one.
# ---------------------------------------------------------------------------

# The frame slot used by background monitoring, kept apart from the numbered
# slots the dashboard tiles use so the two never fight over the same key.
MONITOR_FRAME_ID = "monitor"

MONITOR_SUPERVISOR_INTERVAL_SEC = float(
    os.getenv("VISIONAI_MONITOR_INTERVAL_SEC", "10")
)

# Survives restarts, so "monitoring on" really means 24/7.
MONITOR_STATE_FILE = BASE_DIR / "monitoring_state.json"

_monitor_enabled = False

# Cameras deliberately left out of monitoring - a break room, a changing area,
# or simply somewhere the owner does not want analysed. Stored as exclusions so
# that a newly added camera is monitored by default.
_monitor_excluded = set()

_monitor_lock = threading.RLock()
_monitor_thread = None

# Only one camera runs inference at a time. This is what makes monitoring many
# cameras affordable on a CPU: they queue rather than compete.
_inference_lock = threading.Lock()


def _load_monitor_state():
    global _monitor_enabled

    global _monitor_excluded

    try:
        if MONITOR_STATE_FILE.exists():
            with open(MONITOR_STATE_FILE, "r", encoding="utf-8") as handle:
                saved = json.load(handle)

            _monitor_enabled = bool(saved.get("enabled"))
            _monitor_excluded = {
                int(x) for x in (saved.get("excluded_camera_ids") or [])
            }
    except Exception as error:
        print(f"[WARN] Could not read monitoring state: {error}")
        _monitor_enabled = False
        _monitor_excluded = set()

    return _monitor_enabled


def _save_monitor_state(enabled):
    try:
        with _monitor_lock:
            excluded = sorted(_monitor_excluded)

        with open(MONITOR_STATE_FILE, "w", encoding="utf-8") as handle:
            json.dump(
                {
                    "enabled": bool(enabled),
                    "excluded_camera_ids": excluded,
                    "updated_at": datetime.now().isoformat(),
                },
                handle,
            )
    except Exception as error:
        print(f"[WARN] Could not save monitoring state: {error}")


def is_camera_monitored(camera_id):
    """A camera is monitored unless it has been explicitly excluded."""
    with _monitor_lock:
        return int(camera_id) not in _monitor_excluded


def is_monitoring_enabled():
    with _monitor_lock:
        return bool(_monitor_enabled)


def _detection_control_key(camera_id, frame_id):
    return int(camera_id), str(frame_id)


def ensure_frame_detection_state(camera_id, frame_id, default_enabled=False):
    key = _detection_control_key(camera_id, frame_id)

    with detection_control_lock:
        state = detection_control_states.get(key)

        if state is None:
            state = {
                "camera_id": int(camera_id),
                "frame_id": str(frame_id),
                "enabled": bool(default_enabled),
                "updated_at": datetime.now().isoformat(),
            }
            detection_control_states[key] = state

        return dict(state)


def _camera_is_monitored_now(camera_id):
    try:
        return is_monitoring_enabled() and is_camera_monitored(camera_id)
    except Exception:
        return False


def is_frame_detection_enabled(camera_id, frame_id):
    # A dashboard tile showing a monitored camera shows the detector's view
    # (boxes, counts) without anyone pressing a per-tile Start button.
    if str(frame_id) != MONITOR_FRAME_ID and _camera_is_monitored_now(camera_id):
        return True

    state = ensure_frame_detection_state(
        camera_id=camera_id,
        frame_id=frame_id,
        default_enabled=False,
    )
    return bool(state["enabled"])


def frame_should_save_events(camera_id, frame_id):
    """
    Only one worker per camera writes events. While a camera is monitored
    that is the monitor worker; a tile on the same camera only draws.
    """
    if str(frame_id) == MONITOR_FRAME_ID:
        return True

    return not _camera_is_monitored_now(camera_id)


def set_frame_detection_enabled(camera_id, frame_id, enabled):
    """
    Enable/disable detection for one frame.

    While continuous monitoring is off this stays exclusive - enabling one
    camera disables the rest - because several YOLO loops at once would swamp a
    CPU-only machine. With monitoring on, cameras share the inference lock and
    take turns instead, so they are all allowed to stay enabled.

    Camera capture and raw streams are never stopped by this function.
    """
    global active_detection_camera_id
    global active_detection_frame_id

    camera_id = int(camera_id)
    frame_id = str(frame_id)
    enabled = bool(enabled)
    now_iso = datetime.now().isoformat()

    with detection_control_lock:
        if enabled and not is_monitoring_enabled():
            # Disable all other camera/frame detection states.
            for key, existing_state in list(detection_control_states.items()):
                other_camera_id, other_frame_id = key

                if (
                    int(other_camera_id) != camera_id
                    or str(other_frame_id) != frame_id
                ):
                    detection_control_states[key] = {
                        "camera_id": int(other_camera_id),
                        "frame_id": str(other_frame_id),
                        "enabled": False,
                        "updated_at": now_iso,
                    }

                    update_detection_stats(
                        camera_id=int(other_camera_id),
                        persons_count=0,
                        violations_count=0,
                        fps=0,
                    )

            active_detection_camera_id = camera_id
            active_detection_frame_id = frame_id

        elif (
            active_detection_camera_id == camera_id
            and str(active_detection_frame_id) == frame_id
        ):
            active_detection_camera_id = None
            active_detection_frame_id = None

        state = {
            "camera_id": camera_id,
            "frame_id": frame_id,
            "enabled": enabled,
            "updated_at": now_iso,
        }
        detection_control_states[(camera_id, frame_id)] = state

    if not enabled:
        # Clear visible stats immediately. Shared camera capture stays open.
        update_detection_stats(
            camera_id=camera_id,
            persons_count=0,
            violations_count=0,
            fps=0,
        )

    return dict(state)


def get_frame_detection_status(camera_id, frame_id):
    return ensure_frame_detection_state(
        camera_id=camera_id,
        frame_id=frame_id,
        default_enabled=False,
    )


# =========================================================
# Stats API helpers
# =========================================================
def update_detection_stats(camera_id, persons_count, violations_count, fps):
    detection_stats[camera_id] = {
        "camera_id": camera_id,
        "persons": persons_count,
        "violations": violations_count,
        "fps": round(float(fps), 1),
        "recording": bool(recording_states.get(camera_id, False)),
    }


def get_detection_stats(camera_id: int):
    return detection_stats.get(
        camera_id,
        {
            "camera_id": camera_id,
            "persons": 0,
            "violations": 0,
            "fps": 0,
            "recording": bool(recording_states.get(camera_id, False)),
        },
    )


# =========================================================
# Recording API helpers
# =========================================================
def _get_recording_lock(camera_id):
    camera_id = int(camera_id)

    if camera_id not in recording_locks:
        recording_locks[camera_id] = threading.Lock()

    return recording_locks[camera_id]


class CameraRecordingWorker:
    def __init__(self, camera):
        self.camera = camera
        self.camera_id = int(camera.id)

        self.running = True
        self.file_path = None
        self.error = None

        self.thread = threading.Thread(
            target=self._record_loop,
            daemon=True,
        )
        self.thread.start()

    def _record_loop(self):
        writer = None

        try:
            safe_fps = max(1.0, min(float(RECORDING_FPS), 30.0))

            # Reuse the same latest frame that powers live view and detection.
            # Do not open another RTSP/OpenCV/FFmpeg connection for recording.
            first_frame = get_shared_camera_frame(
                self.camera,
                wait_timeout=3.0,
            )

            if first_frame is None:
                self.error = "No shared camera frame received for recording"
                upsert_camera_issue(
                    self.camera_id,
                    "recording_failed",
                    {"error": self.error},
                )
                self.running = False
                return

            first_frame = resize_frame(first_frame)
            h, w = first_frame.shape[:2]

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_name = f"camera_{self.camera_id}_{timestamp}.avi"
            self.file_path = RECORDINGS_DIR / file_name

            fourcc = cv2.VideoWriter_fourcc(*"XVID")
            writer = cv2.VideoWriter(
                str(self.file_path),
                fourcc,
                safe_fps,
                (w, h),
            )

            if not writer.isOpened():
                self.error = "Could not create video writer"
                upsert_camera_issue(
                    self.camera_id,
                    "recording_failed",
                    {"error": self.error},
                )
                self.running = False
                self.file_path = None
                return

            writer.write(first_frame)

            frame_delay = 1.0 / safe_fps
            next_write_at = time.monotonic() + frame_delay

            while self.running:
                now = time.monotonic()
                wait_time = next_write_at - now

                if wait_time > 0:
                    time.sleep(min(wait_time, 0.05))
                    continue

                frame = get_shared_camera_frame(
                    self.camera,
                    wait_timeout=0.5,
                )

                if frame is None:
                    next_write_at = time.monotonic() + frame_delay
                    continue

                frame = resize_frame(frame)

                if frame.shape[1] != w or frame.shape[0] != h:
                    frame = cv2.resize(frame, (w, h))

                writer.write(frame)
                next_write_at = time.monotonic() + frame_delay

        except Exception as exc:
            self.error = str(exc)
            upsert_camera_issue(
                self.camera_id,
                "recording_failed",
                {"error": self.error},
            )

        finally:
            if writer is not None:
                writer.release()

            self.running = False

    def stop(self):
        self.running = False

        if self.thread.is_alive():
            self.thread.join(timeout=5.0)

        return self.file_path


def start_camera_recording(camera):
    camera_id = int(camera.id)

    with _get_recording_lock(camera_id):
        if recording_states.get(camera_id, False):
            return {
                "success": False,
                "status_code": 400,
                "message": "Recording already running",
            }

        worker = CameraRecordingWorker(camera)

        recording_workers[camera_id] = worker
        recording_states[camera_id] = True
        update_camera_recording_status(camera_id, True)
        clear_camera_issue(camera_id)

        if camera_id in detection_stats:
            detection_stats[camera_id]["recording"] = True

        return {
            "success": True,
            "message": "Recording started",
        }


def stop_camera_recording(camera_id: int):
    camera_id = int(camera_id)

    with _get_recording_lock(camera_id):
        worker = recording_workers.get(camera_id)

        if worker is None or not recording_states.get(camera_id, False):
            return {
                "success": False,
                "status_code": 400,
                "message": "Recording is not running",
            }

        video_path = worker.stop()

        recording_workers.pop(camera_id, None)
        recording_states[camera_id] = False
        update_camera_recording_status(camera_id, False)
        clear_camera_issue(camera_id)

        if camera_id in detection_stats:
            detection_stats[camera_id]["recording"] = False

        if not video_path:
            return {
                "success": False,
                "status_code": 400,
                "message": worker.error or "Recording stopped, but no video was created",
            }

        video_path = Path(video_path)

        if not video_path.exists() or video_path.stat().st_size <= 0:
            return {
                "success": False,
                "status_code": 400,
                "message": "Recording stopped, but video file is empty",
            }

        return {
            "success": True,
            "message": "Recording stopped",
            "file_path": str(video_path),
            "download_url": f"/recordings/{video_path.name}",
        }


# =========================================================
# Stream generator
# =========================================================
class SharedDetectionWorker:
    """
    One detection/render loop for one camera/frame/filter combination.

    Dashboard and Live Monitoring subscribers receive the same encoded MJPEG
    frames. YOLO, face recognition, event saving and email observation run only
    once, regardless of subscriber count.
    """

    def __init__(self, camera, ppe_filter="all", frame_id=1):
        self.camera = camera
        self.camera_id = int(camera.id)
        self.camera_name = str(camera.camera_name)
        self.frame_id = str(frame_id)
        self.ppe_filter = str(ppe_filter or "all")

        self.running = True
        self.last_error = None

        self.latest_jpeg = None
        self.frame_sequence = 0
        self.condition = threading.Condition(threading.RLock())

        # Browser viewers on this worker. A tile worker with no viewers is
        # retired after VIEWER_IDLE_STOP_SEC; the 24/7 monitor worker is not
        # viewer-driven and is never retired this way.
        self.viewer_count = 0
        self.last_viewer_left = time.monotonic()

        self.last_persons = []
        self.last_ppe_objects = []
        self.last_vehicles = []
        self.last_face_tracks_display = {}

        self.persons_count = 0
        self.violations_count = 0

        self.detection_running = False
        self.face_running = False

        self.last_detection_time = 0.0
        self.last_face_time = 0.0

        self.face_tracker = SimpleFaceTracker()
        self.face_frame_index = 0

        self.previous_loop_time = time.time()
        self.fps = 0.0

        self.result_lock = threading.RLock()

        ensure_frame_detection_state(
            self.camera_id,
            self.frame_id,
            default_enabled=False,
        )

        update_detection_stats(
            camera_id=self.camera_id,
            persons_count=0,
            violations_count=0,
            fps=0,
        )

        self.thread = threading.Thread(
            target=self._run,
            daemon=True,
            name=(
                f"shared-detection-{self.camera_id}-"
                f"{self.frame_id}-{self.ppe_filter}"
            ),
        )
        self.thread.start()

    @property
    def is_running(self):
        return self.running and self.thread.is_alive()

    def _set_error(self, error):
        self.last_error = str(error)
        print(
            f"[ERROR] Detection worker error: {self.camera_name} "
            f"(camera_id={self.camera_id}, frame_id={self.frame_id}) | "
            f"{error}"
        )

    def _detect_async(self, display_frame):
        try:
            if not is_frame_detection_enabled(
                self.camera_id,
                self.frame_id,
            ):
                return

            start = time.time()

            # One camera at a time. With several monitored cameras this is what
            # turns "all competing" into "each in turn".
            with _inference_lock:
                persons, ppe_objects, vehicles = run_yolo_detection_full(
                    display_frame, camera_id=self.camera.id
                )

            detect_time = time.time() - start

            # Stop/switch may happen while inference is running.
            if not is_frame_detection_enabled(
                self.camera_id,
                self.frame_id,
            ):
                return

            with self.result_lock:
                persons = assign_face_to_persons(
                    persons,
                    self.last_face_tracks_display,
                )

                self.last_persons = persons
                self.last_ppe_objects = ppe_objects
                self.last_vehicles = vehicles
                (
                    self.persons_count,
                    self.violations_count,
                ) = calculate_counts(persons)

            print(
                f"YOLO detection time: {detect_time:.3f} sec | "
                f"camera={self.camera_name}"
            )

        except Exception as error:
            self._set_error(error)

        finally:
            self.detection_running = False

    def _face_recognition_wanted(self):
        """
        Face recognition exists to put a NAME on a violator. It is the most
        expensive model in the pipeline, so it only runs while there is
        someone to name: the latest PPE pass on this camera found a violator,
        or an incident is still open on it. With nobody in view it costs
        nothing. FACE_RECOGNITION_ALWAYS=1 restores the old behaviour.
        """
        if FACE_RECOGNITION_ALWAYS:
            return True

        with self.result_lock:
            if self.violations_count > 0:
                return True

        return camera_has_open_incident(self.camera_id)

    def _face_async(self, original_frame, display_shape, frame_index):
        try:
            if not is_frame_detection_enabled(
                self.camera_id,
                self.frame_id,
            ):
                return

            start = time.time()

            tracks_full = run_face_recognition(
                original_frame,
                self.face_tracker,
                frame_index,
            )

            tracks_display = scale_face_tracks_to_frame(
                tracks_full,
                original_frame.shape,
                display_shape,
            )

            face_time = time.time() - start

            # Stop/switch may happen while recognition is running.
            if not is_frame_detection_enabled(
                self.camera_id,
                self.frame_id,
            ):
                return

            with self.result_lock:
                self.last_face_tracks_display = tracks_display

                if self.last_persons:
                    self.last_persons = assign_face_to_persons(
                        self.last_persons,
                        self.last_face_tracks_display,
                    )

                    (
                        self.persons_count,
                        self.violations_count,
                    ) = calculate_counts(self.last_persons)

            print(
                f"Face recognition time: {face_time:.3f} sec | "
                f"camera={self.camera_name}"
            )

        except Exception as error:
            self._set_error(error)

        finally:
            self.face_running = False

    def _publish_output(self, output_frame):
        ok, buffer = cv2.imencode(
            ".jpg",
            output_frame,
            [
                int(cv2.IMWRITE_JPEG_QUALITY),
                JPEG_QUALITY,
            ],
        )

        if not ok:
            return

        with self.condition:
            self.latest_jpeg = buffer.tobytes()
            self.frame_sequence += 1
            self.condition.notify_all()

    def _clear_detection_results(self):
        with self.result_lock:
            self.last_persons = []
            self.last_ppe_objects = []
            self.last_vehicles = []
            self.last_face_tracks_display = {}
            self.persons_count = 0
            self.violations_count = 0

    def _run(self):
        print(
            f"Shared detection worker started: {self.camera_name} "
            f"(camera_id={self.camera_id}, frame_id={self.frame_id})"
        )

        try:
            while self.running:
                try:
                    # This reads the same raw frame used by normal Dashboard and
                    # Live Monitoring streams. No extra VideoCapture is opened.
                    original_frame = get_shared_camera_frame(
                        self.camera,
                        wait_timeout=2.0,
                    )

                    if original_frame is None:
                        time.sleep(0.05)
                        continue

                    loop_time = time.time()
                    self.fps = 1.0 / max(
                        loop_time - self.previous_loop_time,
                        0.0001,
                    )
                    self.previous_loop_time = loop_time

                    if self.fps > 0 and self.fps < 5:
                        try:
                            upsert_camera_issue(
                                self.camera_id,
                                "low_fps",
                                {"fps": round(float(self.fps), 1)},
                            )
                        except Exception as issue_error:
                            print(
                                f"[WARN] Low-FPS issue update failed for "
                                f"{self.camera_name}: {issue_error}"
                            )

                    display_frame = resize_frame(
                        original_frame,
                        width=STREAM_WIDTH,
                    )
                    now = time.time()
                    detection_enabled = is_frame_detection_enabled(
                        self.camera_id,
                        self.frame_id,
                    )

                    if detection_enabled:
                        if (
                            now - self.last_detection_time
                            >= DETECTION_INTERVAL_SEC
                            and not self.detection_running
                        ):
                            self.last_detection_time = now
                            self.detection_running = True

                            threading.Thread(
                                target=self._detect_async,
                                args=(display_frame.copy(),),
                                daemon=True,
                                name=(
                                    f"yolo-{self.camera_id}-"
                                    f"{self.frame_id}"
                                ),
                            ).start()

                        if (
                            now - self.last_face_time
                            >= FACE_INTERVAL_SEC
                            and not self.face_running
                            and self._face_recognition_wanted()
                        ):
                            self.last_face_time = now
                            self.face_running = True
                            self.face_frame_index += 1

                            threading.Thread(
                                target=self._face_async,
                                args=(
                                    original_frame.copy(),
                                    display_frame.shape,
                                    self.face_frame_index,
                                ),
                                daemon=True,
                                name=(
                                    f"face-{self.camera_id}-"
                                    f"{self.frame_id}"
                                ),
                            ).start()

                        with self.result_lock:
                            persons_draw = [
                                dict(person)
                                for person in self.last_persons
                            ]
                            vehicles_draw = [
                                dict(item)
                                for item in self.last_vehicles
                            ]
                            ppe_draw = [
                                dict(item)
                                for item in self.last_ppe_objects
                            ]
                            face_draw = dict(
                                self.last_face_tracks_display
                            )
                            persons_count = self.persons_count
                            violations_count = self.violations_count

                        output_frame = draw_detections(
                            display_frame.copy(),
                            persons_draw,
                            ppe_draw,
                            ppe_filter=self.ppe_filter,
                            face_tracks=face_draw,
                        )

                        output_frame = draw_top_stats(
                            output_frame,
                            persons_count=persons_count,
                            violations_count=violations_count,
                            fps=self.fps,
                            recording=recording_states.get(
                                self.camera_id,
                                False,
                            ),
                        )

                        if (
                            persons_draw
                            and is_frame_detection_enabled(
                                self.camera_id,
                                self.frame_id,
                            )
                            and frame_should_save_events(
                                self.camera_id,
                                self.frame_id,
                            )
                        ):
                            try:
                                event_persons = filter_static_persons(
                                    self.camera_id,
                                    persons_draw,
                                    display_frame,
                                )

                                # PPE zones narrow, never widen (no-op without one).
                                event_persons = yard.restrict_ppe_to_zones(
                                    self.camera_id,
                                    event_persons,
                                    display_frame.shape,
                                )

                                if event_persons:
                                    evidence_frame = cv2.resize(
                                        output_frame,
                                        (1920, 1080),
                                        interpolation=cv2.INTER_LINEAR,
                                    )

                                    save_detection_events(
                                        camera=self.camera,
                                        persons=event_persons,
                                        frame=evidence_frame,
                                        frame_id=self.frame_id,
                                        frame_shape=display_frame.shape,
                                    )
                            except Exception as event_error:
                                # DB/email/event failure must not stop video.
                                print(
                                    f"[WARN] Detection event processing "
                                    f"failed for {self.camera_name}: "
                                    f"{event_error}"
                                )

                        # Yard engine: vehicles and people inside drawn zones.
                        # Costs nothing on a camera with no zones.
                        if (
                            (vehicles_draw or persons_draw)
                            and is_frame_detection_enabled(
                                self.camera_id,
                                self.frame_id,
                            )
                            and frame_should_save_events(
                                self.camera_id,
                                self.frame_id,
                            )
                        ):
                            try:
                                yard_now = time.monotonic()
                                yard.observe_vehicles(
                                    self.camera,
                                    vehicles_draw,
                                    output_frame,
                                    yard_now,
                                    frame_shape=display_frame.shape,
                                )
                                yard.observe_people_in_zones(
                                    self.camera,
                                    persons_draw,
                                    output_frame,
                                    yard_now,
                                    frame_shape=display_frame.shape,
                                )
                            except Exception as yard_error:
                                print(
                                    f"[WARN] Yard processing failed for "
                                    f"{self.camera_name}: {yard_error}"
                                )

                        update_detection_stats(
                            camera_id=self.camera_id,
                            persons_count=persons_count,
                            violations_count=violations_count,
                            fps=self.fps,
                        )

                    else:
                        self._clear_detection_results()

                        update_detection_stats(
                            camera_id=self.camera_id,
                            persons_count=0,
                            violations_count=0,
                            fps=self.fps,
                        )

                        # Detection OFF means raw camera remains live.
                        output_frame = display_frame

                    self._publish_output(output_frame)

                    # Avoid repeatedly processing/encoding one cached raw frame
                    # faster than the actual camera preview needs.
                    time.sleep(0.03)

                except Exception as error:
                    self._set_error(error)

                    # Keep this worker alive. A bad frame/model/event operation
                    # must never terminate FastAPI or other camera streams.
                    self._clear_detection_results()
                    update_detection_stats(
                        camera_id=self.camera_id,
                        persons_count=0,
                        violations_count=0,
                        fps=0,
                    )
                    time.sleep(0.5)

        finally:
            with self.condition:
                self.condition.notify_all()

            print(
                f"Shared detection worker stopped: {self.camera_name} "
                f"(camera_id={self.camera_id}, frame_id={self.frame_id})"
            )

    def wait_for_jpeg(self, previous_sequence=0, timeout=2.0):
        deadline = time.monotonic() + max(float(timeout), 0.0)

        with self.condition:
            while (
                self.running
                and (
                    self.latest_jpeg is None
                    or self.frame_sequence <= previous_sequence
                )
            ):
                remaining = deadline - time.monotonic()

                if remaining <= 0:
                    return None, previous_sequence

                self.condition.wait(timeout=remaining)

            if self.latest_jpeg is None:
                return None, previous_sequence

            return self.latest_jpeg, self.frame_sequence

    def add_viewer(self):
        with self.condition:
            self.viewer_count += 1

    def remove_viewer(self):
        with self.condition:
            self.viewer_count = max(0, self.viewer_count - 1)

            if self.viewer_count == 0:
                self.last_viewer_left = time.monotonic()

    @property
    def viewer_idle_seconds(self):
        with self.condition:
            if self.viewer_count > 0:
                return 0.0

            return time.monotonic() - self.last_viewer_left

    def stop(self, join_timeout=3.0):
        self.running = False

        with self.condition:
            self.condition.notify_all()

        if (
            self.thread.is_alive()
            and threading.current_thread() is not self.thread
        ):
            self.thread.join(timeout=join_timeout)


def get_or_create_detection_worker(
    camera,
    ppe_filter="all",
    frame_id=1,
):
    key = (
        int(camera.id),
        str(frame_id),
        str(ppe_filter or "all"),
    )

    with shared_detection_workers_lock:
        worker = shared_detection_workers.get(key)

        if worker is not None and worker.is_running:
            return worker

        if worker is not None:
            worker.stop()
            shared_detection_workers.pop(key, None)

        worker = SharedDetectionWorker(
            camera=camera,
            ppe_filter=ppe_filter,
            frame_id=frame_id,
        )
        shared_detection_workers[key] = worker
        return worker


VIEWER_IDLE_STOP_SEC = float(os.getenv("VISIONAI_VIEWER_IDLE_STOP_SEC", "30"))


def _reap_idle_detection_workers():
    """
    Retire tile detection workers nobody is watching any more.

    A tile worker is created when a browser opens a camera and used to live
    until someone pressed the per-tile Stop button - which the dashboard no
    longer has. Without this, every camera ever opened kept decoding video
    and running the models forever. The 24/7 monitor worker is exempt.
    """
    if VIEWER_IDLE_STOP_SEC <= 0:
        return

    to_stop = []

    with shared_detection_workers_lock:
        for key, worker in list(shared_detection_workers.items()):
            if str(key[1]) == MONITOR_FRAME_ID:
                continue

            if not worker.is_running:
                shared_detection_workers.pop(key, None)
                continue

            if worker.viewer_idle_seconds >= VIEWER_IDLE_STOP_SEC:
                shared_detection_workers.pop(key, None)
                to_stop.append(worker)

    for worker in to_stop:
        try:
            print(
                f"Stopping idle tile worker: {worker.camera_name} "
                f"(camera_id={worker.camera_id}, frame_id={worker.frame_id})"
            )
            worker.stop()
        except Exception as error:
            print(f"[WARN] Could not stop idle tile worker: {error}")


def stop_detection_workers_for_camera(camera_id):
    camera_id = int(camera_id)

    with shared_detection_workers_lock:
        keys = [
            key
            for key in shared_detection_workers
            if int(key[0]) == camera_id
        ]
        workers = [
            shared_detection_workers.pop(key)
            for key in keys
        ]

    for worker in workers:
        try:
            worker.stop()
        except Exception as error:
            print(
                f"[WARN] Could not stop detection worker "
                f"for camera {camera_id}: {error}"
            )


def _sync_monitored_cameras():
    """
    Make sure every active camera has a monitoring worker running.

    Safe to call repeatedly - existing workers are reused, so this doubles as
    the recovery path for a camera that dropped out and came back.
    """
    db = get_db_session()

    try:
        cameras = (
            db.query(Camera)
            .filter(Camera.is_active == True)
            .all()
        )
    finally:
        db.close()

    started = 0

    for camera in cameras:
        try:
            if not is_camera_monitored(camera.id):
                # Excluded - make sure nothing is left running for it.
                _stop_camera_monitoring(camera.id)
                continue

            set_frame_detection_enabled(camera.id, MONITOR_FRAME_ID, True)
            get_or_create_detection_worker(
                camera,
                ppe_filter="all",
                frame_id=MONITOR_FRAME_ID,
            )
            started += 1

        except Exception as error:
            print(
                f"[WARN] Could not start monitoring for camera "
                f"{camera.id}: {error}"
            )

    return started


def _stop_camera_monitoring(camera_id):
    """Turn monitoring off for one camera and release its worker."""
    camera_id = int(camera_id)

    try:
        set_frame_detection_enabled(camera_id, MONITOR_FRAME_ID, False)
    except Exception as error:
        print(f"[WARN] Could not disable monitoring {camera_id}: {error}")

    with shared_detection_workers_lock:
        keys = [
            key
            for key in shared_detection_workers
            if int(key[0]) == camera_id and str(key[1]) == MONITOR_FRAME_ID
        ]
        workers = [shared_detection_workers.pop(key) for key in keys]

    for worker in workers:
        try:
            worker.stop()
        except Exception as error:
            print(
                f"[WARN] Could not stop monitoring worker "
                f"{camera_id}: {error}"
            )

    return len(workers)


def set_camera_monitoring(camera_id, enabled):
    """
    Include or exclude one camera from continuous monitoring.

    Excluding a camera stops its analysis immediately and releases its decoder
    once nothing else needs it. Live viewing is unaffected - an excluded camera
    can still be opened in a tile.
    """
    global _monitor_excluded

    camera_id = int(camera_id)
    enabled = bool(enabled)

    with _monitor_lock:
        if enabled:
            _monitor_excluded.discard(camera_id)
        else:
            _monitor_excluded.add(camera_id)

    _save_monitor_state(is_monitoring_enabled())

    if enabled:
        if is_monitoring_enabled():
            _sync_monitored_cameras()
    else:
        _stop_camera_monitoring(camera_id)

    print(
        f"Camera {camera_id} monitoring "
        f"{'enabled' if enabled else 'disabled'}"
    )

    return {
        "camera_id": camera_id,
        "monitored": enabled,
    }


def _monitor_supervisor_loop():
    while True:
        try:
            if is_monitoring_enabled():
                _sync_monitored_cameras()
        except Exception as error:
            print(f"[WARN] Monitoring supervisor error: {error}")

        time.sleep(MONITOR_SUPERVISOR_INTERVAL_SEC)


def _ensure_monitor_supervisor():
    global _monitor_thread

    with _monitor_lock:
        if _monitor_thread is not None and _monitor_thread.is_alive():
            return

        _monitor_thread = threading.Thread(
            target=_monitor_supervisor_loop,
            name="monitoring-supervisor",
            daemon=True,
        )
        _monitor_thread.start()
        print("Monitoring supervisor started")


def _stop_monitor_workers():
    with detection_control_lock:
        keys = [
            key
            for key in detection_control_states
            if str(key[1]) == MONITOR_FRAME_ID
        ]

    for camera_id, frame_id in keys:
        try:
            set_frame_detection_enabled(camera_id, frame_id, False)
        except Exception as error:
            print(f"[WARN] Could not disable monitoring {camera_id}: {error}")

    with shared_detection_workers_lock:
        keys = [
            key
            for key in shared_detection_workers
            if str(key[1]) == MONITOR_FRAME_ID
        ]
        workers = [shared_detection_workers.pop(key) for key in keys]

    for worker in workers:
        try:
            worker.stop()
        except Exception as error:
            print(f"[WARN] Could not stop monitoring worker: {error}")

    return len(workers)


def start_monitoring():
    """Turn on continuous detection for every active camera."""
    global _monitor_enabled

    with _monitor_lock:
        _monitor_enabled = True

    _save_monitor_state(True)
    _ensure_monitor_supervisor()
    count = _sync_monitored_cameras()

    message = f"Monitoring started on {count} camera(s)"
    print(message)

    return {"enabled": True, "cameras": count, "message": message}


def stop_monitoring():
    """Turn off continuous detection. Live viewing is unaffected."""
    global _monitor_enabled

    with _monitor_lock:
        _monitor_enabled = False

    _save_monitor_state(False)
    stopped = _stop_monitor_workers()

    message = f"Monitoring stopped ({stopped} worker(s) shut down)"
    print(message)

    return {"enabled": False, "cameras": 0, "message": message}


def get_monitoring_status():
    enabled = is_monitoring_enabled()

    with shared_detection_workers_lock:
        active = [
            int(key[0])
            for key in shared_detection_workers
            if str(key[1]) == MONITOR_FRAME_ID
        ]

    with _monitor_lock:
        excluded = sorted(_monitor_excluded)

    return {
        "enabled": enabled,
        "monitored_camera_ids": sorted(set(active)),
        "monitored_count": len(set(active)),
        "excluded_camera_ids": excluded,
        "open_incidents": get_open_incidents(),
        "incident_grace_sec": INCIDENT_GRACE_SEC,
        "evidence_keep_days": EVIDENCE_KEEP_DAYS,
    }


def init_monitoring():
    """
    Restore the saved monitoring state at startup.

    Called from the app's startup hook so that "monitoring on" survives a
    restart, a deploy, or the server rebooting after a power cut.
    """
    enabled = _load_monitor_state()

    _ensure_incident_sweeper()

    if enabled:
        print("Monitoring was enabled before restart - resuming")
        _ensure_monitor_supervisor()
        _sync_monitored_cameras()
    else:
        print("Monitoring is off")

    return enabled


def shutdown_all_detection_workers():
    with shared_detection_workers_lock:
        workers = list(shared_detection_workers.values())
        shared_detection_workers.clear()

    for worker in workers:
        try:
            worker.stop()
        except Exception as error:
            print(
                f"[WARN] Could not stop detection worker "
                f"{worker.camera_id}: {error}"
            )


def generate_detection_stream_service(
    camera,
    ppe_filter="all",
    frame_id=1,
):
    """
    Lightweight MJPEG subscriber.

    It does not open a camera and does not run models. It only streams frames
    produced by the one shared detection worker.
    """
    worker = get_or_create_detection_worker(
        camera=camera,
        ppe_filter=ppe_filter,
        frame_id=frame_id,
    )
    worker.add_viewer()

    last_sequence = 0

    print(
        f"Detection subscriber connected: {camera.camera_name} "
        f"(camera_id={camera.id}, frame_id={frame_id})"
    )

    try:
        while True:
            jpeg, last_sequence = worker.wait_for_jpeg(
                previous_sequence=last_sequence,
                timeout=2.0,
            )

            if jpeg is None:
                time.sleep(0.05)
                continue

            yield (
                b"--frame\r\n"
                b"Content-Type: image/jpeg\r\n\r\n"
                + jpeg
                + b"\r\n"
            )

    except GeneratorExit:
        pass
    except Exception as error:
        # Closing one browser/page must not affect other subscribers/workers.
        print(
            f"[WARN] Detection subscriber error: "
            f"{camera.camera_name} | {error}"
        )
    finally:
        worker.remove_viewer()
        print(
            f"Detection subscriber closed: {camera.camera_name} "
            f"(camera_id={camera.id}, frame_id={frame_id})"
        )

