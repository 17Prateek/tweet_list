from __future__ import annotations

import html
import logging
import mimetypes
import os
import queue
import smtplib
import ssl
import threading
import time

from dataclasses import dataclass, field
from datetime import datetime
from email.message import EmailMessage
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from dotenv import load_dotenv

from app.database import (
    EmailAlertSetting,
    EmailRecipient,
    EmailAlertHistory,
    get_db_session,
)


# =========================================================
# Environment variables
# =========================================================
load_dotenv()


# =========================================================
# Logging
# =========================================================
logger = logging.getLogger(__name__)


# =========================================================
# SMTP configuration
# =========================================================
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))

SMTP_USER = os.getenv("SMTP_USER", "").strip()
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "").strip()

SMTP_USE_TLS = os.getenv(
    "SMTP_USE_TLS",
    "true",
).strip().lower() in {"1", "true", "yes", "on"}

# =========================================================
# New user welcome email configuration
# =========================================================
APP_DIR = Path(__file__).resolve().parent
NEW_USER_EMAIL_TEMPLATE_PATH = APP_DIR / "templates" / "new_user_email.html"
OTP_EMAIL_TEMPLATE_PATH = APP_DIR / "templates" / "otp_email.html"
PPE_VIOLATION_EMAIL_TEMPLATE_PATH = APP_DIR / "templates" / "ppe_violation_email.html"
PAPERLESS_LOGO_PATH = APP_DIR / "email_assets" / "logo.png"
VISION_AI_LOGO_PATH = APP_DIR / "email_assets" / "vision-ai-logo.png"
DEFAULT_LOGIN_URL = os.getenv("FRONTEND_LOGIN_URL", "http://localhost:5173/login").strip()
COUNTING_EMAIL_TEMPLATE_PATH = (
    APP_DIR / "templates" / "bag_box_counting_email.html"
)

# Counting Management email assets
COUNTING_REPORT_CUBE_ICON_PATH = APP_DIR / "email_assets" / "report_cube_icon.png"
COUNTING_CALENDAR_ICON_PATH = APP_DIR / "email_assets" / "calendar_icon.png"
COUNTING_BAG_ICON_PATH = APP_DIR / "email_assets" / "bag_icon.png"
COUNTING_BOX_ICON_PATH = APP_DIR / "email_assets" / "box_icon.png"
COUNTING_TOTAL_ITEMS_ICON_PATH = APP_DIR / "email_assets" / "total_items_icon.png"
COUNTING_INTERVAL_CLOCK_ICON_PATH = APP_DIR / "email_assets" / "interval_clock_icon.png"
COUNTING_CAMERA_ICON_PATH = APP_DIR / "email_assets" / "camera_icon.png"
COUNTING_TIME_ICON_PATH = APP_DIR / "email_assets" / "time_icon.png"
COUNTING_ITEM_SUMMARY_ICON_PATH = APP_DIR / "email_assets" / "item_summary_icon.png"
COUNTING_TREND_ICON_PATH = APP_DIR / "email_assets" / "trend_icon.png"
COUNTING_STATUS_CHECK_ICON_PATH = APP_DIR / "email_assets" / "status_check_icon.png"
COUNTING_REPORT_DOCUMENT_ICON_PATH = APP_DIR / "email_assets" / "report_document_icon.png"


# The first email is always sent after one continuous minute.
EMAIL_INITIAL_DELAY_SECONDS = 60
EMAIL_ALERT_STALE_SECONDS = 10
EMAIL_MAX_RETRIES = max(1, int(os.getenv("EMAIL_MAX_RETRIES", "3")))
EMAIL_QUEUE_MAXSIZE = max(10, int(os.getenv("EMAIL_QUEUE_MAXSIZE", "1000")))
EMAIL_WORKER_POLL_SECONDS = max(
    0.2,
    float(os.getenv("EMAIL_WORKER_POLL_SECONDS", "1.0")),
)

EMAIL_RETRY_DELAYS_SECONDS = (5, 15, 30)

DEFAULT_ALERTS_ENABLED = True
DEFAULT_EMAIL_FREQUENCY_MINUTES = 5
ALLOWED_EMAIL_FREQUENCIES = {5, 10, 15, 20}


# =========================================================
# Module state
# =========================================================
_email_alerts_enabled = DEFAULT_ALERTS_ENABLED
_email_frequency_minutes = DEFAULT_EMAIL_FREQUENCY_MINUTES
_alert_settings_loaded = False
_alert_setting_lock = threading.RLock()

_active_violations: Dict[Tuple[Any, ...], "ViolationState"] = {}
_active_violations_lock = threading.RLock()

_email_job_queue: queue.Queue = queue.Queue(maxsize=EMAIL_QUEUE_MAXSIZE)

_worker_thread: Optional[threading.Thread] = None
_worker_stop_event = threading.Event()
_worker_lock = threading.Lock()

# =========================================================
# Latest successfully sent email notification
# =========================================================
_email_notification_lock = threading.RLock()
_latest_email_notification: Optional[Dict[str, Any]] = None
_email_notification_sequence = 0

# =========================================================
# Data classes
# =========================================================
@dataclass
class ViolationState:
    key: Tuple[Any, ...]
    camera_id: int
    camera_name: str
    camera_location: str

    person_name: str
    employee_id: str

    helmet: bool
    vest: bool
    event_type: str
    alert_type: str

    first_seen_monotonic: float
    last_seen_monotonic: float

    first_seen_at: datetime
    last_seen_at: datetime

    last_email_sent_monotonic: Optional[float] = None
    last_email_sent_at: Optional[datetime] = None
    last_attempt_monotonic: Optional[float] = None

    evidence_path: Optional[str] = None

    email_queued: bool = False
    total_emails_sent: int = 0


@dataclass
class EmailJob:
    violation_key: Tuple[Any, ...]
    camera_id: int
    camera_name: str
    camera_location: str

    person_name: str
    employee_id: str

    helmet: bool
    vest: bool
    event_type: str
    alert_type: str

    first_seen_at: datetime
    observed_at: datetime

    repeat_frequency_minutes: int

    evidence_path: Optional[str] = None
    queued_at: datetime = field(default_factory=datetime.now)


# =========================================================
# Common helpers
# =========================================================
def _clean_text(value: Any, fallback: str = "N/A") -> str:
    if value is None:
        return fallback

    cleaned = str(value).strip()
    return cleaned if cleaned else fallback


def _normalize_person_name(person_name: Any) -> str:
    normalized = _clean_text(
        person_name,
        fallback="Unknown Person",
    ).strip()

    if normalized.lower() in {
        "unknown",
        "unknown person",
        "monitoring",
        "n/a",
        "none",
        "null",
    }:
        return "Unknown Person"

    return normalized


def _normalize_employee_id(
    employee_id: Any,
    person_name: str,
) -> str:
    if person_name == "Unknown Person":
        return "N/A"

    return _clean_text(employee_id, fallback="N/A")


def _build_violation_key(
    camera_id: int,
    person_name: str,
    employee_id: str,
    helmet: bool,
    vest: bool,
) -> Tuple[Any, ...]:
    """
    Violation identity:

        camera ID
        person identity
        helmet status
        vest status

    A PPE status change produces a new key and therefore starts
    a fresh 60-second timer.
    """
    if person_name == "Unknown Person":
        identity = "unknown person"
    else:
        identity = (
            employee_id.strip().lower()
            if employee_id and employee_id != "N/A"
            else person_name.strip().lower()
        )

    return (
        int(camera_id),
        identity,
        bool(helmet),
        bool(vest),
    )


def _derive_event_type(
    helmet: bool,
    vest: bool,
    supplied_event_type: Optional[str] = None,
) -> Optional[str]:
    if supplied_event_type:
        return _clean_text(supplied_event_type)

    if not helmet and not vest:
        return "Helmet and Vest Violation"

    if not helmet:
        return "Helmet Violation"

    if not vest:
        return "Vest Violation"

    return None


def _derive_alert_type(event_type: str) -> str:
    event_type_lower = event_type.strip().lower()

    if "helmet" in event_type_lower:
        return "PPE Alerts"

    if "vest" in event_type_lower:
        return "PPE Alerts"

    if "ppe" in event_type_lower:
        return "PPE Alerts"

    if "unauthorized" in event_type_lower:
        return "Unauthorized Access"

    if "camera" in event_type_lower:
        return "Camera Alerts"

    return "All Alerts"


def _format_datetime(value: datetime) -> str:
    from app.timezone_util import to_local_time

    return to_local_time(value).strftime("%d %B %Y, %I:%M:%S %p")


def _validate_smtp_configuration() -> None:
    missing = []

    if not SMTP_USER:
        missing.append("SMTP_USER")

    if not SMTP_PASSWORD:
        missing.append("SMTP_PASSWORD")

    if missing:
        raise RuntimeError(
            "Missing email configuration: "
            + ", ".join(missing)
        )


# =========================================================
# Recipient serialization and CRUD
# =========================================================
def serialize_email_recipient(recipient: EmailRecipient) -> Dict[str, Any]:
    return {
        "id": recipient.id,
        "email": recipient.email,
        "name": recipient.name,
        "position": recipient.position,
        "alertType": recipient.alert_type,
        "status": recipient.status,
        "isActive": recipient.is_active,
        "createdAt": (
            recipient.created_at.isoformat()
            if recipient.created_at
            else None
        ),
        "updatedAt": (
            recipient.updated_at.isoformat()
            if recipient.updated_at
            else None
        ),
    }


def get_email_recipients_service(db) -> List[Dict[str, Any]]:
    recipients = (
        db.query(EmailRecipient)
        .filter(EmailRecipient.is_active.is_(True))
        .order_by(EmailRecipient.id.desc())
        .all()
    )

    return [
        serialize_email_recipient(recipient)
        for recipient in recipients
    ]


def create_email_recipient_service(
    db,
    email: str,
    name: str,
    position: str,
    alert_type: str,
    status: str,
) -> Dict[str, Any]:
    email = _clean_text(email, fallback="").lower()

    if not email:
        return {
            "success": False,
            "message": "Email address is required",
            "status_code": 400,
        }

    existing = (
        db.query(EmailRecipient)
        .filter(EmailRecipient.email == email)
        .first()
    )

    if existing:
        return {
            "success": False,
            "message": "This email already exists",
            "status_code": 409,
        }

    recipient = EmailRecipient(
        email=email,
        name=_clean_text(name),
        position=_clean_text(position),
        alert_type=_clean_text(
            alert_type,
            fallback="All Alerts",
        ),
        status=_clean_text(
            status,
            fallback="Active",
        ),
        is_active=True,
    )

    try:
        db.add(recipient)
        db.commit()
        db.refresh(recipient)

        return {
            "success": True,
            "data": serialize_email_recipient(recipient),
        }

    except Exception:
        db.rollback()
        logger.exception("Could not create email recipient")

        return {
            "success": False,
            "message": "Could not create email recipient",
            "status_code": 500,
        }


def update_email_recipient_service(
    db,
    recipient_id: int,
    email: str,
    name: str,
    position: str,
    alert_type: str,
    status: str,
) -> Dict[str, Any]:
    recipient = (
        db.query(EmailRecipient)
        .filter(
            EmailRecipient.id == recipient_id,
            EmailRecipient.is_active.is_(True),
        )
        .first()
    )

    if not recipient:
        return {
            "success": False,
            "message": "Email recipient not found",
            "status_code": 404,
        }

    email = _clean_text(email, fallback="").lower()

    if not email:
        return {
            "success": False,
            "message": "Email address is required",
            "status_code": 400,
        }

    duplicate = (
        db.query(EmailRecipient)
        .filter(
            EmailRecipient.email == email,
            EmailRecipient.id != recipient_id,
            EmailRecipient.is_active.is_(True),
        )
        .first()
    )

    if duplicate:
        return {
            "success": False,
            "message": "This email already exists",
            "status_code": 409,
        }

    recipient.email = email
    recipient.name = _clean_text(name)
    recipient.position = _clean_text(position)
    recipient.alert_type = _clean_text(
        alert_type,
        fallback="All Alerts",
    )
    recipient.status = _clean_text(
        status,
        fallback="Active",
    )

    try:
        db.commit()
        db.refresh(recipient)

        return {
            "success": True,
            "data": serialize_email_recipient(recipient),
        }

    except Exception:
        db.rollback()
        logger.exception(
            "Could not update email recipient %s",
            recipient_id,
        )

        return {
            "success": False,
            "message": "Could not update email recipient",
            "status_code": 500,
        }


def delete_email_recipient_service(
    db,
    recipient_id: int,
) -> Dict[str, Any]:
    recipient = (
        db.query(EmailRecipient)
        .filter(
            EmailRecipient.id == recipient_id,
            EmailRecipient.is_active.is_(True),
        )
        .first()
    )

    if not recipient:
        return {
            "success": False,
            "message": "Email recipient not found",
            "status_code": 404,
        }

    recipient.is_active = False

    try:
        db.commit()

        return {
            "success": True,
            "message": "Email recipient deleted successfully",
        }

    except Exception:
        db.rollback()
        logger.exception(
            "Could not delete email recipient %s",
            recipient_id,
        )

        return {
            "success": False,
            "message": "Could not delete email recipient",
            "status_code": 500,
        }


# =========================================================
# Alert settings
# =========================================================
def _validate_frequency_minutes(value: int) -> int:
    frequency = int(value)

    if frequency not in ALLOWED_EMAIL_FREQUENCIES:
        raise ValueError(
            "frequency_minutes must be one of: 5, 10, 15, 20"
        )

    return frequency


def _get_or_create_alert_setting(db) -> EmailAlertSetting:
    setting = (
        db.query(EmailAlertSetting)
        .filter(EmailAlertSetting.id == 1)
        .first()
    )

    if setting is None:
        setting = EmailAlertSetting(
            id=1,
            enabled=DEFAULT_ALERTS_ENABLED,
            frequency_minutes=DEFAULT_EMAIL_FREQUENCY_MINUTES,
        )
        db.add(setting)
        db.commit()
        db.refresh(setting)

    return setting


def load_email_alert_settings_service() -> Dict[str, Any]:
    global _email_alerts_enabled
    global _email_frequency_minutes
    global _alert_settings_loaded

    db = get_db_session()

    try:
        setting = _get_or_create_alert_setting(db)
        frequency = _validate_frequency_minutes(
            setting.frequency_minutes
        )

        with _alert_setting_lock:
            _email_alerts_enabled = bool(setting.enabled)
            _email_frequency_minutes = frequency
            _alert_settings_loaded = True

        return {
            "success": True,
            "enabled": bool(setting.enabled),
            "frequency_minutes": frequency,
        }

    finally:
        db.close()


def _ensure_alert_settings_loaded() -> None:
    """
    Best-effort settings load.

    A temporary database failure must not stop camera, AI, auth, or other
    unrelated APIs. The in-memory defaults remain usable and a later call
    can retry loading the persisted settings.
    """
    with _alert_setting_lock:
        loaded = _alert_settings_loaded

    if loaded:
        return

    try:
        load_email_alert_settings_service()
    except Exception:
        logger.exception(
            "Could not load email alert settings; using in-memory defaults"
        )


def get_email_alert_status_service() -> Dict[str, Any]:
    _ensure_alert_settings_loaded()

    with _alert_setting_lock:
        enabled = _email_alerts_enabled
        frequency_minutes = _email_frequency_minutes

    return {
        "success": True,
        "enabled": enabled,
        "frequency_minutes": frequency_minutes,
    }


def update_email_alert_status_service(
    enabled: bool,
    frequency_minutes: int,
) -> Dict[str, Any]:
    global _email_alerts_enabled
    global _email_frequency_minutes
    global _alert_settings_loaded

    frequency = _validate_frequency_minutes(
        frequency_minutes
    )

    db = get_db_session()

    try:
        setting = _get_or_create_alert_setting(db)
        setting.enabled = bool(enabled)
        setting.frequency_minutes = frequency
        db.commit()
        db.refresh(setting)

        with _alert_setting_lock:
            _email_alerts_enabled = bool(setting.enabled)
            _email_frequency_minutes = int(
                setting.frequency_minutes
            )
            _alert_settings_loaded = True

        logger.info(
            "Email alerts changed: enabled=%s, frequency=%s minutes",
            setting.enabled,
            setting.frequency_minutes,
        )

        return {
            "success": True,
            "enabled": bool(setting.enabled),
            "frequency_minutes": int(
                setting.frequency_minutes
            ),
            "message": (
                "Email alert settings updated successfully"
            ),
        }

    except Exception:
        db.rollback()
        logger.exception(
            "Could not update email alert settings"
        )
        raise

    finally:
        db.close()


def are_email_alerts_enabled() -> bool:
    _ensure_alert_settings_loaded()

    with _alert_setting_lock:
        return _email_alerts_enabled


def get_email_alert_frequency_minutes() -> int:
    _ensure_alert_settings_loaded()

    with _alert_setting_lock:
        return _email_frequency_minutes


# =========================================================
# Recipient selection
# =========================================================
def _recipient_accepts_alert(
    recipient_alert_type: Optional[str],
    requested_alert_type: str,
) -> bool:
    configured = _clean_text(
        recipient_alert_type,
        fallback="All Alerts",
    ).strip().lower()

    requested = _clean_text(
        requested_alert_type,
        fallback="All Alerts",
    ).strip().lower()

    if configured in {
        "all",
        "all alert",
        "all alerts",
    }:
        return True

    if configured == requested:
        return True

    # Treat every PPE-related setting as compatible: a recipient set to
    # "Helmet Missing" or "Vest Missing" in Email Settings gets PPE alerts.
    if "ppe" in requested and any(word in configured for word in ("ppe", "helmet", "vest")):
        return True

    return False


def _get_active_recipient_addresses(
    db,
    alert_type: str,
) -> List[str]:
    recipients = (
        db.query(EmailRecipient)
        .filter(EmailRecipient.is_active.is_(True))
        .all()
    )

    unique_addresses: List[str] = []
    seen = set()

    for recipient in recipients:
        status = _clean_text(
            recipient.status,
            fallback="Inactive",
        ).strip().lower()

        if status != "active":
            continue

        if not _recipient_accepts_alert(
            recipient.alert_type,
            alert_type,
        ):
            continue

        email_address = _clean_text(
            recipient.email,
            fallback="",
        ).strip().lower()

        if not email_address:
            continue

        if email_address in seen:
            continue

        seen.add(email_address)
        unique_addresses.append(email_address)

    return unique_addresses


# =========================================================
# Message creation and attachments
# =========================================================
def _attach_file(
    message: EmailMessage,
    file_path: Optional[str],
) -> None:
    if not file_path:
        return

    path = Path(file_path)

    if not path.exists() or not path.is_file():
        logger.warning(
            "Email evidence file does not exist: %s",
            path,
        )
        return

    mime_type, _ = mimetypes.guess_type(path.name)

    if mime_type:
        main_type, sub_type = mime_type.split("/", 1)
    else:
        main_type = "application"
        sub_type = "octet-stream"

    try:
        with path.open("rb") as file:
            message.add_attachment(
                file.read(),
                maintype=main_type,
                subtype=sub_type,
                filename=path.name,
            )

    except Exception:
        logger.exception(
            "Could not attach evidence file: %s",
            path,
        )


def _build_test_email_message(
    recipient: EmailRecipient,
) -> EmailMessage:
    message = EmailMessage()

    message["Subject"] = "Testing Successful"
    message["From"] = SMTP_USER
    message["To"] = recipient.email

    recipient_name = _clean_text(
        recipient.name,
        fallback="User",
    ).strip().title()

    message.set_content(
        f"""Hello {recipient_name},

Testing successful.

Your email has been configured successfully for alert notifications.

Regards,
Paperless Management System
"""
    )

    return message


def _read_ppe_violation_email_template() -> str:
    if not PPE_VIOLATION_EMAIL_TEMPLATE_PATH.exists():
        raise FileNotFoundError(
            "PPE violation email template not found: "
            f"{PPE_VIOLATION_EMAIL_TEMPLATE_PATH}"
        )

    return PPE_VIOLATION_EMAIL_TEMPLATE_PATH.read_text(
        encoding="utf-8"
    )


def _build_violation_email_message(
    job: EmailJob,
) -> EmailMessage:
    # ---------------------------------------------------------
    # Continuous violation duration
    # ---------------------------------------------------------
    active_seconds = max(
        0,
        int(
            (
                job.observed_at
                - job.first_seen_at
            ).total_seconds()
        ),
    )

    # ---------------------------------------------------------
    # PPE status text
    # ---------------------------------------------------------
    helmet_text = (
        "Detected"
        if job.helmet
        else "Not Detected"
    )

    vest_text = (
        "Detected"
        if job.vest
        else "Not Detected"
    )

    # ---------------------------------------------------------
    # Clean values
    # ---------------------------------------------------------
    location = _clean_text(
        job.camera_location,
        fallback="Unknown Location",
    )

    camera_name = _clean_text(
        job.camera_name,
        fallback=f"Camera {job.camera_id}",
    )

    person_name = _clean_text(
        job.person_name,
        fallback="Unknown Person",
    )

    employee_id = _clean_text(
        job.employee_id,
        fallback="N/A",
    )

    violation_type = _clean_text(
        job.event_type,
        fallback="PPE Violation",
    )

    repeat_frequency_minutes = max(
        1,
        int(job.repeat_frequency_minutes),
    )

    violation_started = _format_datetime(
        job.first_seen_at
    )

    latest_observation = _format_datetime(
        job.observed_at
    )

    # ---------------------------------------------------------
    # Subject
    # ---------------------------------------------------------
    subject = (
        "PPE Safety Violation Alert at "
        f"{location} – Immediate Attention Required"
    )

    # ---------------------------------------------------------
    # Read HTML template and replace placeholders
    # ---------------------------------------------------------
    template = _read_ppe_violation_email_template()

    replacements = {
        "{{ location }}": html.escape(location),
        "{{ violation_type }}": html.escape(
            violation_type
        ),
        "{{ person_name }}": html.escape(
            person_name
        ),
        "{{ employee_id }}": html.escape(
            employee_id
        ),
        "{{ helmet_status }}": html.escape(
            helmet_text
        ),
        "{{ vest_status }}": html.escape(
            vest_text
        ),
        "{{ camera_name }}": html.escape(
            camera_name
        ),
        "{{ camera_id }}": html.escape(
            str(job.camera_id)
        ),
        "{{ violation_started }}": html.escape(
            violation_started
        ),
        "{{ latest_observation }}": html.escape(
            latest_observation
        ),
        "{{ violation_duration }}": html.escape(
            str(active_seconds)
        ),
        "{{ repeat_frequency_minutes }}": html.escape(
            str(repeat_frequency_minutes)
        ),
    }

    html_body = template

    for placeholder, value in replacements.items():
        html_body = html_body.replace(
            placeholder,
            value,
        )

    # ---------------------------------------------------------
    # Email message
    # ---------------------------------------------------------
    message = EmailMessage()

    message["Subject"] = subject
    message["From"] = SMTP_USER

    # Actual recipients are supplied separately during SMTP sending.
    message["To"] = SMTP_USER

    # ---------------------------------------------------------
    # Plain-text fallback
    # ---------------------------------------------------------
    message.set_content(
        f"""Dear Safety Team,

A PPE safety violation has been detected by the VisionAI Monitoring System.

Violation Details
Violation Type: {violation_type}

Person Information
Name: {person_name}
Employee ID: {employee_id}

PPE Status
Helmet: {helmet_text}
Safety Vest: {vest_text}

Location Information
Camera Name: {camera_name}
Camera ID: {job.camera_id}
Location: {location}

Event Timeline
Violation Started: {violation_started}
Latest Observation: {latest_observation}
Continuous Violation Duration: {active_seconds} Seconds

Action Required
Please verify the situation and take appropriate corrective action if the unsafe condition persists.

Note: If this violation continues, a subsequent alert will be generated after {repeat_frequency_minutes} minutes.

Regards,
VisionAI Monitoring System
Paperless AI Team
"""
    )

    # ---------------------------------------------------------
    # HTML version
    # ---------------------------------------------------------
    message.add_alternative(
        html_body,
        subtype="html",
    )

    html_part = message.get_payload()[-1]

    # ---------------------------------------------------------
    # Paperless AI logo
    # ---------------------------------------------------------
    _add_inline_image(
        html_part,
        PAPERLESS_LOGO_PATH,
        "paperless_logo",
    )

    # ---------------------------------------------------------
    # Vision AI logo
    # ---------------------------------------------------------
    _add_inline_image(
        html_part,
        VISION_AI_LOGO_PATH,
        "vision_ai_logo",
    )

    # ---------------------------------------------------------
    # PPE violation evidence image
    # Display directly inside ppe_violation_email.html using:
    # <img src="cid:violation_snapshot">
    # ---------------------------------------------------------
    if job.evidence_path:
        evidence_path = Path(
            job.evidence_path
        )

        if (
            evidence_path.exists()
            and evidence_path.is_file()
        ):
            _add_inline_image(
                html_part,
                evidence_path,
                "violation_snapshot",
            )
        else:
            logger.warning(
                "Violation evidence image does not exist: %s",
                evidence_path,
            )

    # IMPORTANT:
    # Do NOT call _attach_file() here. The evidence image is intentionally
    # embedded as a related CID image so Gmail renders it inside the template
    # instead of showing it as a separate normal attachment.

    return message

# =========================================================
# New user welcome email
# =========================================================
def _read_new_user_email_template() -> str:
    if not NEW_USER_EMAIL_TEMPLATE_PATH.exists():
        raise FileNotFoundError(f"New user email template not found: {NEW_USER_EMAIL_TEMPLATE_PATH}")
    return NEW_USER_EMAIL_TEMPLATE_PATH.read_text(encoding="utf-8")


def _add_inline_image(html_part, image_path: Path, content_id: str) -> None:
    if not image_path.exists() or not image_path.is_file():
        logger.warning("Email inline image does not exist: %s", image_path)
        return

    mime_type, _ = mimetypes.guess_type(image_path.name)

    if mime_type and "/" in mime_type:
        main_type, sub_type = mime_type.split("/", 1)
    else:
        main_type, sub_type = "image", "png"

    if main_type != "image":
        logger.warning("Email inline asset is not an image: %s", image_path)
        return

    try:
        html_part.add_related(
            image_path.read_bytes(),
            maintype="image",
            subtype=sub_type,
            cid=f"<{content_id}>",
            filename=image_path.name,
        )
    except Exception:
        logger.exception(
            "Could not attach inline email image: %s",
            image_path,
        )


def _build_new_user_email_message(*, email: str, full_name: str, password: str, login_url: Optional[str] = None) -> EmailMessage:
    recipient_email = _clean_text(email, fallback="").strip().lower()
    if not recipient_email:
        raise ValueError("User email address is required")
    recipient_name = _clean_text(full_name, fallback="User").strip().title()
    plain_password = str(password or "")
    if not plain_password:
        raise ValueError("User password is required")
    resolved_login_url = _clean_text(login_url, fallback=DEFAULT_LOGIN_URL)
    template = _read_new_user_email_template()
    html_body = (template.replace("{{ full_name }}", html.escape(recipient_name)).replace("{{ email }}", html.escape(recipient_email)).replace("{{ password }}", html.escape(plain_password)).replace("{{ login_url }}", html.escape(resolved_login_url, quote=True)))
    message = EmailMessage()
    message["Subject"] = "VisionAI Monitoring System - New User Account"
    message["From"] = SMTP_USER
    message["To"] = recipient_email
    message.set_content(f"""Hello {recipient_name},

You have been added as a user for the VisionAI Monitoring System.

Please login and use the following credentials:

Username: {recipient_email}
Password: {plain_password}

Login: {resolved_login_url}

If you have any questions or encounter any problems while logging in, please contact your site administrator.

This is an auto generated email. Please do not reply to this message.

Regards,
VisionAI Monitoring System
Paperless AI Team
""")
    message.add_alternative(html_body, subtype="html")
    html_part = message.get_payload()[-1]
    _add_inline_image(html_part, PAPERLESS_LOGO_PATH, "paperless_logo")
    _add_inline_image(html_part, VISION_AI_LOGO_PATH, "vision_ai_logo")
    return message


def send_new_user_welcome_email_service(*, email: str, full_name: str, password: str, login_url: Optional[str] = None) -> Dict[str, Any]:
    recipient_email = _clean_text(email, fallback="").strip().lower()
    if not recipient_email:
        return {"success": False, "message": "User email address is required", "status_code": 400}
    if not password:
        return {"success": False, "message": "User password is required", "status_code": 400}
    try:
        message = _build_new_user_email_message(email=recipient_email, full_name=full_name, password=password, login_url=login_url)
        success, error = _send_with_retries(message, [recipient_email])
        if not success:
            return {"success": False, "message": error or "Welcome email could not be sent", "status_code": 500}
        logger.info("New user welcome email sent successfully to %s", recipient_email)
        return {"success": True, "message": f"Welcome email sent successfully to {recipient_email}"}
    except Exception as error:
        logger.exception("New user welcome email could not be sent to %s", recipient_email)
        return {"success": False, "message": str(error), "status_code": 500}


# =========================================================
# SMTP sending
# =========================================================
def _send_message_via_smtp(
    message: EmailMessage,
    recipient_addresses: List[str],
) -> None:
    _validate_smtp_configuration()

    if not recipient_addresses:
        raise ValueError(
            "No active email recipients were found"
        )

    ssl_context = ssl.create_default_context()

    with smtplib.SMTP(
        SMTP_HOST,
        SMTP_PORT,
        timeout=30,
    ) as server:
        server.ehlo()

        if SMTP_USE_TLS:
            server.starttls(
                context=ssl_context,
            )
            server.ehlo()

        server.login(
            SMTP_USER,
            SMTP_PASSWORD,
        )

        server.send_message(
            message,
            from_addr=SMTP_USER,
            to_addrs=recipient_addresses,
        )


def _send_with_retries(
    message: EmailMessage,
    recipients: List[str],
) -> Tuple[bool, Optional[str]]:
    last_error: Optional[str] = None

    retry_count = max(1, EMAIL_MAX_RETRIES)

    for attempt in range(1, retry_count + 1):
        try:
            _send_message_via_smtp(
                message,
                recipients,
            )

            return True, None

        except Exception as error:
            last_error = str(error)

            logger.exception(
                "Email attempt %s of %s failed",
                attempt,
                retry_count,
            )

            if attempt >= retry_count:
                break

            delay_index = min(
                attempt - 1,
                len(EMAIL_RETRY_DELAYS_SECONDS) - 1,
            )
            delay_seconds = EMAIL_RETRY_DELAYS_SECONDS[
                delay_index
            ]

            if _worker_stop_event.wait(delay_seconds):
                break

    return False, last_error



# =========================================================
# Reusable OTP email
# =========================================================
def _read_otp_email_template() -> str:
    if not OTP_EMAIL_TEMPLATE_PATH.exists():
        raise FileNotFoundError(
            f"OTP email template not found: {OTP_EMAIL_TEMPLATE_PATH}"
        )

    return OTP_EMAIL_TEMPLATE_PATH.read_text(encoding="utf-8")


def _resolve_otp_email_content(purpose: str) -> Dict[str, str]:
    normalized_purpose = str(purpose or "login").strip().lower()

    if normalized_purpose in {
        "forgot_password",
        "password_reset",
        "reset_password",
    }:
        return {
            "purpose": "forgot_password",
            "title": "PASSWORD RESET",
            "subject": "VisionAI Monitoring System - Password Reset OTP",
            "intro_message": (
                "We received a request to reset the password "
                "for your VisionAI Monitoring System account."
            ),
            "instruction_message": (
                "Please use the following One-Time Password (OTP) "
                "to verify your password reset request:"
            ),
            "ignore_message": (
                "If you did not request a password reset, "
                "please ignore this email."
            ),
        }

    return {
        "purpose": "login",
        "title": "LOGIN VERIFICATION",
        "subject": "VisionAI Monitoring System - Login Verification OTP",
        "intro_message": (
            "We received a request to login to your account "
            "on VisionAI Monitoring System."
        ),
        "instruction_message": (
            "Please use the following One-Time Password (OTP) "
            "to complete your login:"
        ),
        "ignore_message": (
            "If you did not initiate this login, "
            "please ignore this email."
        ),
    }


def _build_otp_email_message(
    *,
    email: str,
    full_name: str,
    otp: str,
    purpose: str = "login",
    expiry_minutes: int = 5,
) -> EmailMessage:
    recipient_email = _clean_text(email, fallback="").strip().lower()
    if not recipient_email:
        raise ValueError("User email address is required")

    recipient_name = _clean_text(full_name, fallback="User").strip().title()
    otp_value = str(otp or "").strip()

    if not otp_value:
        raise ValueError("OTP is required")

    if not otp_value.isdigit() or len(otp_value) != 6:
        raise ValueError("OTP must be a 6-digit number")

    try:
        resolved_expiry_minutes = max(1, int(expiry_minutes))
    except (TypeError, ValueError):
        resolved_expiry_minutes = 5

    content = _resolve_otp_email_content(purpose)
    template = _read_otp_email_template()

    replacements = {
        "{{ title }}": html.escape(content["title"]),
        "{{ full_name }}": html.escape(recipient_name),
        "{{ intro_message }}": html.escape(content["intro_message"]),
        "{{ instruction_message }}": html.escape(content["instruction_message"]),
        "{{ otp }}": html.escape(otp_value),
        "{{ expiry_minutes }}": html.escape(str(resolved_expiry_minutes)),
        "{{ ignore_message }}": html.escape(content["ignore_message"]),
    }

    html_body = template
    for placeholder, value in replacements.items():
        html_body = html_body.replace(placeholder, value)

    message = EmailMessage()
    message["Subject"] = content["subject"]
    message["From"] = SMTP_USER
    message["To"] = recipient_email

    if content["purpose"] == "forgot_password":
        plain_intro = (
            "We received a request to reset the password "
            "for your VisionAI Monitoring System account."
        )
        plain_instruction = (
            "Use the following OTP to verify your password reset request:"
        )
        plain_ignore = (
            "If you did not request a password reset, please ignore this email."
        )
    else:
        plain_intro = (
            "We received a request to login to your account "
            "on VisionAI Monitoring System."
        )
        plain_instruction = "Use the following OTP to complete your login:"
        plain_ignore = (
            "If you did not initiate this login, please ignore this email."
        )

    message.set_content(
        f"""Dear {recipient_name},

{plain_intro}

{plain_instruction}

{otp_value}

This OTP is valid for {resolved_expiry_minutes} minutes.

Please keep this OTP confidential.
Do not share this OTP with anyone.

{plain_ignore}

Regards,
VisionAI Monitoring System
Paperless AI Team

This is an auto generated email. Please do not reply.
"""
    )

    message.add_alternative(html_body, subtype="html")
    html_part = message.get_payload()[-1]

    _add_inline_image(html_part, PAPERLESS_LOGO_PATH, "paperless_logo")
    _add_inline_image(html_part, VISION_AI_LOGO_PATH, "vision_ai_logo")

    return message


def send_otp_email_service(
    *,
    email: str,
    full_name: str,
    otp: str,
    purpose: str = "login",
    expiry_minutes: int = 5,
) -> Dict[str, Any]:
    recipient_email = _clean_text(email, fallback="").strip().lower()

    if not recipient_email:
        return {
            "success": False,
            "message": "User email address is required",
            "status_code": 400,
        }

    otp_value = str(otp or "").strip()
    if not otp_value:
        return {
            "success": False,
            "message": "OTP is required",
            "status_code": 400,
        }

    try:
        message = _build_otp_email_message(
            email=recipient_email,
            full_name=full_name,
            otp=otp_value,
            purpose=purpose,
            expiry_minutes=expiry_minutes,
        )

        success, error = _send_with_retries(message, [recipient_email])

        if not success:
            return {
                "success": False,
                "message": error or "OTP email could not be sent",
                "status_code": 500,
            }

        resolved_content = _resolve_otp_email_content(purpose)
        logger.info(
            "%s OTP email sent successfully to %s",
            resolved_content["purpose"],
            recipient_email,
        )

        return {
            "success": True,
            "message": (
                f"{resolved_content['title'].title()} "
                f"OTP sent successfully to {recipient_email}"
            ),
            "purpose": resolved_content["purpose"],
        }

    except Exception as error:
        logger.exception(
            "OTP email could not be sent to %s",
            recipient_email,
        )
        return {
            "success": False,
            "message": str(error),
            "status_code": 500,
        }


def send_login_otp_email_service(
    *,
    email: str,
    full_name: str,
    otp: str,
    expiry_minutes: int = 5,
) -> Dict[str, Any]:
    return send_otp_email_service(
        email=email,
        full_name=full_name,
        otp=otp,
        purpose="login",
        expiry_minutes=expiry_minutes,
    )


def send_forgot_password_otp_email_service(
    *,
    email: str,
    full_name: str,
    otp: str,
    expiry_minutes: int = 5,
) -> Dict[str, Any]:
    return send_otp_email_service(
        email=email,
        full_name=full_name,
        otp=otp,
        purpose="forgot_password",
        expiry_minutes=expiry_minutes,
    )


# =========================================================
# Test email
# =========================================================
def send_test_email_recipient_service(
    db,
    recipient_id: int,
) -> Dict[str, Any]:
    recipient = (
        db.query(EmailRecipient)
        .filter(
            EmailRecipient.id == recipient_id,
            EmailRecipient.is_active.is_(True),
        )
        .first()
    )

    if not recipient:
        return {
            "success": False,
            "message": "Email recipient not found",
            "status_code": 404,
        }

    if (
        _clean_text(
            recipient.status,
            fallback="Inactive",
        ).strip().lower()
        != "active"
    ):
        return {
            "success": False,
            "message": (
                f"{recipient.email} is inactive. "
                "Test email not sent."
            ),
            "status_code": 400,
        }

    try:
        message = _build_test_email_message(
            recipient,
        )

        success, error = _send_with_retries(
            message,
            [recipient.email],
        )

        if not success:
            return {
                "success": False,
                "message": error or "Test email failed",
                "status_code": 500,
            }

        return {
            "success": True,
            "message": (
                "Testing successful email sent to "
                f"{recipient.email}"
            ),
        }

    except Exception as error:
        logger.exception(
            "Test email could not be sent"
        )

        return {
            "success": False,
            "message": str(error),
            "status_code": 500,
        }


# =========================================================
# Active violation tracking
# =========================================================
def process_violation_observation(
    *,
    camera_id: int,
    camera_name: str,
    camera_location: Optional[str],
    person_name: Optional[str],
    employee_id: Optional[str],
    helmet: bool,
    vest: bool,
    event_type: Optional[str] = None,
    alert_type: Optional[str] = None,
    evidence_path: Optional[str] = None,
    observed_at: Optional[datetime] = None,
) -> Dict[str, Any]:
    """
    Call this repeatedly while a person is visible.

    The function does not send SMTP email directly. It only updates
    violation state and adds an email job to the background queue when:

        1. The violation has remained continuously active for 60 seconds.
        2. Later emails follow the configured 5/10/15/20-minute frequency.
        3. Email alerts are enabled.
        4. No email for this violation is already queued.

    When helmet=True and vest=True, this observation is compliant,
    so any active violation state for the same camera/person is closed.
    """
    now_monotonic = time.monotonic()
    observed_at = observed_at or datetime.now()

    normalized_person_name = _normalize_person_name(
        person_name
    )
    normalized_employee_id = _normalize_employee_id(
        employee_id,
        normalized_person_name,
    )

    helmet = bool(helmet)
    vest = bool(vest)

    if helmet and vest:
        close_person_violation_state(
            camera_id=camera_id,
            person_name=normalized_person_name,
            employee_id=normalized_employee_id,
        )

        return {
            "success": True,
            "violation": False,
            "queued": False,
            "message": "Compliant PPE status",
        }

    resolved_event_type = _derive_event_type(
        helmet,
        vest,
        event_type,
    )

    if not resolved_event_type:
        return {
            "success": True,
            "violation": False,
            "queued": False,
            "message": "No violation type resolved",
        }

    resolved_alert_type = (
        _clean_text(alert_type)
        if alert_type
        else _derive_alert_type(resolved_event_type)
    )

    violation_key = _build_violation_key(
        camera_id=camera_id,
        person_name=normalized_person_name,
        employee_id=normalized_employee_id,
        helmet=helmet,
        vest=vest,
    )

    queued = False

    with _active_violations_lock:
        _close_changed_status_states_locked(
            camera_id=camera_id,
            person_name=normalized_person_name,
            employee_id=normalized_employee_id,
            current_key=violation_key,
        )

        state = _active_violations.get(
            violation_key
        )

        if state is None:
            state = ViolationState(
                key=violation_key,
                camera_id=int(camera_id),
                camera_name=_clean_text(
                    camera_name,
                    fallback=f"Camera {camera_id}",
                ),
                camera_location=_clean_text(
                    camera_location,
                    fallback="N/A",
                ),
                person_name=normalized_person_name,
                employee_id=normalized_employee_id,
                helmet=helmet,
                vest=vest,
                event_type=resolved_event_type,
                alert_type=resolved_alert_type,
                first_seen_monotonic=now_monotonic,
                last_seen_monotonic=now_monotonic,
                first_seen_at=observed_at,
                last_seen_at=observed_at,
                evidence_path=evidence_path,
            )

            _active_violations[
                violation_key
            ] = state

        else:
            state.last_seen_monotonic = now_monotonic
            state.last_seen_at = observed_at

            state.camera_name = _clean_text(
                camera_name,
                fallback=state.camera_name,
            )
            state.camera_location = _clean_text(
                camera_location,
                fallback=state.camera_location,
            )

            state.event_type = resolved_event_type
            state.alert_type = resolved_alert_type

            if evidence_path:
                state.evidence_path = evidence_path

        active_duration = (
            now_monotonic
            - state.first_seen_monotonic
        )

        repeat_frequency_minutes = (
            get_email_alert_frequency_minutes()
        )
        repeat_interval_seconds = (
            repeat_frequency_minutes * 60
        )

        if state.last_email_sent_monotonic is None:
            ready_for_email = (
                active_duration
                >= EMAIL_INITIAL_DELAY_SECONDS
            )
        else:
            seconds_since_email = (
                now_monotonic
                - state.last_email_sent_monotonic
            )
            ready_for_email = (
                seconds_since_email
                >= repeat_interval_seconds
            )

        if (
            ready_for_email
            and are_email_alerts_enabled()
            and not state.email_queued
        ):
            job = EmailJob(
                violation_key=state.key,
                camera_id=state.camera_id,
                camera_name=state.camera_name,
                camera_location=state.camera_location,
                person_name=state.person_name,
                employee_id=state.employee_id,
                helmet=state.helmet,
                vest=state.vest,
                event_type=state.event_type,
                alert_type=state.alert_type,
                first_seen_at=state.first_seen_at,
                observed_at=state.last_seen_at,
                repeat_frequency_minutes=get_email_alert_frequency_minutes(),
                evidence_path=state.evidence_path,
            )

            try:
                _email_job_queue.put_nowait(job)
                state.email_queued = True
                state.last_attempt_monotonic = now_monotonic
                queued = True

            except queue.Full:
                logger.error(
                    "Email queue is full. Alert was not queued: %s",
                    violation_key,
                )

            except Exception:
                # Queue failure must not escape into the AI/event hot path.
                logger.exception(
                    "Could not queue email alert: %s",
                    violation_key,
                )

    cleanup_stale_violation_states()

    return {
        "success": True,
        "violation": True,
        "queued": queued,
        "key": list(violation_key),
        "firstSeenAt": state.first_seen_at.isoformat(),
        "lastSeenAt": state.last_seen_at.isoformat(),
        "activeSeconds": round(
            now_monotonic
            - state.first_seen_monotonic,
            2,
        ),
        "emailsSent": state.total_emails_sent,
    }


def _close_changed_status_states_locked(
    *,
    camera_id: int,
    person_name: str,
    employee_id: str,
    current_key: Tuple[Any, ...],
) -> None:
    """
    Remove an old PPE combination when the same person's status changes.

    Example:
        old: helmet=False, vest=False
        new: helmet=True, vest=False

    The new combination starts a new one-minute timer.
    """
    if person_name == "Unknown Person":
        identity = "unknown person"
    else:
        identity = (
            employee_id.strip().lower()
            if employee_id and employee_id != "N/A"
            else person_name.strip().lower()
        )

    keys_to_remove = []

    for key in _active_violations:
        same_person = (
            int(key[0]) == int(camera_id)
            and key[1] == identity
        )

        if same_person and key != current_key:
            keys_to_remove.append(key)

    for key in keys_to_remove:
        _active_violations.pop(key, None)


def close_person_violation_state(
    *,
    camera_id: int,
    person_name: Optional[str],
    employee_id: Optional[str],
) -> int:
    normalized_person_name = _normalize_person_name(
        person_name
    )
    normalized_employee_id = _normalize_employee_id(
        employee_id,
        normalized_person_name,
    )

    if normalized_person_name == "Unknown Person":
        identity = "unknown person"
    else:
        identity = (
            normalized_employee_id.strip().lower()
            if normalized_employee_id != "N/A"
            else normalized_person_name.strip().lower()
        )

    removed_count = 0

    with _active_violations_lock:
        keys_to_remove = [
            key
            for key in _active_violations
            if (
                int(key[0]) == int(camera_id)
                and key[1] == identity
            )
        ]

        for key in keys_to_remove:
            _active_violations.pop(
                key,
                None,
            )
            removed_count += 1

    return removed_count


def cleanup_stale_violation_states() -> int:
    now_monotonic = time.monotonic()
    removed_count = 0

    with _active_violations_lock:
        stale_keys = [
            key
            for key, state
            in _active_violations.items()
            if (
                now_monotonic
                - state.last_seen_monotonic
                > EMAIL_ALERT_STALE_SECONDS
            )
        ]

        for key in stale_keys:
            _active_violations.pop(
                key,
                None,
            )
            removed_count += 1

    return removed_count


def get_active_email_violations_service() -> Dict[str, Any]:
    cleanup_stale_violation_states()

    now_monotonic = time.monotonic()

    with _active_violations_lock:
        data = []

        for state in _active_violations.values():
            data.append(
                {
                    "cameraId": state.camera_id,
                    "cameraName": state.camera_name,
                    "cameraLocation": state.camera_location,
                    "personName": state.person_name,
                    "employeeId": state.employee_id,
                    "helmet": state.helmet,
                    "vest": state.vest,
                    "eventType": state.event_type,
                    "alertType": state.alert_type,
                    "firstSeenAt": (
                        state.first_seen_at.isoformat()
                    ),
                    "lastSeenAt": (
                        state.last_seen_at.isoformat()
                    ),
                    "lastEmailSentAt": (
                        state.last_email_sent_at.isoformat()
                        if state.last_email_sent_at
                        else None
                    ),
                    "activeSeconds": round(
                        now_monotonic
                        - state.first_seen_monotonic,
                        2,
                    ),
                    "emailQueued": state.email_queued,
                    "totalEmailsSent": (
                        state.total_emails_sent
                    ),
                    "evidencePath": state.evidence_path,
                }
            )

    return {
        "success": True,
        "count": len(data),
        "data": data,
    }

# =========================================================
# Sent PPE email alert history
# =========================================================
def _save_email_alert_history(
    *,
    db,
    job: EmailJob,
    recipient_addresses: List[str],
    sent_at: datetime,
) -> Optional[EmailAlertHistory]:
    """
    Persist one history row only after a PPE alert email has been
    successfully sent.

    History persistence is intentionally best-effort: a database write
    failure is logged and rolled back, but it does not change the SMTP
    success result or stop the email worker.
    """
    try:
        history = EmailAlertHistory(
            camera_id=job.camera_id,
            camera_name=_clean_text(
                job.camera_name,
                fallback=f"Camera {job.camera_id}",
            ),
            camera_location=_clean_text(
                job.camera_location,
                fallback="Unknown Location",
            ),
            person_name=_clean_text(
                job.person_name,
                fallback="Unknown Person",
            ),
            employee_id=_clean_text(
                job.employee_id,
                fallback="N/A",
            ),
            event_type=_clean_text(
                job.event_type,
                fallback="PPE Violation",
            ),
            helmet=bool(job.helmet),
            vest=bool(job.vest),
            evidence_image=job.evidence_path,
            recipients=",".join(recipient_addresses),
            email_status="Sent",
            email_sent_at=sent_at,
        )

        db.add(history)
        db.commit()
        db.refresh(history)

        return history

    except Exception:
        db.rollback()
        logger.exception(
            "Could not save sent PPE email alert history for %s",
            job.violation_key,
        )
        return None


def _serialize_email_alert_history(
    row: EmailAlertHistory,
) -> Dict[str, Any]:
    recipient_addresses = [
        email_address.strip()
        for email_address in (row.recipients or "").split(",")
        if email_address.strip()
    ]

    return {
        "id": row.id,
        "cameraId": row.camera_id,
        "cameraName": row.camera_name,
        "cameraLocation": row.camera_location,
        "personName": row.person_name,
        "employeeId": row.employee_id,
        "eventType": row.event_type,
        "helmet": bool(row.helmet),
        "vest": bool(row.vest),
        "evidenceImage": row.evidence_image,
        "recipients": recipient_addresses,
        "recipientCount": len(recipient_addresses),
        "emailStatus": row.email_status,
        "emailSentAt": (
            row.email_sent_at.isoformat()
            if row.email_sent_at
            else None
        ),
        "createdAt": (
            row.created_at.isoformat()
            if row.created_at
            else None
        ),
    }


def get_email_alert_history_service(
    db,
    page: int = 1,
    page_size: int = 10,
) -> Dict[str, Any]:
    """
    Return successfully sent PPE email alerts using server-side pagination.

    pagination.total is the value that should be used by the frontend
    TOTAL ALERTS card.
    """
    try:
        page = max(1, int(page))
    except (TypeError, ValueError):
        page = 1

    try:
        page_size = max(1, min(int(page_size), 100))
    except (TypeError, ValueError):
        page_size = 10

    query = db.query(EmailAlertHistory)

    total = query.count()

    rows = (
        query
        .order_by(
            EmailAlertHistory.email_sent_at.desc(),
            EmailAlertHistory.id.desc(),
        )
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )

    total_pages = (
        (total + page_size - 1) // page_size
        if total > 0
        else 0
    )

    return {
        "success": True,
        "data": [
            _serialize_email_alert_history(row)
            for row in rows
        ],
        "pagination": {
            "page": page,
            "pageSize": page_size,
            "total": total,
            "totalPages": total_pages,
        },
    }


def _publish_email_sent_notification(
    job: EmailJob,
    recipient_addresses: List[str],
    sent_at: datetime,
) -> Dict[str, Any]:
    global _latest_email_notification
    global _email_notification_sequence

    with _email_notification_lock:
        _email_notification_sequence += 1

        notification = {
            "notificationId": _email_notification_sequence,
            "status": "sent",
            "cameraId": job.camera_id,
            "cameraName": job.camera_name,
            "cameraLocation": job.camera_location,
            "personName": job.person_name,
            "employeeId": job.employee_id,
            "eventType": job.event_type,
            "alertType": job.alert_type,
            "helmet": job.helmet,
            "vest": job.vest,
            "recipientCount": len(recipient_addresses),
            "sentAt": sent_at.isoformat(),
        }

        _latest_email_notification = notification

        return dict(notification)


def get_latest_email_sent_notification_service() -> Dict[str, Any]:
    with _email_notification_lock:
        notification = (
            dict(_latest_email_notification)
            if _latest_email_notification
            else None
        )

    return {
        "success": True,
        "data": notification,
    }


# =========================================================
# Background email worker
# =========================================================
def _process_email_job(job: EmailJob) -> None:
    if not are_email_alerts_enabled():
        logger.info(
            "Email alert skipped because alerts are disabled: %s",
            job.violation_key,
        )

        with _active_violations_lock:
            state = _active_violations.get(
                job.violation_key
            )

            if state:
                state.email_queued = False

        return

    db = get_db_session()

    try:
        recipient_addresses = (
            _get_active_recipient_addresses(
                db,
                job.alert_type,
            )
        )

        if not recipient_addresses:
            logger.warning(
                "No active recipients found for %s",
                job.alert_type,
            )

            with _active_violations_lock:
                state = _active_violations.get(
                    job.violation_key
                )

                if state:
                    state.email_queued = False

            return

        message = _build_violation_email_message(
            job
        )

        success, error = _send_with_retries(
            message,
            recipient_addresses,
        )

        now_monotonic = time.monotonic()
        now_datetime = datetime.now()

        with _active_violations_lock:
            state = _active_violations.get(
                job.violation_key
            )

            if state:
                state.email_queued = False

                if success:
                    state.last_email_sent_monotonic = (
                        now_monotonic
                    )
                    state.last_email_sent_at = now_datetime
                    state.total_emails_sent += 1

        if success:
            _save_email_alert_history(
                db=db,
                job=job,
                recipient_addresses=recipient_addresses,
                sent_at=now_datetime,
            )

            notification = _publish_email_sent_notification(
                job=job,
                recipient_addresses=recipient_addresses,
                sent_at=now_datetime,
            )

            logger.info(
                "Alert email sent for %s to %s recipients. Notification ID: %s",
                job.violation_key,
                len(recipient_addresses),
                notification["notificationId"],
            )
        else:
            logger.error(
                "Alert email failed for %s: %s",
                job.violation_key,
                error,
            )

    except Exception:
        logger.exception(
            "Unexpected email worker error for %s",
            job.violation_key,
        )

        with _active_violations_lock:
            state = _active_violations.get(
                job.violation_key
            )

            if state:
                state.email_queued = False

    finally:
        db.close()


def _email_worker_loop() -> None:
    logger.info("Email worker started")

    while not _worker_stop_event.is_set():
        try:
            try:
                cleanup_stale_violation_states()
            except Exception:
                logger.exception(
                    "Could not clean stale email violation states"
                )

            try:
                job = _email_job_queue.get(
                    timeout=EMAIL_WORKER_POLL_SECONDS
                )
            except queue.Empty:
                continue

            try:
                if job is None:
                    break

                try:
                    _process_email_job(job)
                except Exception:
                    # Final per-job isolation boundary. One bad email job must
                    # never permanently terminate the worker.
                    logger.exception(
                        "Unhandled email job processing error"
                    )
            finally:
                try:
                    _email_job_queue.task_done()
                except Exception:
                    logger.exception(
                        "Could not mark email queue task done"
                    )

        except Exception:
            # Ultimate loop isolation. Unexpected worker bugs are logged and
            # the loop continues instead of silently dying.
            logger.exception(
                "Unexpected email worker loop error"
            )

            if _worker_stop_event.wait(0.5):
                break

    logger.info("Email worker stopped")


def start_email_worker() -> Dict[str, Any]:
    global _worker_thread

    # Settings/DB failure must not make the whole application fail startup.
    try:
        load_email_alert_settings_service()
    except Exception:
        logger.exception(
            "Email settings could not be loaded at worker startup; "
            "continuing with in-memory defaults"
        )

    with _worker_lock:
        if (
            _worker_thread is not None
            and _worker_thread.is_alive()
        ):
            return {
                "success": True,
                "message": "Email worker already running",
            }

        _worker_stop_event.clear()

        _worker_thread = threading.Thread(
            target=_email_worker_loop,
            name="email-alert-worker",
            daemon=True,
        )

        _worker_thread.start()

    return {
        "success": True,
        "message": "Email worker started",
    }


def stop_email_worker(
    wait_for_pending_jobs: bool = False,
) -> Dict[str, Any]:
    global _worker_thread

    with _worker_lock:
        if (
            _worker_thread is None
            or not _worker_thread.is_alive()
        ):
            return {
                "success": True,
                "message": "Email worker is not running",
            }

        if wait_for_pending_jobs:
            try:
                _email_job_queue.join()
            except Exception:
                logger.exception(
                    "Could not wait for pending email jobs"
                )

        _worker_stop_event.set()

        try:
            _email_job_queue.put_nowait(None)
        except queue.Full:
            pass

        _worker_thread.join(timeout=10.0)
        _worker_thread = None

    return {
        "success": True,
        "message": "Email worker stopped",
    }


def get_email_worker_status_service() -> Dict[str, Any]:
    running = bool(
        _worker_thread
        and _worker_thread.is_alive()
    )

    try:
        alerts_enabled = are_email_alerts_enabled()
    except Exception:
        logger.exception(
            "Could not resolve email alert enabled status"
        )
        with _alert_setting_lock:
            alerts_enabled = _email_alerts_enabled

    try:
        frequency_minutes = get_email_alert_frequency_minutes()
    except Exception:
        logger.exception(
            "Could not resolve email frequency"
        )
        with _alert_setting_lock:
            frequency_minutes = _email_frequency_minutes

    with _active_violations_lock:
        active_violation_count = len(_active_violations)

    return {
        "success": True,
        "running": running,
        "queueSize": _email_job_queue.qsize(),
        "queueMaxSize": EMAIL_QUEUE_MAXSIZE,
        "alertsEnabled": alerts_enabled,
        "frequencyMinutes": frequency_minutes,
        "initialDelaySeconds": EMAIL_INITIAL_DELAY_SECONDS,
        "activeViolations": active_violation_count,
    }




# =========================================================
# Additional resilience helpers
# =========================================================
def clear_email_runtime_state_service() -> Dict[str, Any]:
    """
    Clear transient in-memory email tracking only.

    This does not delete database recipients/settings and does not change
    SMTP configuration.
    """
    global _latest_email_notification

    with _active_violations_lock:
        _active_violations.clear()

    with _email_notification_lock:
        _latest_email_notification = None

    return {
        "success": True,
        "message": "Email runtime state cleared",
    }


def _read_counting_email_template() -> str:
    if not COUNTING_EMAIL_TEMPLATE_PATH.exists():
        raise FileNotFoundError(
            f"Counting email template not found: "
            f"{COUNTING_EMAIL_TEMPLATE_PATH}"
        )

    return COUNTING_EMAIL_TEMPLATE_PATH.read_text(
        encoding="utf-8"
    )

def _get_counting_email_recipients(
    db,
) -> List[str]:
    recipients = (
        db.query(EmailRecipient)
        .filter(
            EmailRecipient.is_active.is_(True)
        )
        .all()
    )

    emails = []
    seen = set()

    for recipient in recipients:
        status = str(
            recipient.status or ""
        ).strip().lower()

        if status != "active":
            continue

        email_address = str(
            recipient.email or ""
        ).strip().lower()

        if (
            not email_address
            or email_address in seen
        ):
            continue

        seen.add(email_address)
        emails.append(email_address)

    return emails

def _build_counting_test_email_message() -> EmailMessage:
    template = _read_counting_email_template()

    message = EmailMessage()

    message["Subject"] = (
        "VisionAI Monitoring System - Bag & Box Counting Report"
    )

    message["From"] = SMTP_USER

    # Actual recipients SMTP send ke time diye jayenge.
    message["To"] = SMTP_USER

    message.set_content(
        """Dear Team,

This is a test Bag & Box Counting Report.

Dummy Counting Data

Bags Counted: 48
Boxes Counted: 72
Total Items: 120
Interval: 5 Minutes

Regards,
VisionAI Monitoring System
Paperless AI Team
"""
    )

    message.add_alternative(
        template,
        subtype="html",
    )

    html_part = message.get_payload()[-1]

    # Paperless AI logo
    _add_inline_image(
        html_part,
        PAPERLESS_LOGO_PATH,
        "paperless_logo",
    )

    # Vision AI logo
    _add_inline_image(
        html_part,
        VISION_AI_LOGO_PATH,
        "vision_ai_logo",
    )

    # ---------------------------------------------------------
    # Counting Management email icons
    # ---------------------------------------------------------
    _add_inline_image(
        html_part,
        COUNTING_REPORT_CUBE_ICON_PATH,
        "report_cube_icon",
    )

    _add_inline_image(
        html_part,
        COUNTING_CALENDAR_ICON_PATH,
        "calendar_icon",
    )

    _add_inline_image(
        html_part,
        COUNTING_BAG_ICON_PATH,
        "bag_icon",
    )

    _add_inline_image(
        html_part,
        COUNTING_BOX_ICON_PATH,
        "box_icon",
    )

    _add_inline_image(
        html_part,
        COUNTING_TOTAL_ITEMS_ICON_PATH,
        "total_items_icon",
    )

    _add_inline_image(
        html_part,
        COUNTING_INTERVAL_CLOCK_ICON_PATH,
        "interval_clock_icon",
    )

    _add_inline_image(
        html_part,
        COUNTING_CAMERA_ICON_PATH,
        "camera_icon",
    )

    _add_inline_image(
        html_part,
        COUNTING_TIME_ICON_PATH,
        "time_icon",
    )

    _add_inline_image(
        html_part,
        COUNTING_ITEM_SUMMARY_ICON_PATH,
        "item_summary_icon",
    )

    _add_inline_image(
        html_part,
        COUNTING_TREND_ICON_PATH,
        "trend_icon",
    )

    _add_inline_image(
        html_part,
        COUNTING_STATUS_CHECK_ICON_PATH,
        "status_check_icon",
    )

    _add_inline_image(
        html_part,
        COUNTING_REPORT_DOCUMENT_ICON_PATH,
        "report_document_icon",
    )

    return message

def send_counting_test_email_service() -> Dict[str, Any]:
    db = get_db_session()

    try:
        recipients = (
            _get_counting_email_recipients(db)
        )

        if not recipients:
            return {
                "success": False,
                "message": (
                    "No active email recipients found"
                ),
                "status_code": 400,
            }

        message = (
            _build_counting_test_email_message()
        )

        success, error = _send_with_retries(
            message,
            recipients,
        )

        if not success:
            return {
                "success": False,
                "message": (
                    error
                    or "Counting test email could not be sent"
                ),
                "status_code": 500,
            }

        logger.info(
            "Counting test email sent to %s recipients",
            len(recipients),
        )

        return {
            "success": True,
            "message": (
                "Counting test email sent successfully"
            ),
            "recipient_count": len(recipients),
        }

    except Exception as error:
        logger.exception(
            "Counting test email could not be sent"
        )

        return {
            "success": False,
            "message": str(error),
            "status_code": 500,
        }

    finally:
        db.close()