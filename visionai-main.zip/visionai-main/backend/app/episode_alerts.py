"""
Email alerts for the episodes that are not PPE violations.

PPE emails keep their own state machine in email_service (the 60-second rule
and the repeat cadence). Everything else goes through here: this module
listens on the episode bus and sends one email, once, when

  * a person is confirmed inside a restricted zone   (kind person_in_zone, opened)
  * a vehicle crosses its zone's time limit          (kind vehicle_in_zone, updated with over_limit)
  * a camera goes offline                            (kind system, subject camera, opened)

Who gets which email is chosen per recipient in Email Settings by alert type;
"All Alerts" recipients get everything. Sending runs on its own thread and
never touches the camera loop - a slow SMTP server only delays the email.
"""
from __future__ import annotations

import html
import logging
import os
import queue
import threading
from collections import deque
from datetime import datetime
from email.message import EmailMessage
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from app import episodes
from app.database import get_db_session
from app.email_service import (
    SMTP_USER,
    _attach_file,
    _get_active_recipient_addresses,
    _send_with_retries,
    are_email_alerts_enabled,
)

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent

# Alert type (as shown in Email Settings) per episode kind.
ALERT_TYPE_RESTRICTED = "Restricted Zone"
ALERT_TYPE_VEHICLE_OVER_LIMIT = "Vehicle Over Limit"
ALERT_TYPE_CAMERA_OFFLINE = "Camera Offline"

SEVERITY_WORD = {"critical": "Critical", "warning": "Warning", "notice": "Notice", "info": "Info"}
SEVERITY_COLOUR = {"critical": "#c62828", "warning": "#b26a00", "notice": "#37474f", "info": "#1565c0"}

# The board link at the bottom of every email.
OPS_BOARD_URL = os.getenv("FRONTEND_OPS_URL", "").strip() or (
    os.getenv("FRONTEND_LOGIN_URL", "http://localhost:5173/login").strip().rsplit("/login", 1)[0] + "/ops"
)

_REMEMBER = 2000   # episode ids already emailed, so an episode is never mailed twice
_notified: deque = deque(maxlen=_REMEMBER)
_notified_set = set()
_notified_lock = threading.Lock()

_worker: Optional[threading.Thread] = None
_worker_lock = threading.Lock()
_stop = threading.Event()

Sender = Callable[[EmailMessage, List[str]], Tuple[bool, Optional[str]]]


# ---------------------------------------------------------------------------
# Decide
# ---------------------------------------------------------------------------

def alert_type_for(message: Dict[str, Any]) -> Optional[str]:
    """
    Which alert (if any) a bus message deserves. Pure, so it is easy to test.
    """
    if not isinstance(message, dict):
        return None
    episode = message.get("episode") or {}
    kind = episode.get("kind")
    mtype = message.get("type")

    if mtype == "opened" and kind == "person_in_zone":
        if (episode.get("attributes") or {}).get("zone_type", "restricted") == "restricted":
            return ALERT_TYPE_RESTRICTED
        return None

    if mtype == "updated" and kind == "vehicle_in_zone":
        attrs = episode.get("attributes") or {}
        if attrs.get("over_limit") and episode.get("severity") in ("warning", "critical"):
            return ALERT_TYPE_VEHICLE_OVER_LIMIT
        return None

    if mtype == "opened" and kind == "system" and episode.get("subject_type") == "camera":
        return ALERT_TYPE_CAMERA_OFFLINE

    return None


def _first_time(episode_id: str, alert_type: str) -> bool:
    key = (episode_id, alert_type)
    with _notified_lock:
        if key in _notified_set:
            return False
        if len(_notified) == _notified.maxlen:
            _notified_set.discard(_notified[0])
        _notified.append(key)
        _notified_set.add(key)
        return True


def forget_all() -> None:
    """Tests only."""
    with _notified_lock:
        _notified.clear()
        _notified_set.clear()


# ---------------------------------------------------------------------------
# Build
# ---------------------------------------------------------------------------

def _fmt_local(iso_value: Optional[str]) -> str:
    if not iso_value:
        return "-"
    try:
        return datetime.fromisoformat(iso_value).strftime("%d %b %Y, %I:%M:%S %p")
    except ValueError:
        return iso_value


def _fmt_duration(seconds: Optional[float]) -> str:
    seconds = int(seconds or 0)
    if seconds < 60:
        return f"{seconds} s"
    minutes, seconds = divmod(seconds, 60)
    if minutes < 60:
        return f"{minutes} m {seconds:02d} s"
    hours, minutes = divmod(minutes, 60)
    return f"{hours} h {minutes:02d} m"


def _evidence_file(episode: Dict[str, Any]) -> Optional[str]:
    rel = episode.get("evidence_last") or episode.get("evidence_first")
    if not rel:
        return None
    path = BASE_DIR / str(rel).lstrip("/")
    return str(path) if path.is_file() else None


def _facts(episode: Dict[str, Any], alert_type: str) -> List[Tuple[str, str]]:
    attrs = episode.get("attributes") or {}
    where = episode.get("zone_name") or episode.get("camera_name") or "-"
    camera = f"{episode.get('camera_name') or '-'} (ID {episode.get('camera_id')})"
    facts: List[Tuple[str, str]] = []
    if alert_type == ALERT_TYPE_RESTRICTED:
        facts += [("Who", episode.get("subject_label") or "Unknown person"),
                  ("Restricted zone", where)]
    elif alert_type == ALERT_TYPE_VEHICLE_OVER_LIMIT:
        facts += [("Vehicle", episode.get("subject_label") or "Vehicle"),
                  ("Zone", where),
                  ("Waiting for", _fmt_duration(episode.get("duration_sec"))),
                  ("Time limit", _fmt_duration(attrs.get("limit_sec")))]
    facts += [("Camera", camera),
              ("Location", episode.get("camera_location") or "-"),
              ("Started", _fmt_local(episode.get("started_at"))),
              ("Episode", episode.get("episode_id") or "-")]
    return facts


def build_message(episode: Dict[str, Any], alert_type: str) -> EmailMessage:
    severity = episode.get("severity") or "warning"
    sev_word = SEVERITY_WORD.get(severity, severity.title())
    colour = SEVERITY_COLOUR.get(severity, "#37474f")
    title = episode.get("title") or alert_type
    location = episode.get("camera_location") or episode.get("camera_name") or "site"

    subject = f"[{sev_word}] {title} - {location}"

    rows = "".join(
        f'<tr><td style="padding:6px 10px;color:#607d8b;white-space:nowrap">{html.escape(k)}</td>'
        f'<td style="padding:6px 10px;color:#102027;font-weight:600">{html.escape(str(v))}</td></tr>'
        for k, v in _facts(episode, alert_type)
    )
    body_html = f"""<!DOCTYPE html>
<html><body style="margin:0;padding:24px 10px;background:#f4f6f8;font-family:Arial,Helvetica,sans-serif">
<table role="presentation" width="560" cellspacing="0" cellpadding="0" border="0" style="max-width:100%;margin:0 auto;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e0e6ea">
<tr><td style="background:{colour};color:#ffffff;padding:16px 20px;font-size:12px;letter-spacing:.08em;text-transform:uppercase">{html.escape(sev_word)} &middot; {html.escape(alert_type)}</td></tr>
<tr><td style="padding:20px 20px 6px 20px;font-size:20px;font-weight:700;color:#102027">{html.escape(title)}</td></tr>
<tr><td style="padding:0 10px 10px 10px"><table role="presentation" cellspacing="0" cellpadding="0" border="0" style="font-size:14px">{rows}</table></td></tr>
<tr><td style="padding:6px 20px 20px 20px;font-size:13px;color:#455a64">The picture is attached. Acknowledge or resolve this on the Ops Board:<br>
<a href="{html.escape(OPS_BOARD_URL)}" style="color:#1565c0">{html.escape(OPS_BOARD_URL)}</a></td></tr>
<tr><td style="padding:12px 20px;background:#f4f6f8;font-size:11px;color:#78909c">Vision AI &middot; automatic alert, one email per episode.</td></tr>
</table></body></html>"""

    text = f"{sev_word}: {title}\n" + "\n".join(f"{k}: {v}" for k, v in _facts(episode, alert_type)) + f"\n\nOps Board: {OPS_BOARD_URL}\n"

    message = EmailMessage()
    message["Subject"] = subject
    if SMTP_USER:
        message["From"] = SMTP_USER
    message.set_content(text)
    message.add_alternative(body_html, subtype="html")
    _attach_file(message, _evidence_file(episode))
    return message


# ---------------------------------------------------------------------------
# Send
# ---------------------------------------------------------------------------

def handle_message(message: Dict[str, Any], *, sender: Optional[Sender] = None) -> Optional[Dict[str, Any]]:
    """
    Look at one bus message; send the email it deserves, if any. Returns a
    small report (for tests and logs) or None when nothing was sent.
    """
    alert_type = alert_type_for(message)
    if alert_type is None:
        return None
    episode = message["episode"]
    episode_id = episode.get("episode_id") or ""
    if not _first_time(episode_id, alert_type):
        return None

    if not are_email_alerts_enabled():
        logger.info("Episode alert skipped, alerts disabled: %s %s", alert_type, episode_id)
        return {"episode_id": episode_id, "alert_type": alert_type, "sent": False, "reason": "disabled"}

    db = get_db_session()
    try:
        recipients = _get_active_recipient_addresses(db, alert_type)
    finally:
        db.close()
    if not recipients:
        logger.warning("Episode alert has no recipients: %s %s", alert_type, episode_id)
        return {"episode_id": episode_id, "alert_type": alert_type, "sent": False, "reason": "no recipients"}

    mail = build_message(episode, alert_type)
    ok, error = (sender or _send_with_retries)(mail, recipients)
    if ok:
        logger.info("Episode alert sent: %s %s -> %d recipients", alert_type, episode_id, len(recipients))
    else:
        logger.error("Episode alert failed: %s %s: %s", alert_type, episode_id, error)
    return {"episode_id": episode_id, "alert_type": alert_type, "sent": bool(ok),
            "recipients": recipients, "subject": mail["Subject"], "error": error}


def _loop(bus: "queue.Queue", sender: Optional[Sender]) -> None:
    while not _stop.is_set():
        try:
            message = bus.get(timeout=1.0)
        except queue.Empty:
            continue
        try:
            handle_message(message, sender=sender)
        except Exception:
            logger.exception("Episode alert worker error")


def start_episode_alerts(*, sender: Optional[Sender] = None) -> Dict[str, Any]:
    global _worker
    with _worker_lock:
        if _worker is not None and _worker.is_alive():
            return {"success": True, "message": "Episode alert worker already running"}
        _stop.clear()
        bus = episodes.subscribe()
        _worker = threading.Thread(target=_loop, args=(bus, sender), name="episode-alerts", daemon=True)
        _worker.start()
        return {"success": True, "message": "Episode alert worker started"}


def stop_episode_alerts(timeout: float = 3.0) -> None:
    global _worker
    with _worker_lock:
        _stop.set()
        if _worker is not None:
            _worker.join(timeout)
        _worker = None
