"""
Episode engine.

One Episode row per thing-in-progress seen by a camera. detection_service
opens/touches/closes episodes; the API reads live state and records human
actions; the Ops Board and the phone app subscribe to the live bus.

Keep this module light: it must import without the detection models.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import queue
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Optional

from app.database import Camera, Episode, get_db_session
from app.live_event_service import EVIDENCE_DIR, save_evidence_image
from app.timezone_util import to_local_time

SEVERITIES = ("critical", "warning", "notice", "info")
STATUSES = ("open", "acknowledged", "resolved", "false_positive")

# Write last_seen_at to the database at most this often per open episode.
TOUCH_DB_WRITE_SEC = 10.0

# Open episodes: episode_id -> {"last_db_write": mono, "people_count": int}
_open_index: Dict[str, Dict[str, Any]] = {}
_lock = threading.Lock()

# ---------------------------------------------------------------------------
# Time helpers
# ---------------------------------------------------------------------------

def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _as_utc(value: Optional[datetime]) -> Optional[datetime]:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def _epoch(value: Optional[datetime]) -> Optional[float]:
    value = _as_utc(value)
    return value.timestamp() if value else None


def _local_iso(value: Optional[datetime]) -> Optional[str]:
    return to_local_time(_as_utc(value)).isoformat() if value else None


# ---------------------------------------------------------------------------
# Serialisation
# ---------------------------------------------------------------------------

def needs_action(row: Episode) -> bool:
    """True while a person still has to deal with this episode."""
    return row.status in ("open", "acknowledged") and row.severity != "info"


def serialize_episode(row: Episode) -> Dict[str, Any]:
    started = _as_utc(row.started_at)
    ended = _as_utc(row.ended_at)
    end_for_duration = ended or _utcnow()
    duration = max(0.0, (end_for_duration - started).total_seconds()) if started else 0.0

    try:
        attributes = json.loads(row.attributes_json) if row.attributes_json else {}
    except ValueError:
        attributes = {}

    return {
        "episode_id": row.episode_id,
        "site_id": row.site_id,
        "camera_id": row.camera_id,
        "camera_name": row.camera_name,
        "camera_location": row.camera_location,
        "zone_id": row.zone_id,
        "zone_name": row.zone_name,
        "kind": row.kind,
        "title": row.title,
        "subject_type": row.subject_type,
        "subject_label": row.subject_label,
        "subject_id": row.subject_id,
        "severity": row.severity,
        "status": row.status,
        "needs_action": needs_action(row),
        "started_at": _local_iso(row.started_at),
        "started_epoch": _epoch(row.started_at),
        "last_seen_epoch": _epoch(row.last_seen_at),
        "ended_at": _local_iso(row.ended_at),
        "ended_epoch": _epoch(row.ended_at),
        "duration_sec": round(duration, 1),
        "acknowledged_by": row.acknowledged_by,
        "acknowledged_at": _local_iso(row.acknowledged_at),
        "resolved_by": row.resolved_by,
        "resolved_at": _local_iso(row.resolved_at),
        "resolve_note": row.resolve_note,
        "evidence_first": row.evidence_first,
        "evidence_last": row.evidence_last,
        "people_count": row.people_count,
        "attributes": attributes,
    }


# ---------------------------------------------------------------------------
# Lifecycle: open / touch / close
# ---------------------------------------------------------------------------

def _new_episode_id(camera_id: int) -> str:
    # Timestamp for readability, short random tail so two episodes opened in
    # the same instant on one camera can never collide on the unique column.
    stamp = datetime.now().strftime("%Y%m%d%H%M%S%f")
    return f"EP-{int(camera_id)}-{stamp}-{uuid.uuid4().hex[:4]}"


def open_episode(
    *,
    camera_id: int,
    camera_name: str,
    camera_location: Optional[str],
    kind: str,
    title: str,
    subject_type: str,
    subject_label: str,
    subject_id: Optional[str],
    severity: str,
    frame=None,
    zone_id: Optional[int] = None,
    zone_name: Optional[str] = None,
    people_count: int = 1,
    attributes: Optional[Dict[str, Any]] = None,
    site_id: Optional[int] = None,
) -> Optional[str]:
    """Create the row (database first, picture second). Returns episode_id or None."""
    if severity not in SEVERITIES:
        severity = "warning"

    episode_id = _new_episode_id(camera_id)
    now = _utcnow()
    db = get_db_session()

    try:
        row = Episode(
            episode_id=episode_id, site_id=site_id,
            camera_id=int(camera_id), camera_name=camera_name, camera_location=camera_location,
            zone_id=zone_id, zone_name=zone_name,
            kind=kind, title=str(title)[:200],
            subject_type=subject_type, subject_label=str(subject_label)[:150], subject_id=subject_id,
            severity=severity, status="open",
            started_at=now, last_seen_at=now,
            people_count=max(1, int(people_count)),
            attributes_json=json.dumps(attributes or {}),
        )
        db.add(row)
        db.commit()

        if frame is not None:
            picture = save_evidence_image(frame, episode_id)
            if picture:
                row.evidence_first = picture
                row.evidence_last = picture
                db.commit()

        with _lock:
            _open_index[episode_id] = {"last_db_write": time.monotonic(), "people_count": row.people_count}

        publish({"type": "opened", "episode": serialize_episode(row)})
        return episode_id

    except Exception as exc:
        try:
            db.rollback()
        except Exception:
            pass
        print("[EPISODE] open failed:", exc)
        return None

    finally:
        db.close()


def touch_episode(episode_id: str, *, frame=None, people_count: Optional[int] = None) -> None:
    """
    Still being seen. Cheap by design: the database is written at most every
    TOUCH_DB_WRITE_SEC, or immediately when the people count rises (that is a
    new arrival and deserves a fresh picture + a live update).
    """
    now_mono = time.monotonic()

    with _lock:
        entry = _open_index.get(episode_id)
        if entry is None:
            return
        arrival = people_count is not None and people_count > entry["people_count"]
        due = now_mono - entry["last_db_write"] >= TOUCH_DB_WRITE_SEC
        if not (arrival or due):
            return
        entry["last_db_write"] = now_mono
        if people_count is not None:
            entry["people_count"] = max(entry["people_count"], people_count)
        new_count = entry["people_count"]

    db = get_db_session()
    try:
        row = db.query(Episode).filter(Episode.episode_id == episode_id).first()
        if row is None:
            return
        row.last_seen_at = _utcnow()
        if new_count != row.people_count:
            row.people_count = new_count
        if arrival and frame is not None:
            picture = save_evidence_image(frame, f"{episode_id}-{new_count}")
            if picture:
                row.evidence_last = picture
        db.commit()
        if arrival:
            publish({"type": "updated", "episode": serialize_episode(row)})
    except Exception as exc:
        try:
            db.rollback()
        except Exception:
            pass
        print("[EPISODE] touch failed:", exc)
    finally:
        db.close()


def close_episode(episode_id: str, *, frame=None) -> None:
    """Ended on camera. Info-severity episodes need nobody, so they auto-resolve."""
    with _lock:
        _open_index.pop(episode_id, None)

    db = get_db_session()
    try:
        row = db.query(Episode).filter(Episode.episode_id == episode_id).first()
        if row is None or row.ended_at is not None:
            return
        now = _utcnow()
        row.ended_at = now
        row.last_seen_at = now
        if frame is not None:
            picture = save_evidence_image(frame, f"{episode_id}-end")
            if picture:
                row.evidence_last = picture
        if row.severity == "info" and row.status in ("open", "acknowledged"):
            row.status = "resolved"
            row.resolved_by = "system"
            row.resolved_at = now
            row.resolve_note = "Ended on camera"
        db.commit()
        publish({"type": "closed", "episode": serialize_episode(row)})
    except Exception as exc:
        try:
            db.rollback()
        except Exception:
            pass
        print("[EPISODE] close failed:", exc)
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------

def _live_query(db):
    """
    Live = a person still has it (open / acknowledged). That covers both
    "still on camera" and "ended but not closed out"; info episodes leave
    this set the moment they end because close_episode auto-resolves them.
    """
    return db.query(Episode).filter(Episode.status.in_(("open", "acknowledged")))


def live_state() -> Dict[str, Any]:
    db = get_db_session()
    try:
        rows = _live_query(db).order_by(Episode.started_at.asc()).all()
        items = [serialize_episode(r) for r in rows]
    finally:
        db.close()

    counts = {"critical": 0, "warning": 0, "notice": 0, "info": 0, "needs_action": 0, "vehicles": 0, "people": 0}
    for item in items:
        counts[item["severity"]] = counts.get(item["severity"], 0) + 1
        if item["needs_action"]:
            counts["needs_action"] += 1
        if item["subject_type"] == "vehicle":
            counts["vehicles"] += 1
        elif item["subject_type"] in ("person", "unknown"):
            # An unrecognised person is still a person on the board.
            counts["people"] += 1

    return {"open": items, "counts": counts, "generated_epoch": time.time()}


def list_episodes(*, status=None, kind=None, camera_id=None, since=None, until=None, limit=200) -> List[Dict[str, Any]]:
    db = get_db_session()
    try:
        q = db.query(Episode)
        if status:
            q = q.filter(Episode.status == status)
        if kind:
            q = q.filter(Episode.kind == kind)
        if camera_id is not None:
            q = q.filter(Episode.camera_id == int(camera_id))
        if since is not None:
            q = q.filter(Episode.started_at >= since)
        if until is not None:
            q = q.filter(Episode.started_at <= until)
        rows = q.order_by(Episode.started_at.desc()).limit(max(1, min(int(limit), 1000))).all()
        return [serialize_episode(r) for r in rows]
    finally:
        db.close()


def find_adoptable(
    *,
    kind: str,
    camera_id: int,
    zone_id: Optional[int],
    subject_type: str,
    max_age_sec: float,
    exclude: Optional[Iterable[str]] = None,
) -> Optional[str]:
    """
    An episode still open on camera for the same kind / camera / zone /
    subject type, last seen within max_age_sec. After a backend restart the
    in-memory visit table is empty, so the first confirmed sighting adopts
    this row instead of opening a duplicate. Oldest first, so several trucks
    in one yard each pick up a different row.
    """
    skip = set(exclude or ())
    db = get_db_session()
    try:
        q = (
            db.query(Episode)
            .filter(
                Episode.kind == kind,
                Episode.camera_id == int(camera_id),
                Episode.subject_type == subject_type,
                Episode.ended_at.is_(None),
                Episode.status.in_(("open", "acknowledged")),
                Episode.last_seen_at >= _utcnow() - timedelta(seconds=max_age_sec),
            )
        )
        q = q.filter(Episode.zone_id == zone_id) if zone_id is not None else q.filter(Episode.zone_id.is_(None))
        for row in q.order_by(Episode.started_at.asc()).all():
            if row.episode_id not in skip:
                return row.episode_id
        return None
    finally:
        db.close()


def adopt_episode(episode_id: str, *, people_count: int = 1) -> None:
    """Re-register an existing open episode so touch_episode works for it again."""
    with _lock:
        _open_index[episode_id] = {"last_db_write": time.monotonic(), "people_count": max(1, int(people_count))}


def open_unended(kinds: Iterable[str], *, idle_for_sec: float) -> List[str]:
    """Episode ids of the given kinds still without an end, not touched for idle_for_sec."""
    db = get_db_session()
    try:
        rows = (
            db.query(Episode.episode_id)
            .filter(
                Episode.kind.in_(tuple(kinds)),
                Episode.ended_at.is_(None),
                Episode.last_seen_at < _utcnow() - timedelta(seconds=idle_for_sec),
            )
            .all()
        )
        return [r[0] for r in rows]
    finally:
        db.close()


def as_live_event_rows(
    *,
    limit: Optional[int] = 100,
    since: Optional[datetime] = None,
    until: Optional[datetime] = None,
    camera_id: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """
    Episodes in the shape the older Live Events table and its Excel export
    already understand - one row per episode, every kind (PPE, vehicles,
    restricted areas, camera notices), so both screens show the same truth.
    """
    db = get_db_session()
    try:
        q = db.query(Episode)
        if since is not None:
            q = q.filter(Episode.started_at >= since)
        if until is not None:
            q = q.filter(Episode.started_at <= until)
        if camera_id is not None:
            q = q.filter(Episode.camera_id == int(camera_id))
        q = q.order_by(Episode.started_at.desc())
        if limit:
            q = q.limit(max(1, min(int(limit), 5000)))
        rows = q.all()
    finally:
        db.close()

    def yes_no(value):
        if value is None:
            return "-"
        return "Yes" if value else "No"

    out = []
    for row in rows:
        try:
            attrs = json.loads(row.attributes_json) if row.attributes_json else {}
        except ValueError:
            attrs = {}
        started = _as_utc(row.started_at)
        ended = _as_utc(row.ended_at)
        title = row.title
        if ended and started:
            secs = int((ended - started).total_seconds())
            h, rest = divmod(secs, 3600)
            m, s_ = divmod(rest, 60)
            lasted = f"{h}h {m:02d}m" if h else (f"{m}m {s_:02d}s" if m else f"{s_}s")
            title = f"{title} — ended after {lasted}"
        state = row.status if row.status != "open" else ("open" if row.ended_at is None else "needs close-out")
        out.append({
            "event_id": row.episode_id,
            "camera_id": row.camera_id,
            "frame_id": 0,
            "camera_name": row.camera_name,
            "camera_location": row.camera_location or "N/A",
            "event_type": title,
            "person_name": row.subject_label,
            "person_id": row.subject_id or "N/A",
            "helmet": yes_no(attrs.get("helmet")) if row.kind == "ppe_violation" else "-",
            "vest": yes_no(attrs.get("vest")) if row.kind == "ppe_violation" else "-",
            "face_match": "Yes" if row.subject_type == "person" else "No",
            "evidence_image": row.evidence_last or row.evidence_first,
            "created_at": _local_iso(row.started_at),
            "time": to_local_time(started).strftime("%d %b %Y %I:%M %p") if started else "",
            "kind": row.kind,
            "severity": row.severity,
            "status": state,
            "zone_name": row.zone_name,
            "duration_sec": round(((ended or _utcnow()) - started).total_seconds(), 1) if started else None,
            "resolved_by": row.resolved_by,
            "resolve_note": row.resolve_note,
        })
    return out


def get_episode(episode_id: str) -> Optional[Dict[str, Any]]:
    db = get_db_session()
    try:
        row = db.query(Episode).filter(Episode.episode_id == episode_id).first()
        return serialize_episode(row) if row else None
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Human actions
# ---------------------------------------------------------------------------

def _apply_action(episode_id: str, mutate) -> Optional[Dict[str, Any]]:
    db = get_db_session()
    try:
        row = db.query(Episode).filter(Episode.episode_id == episode_id).first()
        if row is None:
            return None
        mutate(row)
        db.commit()
        result = serialize_episode(row)
        publish({"type": "action", "episode": result})
        return result
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def acknowledge(episode_id: str, user_label: str) -> Optional[Dict[str, Any]]:
    def mutate(row: Episode):
        if row.status == "open":
            row.status = "acknowledged"
            row.acknowledged_by = str(user_label)[:150]
            row.acknowledged_at = _utcnow()
    return _apply_action(episode_id, mutate)


def resolve(episode_id: str, user_label: str, note: str) -> Optional[Dict[str, Any]]:
    note = (note or "").strip()
    if not note:
        raise ValueError("A note is required to resolve")

    def mutate(row: Episode):
        row.status = "resolved"
        row.resolved_by = str(user_label)[:150]
        row.resolved_at = _utcnow()
        row.resolve_note = note
        if row.acknowledged_at is None:
            row.acknowledged_by = row.resolved_by
            row.acknowledged_at = row.resolved_at
    return _apply_action(episode_id, mutate)


def mark_false_positive(episode_id: str, user_label: str) -> Optional[Dict[str, Any]]:
    def mutate(row: Episode):
        row.status = "false_positive"
        row.resolved_by = str(user_label)[:150]
        row.resolved_at = _utcnow()
        row.resolve_note = "Marked not a real issue"
    return _apply_action(episode_id, mutate)


def set_keep(episode_id: str, keep: bool, user_label: str) -> Optional[Dict[str, Any]]:
    """Kept episodes' pictures are never auto-deleted by the evidence sweep."""
    def mutate(row: Episode):
        try:
            attrs = json.loads(row.attributes_json) if row.attributes_json else {}
        except ValueError:
            attrs = {}
        if keep:
            attrs["keep"] = True
            attrs["kept_by"] = str(user_label)[:150]
        else:
            attrs.pop("keep", None)
            attrs.pop("kept_by", None)
        row.attributes_json = json.dumps(attrs)
    return _apply_action(episode_id, mutate)


def tag_episode(episode_id: str, attributes: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Merge attributes (plate, transporter, ...) into an episode; publishes an action."""
    def mutate(row: Episode):
        try:
            attrs = json.loads(row.attributes_json) if row.attributes_json else {}
        except ValueError:
            attrs = {}
        attrs.update({k: v for k, v in (attributes or {}).items() if v is not None})
        row.attributes_json = json.dumps(attrs)
    return _apply_action(episode_id, mutate)


def kept_episode_ids() -> List[str]:
    """Ids of every episode marked keep - the evidence sweep skips their files."""
    db = get_db_session()
    try:
        rows = db.query(Episode.episode_id).filter(Episode.attributes_json.like('%"keep": true%')).all()
        return [r[0] for r in rows]
    finally:
        db.close()


BULK_ACTIONS = ("acknowledge", "resolve", "false_positive")
BULK_MAX = 200


def delete_episodes(episode_ids, user_label: str) -> Dict[str, Any]:
    """
    Permanently remove episodes and every picture saved for them
    (<episode_id>.jpg, <episode_id>-2.jpg, <episode_id>-end.jpg ...).
    Super-admin only at the API; the rows are gone for good, so the
    caller confirms first. Returns which ids were deleted and which
    did not exist.
    """
    ids = []
    for eid in episode_ids or []:
        eid = str(eid).strip()
        if eid and eid not in ids:
            ids.append(eid)
    if not ids:
        raise ValueError("No episodes selected")
    if len(ids) > BULK_MAX:
        raise ValueError(f"At most {BULK_MAX} episodes at a time")

    db = get_db_session()
    try:
        rows = db.query(Episode).filter(Episode.episode_id.in_(ids)).all()
        found = [r.episode_id for r in rows]
        for row in rows:
            db.delete(row)
        db.commit()
    finally:
        db.close()

    with _lock:
        for eid in found:
            _open_index.pop(eid, None)

    for eid in found:
        for path in Path(EVIDENCE_DIR).glob(f"{eid}*.jpg"):
            try:
                path.unlink()
            except OSError:
                pass

    if found:
        publish({"type": "deleted", "ids": found, "by": str(user_label)[:150]})
        print(f"[EPISODE] {len(found)} deleted by {user_label}")
    return {"deleted": found, "missing": [e for e in ids if e not in found]}


def bulk_action(episode_ids, action: str, user_label: str, note: str = "") -> Dict[str, Any]:
    """
    One human action applied to many episodes - the morning-after case where
    a supervisor clears twenty overnight cards at once. Each episode goes
    through the same single-episode function (so the same rules, audit fields
    and stream messages apply); ids that no longer exist are reported back
    rather than failing the whole batch.
    """
    if action not in BULK_ACTIONS:
        raise ValueError(f"Unknown action: {action}")
    ids = []
    for eid in episode_ids or []:
        eid = str(eid).strip()
        if eid and eid not in ids:
            ids.append(eid)
    if not ids:
        raise ValueError("No episodes selected")
    if len(ids) > BULK_MAX:
        raise ValueError(f"At most {BULK_MAX} episodes at a time")
    if action == "resolve" and not (note or "").strip():
        raise ValueError("A note is required to resolve")

    updated, missing = [], []
    for eid in ids:
        if action == "acknowledge":
            result = acknowledge(eid, user_label)
        elif action == "resolve":
            result = resolve(eid, user_label, note)
        else:
            result = mark_false_positive(eid, user_label)
        (updated if result is not None else missing).append(result if result is not None else eid)
    return {"updated": updated, "missing": missing}


def escalate_episode(
    episode_id: str,
    *,
    severity: str,
    title: Optional[str] = None,
    attributes: Optional[Dict[str, Any]] = None,
) -> Optional[Dict[str, Any]]:
    """
    System action: raise an episode's severity (never lower it), optionally
    retitle it and merge attributes. A truck that crosses its zone's time
    limit goes info -> warning here, so the same card and timer simply turn
    into something a person must deal with.
    """
    if severity not in SEVERITIES:
        return get_episode(episode_id)

    db = get_db_session()
    try:
        row = db.query(Episode).filter(Episode.episode_id == episode_id).first()
        if row is None:
            return None

        changed = False
        if SEVERITIES.index(severity) < SEVERITIES.index(row.severity):
            row.severity = severity
            changed = True
        if title and title != row.title:
            row.title = str(title)[:200]
            changed = True
        if attributes:
            try:
                merged = json.loads(row.attributes_json) if row.attributes_json else {}
            except ValueError:
                merged = {}
            merged.update(attributes)
            row.attributes_json = json.dumps(merged)
            changed = True

        if not changed:
            return serialize_episode(row)

        db.commit()
        result = serialize_episode(row)
        publish({"type": "updated", "episode": result})
        return result
    except Exception as exc:
        try:
            db.rollback()
        except Exception:
            pass
        print("[EPISODE] escalate failed:", exc)
        return None
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Live bus (in-process publish/subscribe)
# ---------------------------------------------------------------------------

_subscribers: List["queue.Queue"] = []
_subscribers_lock = threading.Lock()


def subscribe() -> "queue.Queue":
    q: "queue.Queue" = queue.Queue(maxsize=500)
    with _subscribers_lock:
        _subscribers.append(q)
    return q


def unsubscribe(q: "queue.Queue") -> None:
    with _subscribers_lock:
        if q in _subscribers:
            _subscribers.remove(q)


def publish(message: Dict[str, Any]) -> None:
    with _subscribers_lock:
        targets = list(_subscribers)
    for q in targets:
        try:
            q.put_nowait(message)
        except queue.Full:
            # A dead or very slow listener must never block the camera loop.
            pass


# ---------------------------------------------------------------------------
# Camera health -> "Notice" episodes
# ---------------------------------------------------------------------------

CAMERA_OFFLINE_SEC = float(os.getenv("VISIONAI_CAMERA_OFFLINE_SEC", "300"))

# camera_id -> monotonic time we first saw it not "online". In memory on
# purpose: Camera.status only flips on transitions and last_seen_at is not
# refreshed while a stream is healthy, so the database cannot tell us how
# long a camera has been down - the sweep itself keeps that clock.
_unhealthy_since: Dict[int, float] = {}


def sweep_camera_health(
    offline_after_sec: float = CAMERA_OFFLINE_SEC,
    *,
    is_watched=None,
    now_mono: Optional[float] = None,
) -> None:
    """
    A monitored camera whose status has not been "online" for
    offline_after_sec gets one open system episode ("CAM-06 is offline -
    Truck Yard is unwatched"); the episode ends automatically when the camera
    reports online again (a person still closes it out). Cameras that have
    never connected are ignored (still being set up), and so are cameras
    is_watched(camera_id) says nobody expects to be running.
    """
    if now_mono is None:
        now_mono = time.monotonic()

    db = get_db_session()
    try:
        cameras = db.query(Camera).filter(Camera.is_active.is_(True)).all()
        open_notices = {
            row.camera_id: row.episode_id
            for row in db.query(Episode).filter(Episode.kind == "system", Episode.ended_at.is_(None)).all()
        }
    finally:
        db.close()

    for cam in cameras:
        if cam.last_seen_at is None:
            continue
        if is_watched is not None and not is_watched(cam.id):
            _unhealthy_since.pop(cam.id, None)
            continue

        healthy = str(cam.status or "").strip().lower() == "online"
        notice_id = open_notices.get(cam.id)

        if healthy:
            _unhealthy_since.pop(cam.id, None)
            if notice_id:
                close_episode(notice_id)
            continue

        since = _unhealthy_since.setdefault(cam.id, now_mono)
        if notice_id is None and now_mono - since >= offline_after_sec:
            where = f" - {cam.location} is unwatched" if cam.location else " - its area is unwatched"
            open_episode(
                camera_id=cam.id, camera_name=cam.camera_name, camera_location=cam.location,
                kind="system", title=f"{cam.camera_name} is offline{where}",
                subject_type="camera", subject_label=cam.camera_name, subject_id=str(cam.id),
                severity="notice",
                attributes={"last_seen_epoch": _epoch(cam.last_seen_at), "status": cam.status},
            )
