"""
HTTP surface of the episode engine. The Ops Board and the phone app talk
only to these routes.
"""
from __future__ import annotations

import asyncio
import json
import queue
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, Query
from fastapi.responses import JSONResponse, StreamingResponse
from starlette.concurrency import run_in_threadpool
from pydantic import BaseModel

from app import episodes
from app.auth_dependencies import get_current_user, require_super_admin, user_from_access_token
from app.database import User, get_db_session

router = APIRouter(prefix="/api/episodes", tags=["episodes"])

STREAM_PING_SEC = 15.0


def _who(user: User) -> str:
    return (getattr(user, "full_name", None) or getattr(user, "email", None) or "user")


class ResolveBody(BaseModel):
    note: str = ""


class KeepBody(BaseModel):
    keep: bool = True


class BulkBody(BaseModel):
    ids: list[str]
    action: str          # acknowledge | resolve | false_positive
    note: str = ""       # required when action is resolve


class DeleteBody(BaseModel):
    ids: list[str]


@router.get("/live", dependencies=[Depends(get_current_user)])
def live():
    return JSONResponse({"ok": True, "data": episodes.live_state()})


@router.get("", dependencies=[Depends(get_current_user)])
def list_(
    status: Optional[str] = None,
    kind: Optional[str] = None,
    camera_id: Optional[int] = None,
    since: Optional[datetime] = None,
    until: Optional[datetime] = None,
    limit: int = Query(200, ge=1, le=1000),
):
    data = episodes.list_episodes(status=status, kind=kind, camera_id=camera_id, since=since, until=until, limit=limit)
    return JSONResponse({"ok": True, "data": data})


def _authenticate_query_token(token: str) -> User:
    """
    Check the token with a session that is closed straight away. A `Depends`
    session would stay checked out of the pool for the life of the response,
    and a live stream never ends - that pinned one pooled connection per
    open browser tab until the pool ran dry (15 Sep).
    """
    db = get_db_session()
    try:
        return user_from_access_token(token, db)
    finally:
        db.close()


@router.get("/stream")
async def stream(token: str = Query(..., description="Access token (EventSource cannot send headers)")):
    """
    Server-Sent Events. One `episode` event per change; a comment line every
    STREAM_PING_SEC so proxies keep the connection open. Holds no database
    connection while streaming.
    """
    await run_in_threadpool(_authenticate_query_token, token)
    q = episodes.subscribe()
    loop = asyncio.get_running_loop()

    async def gen():
        try:
            yield ": connected\n\n"
            while True:
                try:
                    msg = await loop.run_in_executor(None, q.get, True, STREAM_PING_SEC)
                except queue.Empty:
                    yield ": ping\n\n"
                    continue
                yield f"event: episode\ndata: {json.dumps(msg)}\n\n"
        finally:
            episodes.unsubscribe(q)

    headers = {"Cache-Control": "no-cache", "X-Accel-Buffering": "no", "Connection": "keep-alive"}
    return StreamingResponse(gen(), media_type="text/event-stream", headers=headers)


@router.post("/{episode_id}/keep")
def keep(episode_id: str, body: KeepBody, user: User = Depends(get_current_user)):
    data = episodes.set_keep(episode_id, body.keep, _who(user))
    if data is None:
        return JSONResponse({"ok": False, "message": "Episode not found"}, status_code=404)
    return JSONResponse({"ok": True, "data": data})


@router.post("/bulk")
def bulk(body: BulkBody, user: User = Depends(get_current_user)):
    """Apply one action to many episodes; declared before /{episode_id}."""
    try:
        data = episodes.bulk_action(body.ids, body.action, _who(user), body.note)
    except ValueError as exc:
        return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
    return JSONResponse({"ok": True, "data": data})


@router.post("/delete")
def delete(body: DeleteBody, user: User = Depends(require_super_admin)):
    """Permanently delete episodes and their pictures; super-admin only."""
    try:
        data = episodes.delete_episodes(body.ids, _who(user))
    except ValueError as exc:
        return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
    return JSONResponse({"ok": True, "data": data})


@router.get("/{episode_id}", dependencies=[Depends(get_current_user)])
def get_one(episode_id: str):
    data = episodes.get_episode(episode_id)
    if data is None:
        return JSONResponse({"ok": False, "message": "Episode not found"}, status_code=404)
    return JSONResponse({"ok": True, "data": data})


@router.post("/{episode_id}/acknowledge")
def acknowledge(episode_id: str, user: User = Depends(get_current_user)):
    data = episodes.acknowledge(episode_id, _who(user))
    if data is None:
        return JSONResponse({"ok": False, "message": "Episode not found"}, status_code=404)
    return JSONResponse({"ok": True, "data": data})


@router.post("/{episode_id}/resolve")
def resolve(episode_id: str, body: ResolveBody, user: User = Depends(get_current_user)):
    try:
        data = episodes.resolve(episode_id, _who(user), body.note)
    except ValueError as exc:
        return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
    if data is None:
        return JSONResponse({"ok": False, "message": "Episode not found"}, status_code=404)
    return JSONResponse({"ok": True, "data": data})


@router.post("/{episode_id}/false-positive")
def false_positive(episode_id: str, user: User = Depends(get_current_user)):
    data = episodes.mark_false_positive(episode_id, _who(user))
    if data is None:
        return JSONResponse({"ok": False, "message": "Episode not found"}, status_code=404)
    return JSONResponse({"ok": True, "data": data})


# ---------------------------------------------------------------------------
# Camera zones
# ---------------------------------------------------------------------------
from typing import List  # noqa: E402

from app.database import CameraZone, get_db_session  # noqa: E402
from app import zones as zone_cache  # noqa: E402

zones_router = APIRouter(prefix="/api/zones", tags=["zones"], dependencies=[Depends(get_current_user)])

ZONE_TYPES = ("gate", "weighbridge", "yard", "bay", "unloading_bay", "restricted", "ppe", "custom")


class ZoneBody(BaseModel):
    camera_id: Optional[int] = None
    name: Optional[str] = None
    zone_type: Optional[str] = None
    polygon: Optional[List[List[float]]] = None
    limit_sec: Optional[int] = None
    site_id: Optional[int] = None


def _zone_out(z: CameraZone) -> dict:
    return {
        "id": z.id, "site_id": z.site_id, "camera_id": z.camera_id, "name": z.name, "zone_type": z.zone_type,
        "polygon": json.loads(z.polygon_json), "limit_sec": z.limit_sec, "is_active": bool(z.is_active),
    }


def _bad(message: str):
    return JSONResponse({"ok": False, "message": message}, status_code=400)


def _valid_polygon(poly) -> bool:
    return isinstance(poly, list) and len(poly) >= 3 and all(
        isinstance(p, list) and len(p) == 2 and all(isinstance(v, (int, float)) and 0 <= v <= 1 for v in p) for p in poly
    )


@zones_router.get("")
def list_zones(camera_id: Optional[int] = None):
    db = get_db_session()
    try:
        q = db.query(CameraZone).filter(CameraZone.is_active.is_(True))
        if camera_id is not None:
            q = q.filter(CameraZone.camera_id == camera_id)
        return JSONResponse({"ok": True, "data": [_zone_out(z) for z in q.order_by(CameraZone.id).all()]})
    finally:
        db.close()


@zones_router.get("/summary")
def zones_summary(camera_id: Optional[int] = None):
    """
    Every active zone with what is live inside it right now - the Plant map
    is drawn from this. Empty zones are listed too (an empty bay is news).
    """
    db = get_db_session()
    try:
        q = db.query(CameraZone).filter(CameraZone.is_active.is_(True))
        if camera_id is not None:
            q = q.filter(CameraZone.camera_id == camera_id)
        zone_rows = [_zone_out(z) for z in q.order_by(CameraZone.id).all()]
    finally:
        db.close()

    live = episodes.live_state()
    by_zone = {}
    for ep in live["open"]:
        if ep.get("zone_id") is not None:
            by_zone.setdefault(ep["zone_id"], []).append(ep)

    data = []
    for zone in zone_rows:
        eps = by_zone.get(zone["id"], [])
        durations = [e["duration_sec"] for e in eps if e.get("ended_epoch") is None]
        data.append({
            "zone": zone,
            "open": [e["episode_id"] for e in eps],
            "vehicles": sum(1 for e in eps if e["subject_type"] == "vehicle"),
            "people": sum(1 for e in eps if e["subject_type"] in ("person", "unknown")),
            "needs_action": sum(1 for e in eps if e["needs_action"]),
            "worst": max((e["severity"] for e in eps), key=lambda s: -episodes.SEVERITIES.index(s), default=None),
            "longest_sec": max(durations) if durations else None,
            "lead": eps[0] if eps else None,
        })
    return JSONResponse({"ok": True, "data": data, "generated_epoch": live["generated_epoch"]})


@zones_router.post("")
def create_zone(body: ZoneBody):
    if body.camera_id is None or not (body.name or "").strip():
        return _bad("camera_id and name are required")
    if body.zone_type not in ZONE_TYPES:
        return _bad(f"zone_type must be one of {', '.join(ZONE_TYPES)}")
    if not _valid_polygon(body.polygon):
        return _bad("polygon needs at least 3 points, each [x, y] between 0 and 1")
    db = get_db_session()
    try:
        z = CameraZone(camera_id=body.camera_id, name=body.name.strip()[:150], zone_type=body.zone_type,
                       polygon_json=json.dumps(body.polygon), limit_sec=body.limit_sec, site_id=body.site_id)
        db.add(z); db.commit(); db.refresh(z)
        zone_cache.bump_zone_version()
        return JSONResponse({"ok": True, "data": _zone_out(z)})
    finally:
        db.close()


@zones_router.put("/{zone_id}")
def update_zone(zone_id: int, body: ZoneBody):
    db = get_db_session()
    try:
        z = db.query(CameraZone).filter(CameraZone.id == zone_id, CameraZone.is_active.is_(True)).first()
        if z is None:
            return JSONResponse({"ok": False, "message": "Zone not found"}, status_code=404)
        if body.name is not None:
            z.name = body.name.strip()[:150]
        if body.zone_type is not None:
            if body.zone_type not in ZONE_TYPES:
                return _bad(f"zone_type must be one of {', '.join(ZONE_TYPES)}")
            z.zone_type = body.zone_type
        if body.polygon is not None:
            if not _valid_polygon(body.polygon):
                return _bad("polygon needs at least 3 points, each [x, y] between 0 and 1")
            z.polygon_json = json.dumps(body.polygon)
        if body.limit_sec is not None:
            z.limit_sec = body.limit_sec
        if body.camera_id is not None:
            z.camera_id = body.camera_id
        db.commit(); db.refresh(z)
        zone_cache.bump_zone_version()
        return JSONResponse({"ok": True, "data": _zone_out(z)})
    finally:
        db.close()


@zones_router.delete("/{zone_id}")
def delete_zone(zone_id: int):
    db = get_db_session()
    try:
        z = db.query(CameraZone).filter(CameraZone.id == zone_id).first()
        if z is None:
            return JSONResponse({"ok": False, "message": "Zone not found"}, status_code=404)
        z.is_active = False
        db.commit()
        zone_cache.bump_zone_version()
        return JSONResponse({"ok": True, "message": "Zone removed"})
    finally:
        db.close()
