import os
import math
import time
import base64
import threading
import pickle
import logging
import tempfile
from pathlib import Path
from typing import Dict, Optional, List, Tuple

from dotenv import load_dotenv

# =========================================================
# Environment configuration
# =========================================================
BASE_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = BASE_DIR / ".env"
load_dotenv(dotenv_path=ENV_FILE)

# Safe defaults for local + server. main.py also sets these before importing
# application modules; setdefault keeps explicit .env/service values intact.
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("TF_NUM_INTRAOP_THREADS", "1")
os.environ.setdefault("TF_NUM_INTEROP_THREADS", "1")

import cv2
import numpy as np
from sqlalchemy import func, or_

from app import face_model
from app.database import Department, RoleAccess, FaceEnrollmentPerson
from app.camera_management import (
    get_shared_camera_frame,
    get_camera_worker_status,
)

logger = logging.getLogger(__name__)

# Keep OpenCV from creating a large native worker pool on constrained hosts.
try:
    cv2.setNumThreads(int(os.getenv("OPENCV_NUM_THREADS", "1")))
except Exception as error:
    print(f"[WARN] Could not set OpenCV thread count: {error}")

YUNET_MODEL_PATH = os.getenv("YUNET_MODEL_PATH", "").strip()

# =========================================================
# Face geometry / model settings
# =========================================================

# Keep detection-side geometry compatible with detection_service.py.
CONF_THRESHOLD = 0.80
NMS_THRESHOLD = 0.30
TOP_K = 5000

TARGET_FACE_SIZE = 160
PADDING_RATIO = 0.15

# Enrollment quality remains intentionally stricter than runtime recognition.
MIN_FACE_WIDTH = 100
MIN_FACE_HEIGHT = 100
MIN_BLUR_SCORE = 30.0
EXCELLENT_BLUR_SCORE = 100.0
MIN_BRIGHTNESS = 60.0
MAX_BRIGHTNESS = 220.0
MIN_FACE_OCCUPANCY = 0.20
MAX_FACE_OCCUPANCY = 0.60
MAX_YAW_DEG = 15.0
MAX_PITCH_DEG = 10.0
MAX_ROLL_DEG = 10.0
MIN_VISIBILITY_ACCEPT = 90.0
MIN_VISIBILITY_REVIEW = 70.0

# Browser preview only. AI/capture continues on native raw frame.
STREAM_WIDTH = int(os.getenv("FACE_ENROLLMENT_STREAM_WIDTH", "960"))
STREAM_HEIGHT = int(os.getenv("FACE_ENROLLMENT_STREAM_HEIGHT", "540"))
JPEG_QUALITY = int(os.getenv("FACE_ENROLLMENT_JPEG_QUALITY", "70"))
DETECT_EVERY_N_FRAMES = max(
    1,
    int(os.getenv("FACE_ENROLLMENT_DETECT_EVERY_N_FRAMES", "2")),
)

recognition_states: Dict[int, bool] = {}

detector_lock = threading.RLock()
_detector_create_lock = threading.RLock()
detector = None


def make_detector():
    """Create YuNet lazily so model failure cannot kill FastAPI startup."""
    if not YUNET_MODEL_PATH:
        raise RuntimeError("YUNET_MODEL_PATH is missing in .env")

    model_path = Path(YUNET_MODEL_PATH)

    if not model_path.exists():
        raise FileNotFoundError(
            f"YuNet model not found: {model_path}"
        )

    return cv2.FaceDetectorYN.create(
        str(model_path),
        "",
        (320, 320),
        score_threshold=CONF_THRESHOLD,
        nms_threshold=NMS_THRESHOLD,
        top_k=TOP_K,
    )


def get_detector():
    global detector

    if detector is not None:
        return detector

    with _detector_create_lock:
        if detector is None:
            logger.info(
                "Loading YuNet enrollment detector: %s",
                YUNET_MODEL_PATH,
            )
            detector = make_detector()
            logger.info("YuNet enrollment detector loaded")

    return detector


def get_face_enrollment_stats_service(db):
    total_enrolled = (
        db.query(FaceEnrollmentPerson)
        .count()
    )

    active_personnel = (
        db.query(FaceEnrollmentPerson)
        .filter(
            FaceEnrollmentPerson.is_active.is_(True)
        )
        .count()
    )

    today_enrollments = (
        db.query(FaceEnrollmentPerson)
        .filter(
            func.date(
                FaceEnrollmentPerson.created_at
            ) == func.current_date()
        )
        .count()
    )

    inactive_personnel = (
        db.query(FaceEnrollmentPerson)
        .filter(
            FaceEnrollmentPerson.is_active.is_(False)
        )
        .count()
    )

    archived_personnel = 0
    if hasattr(FaceEnrollmentPerson, "is_archived"):
        archived_personnel = (
            db.query(FaceEnrollmentPerson)
            .filter(
                FaceEnrollmentPerson.is_archived.is_(True)
            )
            .count()
        )

    face_quality_average = (
        db.query(
            func.avg(
                FaceEnrollmentPerson.primary_quality_score
            )
        )
        .scalar()
        or 0
    )

    return {
        "totalEnrolled": total_enrolled,
        "activePersonnel": active_personnel,
        "todayEnrollments": today_enrollments,
        "inactivePersonnel": inactive_personnel,
        "archivedPersonnel": archived_personnel,
        "faceQualityAverage": round(float(face_quality_average)),
    }



def start_face_recognition_service(camera, camera_id: int):
    """
    Enable face-recognition processing for this camera.

    No camera/RTSP connection is opened here. The shared CameraWorker in
    camera_management.py owns the single physical capture for live view,
    detection, face enrollment and face recognition.
    """
    camera_id = int(camera_id)
    recognition_states[camera_id] = True

    # Warm/get the shared worker by requesting a frame. This never creates a
    # second capture for the same camera ID.
    get_shared_camera_frame(camera, wait_timeout=0.5)

    return {
        "success": True,
        "message": "Face recognition detection started",
        "data": {
            "camera_id": camera_id,
            "recognition_enabled": True,
        },
    }


def stop_face_recognition_service(camera_id: int):
    """Stop face processing only; keep the shared live camera running."""
    camera_id = int(camera_id)
    recognition_states[camera_id] = False

    return {
        "success": True,
        "message": "Face recognition detection stopped; camera stream remains live",
        "data": {
            "camera_id": camera_id,
            "recognition_enabled": False,
        },
    }


def get_face_recognition_status_service(camera_id: int):
    camera_id = int(camera_id)
    enabled = recognition_states.get(camera_id, False)
    camera_status = get_camera_worker_status(camera_id)

    return {
        "success": True,
        "message": "Face recognition detection status fetched",
        "data": {
            "camera_id": camera_id,
            "recognition_enabled": enabled,
            "camera_running": bool(camera_status.get("running")),
            "camera_status": camera_status.get("status"),
            "camera_backend": camera_status.get("backend"),
            "ffmpeg_pid": camera_status.get("ffmpeg_pid"),
            "last_frame_age_sec": camera_status.get("last_frame_age_sec"),
        },
    }


def variance_of_laplacian(image_bgr):
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
    return float(cv2.Laplacian(gray, cv2.CV_64F).var())


def mean_brightness(image_bgr):
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
    return float(np.mean(gray))


def extract_landmarks(face_row):
    return [(int(face_row[i]), int(face_row[i + 1])) for i in range(4, 14, 2)]


def clamp_box(x1, y1, x2, y2, frame_w, frame_h):
    x1 = max(0, min(x1, frame_w - 1))
    y1 = max(0, min(y1, frame_h - 1))
    x2 = max(1, min(x2, frame_w))
    y2 = max(1, min(y2, frame_h))
    return x1, y1, x2, y2


def build_square_crop_box(fx1, fy1, fx2, fy2, frame_w, frame_h):
    bw = fx2 - fx1
    bh = fy2 - fy1
    cx = (fx1 + fx2) / 2.0
    cy = (fy1 + fy2) / 2.0
    side = int(max(bw, bh) * (1.0 + 2.0 * PADDING_RATIO))
    side = max(side, TARGET_FACE_SIZE)
    x1 = int(cx - side / 2)
    y1 = int(cy - side / 2)
    x2 = x1 + side
    y2 = y1 + side

    if x1 < 0:
        x2 -= x1
        x1 = 0
    if y1 < 0:
        y2 -= y1
        y1 = 0
    if x2 > frame_w:
        x1 -= x2 - frame_w
        x2 = frame_w
    if y2 > frame_h:
        y1 -= y2 - frame_h
        y2 = frame_h

    return clamp_box(x1, y1, x2, y2, frame_w, frame_h)


def image_to_base64(image_bgr):
    ok, buffer = cv2.imencode(".jpg", image_bgr, [cv2.IMWRITE_JPEG_QUALITY, 90])
    if not ok:
        return None
    return base64.b64encode(buffer).decode("utf-8")


def align_face_by_eyes(face_bgr, landmarks_global, crop_x1, crop_y1):
    if len(landmarks_global) < 2:
        return face_bgr

    right_eye_global = landmarks_global[0]
    left_eye_global = landmarks_global[1]
    rx = right_eye_global[0] - crop_x1
    ry = right_eye_global[1] - crop_y1
    lx = left_eye_global[0] - crop_x1
    ly = left_eye_global[1] - crop_y1
    dx = lx - rx
    dy = ly - ry
    if dx == 0 and dy == 0:
        return face_bgr

    angle = math.degrees(math.atan2(dy, dx))
    h, w = face_bgr.shape[:2]
    rot_mat = cv2.getRotationMatrix2D((w // 2, h // 2), angle, 1.0)
    return cv2.warpAffine(face_bgr, rot_mat, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)


def detect_faces(frame):
    if frame is None or getattr(frame, "size", 0) == 0:
        return None, "Empty frame"

    frame_h, frame_w = frame.shape[:2]

    try:
        local_detector = get_detector()
    except Exception as error:
        logger.exception("YuNet detector unavailable")
        return None, f"Face detector unavailable: {error}"

    with detector_lock:
        try:
            local_detector.setInputSize((frame_w, frame_h))
            _, faces = local_detector.detect(frame)
        except Exception as error:
            logger.exception("Face detection failed")
            return None, f"Face detection error: {error}"

    return faces, None


def pick_best_face(faces, frame_w, frame_h):
    if faces is None or len(faces) == 0:
        return None
    best_face = None
    best_area = -1
    for face in faces:
        x, y, bw, bh = face[0:4]
        score = float(face[-1])
        if score < CONF_THRESHOLD:
            continue
        fx1 = max(0, int(x))
        fy1 = max(0, int(y))
        fx2 = min(frame_w, int(x + bw))
        fy2 = min(frame_h, int(y + bh))
        area = max(0, fx2 - fx1) * max(0, fy2 - fy1)
        if area > best_area:
            best_area = area
            best_face = face
    return best_face


def calculate_pose_from_landmarks(landmarks: List[Tuple[int, int]], face_w: int, face_h: int):
    # Approximate pose from YuNet landmarks: [right_eye, left_eye, nose, right_mouth, left_mouth]
    result = {"yaw": 0.0, "pitch": 0.0, "roll": 0.0, "ok": True}
    if len(landmarks) < 5 or face_w <= 0 or face_h <= 0:
        return result

    right_eye, left_eye, nose, right_mouth, left_mouth = landmarks[:5]
    eye_cx = (right_eye[0] + left_eye[0]) / 2.0
    mouth_cx = (right_mouth[0] + left_mouth[0]) / 2.0
    face_mid_x = (eye_cx + mouth_cx) / 2.0
    face_mid_y = ((right_eye[1] + left_eye[1]) / 2.0 + (right_mouth[1] + left_mouth[1]) / 2.0) / 2.0

    result["yaw"] = round(((nose[0] - face_mid_x) / face_w) * 60.0, 2)
    result["pitch"] = round(((nose[1] - face_mid_y) / face_h) * 45.0, 2)
    result["roll"] = round(math.degrees(math.atan2(left_eye[1] - right_eye[1], left_eye[0] - right_eye[0])), 2)
    result["ok"] = abs(result["yaw"]) <= MAX_YAW_DEG and abs(result["pitch"]) <= MAX_PITCH_DEG and abs(result["roll"]) <= MAX_ROLL_DEG
    return result


def estimate_visibility(landmarks: List[Tuple[int, int]], fx1: int, fy1: int, fx2: int, fy2: int):
    # Practical enrollment visibility: required landmarks inside face box and sufficiently separated.
    if len(landmarks) < 5:
        return 50.0, False, "Landmarks not visible"

    inside = 0
    for px, py in landmarks[:5]:
        if fx1 <= px <= fx2 and fy1 <= py <= fy2:
            inside += 1

    right_eye, left_eye, nose, right_mouth, left_mouth = landmarks[:5]
    eye_distance = math.dist(right_eye, left_eye)
    mouth_distance = math.dist(right_mouth, left_mouth)
    face_w = max(1, fx2 - fx1)

    landmark_score = (inside / 5.0) * 100.0
    eye_score = min(100.0, (eye_distance / (face_w * 0.22)) * 100.0)
    mouth_score = min(100.0, (mouth_distance / (face_w * 0.18)) * 100.0)
    visibility = round((landmark_score * 0.60) + (eye_score * 0.25) + (mouth_score * 0.15), 2)

    eyes_visible = inside >= 5 and eye_distance >= face_w * 0.18
    reason = "Visible" if visibility >= MIN_VISIBILITY_ACCEPT else "Face partially hidden / landmarks weak"
    return visibility, eyes_visible, reason


def score_metric(value: float, min_ok: float, max_good: float):
    if value <= min_ok:
        return 0
    if value >= max_good:
        return 100
    return int(((value - min_ok) / (max_good - min_ok)) * 100)


def build_quality_payload(frame, faces, best_face, raw_crop):
    frame_h, frame_w = frame.shape[:2]
    reasons = []
    checks = {}

    face_count = 0 if faces is None else len(faces)
    checks["face_detected"] = face_count > 0
    checks["single_face"] = face_count == 1

    if face_count == 0:
        reasons.append("No face detected")
    elif face_count > 1:
        reasons.append("Multiple faces detected")

    x, y, bw, bh = best_face[0:4]
    confidence = round(float(best_face[-1]) * 100, 2)
    fx1 = max(0, int(x))
    fy1 = max(0, int(y))
    fx2 = min(frame_w, int(x + bw))
    fy2 = min(frame_h, int(y + bh))
    face_w = fx2 - fx1
    face_h = fy2 - fy1

    occupancy = max(face_w / frame_w, face_h / frame_h)
    occupancy_percent = round(occupancy * 100, 2)
    checks["face_size"] = face_w >= MIN_FACE_WIDTH and face_h >= MIN_FACE_HEIGHT and MIN_FACE_OCCUPANCY <= occupancy <= MAX_FACE_OCCUPANCY
    if face_w < MIN_FACE_WIDTH or face_h < MIN_FACE_HEIGHT or occupancy < MIN_FACE_OCCUPANCY:
        reasons.append("Face too small / too far")
    if occupancy > MAX_FACE_OCCUPANCY:
        reasons.append("Face too close")

    landmarks = extract_landmarks(best_face)
    pose = calculate_pose_from_landmarks(landmarks, face_w, face_h)
    checks["pose"] = pose["ok"]
    if not pose["ok"]:
        reasons.append("Face angle not acceptable")

    brightness = round(mean_brightness(raw_crop), 2)
    checks["lighting"] = MIN_BRIGHTNESS <= brightness <= MAX_BRIGHTNESS
    if brightness < MIN_BRIGHTNESS:
        reasons.append("Poor lighting / face too dark")
    if brightness > MAX_BRIGHTNESS:
        reasons.append("Face overexposed")

    blur_score = round(variance_of_laplacian(raw_crop), 2)
    checks["clarity"] = blur_score >= MIN_BLUR_SCORE
    if blur_score < MIN_BLUR_SCORE:
        reasons.append("Blurred / motion blur")

    visibility, eyes_visible, visibility_reason = estimate_visibility(landmarks, fx1, fy1, fx2, fy2)
    checks["visibility"] = visibility >= MIN_VISIBILITY_REVIEW
    checks["eye_visibility"] = eyes_visible
    if visibility < MIN_VISIBILITY_REVIEW:
        reasons.append("Face obstructed / visibility below 70%")
    elif visibility < MIN_VISIBILITY_ACCEPT:
        reasons.append("Face visibility needs operator review")
    if not eyes_visible:
        reasons.append("Eyes not clearly visible")

    position_score = 100 if checks["face_size"] else score_metric(occupancy_percent, 10, 20)
    lighting_score = 100 if checks["lighting"] else max(0, 100 - int(abs(brightness - 140) / 1.4))
    blur_part = min(100, int((blur_score / EXCELLENT_BLUR_SCORE) * 100))
    stability_score = 85  # real stability needs frame history; for single capture we keep a conservative score
    eye_score = 100 if eyes_visible else 20
    angle_score = 100 if pose["ok"] else max(0, 100 - int(abs(pose["yaw"]) + abs(pose["pitch"]) + abs(pose["roll"])))

    quality_score = round(
        position_score * 0.20
        + lighting_score * 0.20
        + blur_part * 0.25
        + stability_score * 0.15
        + eye_score * 0.10
        + angle_score * 0.10
    )

    # Hard reject rules for DB quality
    hard_reject = not checks["face_detected"] or not checks["single_face"] or not checks["face_size"] or not checks["clarity"] or visibility < MIN_VISIBILITY_REVIEW

    if hard_reject or quality_score < 70:
        decision = "rejected"
        status = "Rejected"
        label = "Rejected"
    elif quality_score >= 90 and visibility >= MIN_VISIBILITY_ACCEPT and all([checks["pose"], checks["lighting"], checks["eye_visibility"]]):
        decision = "accepted"
        status = "Excellent"
        label = "Excellent"
    elif quality_score >= 80 and visibility >= MIN_VISIBILITY_ACCEPT:
        decision = "accepted"
        status = "Good"
        label = "Good"
    else:
        decision = "review"
        status = "Review"
        label = "Review"

    if not reasons and decision == "accepted":
        reasons.append("Image accepted for enrollment")

    return {
        "status": status,
        "decision": decision,
        "quality_label": label,
        "quality_score": int(quality_score),
        "confidence": confidence,
        "blur_score": blur_score,
        "brightness": brightness,
        "visibility": visibility,
        "face_count": face_count,
        "face_occupancy": occupancy_percent,
        "pose": pose,
        "checks": checks,
        "reasons": reasons,
        "box": {"x1": fx1, "y1": fy1, "x2": fx2, "y2": fy2},
        "metrics": {
            "face_width": face_w,
            "face_height": face_h,
            "position_score": position_score,
            "lighting_score": lighting_score,
            "blur_score_component": blur_part,
            "stability_score": stability_score,
            "eye_score": eye_score,
            "angle_score": angle_score,
        },
    }


def process_face_frame(frame):
    clean_frame = frame.copy()
    frame_h, frame_w = frame.shape[:2]
    faces, error = detect_faces(clean_frame)

    if error:
        return {"success": False, "message": error, "data": {"decision": "rejected", "reasons": [error]}}

    if faces is None or len(faces) == 0:
        return {"success": False, "message": "No face detected", "data": {"decision": "rejected", "status": "Rejected", "quality_score": 0, "face_count": 0, "reasons": ["No face detected"]}}

    best_face = pick_best_face(faces, frame_w, frame_h)
    if best_face is None:
        return {"success": False, "message": "Face too small or low confidence", "data": {"decision": "rejected", "status": "Rejected", "quality_score": 0, "face_count": len(faces), "reasons": ["Face too small or low confidence"]}}

    x, y, bw, bh = best_face[0:4]
    fx1 = max(0, int(x))
    fy1 = max(0, int(y))
    fx2 = min(frame_w, int(x + bw))
    fy2 = min(frame_h, int(y + bh))
    landmarks = extract_landmarks(best_face)
    crop_x1, crop_y1, crop_x2, crop_y2 = build_square_crop_box(fx1, fy1, fx2, fy2, frame_w, frame_h)
    raw_crop = clean_frame[crop_y1:crop_y2, crop_x1:crop_x2]

    if raw_crop.size == 0:
        return {"success": False, "message": "Empty face crop", "data": {"decision": "rejected", "status": "Rejected", "quality_score": 0, "reasons": ["Empty face crop"]}}

    quality = build_quality_payload(clean_frame, faces, best_face, raw_crop)
    aligned_crop = align_face_by_eyes(raw_crop, landmarks, crop_x1, crop_y1)
    face_base64 = image_to_base64(aligned_crop)

    if not face_base64:
        return {"success": False, "message": "Face image encode failed", "data": {"decision": "rejected", "status": "Rejected", "quality_score": 0, "reasons": ["Face image encode failed"]}}

    quality["image_base64"] = face_base64
    quality["image_url"] = f"data:image/jpeg;base64,{face_base64}"

    # Return success for accepted/review so frontend can show it; rejected returns success False but still carries image data.
    success = quality["decision"] in ["accepted", "review"]
    message = "Face image evaluated" if success else ", ".join(quality["reasons"][:2])
    return {"success": success, "message": message, "data": quality}


def process_frame_for_face_detection(frame):
    display_frame = frame.copy()
    clean_frame = frame.copy()
    frame_h, frame_w = display_frame.shape[:2]
    status_text = "No face"
    status_color = (0, 0, 255)

    faces, error = detect_faces(clean_frame)
    if error:
        status_text = error[:60]
        cv2.putText(display_frame, status_text, (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, status_color, 2)
        return display_frame

    if faces is None or len(faces) == 0:
        cv2.putText(display_frame, status_text, (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, status_color, 2)
        return display_frame

    best_face = pick_best_face(faces, frame_w, frame_h)
    if best_face is None:
        status_text = "Face too small / low confidence"
        cv2.putText(display_frame, status_text, (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, status_color, 2)
        return display_frame

    x, y, bw, bh = best_face[0:4]
    fx1 = max(0, int(x))
    fy1 = max(0, int(y))
    fx2 = min(frame_w, int(x + bw))
    fy2 = min(frame_h, int(y + bh))
    crop_x1, crop_y1, crop_x2, crop_y2 = build_square_crop_box(fx1, fy1, fx2, fy2, frame_w, frame_h)
    raw_crop = clean_frame[crop_y1:crop_y2, crop_x1:crop_x2]

    if raw_crop.size == 0:
        status_text = "Empty crop"
    else:
        quality = build_quality_payload(clean_frame, faces, best_face, raw_crop)
        color_map = {"accepted": (0, 255, 0), "review": (0, 255, 255), "rejected": (0, 0, 255)}
        status_color = color_map.get(quality["decision"], (0, 0, 255))
        status_text = f"{quality['quality_score']}% {quality['status']} | blur {quality['blur_score']} | vis {quality['visibility']}%"
        cv2.rectangle(display_frame, (fx1, fy1), (fx2, fy2), status_color, 2)
        cv2.rectangle(display_frame, (crop_x1, crop_y1), (crop_x2, crop_y2), (255, 0, 0), 1)
        for px, py in extract_landmarks(best_face):
            cv2.circle(display_frame, (px, py), 2, (0, 255, 255), -1)

    cv2.putText(display_frame, status_text, (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, status_color, 2)
    return display_frame


def capture_face_service(camera, camera_id: Optional[int] = None):
    """
    Capture one face-enrollment frame from the existing shared camera worker.

    This function never opens cv2.VideoCapture/FFmpeg itself, so clicking
    Capture cannot create another RTSP connection or another FFmpeg process.
    """
    frame = get_shared_camera_frame(
        camera,
        wait_timeout=1.0,
    )

    if frame is None:
        return {
            "success": False,
            "message": "Camera frame not available",
        }

    return process_face_frame(frame)


async def import_faces_service(files):
    results = []
    accepted_or_review = 0

    for file in files:
        image_bytes = await file.read()
        np_arr = np.frombuffer(image_bytes, np.uint8)
        frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

        if frame is None:
            results.append({"file_name": file.filename, "ok": False, "message": "Invalid image file", "data": {"decision": "rejected", "reasons": ["Invalid image file"]}})
            continue

        result = process_face_frame(frame)
        decision = result.get("data", {}).get("decision", "rejected")
        ok = decision in ["accepted", "review"]
        if ok:
            accepted_or_review += 1

        results.append({"file_name": file.filename, "ok": ok, "message": result.get("message"), "data": result.get("data")})

    if accepted_or_review == 0:
        return {"success": False, "message": "No acceptable face found in imported images", "data": {"total": len(files), "accepted_or_review": accepted_or_review, "results": results}}

    return {"success": True, "message": "Faces evaluated successfully", "data": {"total": len(files), "accepted_or_review": accepted_or_review, "results": results}}


def _resize_for_browser(frame, width=STREAM_WIDTH):
    """Resize display/JPEG only. Never use this result as enrollment AI input."""
    if frame is None or getattr(frame, "size", 0) == 0:
        return frame

    frame_h, frame_w = frame.shape[:2]

    if width <= 0 or frame_w <= width:
        return frame

    scale = width / float(frame_w)
    target_h = max(1, int(frame_h * scale))

    return cv2.resize(
        frame,
        (int(width), target_h),
        interpolation=cv2.INTER_AREA,
    )


def generate_face_recognition_stream_service(camera, camera_id: int):
    """
    Face-enrollment/quality preview using ONE shared camera capture.

    YuNet and quality checks receive the native/raw SharedCameraWorker frame.
    Only the final annotated frame is resized for the browser.
    """
    camera_id = int(camera_id)
    recognition_states[camera_id] = True

    frame_count = 0
    last_processed_native = None

    try:
        while recognition_states.get(camera_id, False):
            try:
                raw_frame = get_shared_camera_frame(
                    camera,
                    wait_timeout=0.5,
                )

                if raw_frame is None:
                    time.sleep(0.02)
                    continue

                frame_count += 1

                should_process = (
                    frame_count % DETECT_EVERY_N_FRAMES == 0
                    or last_processed_native is None
                )

                if should_process:
                    last_processed_native = (
                        process_frame_for_face_detection(
                            raw_frame
                        )
                    )
                    native_output = last_processed_native
                else:
                    native_output = raw_frame

                output_frame = _resize_for_browser(
                    native_output,
                    width=STREAM_WIDTH,
                )

                ok, buffer = cv2.imencode(
                    ".jpg",
                    output_frame,
                    [
                        int(cv2.IMWRITE_JPEG_QUALITY),
                        JPEG_QUALITY,
                    ],
                )

                if not ok:
                    continue

                yield (
                    b"--frame\r\n"
                    b"Content-Type: image/jpeg\r\n\r\n"
                    + buffer.tobytes()
                    + b"\r\n"
                )

            except GeneratorExit:
                break

            except Exception:
                logger.exception(
                    "Face enrollment stream iteration failed; camera=%s continues",
                    camera_id,
                )
                time.sleep(0.25)

    finally:
        recognition_states[camera_id] = False




# =========================================================
# Face enrollment storage from .env
# =========================================================

_face_db_value = os.getenv("FACE_DB_PATH", "").strip()

FACE_DB_PATH = (
    Path(_face_db_value).expanduser()
    if _face_db_value
    else BASE_DIR / "face_db.pkl"
)

_face_image_dir_value = os.getenv(
    "FACE_ENROLLMENT_IMAGE_DIR",
    "face_enrollment_images",
).strip()

FACE_ENROLLMENT_IMAGE_DIR = Path(
    _face_image_dir_value
).expanduser()

if not FACE_ENROLLMENT_IMAGE_DIR.is_absolute():
    FACE_ENROLLMENT_IMAGE_DIR = (
        BASE_DIR / FACE_ENROLLMENT_IMAGE_DIR
    ).resolve()

try:
    FACE_ENROLLMENT_IMAGE_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )
except Exception:
    logger.exception(
        "Could not create face enrollment image directory: %s",
        FACE_ENROLLMENT_IMAGE_DIR,
    )

try:
    FACE_DB_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )
except Exception:
    logger.exception(
        "Could not create FACE_DB_PATH parent: %s",
        FACE_DB_PATH.parent,
    )


_face_db_lock = threading.RLock()


def load_face_pickle_db():
    """Load the same dictionary format consumed by detection_service.py."""
    with _face_db_lock:
        if not FACE_DB_PATH.exists():
            return {}

        try:
            with FACE_DB_PATH.open("rb") as file_handle:
                payload = pickle.load(file_handle)

            if not isinstance(payload, dict):
                raise ValueError(
                    "face_db.pkl must contain a dictionary"
                )

            return payload

        except Exception:
            logger.exception(
                "Could not load face database: %s",
                FACE_DB_PATH,
            )
            raise


def save_face_pickle_db(face_db):
    """
    Atomic pickle save so detection never reads a half-written database.
    detection_service.py reloads when this file's mtime changes.
    """
    if not isinstance(face_db, dict):
        raise ValueError(
            "face database must be a dictionary"
        )

    with _face_db_lock:
        FACE_DB_PATH.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        temp_path = None

        try:
            with tempfile.NamedTemporaryFile(
                mode="wb",
                delete=False,
                dir=str(FACE_DB_PATH.parent),
                prefix=f"{FACE_DB_PATH.name}.",
                suffix=".tmp",
            ) as temp_file:
                temp_path = Path(temp_file.name)

                pickle.dump(
                    face_db,
                    temp_file,
                    protocol=pickle.HIGHEST_PROTOCOL,
                )
                temp_file.flush()
                os.fsync(temp_file.fileno())

            os.replace(
                str(temp_path),
                str(FACE_DB_PATH),
            )

        except Exception:
            if temp_path is not None:
                try:
                    temp_path.unlink(missing_ok=True)
                except Exception:
                    pass
            raise


def base64_to_bgr(image_base64: str):
    """Decode the aligned face crop (data URL or raw base64) to a BGR image."""
    if not image_base64:
        return None

    try:
        if "," in image_base64:
            image_base64 = image_base64.split(",", 1)[1]

        image_bytes = base64.b64decode(image_base64)
        np_arr = np.frombuffer(image_bytes, np.uint8)
        face_bgr = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

        if face_bgr is None or face_bgr.size == 0:
            return None

        return face_bgr

    except Exception:
        logger.exception("Could not decode enrollment face image")
        return None


def create_face_embedding_from_base64(image_base64: str):
    """
    Embed an approved enrollment crop with SFace (128-dim). SFace re-detects the
    face inside the crop to recover the landmarks it needs, then aligns and
    embeds - identical to the runtime path, so enrollment and recognition agree.
    """
    face_bgr = base64_to_bgr(image_base64)

    if face_bgr is None:
        return None

    embedding = face_model.embed_face_image(face_bgr)

    if embedding is None or embedding.size == 0:
        return None

    return np.asarray(embedding, dtype=np.float32).flatten()



def save_primary_face_image(employee_id: str, image_base64: str):
    if not image_base64:
        return None

    try:
        if "," in image_base64:
            image_base64 = image_base64.split(",", 1)[1]

        image_bytes = base64.b64decode(image_base64)

        employee_dir = FACE_ENROLLMENT_IMAGE_DIR / employee_id
        employee_dir.mkdir(parents=True, exist_ok=True)

        filename = f"primary_{int(time.time() * 1000)}.jpg"
        file_path = employee_dir / filename

        with open(file_path, "wb") as file:
            file.write(image_bytes)

        return str(file_path).replace("\\", "/")
    except Exception as error:
        print(f"[ERROR] Could not save primary enrollment face: {error}")
        return None


def get_recent_enrollment_logs_service(db, limit: int = 50):
    persons = (
        db.query(FaceEnrollmentPerson)
        .order_by(FaceEnrollmentPerson.created_at.desc(), FaceEnrollmentPerson.id.desc())
        .limit(limit)
        .all()
    )

    data = []

    for person in persons:
        enrolled_face_url = (
            f"/api/face-enrollment/persons/{person.id}/face"
            if person.primary_face_path
            else None
        )

        data.append({
            "id": person.id,
            "time": person.created_at.isoformat() if person.created_at else None,
            "name": person.full_name,
            "employeeId": person.employee_id,
            "camera": person.camera_name or "Unknown Camera",
            "cameraId": person.camera_id,
            "totalImages": person.total_images or 0,
            "score": f"{person.primary_quality_score or 0}%",
            "quality": person.primary_quality_score or 0,
            "enrolledFace": enrolled_face_url,
        })

    return data


def get_departments_service(db):
    departments = db.query(Department).filter(Department.is_active == True).all()
    return [{"id": item.id, "name": item.name} for item in departments]


def create_department_service(db, name: str):
    exists = db.query(Department).filter(Department.name == name).first()

    if exists:
        return {"success": False, "message": "Department already exists", "status_code": 400}

    department = Department(name=name)
    db.add(department)
    db.commit()
    db.refresh(department)

    return {"success": True, "data": {"id": department.id, "name": department.name}}


def delete_department_service(db, department_id: int):
    department = db.query(Department).filter(Department.id == department_id).first()

    if not department:
        return {"success": False, "message": "Department not found", "status_code": 404}

    db.delete(department)
    db.commit()

    return {"success": True, "message": "Department deleted successfully"}


def get_roles_service(db):
    roles = db.query(RoleAccess).filter(RoleAccess.is_active == True).all()
    return [{"id": item.id, "name": item.name} for item in roles]


def create_role_service(db, name: str):
    exists = db.query(RoleAccess).filter(RoleAccess.name == name).first()

    if exists:
        return {"success": False, "message": "Role already exists", "status_code": 400}

    role = RoleAccess(name=name)
    db.add(role)
    db.commit()
    db.refresh(role)

    return {"success": True, "data": {"id": role.id, "name": role.name}}


def delete_role_service(db, role_id: int):
    role = db.query(RoleAccess).filter(RoleAccess.id == role_id).first()

    if not role:
        return {"success": False, "message": "Role not found", "status_code": 404}

    db.delete(role)
    db.commit()

    return {"success": True, "message": "Role deleted successfully"}


def enroll_person_service(db, payload: dict):
    full_name = payload.get("fullName", "").strip()
    employee_id = payload.get("employeeId", "").strip()
    department = payload.get("department", "").strip()
    role = payload.get("role", "").strip()
    mobile = payload.get("mobile", "").strip()
    email = payload.get("email", "").strip()
    images = payload.get("images", [])
    camera_id = payload.get("cameraId")
    camera_name = (payload.get("cameraName") or "Unknown Camera").strip()

    if not full_name:
        return {"success": False, "message": "Full name is required", "status_code": 400}

    if not employee_id:
        return {"success": False, "message": "Employee ID is required", "status_code": 400}

    if not department:
        return {"success": False, "message": "Department is required", "status_code": 400}

    if not role:
        return {"success": False, "message": "Role / Access is required", "status_code": 400}

    if not images:
        return {"success": False, "message": "At least one approved face image is required", "status_code": 400}

    existing_person = db.query(FaceEnrollmentPerson).filter(
        FaceEnrollmentPerson.employee_id == employee_id
    ).first()

    if existing_person:
        return {"success": False, "message": "Employee ID already enrolled", "status_code": 400}

    face_pickle_db = load_face_pickle_db()

    if employee_id in face_pickle_db:
        return {"success": False, "message": "Employee ID already exists in face DB", "status_code": 400}

    primary_image = next(
        (image for image in images if image.get("isPrimary") is True),
        images[0],
    )

    primary_image_base64 = primary_image.get("image_base64") or primary_image.get("src")

    try:
        primary_quality_score = int(float(primary_image.get("qualityScore", 0) or 0))
    except (TypeError, ValueError):
        primary_quality_score = 0

    primary_quality_score = max(0, min(100, primary_quality_score))

    embeddings = []

    for image in images:
        image_base64 = image.get("image_base64") or image.get("src")

        if not image_base64:
            continue

        try:
            emb = create_face_embedding_from_base64(
                image_base64
            )
        except Exception:
            logger.exception(
                "Face embedding creation failed for employee=%s",
                employee_id,
            )
            continue

        if emb is None:
            continue

        embeddings.append(
            np.asarray(
                emb,
                dtype=np.float32,
            )
        )

    if not embeddings:
        return {"success": False, "message": "No valid face embedding created", "status_code": 400}

    primary_face_path = save_primary_face_image(
        employee_id=employee_id,
        image_base64=primary_image_base64,
    )

    if not primary_face_path:
        return {
            "success": False,
            "message": "Primary face image could not be saved",
            "status_code": 500,
        }

    person = FaceEnrollmentPerson(
        full_name=full_name,
        employee_id=employee_id,
        department=department,
        role=role,
        mobile=mobile or None,
        email=email or None,
        pickle_key=employee_id,
        camera_id=camera_id,
        camera_name=camera_name,
        total_images=len(embeddings),
        primary_quality_score=primary_quality_score,
        primary_face_path=primary_face_path,
        is_active=True,
        is_archived=False,
        recognition_count=0,
    )

    try:
        db.add(person)
        db.commit()
        db.refresh(person)
    except Exception:
        db.rollback()

        try:
            saved_path = Path(primary_face_path)
            if saved_path.exists():
                saved_path.unlink()
        except Exception:
            pass

        raise

    face_pickle_db[employee_id] = {
        "person_id": person.id,
        "employee_id": employee_id,
        "full_name": full_name,
        "department": department,
        "role": role,
        "is_active": True,
        "embeddings": embeddings,
    }

    try:
        save_face_pickle_db(face_pickle_db)
    except Exception:
        db.delete(person)
        db.commit()

        try:
            saved_path = Path(primary_face_path)
            if saved_path.exists():
                saved_path.unlink()
        except Exception:
            pass

        raise

    return {
        "success": True,
        "message": "Person enrolled successfully",
        "data": {
            "id": person.id,
            "fullName": person.full_name,
            "employeeId": person.employee_id,
            "department": person.department,
            "role": person.role,
            "cameraId": person.camera_id,
            "cameraName": person.camera_name,
            "totalImages": person.total_images,
            "quality": person.primary_quality_score,
            "enrolledFace": f"/api/face-enrollment/persons/{person.id}/face",
            "createdAt": person.created_at.isoformat() if person.created_at else None,
            "totalEmbeddings": len(embeddings),
        },
    }

# =========================================================
# Enrolled Persons services
# =========================================================

def _serialize_enrolled_person(person):
    last_seen_at = getattr(person, "last_seen_at", None)

    return {
        "id": person.id,
        "name": person.full_name,
        "fullName": person.full_name,
        "employeeId": person.employee_id,
        "department": person.department,
        "role": person.role,
        "mobile": person.mobile,
        "email": person.email,
        "status": "Active" if person.is_active else "Inactive",
        "isActive": bool(person.is_active),
        "faceQuality": person.primary_quality_score or 0,
        "images": person.total_images or 0,
        "enrolledOn": (
            person.created_at.isoformat()
            if person.created_at
            else None
        ),
        "lastSeen": (
            last_seen_at.isoformat()
            if last_seen_at
            else None
        ),
        "cameraId": person.camera_id,
        "camera": person.camera_name or "Unknown Camera",
        "cameraName": person.camera_name or "Unknown Camera",
        "image": (
            f"/api/face-enrollment/persons/{person.id}/face"
            if person.primary_face_path
            else None
        ),
    }


def get_enrolled_persons_service(
    db,
    search: Optional[str] = None,
    status: Optional[str] = None,
    department: Optional[str] = None,
    role: Optional[str] = None,
):
    query = db.query(FaceEnrollmentPerson)

    if search and search.strip():
        value = f"%{search.strip()}%"

        query = query.filter(
            or_(
                FaceEnrollmentPerson.full_name.ilike(value),
                FaceEnrollmentPerson.employee_id.ilike(value),
                FaceEnrollmentPerson.department.ilike(value),
                FaceEnrollmentPerson.role.ilike(value),
                FaceEnrollmentPerson.mobile.ilike(value),
                FaceEnrollmentPerson.email.ilike(value),
                FaceEnrollmentPerson.camera_name.ilike(value),
            )
        )

    if status and status.strip():
        normalized_status = status.strip().lower()

        if normalized_status == "active":
            query = query.filter(
                FaceEnrollmentPerson.is_active.is_(True)
            )
        elif normalized_status == "inactive":
            query = query.filter(
                FaceEnrollmentPerson.is_active.is_(False)
            )

    if department and department.strip():
        query = query.filter(
            FaceEnrollmentPerson.department == department.strip()
        )

    if role and role.strip():
        query = query.filter(
            FaceEnrollmentPerson.role == role.strip()
        )

    persons = (
        query
        .order_by(
            FaceEnrollmentPerson.created_at.desc(),
            FaceEnrollmentPerson.id.desc(),
        )
        .all()
    )

    return [
        _serialize_enrolled_person(person)
        for person in persons
    ]


def get_enrolled_person_service(db, person_id: int):
    person = (
        db.query(FaceEnrollmentPerson)
        .filter(FaceEnrollmentPerson.id == person_id)
        .first()
    )

    if not person:
        return {
            "success": False,
            "message": "Enrolled person not found",
            "status_code": 404,
        }

    return {
        "success": True,
        "data": _serialize_enrolled_person(person),
    }


def update_enrolled_person_service(db, person_id: int, payload: dict):
    person = (
        db.query(FaceEnrollmentPerson)
        .filter(FaceEnrollmentPerson.id == person_id)
        .first()
    )

    if not person:
        return {
            "success": False,
            "message": "Enrolled person not found",
            "status_code": 404,
        }

    full_name = (payload.get("fullName") or "").strip()
    department = (payload.get("department") or "").strip()
    role = (payload.get("role") or "").strip()
    mobile = (payload.get("mobile") or "").strip()
    email = (payload.get("email") or "").strip()

    if not full_name:
        return {
            "success": False,
            "message": "Full name is required",
            "status_code": 400,
        }

    if not department:
        return {
            "success": False,
            "message": "Department is required",
            "status_code": 400,
        }

    if not role:
        return {
            "success": False,
            "message": "Role / Access is required",
            "status_code": 400,
        }

    # Person-detail editing updates SQL only, as requested.
    # Face embeddings and pickle identity are not changed here.
    person.full_name = full_name
    person.department = department
    person.role = role
    person.mobile = mobile or None
    person.email = email or None

    try:
        db.commit()
        db.refresh(person)
    except Exception:
        db.rollback()
        raise

    return {
        "success": True,
        "message": "Person details updated successfully",
        "data": _serialize_enrolled_person(person),
    }


def update_enrolled_person_status_service(
    db,
    person_id: int,
    is_active: bool,
):
    person = (
        db.query(FaceEnrollmentPerson)
        .filter(FaceEnrollmentPerson.id == person_id)
        .first()
    )

    if not person:
        return {
            "success": False,
            "message": "Enrolled person not found",
            "status_code": 404,
        }

    face_pickle_db = load_face_pickle_db()
    pickle_key = person.pickle_key or person.employee_id
    pickle_entry = face_pickle_db.get(pickle_key)

    if pickle_entry is None:
        return {
            "success": False,
            "message": "Face data not found in face_db.pkl",
            "status_code": 409,
        }

    old_pickle_active = pickle_entry.get("is_active", True)
    old_sql_active = bool(person.is_active)

    pickle_entry["is_active"] = bool(is_active)
    face_pickle_db[pickle_key] = pickle_entry

    # Save pickle first. detection_service.py reloads when mtime changes.
    save_face_pickle_db(face_pickle_db)

    try:
        person.is_active = bool(is_active)
        db.commit()
        db.refresh(person)
    except Exception:
        db.rollback()

        # Restore pickle if SQL update fails.
        try:
            restore_db = load_face_pickle_db()
            restore_entry = restore_db.get(pickle_key)
            if restore_entry is not None:
                restore_entry["is_active"] = old_pickle_active
                restore_db[pickle_key] = restore_entry
                save_face_pickle_db(restore_db)
        except Exception:
            logger.exception(
                "Could not restore pickle status for person_id=%s",
                person_id,
            )

        person.is_active = old_sql_active
        raise

    return {
        "success": True,
        "message": (
            "Face access activated successfully"
            if is_active
            else "Face access deactivated successfully"
        ),
        "data": _serialize_enrolled_person(person),
    }


def delete_enrolled_person_service(db, person_id: int):
    person = (
        db.query(FaceEnrollmentPerson)
        .filter(FaceEnrollmentPerson.id == person_id)
        .first()
    )

    if not person:
        return {
            "success": False,
            "message": "Enrolled person not found",
            "status_code": 404,
        }

    pickle_key = person.pickle_key or person.employee_id
    face_pickle_db = load_face_pickle_db()
    old_pickle_entry = face_pickle_db.get(pickle_key)

    if pickle_key in face_pickle_db:
        del face_pickle_db[pickle_key]
        save_face_pickle_db(face_pickle_db)

    employee_dir = FACE_ENROLLMENT_IMAGE_DIR / person.employee_id
    primary_face_path = person.primary_face_path

    try:
        db.delete(person)
        db.commit()
    except Exception:
        db.rollback()

        # Restore face data if SQL deletion fails.
        if old_pickle_entry is not None:
            try:
                restore_db = load_face_pickle_db()
                restore_db[pickle_key] = old_pickle_entry
                save_face_pickle_db(restore_db)
            except Exception:
                logger.exception(
                    "Could not restore deleted pickle entry for person_id=%s",
                    person_id,
                )

        raise

    # SQL + pickle deletion succeeded. Remove stored images afterwards.
    try:
        if employee_dir.exists() and employee_dir.is_dir():
            for child in sorted(
                employee_dir.rglob("*"),
                key=lambda item: len(item.parts),
                reverse=True,
            ):
                if child.is_file() or child.is_symlink():
                    child.unlink(missing_ok=True)
                elif child.is_dir():
                    child.rmdir()

            employee_dir.rmdir()

        elif primary_face_path:
            saved_path = Path(primary_face_path)
            if saved_path.exists() and saved_path.is_file():
                saved_path.unlink()

    except Exception:
        logger.exception(
            "Person deleted but face image cleanup failed: person_id=%s",
            person_id,
        )

    return {
        "success": True,
        "message": "Person and all face data deleted permanently",
    }

