"""
Shared face-embedding model (SFace via OpenCV, ONNX).

This replaces the old TensorFlow FaceNet embedder. SFace runs on OpenCV's DNN
backend (CPU) in ~10-15 ms per face instead of FaceNet's 200-500 ms, and pairs
natively with the YuNet detector we already use: YuNet gives a 15-value "face
row" (box + 5 landmarks), and SFace.alignCrop() uses those landmarks to align
the face before producing a 128-number fingerprint.

Both the live recognition path (detection_service.py) and the enrollment path
(face_enrollment.py) import this module, so there is exactly one embedding
implementation and both sides always agree.

IMPORTANT: SFace fingerprints are 128 numbers; the old FaceNet ones were 512.
They are NOT comparable. Everyone enrolled under FaceNet must be re-embedded
with SFace once (see scripts/reembed_faces_sface.py). recognize_face() in
detection_service.py skips any leftover 512-length vector, so nothing crashes
during the transition.
"""

import os
import threading
import logging
from pathlib import Path

import cv2
import numpy as np

logger = logging.getLogger(__name__)

# The SFace embedding length. Used as the compatibility guard elsewhere.
EMBEDDING_DIM = 128

BASE_DIR = Path(__file__).resolve().parent.parent

SFACE_MODEL_PATH = os.getenv("SFACE_MODEL_PATH", "").strip()
YUNET_MODEL_PATH = os.getenv("YUNET_MODEL_PATH", "").strip()

# YuNet detector confidence for the standalone (enrollment) embed path.
_YUNET_SCORE = float(os.getenv("SFACE_ENROLL_DETECT_SCORE", "0.6"))
_YUNET_NMS = 0.3
_YUNET_TOPK = 50

_recognizer = None
_recognizer_lock = threading.RLock()

_yunet = None
_yunet_lock = threading.RLock()


def get_recognizer():
    """Lazy SFace recognizer. Raises a clear error if the model is missing."""
    global _recognizer

    if _recognizer is not None:
        return _recognizer

    with _recognizer_lock:
        if _recognizer is None:
            if not SFACE_MODEL_PATH:
                raise RuntimeError("SFACE_MODEL_PATH is missing in .env")

            model_path = Path(SFACE_MODEL_PATH)
            if not model_path.exists():
                raise FileNotFoundError(f"SFace model not found: {model_path}")

            logger.info("Loading SFace recognizer: %s", model_path)
            _recognizer = cv2.FaceRecognizerSF.create(str(model_path), "")
            logger.info("SFace recognizer loaded (embedding dim %d)", EMBEDDING_DIM)

    return _recognizer


def _get_yunet():
    """A small YuNet used only by the standalone enrollment embed path."""
    global _yunet

    if _yunet is not None:
        return _yunet

    with _yunet_lock:
        if _yunet is None:
            if not YUNET_MODEL_PATH:
                raise RuntimeError("YUNET_MODEL_PATH is missing in .env")

            model_path = Path(YUNET_MODEL_PATH)
            if not model_path.exists():
                raise FileNotFoundError(f"YuNet model not found: {model_path}")

            _yunet = cv2.FaceDetectorYN.create(
                str(model_path),
                "",
                (320, 320),
                score_threshold=_YUNET_SCORE,
                nms_threshold=_YUNET_NMS,
                top_k=_YUNET_TOPK,
            )

    return _yunet


def _feature(frame_bgr, face_row):
    """alignCrop the face using YuNet landmarks, then produce the embedding."""
    recognizer = get_recognizer()
    face_row = np.asarray(face_row, dtype=np.float32).reshape(1, -1)
    aligned = recognizer.alignCrop(frame_bgr, face_row)
    feat = recognizer.feature(aligned)
    return np.asarray(feat, dtype=np.float32).flatten()


def embed_from_row(frame_bgr, face_row):
    """
    Runtime path: embed one face given the full frame and the raw YuNet face
    row (15 values, in full-frame coordinates). This is exactly what the live
    recognition loop already has in hand, so no extra cropping is needed.
    """
    return _feature(frame_bgr, face_row)


def _largest_face(faces):
    if faces is None or len(faces) == 0:
        return None
    return max(faces, key=lambda f: float(f[2]) * float(f[3]))


def embed_face_image(face_bgr):
    """
    Enrollment path: embed a standalone face image (the aligned crop the
    enrollment pipeline already produced). Runs YuNet on the crop to recover
    the landmarks SFace needs, then embeds the largest face found.

    Returns a 128-value float32 vector, or None if no face is found.
    """
    if face_bgr is None or getattr(face_bgr, "size", 0) == 0:
        return None

    h, w = face_bgr.shape[:2]
    if h <= 0 or w <= 0:
        return None

    detector = _get_yunet()
    with _yunet_lock:
        detector.setInputSize((w, h))
        _, faces = detector.detect(face_bgr)

    row = _largest_face(faces)
    if row is None:
        return None

    return _feature(face_bgr, row)


def cosine_similarity(a, b):
    a = np.asarray(a, dtype=np.float32).flatten()
    b = np.asarray(b, dtype=np.float32).flatten()
    denom = np.linalg.norm(a) * np.linalg.norm(b)
    if denom == 0:
        return -1.0
    return float(np.dot(a, b) / denom)
