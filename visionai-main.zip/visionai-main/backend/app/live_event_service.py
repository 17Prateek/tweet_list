from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

import cv2

from app.database import LiveEvent
from app.timezone_util import to_local_time


logger = logging.getLogger(__name__)


# =========================================================
# Paths
# =========================================================

BASE_DIR = Path(__file__).resolve().parent.parent
EVIDENCE_DIR = BASE_DIR / "evidence"

try:
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    logger.exception("Could not create evidence directory: %s", EVIDENCE_DIR)


# =========================================================
# Serialization
# =========================================================

def serialize_live_event(event: LiveEvent) -> Dict[str, Any]:
    return {
        "id": event.id,
        "event_id": event.event_id,

        "time": (
            to_local_time(event.created_at).strftime("%d %b %Y %I:%M:%S %p")
            if event.created_at
            else ""
        ),

        "created_at": (
            to_local_time(event.created_at).isoformat()
            if event.created_at
            else None
        ),

        "camera_id": event.camera_id,
        "frame_id": event.frame_id,
        "camera_name": event.camera_name,
        "camera_location": event.camera_location,
        "event_type": event.event_type,
        "person_name": event.person_name,
        "person_id": event.person_id,
        "helmet": event.helmet,
        "vest": event.vest,
        "face_match": event.face_match,
        "evidence_image": event.evidence_image,
    }


# =========================================================
# Read services
# =========================================================

def get_live_events_service(
    db,
    limit: int = 100,
):
    """
    Return latest live events.

    Failure remains isolated to this API request. Caller/FastAPI
    may return an appropriate HTTP error without affecting camera,
    AI, email, or other endpoints.
    """

    safe_limit = max(1, min(int(limit), 1000))

    events = (
        db.query(LiveEvent)
        .order_by(LiveEvent.created_at.desc())
        .limit(safe_limit)
        .all()
    )

    return [
        serialize_live_event(event)
        for event in events
    ]


def get_live_events_by_range_service(
    db,
    start_time: datetime,
    end_time: datetime,
    camera_id: Optional[int] = None,
):
    """
    Return every event between start_time and end_time.

    No 100-row limit is applied because this is used by export/
    reporting features.
    """

    query = db.query(LiveEvent).filter(
        LiveEvent.created_at >= start_time,
        LiveEvent.created_at <= end_time,
    )

    if camera_id is not None:
        query = query.filter(
            LiveEvent.camera_id == int(camera_id)
        )

    events = (
        query
        .order_by(LiveEvent.created_at.asc())
        .all()
    )

    return [
        serialize_live_event(event)
        for event in events
    ]


# =========================================================
# Evidence helpers
# =========================================================

def _safe_event_filename(event_id: str) -> str:
    """
    Keep evidence filenames portable on Windows/Linux and avoid
    path traversal or invalid filename characters.
    """

    raw = str(event_id or "").strip()

    if not raw:
        raw = (
            "EVT-"
            + datetime.now().strftime("%Y%m%d%H%M%S%f")
        )

    safe_chars = []

    for char in raw:
        if char.isalnum() or char in {"-", "_"}:
            safe_chars.append(char)
        else:
            safe_chars.append("_")

    return "".join(safe_chars) + ".jpg"


def save_evidence_image(
    frame,
    event_id: str,
    *,
    jpeg_quality: int = 90,
) -> Optional[str]:
    """
    Save evidence image safely.

    Returns:
        /evidence/<filename>

    or:
        None

    IMPORTANT:
    Disk/image failure does not raise by default. The event may
    still be saved without an image.
    """

    if frame is None:
        return None

    try:
        if not hasattr(frame, "size") or frame.size == 0:
            return None

        EVIDENCE_DIR.mkdir(
            parents=True,
            exist_ok=True,
        )

        filename = _safe_event_filename(
            event_id
        )

        file_path = EVIDENCE_DIR / filename

        quality = max(
            40,
            min(
                int(jpeg_quality),
                100,
            ),
        )

        image_saved = cv2.imwrite(
            str(file_path),
            frame,
            [
                int(cv2.IMWRITE_JPEG_QUALITY),
                quality,
            ],
        )

        if not image_saved:
            logger.error(
                "cv2.imwrite returned False for event evidence: %s",
                file_path,
            )
            return None

        return f"/evidence/{filename}"

    except Exception:
        logger.exception(
            "Could not save evidence image for event %s",
            event_id,
        )
        return None


# =========================================================
# Event creation
# =========================================================

def create_live_event_service(
    db,
    camera_id,
    frame_id,
    camera_name,
    camera_location,
    event_type,
    person_name,
    person_id,
    helmet,
    vest,
    face_match,
    frame=None,
):
    """
    Create one LiveEvent safely.

    Design rules:
      - Evidence failure does NOT prevent DB event creation.
      - DB failure performs rollback and re-raises only to caller.
      - No process exit / global worker shutdown.
      - event_worker.py can call this function in background.

    For hot AI paths, prefer event_worker.submit_live_event(...)
    so image/DB work does not block inference.
    """

    timestamp = datetime.now().strftime(
        "%Y%m%d%H%M%S%f"
    )

    resolved_camera_id = int(camera_id)

    event_id = (
        f"EVT-{resolved_camera_id}-"
        f"{frame_id}-{timestamp}"
    )

    evidence_image = None

    # Disk failure is intentionally isolated.
    if frame is not None:
        evidence_image = save_evidence_image(
            frame,
            event_id,
        )

    event = LiveEvent(
        event_id=event_id,
        camera_id=resolved_camera_id,
        frame_id=str(frame_id),
        camera_name=str(
            camera_name
            or f"Camera {resolved_camera_id}"
        ),
        camera_location=(
            str(camera_location)
            if camera_location is not None
            else None
        ),
        event_type=str(
            event_type or "Detection Event"
        ),
        person_name=str(
            person_name or "Unknown Person"
        ),
        person_id=(
            str(person_id)
            if person_id is not None
            else None
        ),
        helmet="Yes" if bool(helmet) else "No",
        vest="Yes" if bool(vest) else "No",
        face_match=(
            "Yes"
            if bool(face_match)
            else "No"
        ),
        evidence_image=evidence_image,
    )

    try:
        db.add(event)
        db.commit()
        db.refresh(event)

    except Exception:
        try:
            db.rollback()
        except Exception:
            logger.exception(
                "Could not rollback LiveEvent transaction"
            )

        logger.exception(
            "Could not create live event: "
            "camera_id=%s frame_id=%s event_id=%s",
            resolved_camera_id,
            frame_id,
            event_id,
        )

        raise

    return serialize_live_event(event)


# =========================================================
# Optional safe wrapper
# =========================================================

def try_create_live_event_service(
    db,
    **kwargs,
) -> Dict[str, Any]:
    """
    Non-raising convenience wrapper.

    Useful for places where an event-write failure should be
    reported as data rather than propagated as an exception.
    """

    try:
        data = create_live_event_service(
            db,
            **kwargs,
        )

        return {
            "success": True,
            "data": data,
            "error": None,
        }

    except Exception as exc:
        return {
            "success": False,
            "data": None,
            "error": str(exc),
        }
