"""
One-time migration: re-embed every enrolled person with SFace.

The old face_db.pkl holds 512-dim FaceNet vectors. After the SFace swap those
are unusable (SFace is 128-dim). This script rebuilds each person's fingerprint
from the primary enrollment photo already saved on disk, so nobody has to be
re-enrolled by hand. Person records in the database are untouched.

Run it ON THE SERVER, once, right after deploying the SFace code:

    cd /home/paperlessops/public_html/visionai-backend
    source venv/bin/activate
    python -m app.scripts.reembed_faces_sface

It:
  - backs up face_db.pkl to face_db.pkl.facenet-backup-<stamp>,
  - for each person, finds their newest primary_*.jpg under the enrollment
    image dir and re-embeds it with SFace,
  - writes the updated face_db.pkl atomically,
  - prints a per-person report. Anyone whose photo can't be re-embedded keeps
    their old vector (which recognition safely ignores) and is listed as
    NEEDS RE-ENROLL - re-enroll those few through the normal UI.

Add --dry-run to see what would happen without writing anything.
"""

import os
import sys
import glob
import time
import pickle
import shutil
import tempfile
from pathlib import Path

import cv2
import numpy as np
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent.parent  # backend/
load_dotenv(dotenv_path=BASE_DIR / ".env")

# face_model reads SFACE_MODEL_PATH / YUNET_MODEL_PATH at import, so load the
# environment first (above), then import it.
from app import face_model  # noqa: E402


def _face_db_path():
    value = os.getenv("FACE_DB_PATH", "").strip()
    return Path(value).expanduser() if value else (BASE_DIR / "app" / "face_db.pkl")


def _image_dir():
    value = os.getenv("FACE_ENROLLMENT_IMAGE_DIR", "face_enrollment_images").strip()
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = (BASE_DIR / "app" / value).resolve()
    return path


def _newest_primary(image_dir, employee_id):
    folder = image_dir / str(employee_id)
    if not folder.is_dir():
        return None
    candidates = sorted(
        glob.glob(str(folder / "primary_*.jpg")),
        key=os.path.getmtime,
        reverse=True,
    )
    # Fall back to any jpg in the folder if no primary_*.jpg is present.
    if not candidates:
        candidates = sorted(
            glob.glob(str(folder / "*.jpg")),
            key=os.path.getmtime,
            reverse=True,
        )
    return candidates[0] if candidates else None


def _save_atomic(db, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb", delete=False, dir=str(path.parent),
            prefix=f"{path.name}.", suffix=".tmp",
        ) as fh:
            tmp = Path(fh.name)
            pickle.dump(db, fh, protocol=pickle.HIGHEST_PROTOCOL)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(str(tmp), str(path))
    except Exception:
        if tmp is not None:
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass
        raise


def main():
    dry_run = "--dry-run" in sys.argv[1:]

    db_path = _face_db_path()
    image_dir = _image_dir()

    print(f"[reembed] face_db:    {db_path}")
    print(f"[reembed] image dir:  {image_dir}")
    print(f"[reembed] mode:       {'DRY RUN (no writes)' if dry_run else 'LIVE'}")

    if not db_path.exists():
        print("[reembed] No face_db.pkl found - nothing to migrate. "
              "New enrollments will already be SFace.")
        return 0

    with db_path.open("rb") as fh:
        db = pickle.load(fh)

    if not isinstance(db, dict) or not db:
        print("[reembed] face_db.pkl is empty - nothing to migrate.")
        return 0

    print(f"[reembed] people in DB: {len(db)}")

    # Force the SFace model to load now so a missing model fails loudly, early.
    try:
        face_model.get_recognizer()
    except Exception as error:
        print(f"[reembed] ERROR: cannot load SFace model: {error}")
        print("[reembed] Set SFACE_MODEL_PATH in .env to the .onnx file and retry.")
        return 1

    done, skipped = [], []

    for employee_id, entry in db.items():
        # Support both storage shapes: nested dict {embeddings: [...]} or a bare list.
        if isinstance(entry, dict):
            label = entry.get("full_name") or entry.get("employee_id") or employee_id
            emp = entry.get("employee_id", employee_id)
        else:
            label = employee_id
            emp = employee_id

        image_path = _newest_primary(image_dir, emp)
        if not image_path:
            skipped.append((label, "no saved photo on disk"))
            continue

        face_bgr = cv2.imread(image_path)
        if face_bgr is None:
            skipped.append((label, f"could not read {os.path.basename(image_path)}"))
            continue

        emb = face_model.embed_face_image(face_bgr)
        if emb is None or emb.size != face_model.EMBEDDING_DIM:
            skipped.append((label, "no face found in saved photo"))
            continue

        new_emb = np.asarray(emb, dtype=np.float32).flatten()
        if isinstance(entry, dict):
            entry["embeddings"] = [new_emb]
        else:
            db[employee_id] = [new_emb]
        done.append(label)

    print("\n[reembed] ---- result ----")
    for name in done:
        print(f"  OK           {name}")
    for name, why in skipped:
        print(f"  NEEDS RE-ENROLL  {name}  ({why})")
    print(f"[reembed] re-embedded {len(done)} / {len(db)} people.")

    if dry_run:
        print("[reembed] DRY RUN - no files changed.")
        return 0

    if not done:
        print("[reembed] Nothing re-embedded; leaving face_db.pkl untouched.")
        return 0

    stamp = time.strftime("%Y%m%d-%H%M%S")
    backup = db_path.with_name(f"{db_path.name}.facenet-backup-{stamp}")
    shutil.copy2(db_path, backup)
    print(f"[reembed] backup written: {backup}")

    _save_atomic(db, db_path)
    print(f"[reembed] face_db.pkl updated. Detection reloads it automatically.")

    if skipped:
        print(f"[reembed] {len(skipped)} person(s) still need a fresh UI enrollment "
              "(listed above).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
