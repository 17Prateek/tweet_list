"""
Display-time helper. The server clock is UTC; people reading the dashboard
and the alert emails are in India. Everything is stored in UTC and only
converted when shown. Change the zone with VISIONAI_TIMEZONE in .env.
"""
import os
from datetime import datetime, timezone

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None

LOCAL_TIMEZONE_NAME = os.getenv("VISIONAI_TIMEZONE", "Asia/Kolkata").strip() or "Asia/Kolkata"

try:
    LOCAL_TIMEZONE = ZoneInfo(LOCAL_TIMEZONE_NAME) if ZoneInfo else None
except Exception:
    LOCAL_TIMEZONE = None


def to_local_time(value):
    """UTC (or naive-as-UTC) datetime -> local wall-clock datetime."""
    if value is None or LOCAL_TIMEZONE is None:
        return value

    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)

    return value.astimezone(LOCAL_TIMEZONE)


def now_local():
    return datetime.now(timezone.utc).astimezone(LOCAL_TIMEZONE) if LOCAL_TIMEZONE else datetime.now()
