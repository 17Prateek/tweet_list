"""
A tiny IoU tracker: gives a detection box the same id frame after frame.

Vehicles have no faces, so "the same truck" has to come from position. Each
camera keeps a short list of recent boxes per kind ("vehicle", "person"); a
new box that overlaps one of them enough inherits its id, anything else gets
a fresh id, and boxes not seen for forget_sec are dropped. Greedy matching by
highest overlap - plenty for trucks that stand still for hours.

No numpy, no models: importable from anywhere, testable without cameras.
"""
from __future__ import annotations

import itertools
import threading
from typing import Dict, List, Sequence, Tuple

_tracks: Dict[Tuple[int, str], List[dict]] = {}
_lock = threading.Lock()
_next_id = itertools.count(1)


def _iou(a: Sequence[float], b: Sequence[float]) -> float:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    iw = max(0.0, min(ax2, bx2) - max(ax1, bx1))
    ih = max(0.0, min(ay2, by2) - max(ay1, by1))
    inter = iw * ih
    if inter <= 0:
        return 0.0
    union = (ax2 - ax1) * (ay2 - ay1) + (bx2 - bx1) * (by2 - by1) - inter
    return inter / union if union > 0 else 0.0


def update(
    camera_id: int,
    kind: str,
    boxes: Sequence[Sequence[float]],
    now_mono: float,
    *,
    iou_min: float = 0.3,
    forget_sec: float = 60.0,
) -> List[Tuple[int, tuple]]:
    """Return (track_id, box) for every box, in the order given."""
    key = (int(camera_id), str(kind))
    result: List[Tuple[int, tuple]] = []

    with _lock:
        tracks = [t for t in _tracks.get(key, []) if now_mono - t["last_seen"] <= forget_sec]

        # All candidate pairs, best overlap first; each track and each box used once.
        pairs = []
        for bi, box in enumerate(boxes):
            for ti, track in enumerate(tracks):
                score = _iou(box, track["box"])
                if score >= iou_min:
                    pairs.append((score, bi, ti))
        pairs.sort(reverse=True)

        assigned_box: Dict[int, int] = {}
        used_tracks = set()
        for _, bi, ti in pairs:
            if bi in assigned_box or ti in used_tracks:
                continue
            assigned_box[bi] = ti
            used_tracks.add(ti)

        for bi, box in enumerate(boxes):
            box = tuple(box)
            if bi in assigned_box:
                track = tracks[assigned_box[bi]]
                track["box"] = box
                track["last_seen"] = now_mono
            else:
                track = {"id": next(_next_id), "box": box, "last_seen": now_mono}
                tracks.append(track)
            result.append((track["id"], box))

        _tracks[key] = tracks

    return result


def forget(camera_id: int) -> None:
    with _lock:
        for key in [k for k in _tracks if k[0] == int(camera_id)]:
            _tracks.pop(key, None)
