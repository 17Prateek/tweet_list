from passlib.context import CryptContext
from sqlalchemy import func
from app.database import User

pwd_context = CryptContext(schemes=["pbkdf2_sha256"], deprecated="auto")

def hash_password(password: str):
    return pwd_context.hash(password)

def verify_password(password: str, password_hash: str):
    return pwd_context.verify(password, password_hash)


def serialize_user(user):
    return {
        "email": user.email,
        "employeeId": user.employee_id,
        "name": user.full_name,
        "mobile": user.mobile,
        "department": user.department,
        "status": "Active" if user.is_active else "Inactive",
        "lastLogin": user.last_login.strftime("%d %b %Y, %I:%M %p") if user.last_login else "Never",
        "createdAt": user.created_at.isoformat() if user.created_at else None,
    }


def get_users_service(db):
    users = db.query(User).filter(User.role == "user").order_by(User.created_at.desc()).all()
    return [serialize_user(user) for user in users]


def get_user_stats_service(db):
    total_users = db.query(func.count(User.email)).filter(User.role == "user").scalar() or 0
    active_users = db.query(func.count(User.email)).filter(User.role == "user", User.is_active.is_(True)).scalar() or 0
    inactive_users = db.query(func.count(User.email)).filter(User.role == "user", User.is_active.is_(False)).scalar() or 0
    super_admins = db.query(func.count(User.email)).filter(User.role == "super_admin").scalar() or 0

    return {
        "totalUsers": total_users,
        "activeUsers": active_users,
        "inactiveUsers": inactive_users,
        "superAdmins": super_admins,
    }


def create_user_service(db, email, employee_id, full_name, mobile, department, password):
    email = email.strip().lower()

    if db.query(User).filter(User.email == email).first():
        return {"success": False, "status_code": 409, "message": "Email address already exists"}

    user = User(
        email=email,
        employee_id=employee_id.strip(),
        full_name=full_name.strip(),
        mobile=mobile.strip(),
        department=department.strip(),
        password_hash=hash_password(password),
        role="user",
        is_active=True,
    )

    db.add(user)
    db.commit()
    db.refresh(user)

    return {
        "success": True,
        "status_code": 201,
        "message": "User created successfully",
        "data": serialize_user(user),
    }


def get_user_by_email_service(db, email):
    return db.query(User).filter(User.email == email.strip().lower()).first()


def update_user_service(db, email, employee_id, full_name, mobile, department, password=None):
    user = get_user_by_email_service(db, email)

    if not user:
        return {"success": False, "status_code": 404, "message": "User not found"}

    if user.role != "user":
        return {"success": False, "status_code": 403, "message": "Super Admin cannot be updated here"}

    user.employee_id = employee_id.strip()
    user.full_name = full_name.strip()
    user.mobile = mobile.strip()
    user.department = department.strip()

    if password:
        user.password_hash = hash_password(password)

    db.commit()
    db.refresh(user)

    return {
        "success": True,
        "status_code": 200,
        "message": "User updated successfully",
        "data": serialize_user(user),
    }


def update_user_status_service(db, email, is_active):
    user = get_user_by_email_service(db, email)

    if not user:
        return {"success": False, "status_code": 404, "message": "User not found"}

    if user.role != "user":
        return {"success": False, "status_code": 403, "message": "Super Admin status cannot be changed"}

    user.is_active = bool(is_active)
    db.commit()
    db.refresh(user)

    return {
        "success": True,
        "status_code": 200,
        "message": "User activated successfully" if user.is_active else "User deactivated successfully",
        "data": serialize_user(user),
    }


def delete_user_service(db, email):
    user = get_user_by_email_service(db, email)

    if not user:
        return {"success": False, "status_code": 404, "message": "User not found"}

    if user.role != "user":
        return {"success": False, "status_code": 403, "message": "Super Admin cannot be deleted"}

    db.delete(user)
    db.commit()

    return {
        "success": True,
        "status_code": 200,
        "message": "User deleted successfully",
    }