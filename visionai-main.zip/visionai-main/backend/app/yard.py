"""
Yard engine: who is standing in which zone, and for how long.

Fed per processed frame by the detection worker with the vehicles and people
it found; keeps one "visit" per (camera, zone, track) and turns visits into
episodes through app.episodes exactly like PPE incidents:

  vehicle enters a zone  -> after VEHICLE_CONFIRM_SEC: info episode
                            "Truck in Bay 1" (touched while it stays)
  zone has a time limit  -> when crossed: the same episode is escalated to
                            warning ("Truck waiting 2 h 05 m - over the 2 h limit")
  vehicle leaves         -> after VEHICLE_GRACE_SEC unseen: episode closed
  person in a restricted -> after PERSON_ZONE_CONFIRM_SEC: critical episode
  zone                     "Ajay in restricted area" / "Unknown person in ..."

Cameras with no zones drawn cost nothing here. Light module: no cv2, no
models - everything is testable with a fake clock.
"""
from __future__ import annotations

import os
import threading
import time as _time
from typing import Any, Dict, List, Optional, Sequence, Tuple

from app import episodes, tracks, zones

VEHICLE_CONFIRM_SEC = float(os.getenv("VISIONAI_VEHICLE_CONFIRM_SEC", "5"))
VEHICLE_GRACE_SEC = float(os.getenv("VISIONAI_VEHICLE_GRACE_SEC", "60"))
PERSON_ZONE_CONFIRM_SEC = float(os.getenv("VISIONAI_PERSON_ZONE_CONFIRM_SEC", "3"))
PERSON_ZONE_GRACE_SEC = float(os.getenv("VISIONAI_PERSON_ZONE_GRACE_SEC", "30"))

# After a restart the visit table is empty. A confirmed sighting adopts an
# episode that is still open for the same zone and was seen this recently,
# instead of opening a duplicate; open episodes nobody adopts are closed
# once they have been idle this long.
ADOPT_MAX_AGE_SEC = float(os.getenv("VISIONAI_YARD_ADOPT_SEC", "900"))
RECONCILE_EVERY_SEC = 30.0
_last_reconcile = 0.0
YARD_KINDS = ("vehicle_in_zone", "person_in_zone")

CLASS_WORDS = {
    "truck": "Truck", "car": "Car", "bus": "Bus",
    "motorcycle": "Two-wheeler", "two-wheeler": "Two-wheeler", "bicycle": "Bicycle",
}

UNKNOWN_NAMES = {"", "monitoring", "unknown", "unknown person", "n/a", "none", "null"}

# Best evidence: keep the frame where the subject is largest and not cut off
# at a side, refreshed at most every EVIDENCE_WINDOW_SEC while it stays.
EVIDENCE_WINDOW_SEC = 5.0


def _evidence_score(box, frame_shape) -> float:
    try:
        x1, y1, x2, y2 = box
    except (TypeError, ValueError):
        return 0.0
    area = float(max(0, x2 - x1) * max(0, y2 - y1))
    if frame_shape is not None and len(frame_shape) >= 2 and frame_shape[1]:
        width = float(frame_shape[1])
        margin = max(2.0, width * 0.01)
        if x1 <= margin or x2 >= width - margin:
            area *= 0.3
    return area

# (camera_id, zone_id, subject key) -> visit
_visits: Dict[Tuple[int, int, str], Dict[str, Any]] = {}
_lock = threading.Lock()


def reset_for_tests() -> None:
    global _last_reconcile
    with _lock:
        _visits.clear()
    _last_reconcile = 0.0


def _format_duration(seconds: float) -> str:
    seconds = int(max(0, seconds))
    hours, rest = divmod(seconds, 3600)
    minutes, secs = divmod(rest, 60)
    if hours:
        return f"{hours} h {minutes:02d} m"
    if minutes:
        return f"{minutes} m {secs:02d} s"
    return f"{secs} s"


def _format_limit(seconds: float) -> str:
    seconds = int(seconds)
    if seconds % 3600 == 0:
        return f"{seconds // 3600} h"
    if seconds % 60 == 0:
        return f"{seconds // 60} min"
    return f"{seconds} s"


def _class_word(cls: Optional[str]) -> str:
    return CLASS_WORDS.get(str(cls or "").lower(), "Vehicle")


def _person_identity(person: Dict[str, Any]) -> Tuple[bool, str, Optional[str]]:
    """(recognised, label, employee id)."""
    name = str(person.get("face_name") or "").strip()
    if name.lower() in UNKNOWN_NAMES:
        return False, "Unknown person", None
    emp = person.get("employee_id")
    emp = None if emp in (None, "", "N/A") else str(emp)
    return True, name, emp


# ---------------------------------------------------------------------------
# Visit state machine (shared by vehicles and people)
# ---------------------------------------------------------------------------

def _see(key, *, camera, zone, kind, now_mono, frame, confirm_sec, subject, score=0.0) -> Tuple[Optional[dict], Optional[str]]:
    """
    Record one sighting. Returns (visit to open, episode id to touch) - at
    most one of them - so the caller does the slow work outside the lock.
    """
    with _lock:
        visit = _visits.get(key)
        if visit is None:
            _visits[key] = {
                "kind": kind, "camera_id": int(camera.id),
                "camera_name": getattr(camera, "camera_name", f"CAM-{camera.id}"),
                "camera_location": getattr(camera, "location", None),
                "zone": zone, "subject": subject,
                "first_seen": now_mono, "last_seen": now_mono,
                "episode_id": None, "opening": False, "opened_mono": None,
                "escalated": False, "last_frame": frame,
                "best_score": score, "best_mono": now_mono,
            }
            return None, None
        visit["last_seen"] = now_mono
        visit["zone"] = zone
        # While pending keep the single best frame; once open, the best of the
        # recent window - never just the latest, which may show the subject leaving.
        window_over = now_mono - visit["best_mono"] > EVIDENCE_WINDOW_SEC and visit["episode_id"]
        if window_over or score >= visit["best_score"]:
            visit["best_score"] = score
            visit["best_mono"] = now_mono
            visit["last_frame"] = frame
        if visit["episode_id"]:
            return None, visit["episode_id"]
        if not visit["opening"] and now_mono - visit["first_seen"] >= confirm_sec:
            visit["opening"] = True
            return visit, None
        return None, None


def _open(key, visit, now_mono) -> None:
    subject = visit["subject"]
    zone = visit["zone"]

    # Restart resilience: pick up the episode that is still open for this
    # zone rather than opening a second one for the same vehicle/person.
    with _lock:
        taken = {v["episode_id"] for v in _visits.values() if v["episode_id"]}
    try:
        adopted = episodes.find_adoptable(
            kind=subject["kind"], camera_id=visit["camera_id"], zone_id=zone["id"],
            subject_type=subject["subject_type"], max_age_sec=ADOPT_MAX_AGE_SEC, exclude=taken,
        )
    except Exception as exc:
        print("[YARD] adopt lookup failed:", exc)
        adopted = None
    if adopted:
        episodes.adopt_episode(adopted)
        # Keep the original clock: the dwell timer and the limit run from
        # when the vehicle really arrived, not from the restart.
        row = episodes.get_episode(adopted) or {}
        age = max(0.0, _time.time() - float(row.get("started_epoch") or _time.time()))
        already_over = bool((row.get("attributes") or {}).get("over_limit")) or row.get("severity") not in (None, "info")
        with _lock:
            current = _visits.get(key)
            if current is not None:
                current["opening"] = False
                current["episode_id"] = adopted
                current["opened_mono"] = now_mono - age
                current["escalated"] = already_over
        return

    episode_id = episodes.open_episode(
        camera_id=visit["camera_id"], camera_name=visit["camera_name"], camera_location=visit["camera_location"],
        kind=subject["kind"], title=subject["title"],
        subject_type=subject["subject_type"], subject_label=subject["subject_label"], subject_id=subject.get("subject_id"),
        severity=subject["severity"], frame=visit["last_frame"],
        zone_id=zone["id"], zone_name=zone["name"], attributes=subject.get("attributes"),
        site_id=zone.get("site_id"),
    )
    with _lock:
        current = _visits.get(key)
        if current is None:
            return
        current["opening"] = False
        if episode_id:
            current["episode_id"] = episode_id
            current["opened_mono"] = now_mono
        else:
            # Save failed: back off, try again after another confirm window.
            current["first_seen"] = now_mono


# ---------------------------------------------------------------------------
# Observers (called per processed frame)
# ---------------------------------------------------------------------------

def observe_vehicles(camera, vehicles: Sequence[Dict[str, Any]], frame, now_mono: float, *, frame_shape=None) -> None:
    camera_id = int(camera.id)
    if not vehicles or not zones.has_zones(camera_id):
        return
    shape = frame_shape if frame_shape is not None else getattr(frame, "shape", None)
    if shape is None:
        return

    boxes = [v["box"] for v in vehicles]
    tracked = tracks.update(camera_id, "vehicle", boxes, now_mono, forget_sec=VEHICLE_GRACE_SEC)

    for (track_id, box), vehicle in zip(tracked, vehicles):
        zone = zones.zone_of(camera_id, box, shape)
        if zone is None:
            continue
        cls = str(vehicle.get("cls") or "vehicle").lower()
        word = _class_word(cls)
        subject = {
            "kind": "vehicle_in_zone", "severity": "info",
            "subject_type": "vehicle", "subject_label": word, "subject_id": None,
            "title": f"{word} in {zone['name']}",
            "attributes": {"vehicle_class": cls, "zone_type": zone["zone_type"], "limit_sec": zone.get("limit_sec")},
        }
        key = (camera_id, int(zone["id"]), f"v{track_id}")
        to_open, touch_id = _see(key, camera=camera, zone=zone, kind="vehicle", now_mono=now_mono, frame=frame,
                                 confirm_sec=VEHICLE_CONFIRM_SEC, subject=subject,
                                 score=_evidence_score(box, shape))
        if to_open is not None:
            _open(key, to_open, now_mono)
        elif touch_id:
            episodes.touch_episode(touch_id)


def observe_people_in_zones(camera, persons: Sequence[Dict[str, Any]], frame, now_mono: float, *, frame_shape=None) -> None:
    """Restricted zones only: anyone inside is a critical episode."""
    camera_id = int(camera.id)
    if not persons or not zones.has_zones(camera_id, types=("restricted",)):
        return
    shape = frame_shape if frame_shape is not None else getattr(frame, "shape", None)
    if shape is None:
        return

    boxes = [p["box"] for p in persons]
    tracked = tracks.update(camera_id, "person", boxes, now_mono, forget_sec=PERSON_ZONE_GRACE_SEC)

    for (track_id, box), person in zip(tracked, persons):
        zone = zones.zone_of(camera_id, box, shape, types=("restricted",))
        if zone is None:
            continue
        recognised, label, emp = _person_identity(person)
        subject = {
            "kind": "person_in_zone", "severity": "critical",
            "subject_type": "person" if recognised else "unknown", "subject_label": label, "subject_id": emp,
            "title": f"{label} in restricted area",
            "attributes": {"zone_type": "restricted", "recognised": recognised},
        }
        # A recognised person is one visit no matter how the tracker splits them.
        who = f"p:{label.lower()}" if recognised else f"t{track_id}"
        key = (camera_id, int(zone["id"]), who)
        to_open, touch_id = _see(key, camera=camera, zone=zone, kind="person", now_mono=now_mono, frame=frame,
                                 confirm_sec=PERSON_ZONE_CONFIRM_SEC, subject=subject,
                                 score=_evidence_score(box, shape))
        if to_open is not None:
            _open(key, to_open, now_mono)
        elif touch_id:
            episodes.touch_episode(touch_id)


def restrict_ppe_to_zones(camera_id: int, persons: List[Dict[str, Any]], frame_shape) -> List[Dict[str, Any]]:
    """
    PPE zones narrow, never widen: if the camera has one or more "ppe" zones,
    only people standing in them count for PPE violations. No ppe zone ->
    whole frame, exactly as today.
    """
    camera_id = int(camera_id)
    if not persons or not zones.has_zones(camera_id, types=("ppe",)):
        return persons
    return [p for p in persons if zones.zone_of(camera_id, p["box"], frame_shape, types=("ppe",)) is not None]


# ---------------------------------------------------------------------------
# Sweeper (every few seconds from the detection sweeper thread)
# ---------------------------------------------------------------------------

def sweep_yard(now_mono: Optional[float] = None) -> None:
    if now_mono is None:
        now_mono = _time.monotonic()

    to_close: List[Tuple[str, Any]] = []
    to_escalate: List[Tuple[str, str, Dict[str, Any]]] = []

    with _lock:
        for key, visit in list(_visits.items()):
            grace = VEHICLE_GRACE_SEC if visit["kind"] == "vehicle" else PERSON_ZONE_GRACE_SEC
            if now_mono - visit["last_seen"] >= grace:
                _visits.pop(key, None)
                if visit["episode_id"]:
                    to_close.append((visit["episode_id"], visit["last_frame"]))
                continue

            limit = visit["zone"].get("limit_sec")
            if (
                visit["kind"] == "vehicle" and visit["episode_id"] and limit
                and not visit["escalated"] and visit["opened_mono"] is not None
                and now_mono - visit["opened_mono"] >= float(limit)
            ):
                visit["escalated"] = True
                word = visit["subject"]["subject_label"]
                waited = _format_duration(now_mono - visit["opened_mono"])
                title = f"{word} waiting {waited} — over the {_format_limit(limit)} limit"
                to_escalate.append((visit["episode_id"], title, {"over_limit": True, "limit_sec": limit}))

    for episode_id, frame in to_close:
        try:
            episodes.close_episode(episode_id, frame=frame)
        except Exception as exc:
            print("[YARD] close failed:", exc)

    for episode_id, title, attributes in to_escalate:
        try:
            episodes.escalate_episode(episode_id, severity="warning", title=title, attributes=attributes)
        except Exception as exc:
            print("[YARD] escalate failed:", exc)

    _reconcile_orphans(now_mono)


def _reconcile_orphans(now_mono: float) -> None:
    """
    Close yard episodes left open by a restart that nobody adopted. Only
    rows idle for longer than the vehicle grace are touched, so a live
    episode (touched every few seconds) is never closed by mistake.
    """
    global _last_reconcile
    if now_mono - _last_reconcile < RECONCILE_EVERY_SEC:
        return
    _last_reconcile = now_mono
    with _lock:
        live = {v["episode_id"] for v in _visits.values() if v["episode_id"]}
    try:
        for episode_id in episodes.open_unended(YARD_KINDS, idle_for_sec=VEHICLE_GRACE_SEC):
            if episode_id not in live:
                episodes.close_episode(episode_id)
    except Exception as exc:
        print("[YARD] reconcile failed:", exc)


def yard_state() -> List[Dict[str, Any]]:
    """Open visits, for /api/monitoring/status and debugging."""
    with _lock:
        return [
            {
                "camera_id": v["camera_id"], "zone": v["zone"]["name"], "kind": v["kind"],
                "subject": v["subject"]["subject_label"], "episode_id": v["episode_id"],
                "escalated": v["escalated"],
            }
            for v in _visits.values()
        ]
