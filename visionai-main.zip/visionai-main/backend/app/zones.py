"""
Zone geometry and a small cached lookup of the zones drawn on each camera.

Polygons are stored as [[x, y], ...] with x/y as fractions 0..1 of the frame,
so a zone drawn on a 1280x720 snapshot still fits a 640x360 detection frame.
The detector asks "which zone is this box standing in?" many times a second,
so zones are cached per camera and refreshed every ZONE_REFRESH_SEC or the
moment the API changes one (bump_zone_version).

Light module: imports app.database only.
"""
from __future__ import annotations

import json
import os
import threading
import time
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from app.database import CameraZone, get_db_session

ZONE_REFRESH_SEC = float(os.getenv("VISIONAI_ZONE_REFRESH_SEC", "30"))

_version = 0
_cache: Dict[int, Tuple[float, int, List[Dict[str, Any]]]] = {}
_lock = threading.Lock()


# ---------------------------------------------------------------------------
# Geometry
# ---------------------------------------------------------------------------

def point_in_polygon(x: float, y: float, polygon: Sequence[Sequence[float]]) -> bool:
    """Ray casting. Points exactly on an edge count as outside."""
    n = len(polygon) if polygon else 0
    if n < 3:
        return False

    inside = False
    j = n - 1
    for i in range(n):
        xi, yi = polygon[i][0], polygon[i][1]
        xj, yj = polygon[j][0], polygon[j][1]
        # One strict and one non-strict comparison so a shared edge between
        # two zones is counted once, not twice.
        if (yi > y) != (yj > y):
            x_cross = (xj - xi) * (y - yi) / (yj - yi) + xi
            if x < x_cross:
                inside = not inside
        j = i
    return inside


def ground_point(box: Sequence[float], frame_shape: Sequence[int]) -> Tuple[float, float]:
    """
    Bottom-centre of a detection box as fractions of the frame: where a
    person's feet or a vehicle's wheels meet the ground. Box centres would put
    a tall truck in the zone behind it.
    """
    x1, y1, x2, y2 = box[0], box[1], box[2], box[3]
    height, width = float(frame_shape[0]), float(frame_shape[1])
    if width <= 0 or height <= 0:
        return (0.0, 0.0)
    x = ((x1 + x2) / 2.0) / width
    y = y2 / height
    return (min(1.0, max(0.0, x)), min(1.0, max(0.0, y)))


# ---------------------------------------------------------------------------
# Cache
# ---------------------------------------------------------------------------

def bump_zone_version() -> None:
    """Call after any zone write so every camera reloads on its next lookup."""
    global _version
    with _lock:
        _version += 1


def _load(camera_id: int) -> List[Dict[str, Any]]:
    db = get_db_session()
    try:
        rows = (
            db.query(CameraZone)
            .filter(CameraZone.camera_id == int(camera_id), CameraZone.is_active.is_(True))
            .order_by(CameraZone.id)
            .all()
        )
        zones = []
        for row in rows:
            try:
                polygon = json.loads(row.polygon_json or "[]")
            except ValueError:
                continue
            if not isinstance(polygon, list) or len(polygon) < 3:
                continue
            zones.append({
                "id": row.id,
                "name": row.name,
                "zone_type": row.zone_type,
                "polygon": polygon,
                "limit_sec": row.limit_sec,
                "site_id": row.site_id,
            })
        return zones
    finally:
        db.close()


def zones_for_camera(camera_id: int) -> List[Dict[str, Any]]:
    camera_id = int(camera_id)
    now = time.monotonic()
    with _lock:
        entry = _cache.get(camera_id)
        version = _version
    if entry is not None:
        loaded_at, loaded_version, zones = entry
        if loaded_version == version and now - loaded_at < ZONE_REFRESH_SEC:
            return zones
    try:
        zones = _load(camera_id)
    except Exception as exc:
        print("[ZONES] load failed:", exc)
        return entry[2] if entry is not None else []
    with _lock:
        _cache[camera_id] = (now, version, zones)
    return zones


def has_zones(camera_id: int, *, types: Optional[Iterable[str]] = None) -> bool:
    wanted = set(types) if types else None
    return any(wanted is None or z["zone_type"] in wanted for z in zones_for_camera(camera_id))


def zone_of(
    camera_id: int,
    box: Sequence[float],
    frame_shape: Sequence[int],
    *,
    types: Optional[Iterable[str]] = None,
) -> Optional[Dict[str, Any]]:
    """First active zone (in creation order) whose polygon contains the box's ground point."""
    wanted = set(types) if types else None
    x, y = ground_point(box, frame_shape)
    for zone in zones_for_camera(camera_id):
        if wanted is not None and zone["zone_type"] not in wanted:
            continue
        if point_in_polygon(x, y, zone["polygon"]):
            return zone
    return None
