import os

from dotenv import load_dotenv

import logging

logger = logging.getLogger(__name__)

# Load project/server .env before importing OpenCV, NumPy, PyTorch,
# TensorFlow, Ultralytics, or any app module that may import them.
load_dotenv()

# Conservative native-thread defaults for local + VPS/cPanel.
# Values already defined in .env or the service environment are preserved.
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("TF_NUM_INTRAOP_THREADS", "1")
os.environ.setdefault("TF_NUM_INTEROP_THREADS", "1")

from typing import Optional

import cv2

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse, FileResponse, Response
from starlette.concurrency import run_in_threadpool
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, field_validator, EmailStr
from typing import Optional, List
from datetime import datetime
from sqlalchemy import func
from pathlib import Path

from fastapi import FastAPI, UploadFile, File, Request, Depends, Query

from app.database import (
    create_tables,
    get_db_session,
    FaceEnrollmentPerson,
    FaceRecognitionEvent,
)

from app.detection_service import (
    generate_detection_stream_service,
    get_detection_stats,
    start_camera_recording,
    stop_camera_recording,
    RECORDINGS_DIR,
    set_frame_detection_enabled,
    get_frame_detection_status,
    stop_detection_workers_for_camera,
    shutdown_all_detection_workers,
    start_monitoring,
    stop_monitoring,
    get_monitoring_status,
    init_monitoring,
    set_camera_monitoring,
)

from app.camera_management import (
    create_camera_group_service,
    get_camera_groups_service,
    delete_camera_group_service,
    create_camera_service,
    get_cameras_service,
    delete_camera_service,
    get_camera_by_id_service,
    generate_camera_stream_service,
    get_shared_camera_worker,
    serialize_camera,
    stop_camera_worker,
    shutdown_all_camera_workers,
    store_pushed_frame,
    decode_pushed_jpeg,
    get_ingest_status,
    INGEST_TOKEN,
    INGEST_MAX_BYTES,
)

from app.face_enrollment import (
    start_face_recognition_service,
    stop_face_recognition_service,
    get_face_recognition_status_service,
    generate_face_recognition_stream_service,
    capture_face_service,
    import_faces_service,
    get_departments_service,
    create_department_service,
    delete_department_service,
    get_roles_service,
    create_role_service,
    delete_role_service,
    enroll_person_service,
    get_recent_enrollment_logs_service,
    get_face_enrollment_stats_service,
    get_enrolled_persons_service,
    get_enrolled_person_service,
    update_enrolled_person_service,
    update_enrolled_person_status_service,
    delete_enrolled_person_service,
)

from app.camera_issue_service import (
    get_camera_issues_service,
    get_camera_issue_service,
)

from app.email_service import (
    get_email_recipients_service,
    create_email_recipient_service,
    update_email_recipient_service,
    delete_email_recipient_service,
    send_test_email_recipient_service,
    get_email_alert_status_service,
    update_email_alert_status_service,
    get_active_email_violations_service,
    get_email_worker_status_service,
    get_latest_email_sent_notification_service,
    start_email_worker,
    stop_email_worker,
    send_counting_test_email_service,
    get_email_alert_history_service,
)

from fastapi.staticfiles import StaticFiles

from app.live_event_service import (
    get_live_events_service,
    get_live_events_by_range_service,
)

from app.user_management_service import (
    create_user_service,
    delete_user_service,
    get_user_stats_service,
    get_users_service,
    update_user_service,
    update_user_status_service,
)

from app.email_service import send_new_user_welcome_email_service

from app.database import check_database_health

from app.auth_service import (
    request_login_otp_service,
    verify_login_otp_service,
    request_forgot_password_otp_service,
    verify_forgot_password_otp_service,
    reset_forgot_password_service,
)

from app.auth_dependencies import (
    get_current_user,
    get_current_user_from_query,
    require_super_admin,
    user_from_access_token,
)

from app.counting_service import (
    get_counting_setting,
    update_counting_setting,
    get_counting_summaries,
    get_live_count,
    get_all_live_counts,
    start_counting_monitoring,
    stop_counting_monitoring,
    get_counting_monitoring_status,
    generate_counting_stream,
    get_counting_lines,
    create_counting_line,
    update_counting_line,
    delete_counting_line,


)

from app.episode_alerts import start_episode_alerts

from app.database import (
    Camera,
    CountingSetting,
    CountingSummary,
    get_db_session,
)

from app.episodes_api import router as episodes_router, zones_router
from app.arrivals import router as arrivals_router
from app import episodes



app = FastAPI(title="PPE Camera Management API")

# Serve recorded videos
app.mount(
    "/recordings",
    StaticFiles(directory=str(RECORDINGS_DIR)),
    name="recordings",
)

from app.live_event_service import EVIDENCE_DIR

app.mount(
    "/evidence",
    StaticFiles(directory=str(EVIDENCE_DIR)),
    name="evidence",
)


# =========================================================
# Counting Management - Separate Evidence Storage
# =========================================================

COUNTING_EVIDENCE_DIR = (
    Path(__file__).resolve().parent
    / "counting_evidence"
)

COUNTING_EVIDENCE_DIR.mkdir(
    parents=True,
    exist_ok=True,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://visionai.paperlessops.com",
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Episode engine: live state, history, actions, SSE stream (Ops Board + phone app)
app.include_router(episodes_router)
app.include_router(zones_router)
app.include_router(arrivals_router)


class CameraGroupCreateRequest(BaseModel):
    name: str
    description: Optional[str] = None

class MasterNameRequest(BaseModel):
    name: str


class FaceEnrollRequest(BaseModel):
    fullName: str
    employeeId: str
    department: str
    role: str
    mobile: Optional[str] = None
    email: Optional[str] = None

    cameraId: Optional[int] = None
    cameraName: Optional[str] = None

    images: List[dict]

class CameraCreateRequest(BaseModel):
    camera_name: str
    source_type: str

    rtsp_url: Optional[str] = None
    webcam_index: Optional[int] = None
    usb_index: Optional[int] = None

    group_id: Optional[int] = None
    location: Optional[str] = None
    is_recording: bool = False

    @field_validator("source_type")
    @classmethod
    def validate_source_type(cls, value: str):
        value = value.lower().strip()

        if value not in ["rtsp", "webcam", "usb"]:
            raise ValueError("source_type must be rtsp, webcam or usb")

        return value


class CountingIntervalRequest(BaseModel):
    interval_minutes: int

    @field_validator("interval_minutes")
    @classmethod
    def validate_interval(cls, value: int):
        if value not in [5, 10, 15, 30, 60]:
            raise ValueError(
                "interval_minutes must be 5, 10, 15, 30, or 60"
            )
        return value

class EmailRecipientRequest(BaseModel):
    email: EmailStr
    name: str
    position: str
    alertType: str = "All Alerts"
    status: str = "Active"

    @field_validator("name", "position", "alertType", "status")
    @classmethod
    def not_empty(cls, value: str):
        value = value.strip()

        if not value:
            raise ValueError("Field cannot be empty")

        return value

    @field_validator("status")
    @classmethod
    def validate_status(cls, value: str):
        value = value.strip()

        if value not in ["Active", "Inactive"]:
            raise ValueError("status must be Active or Inactive")

        return value


class EmailAlertStatusRequest(BaseModel):
    enabled: bool
    frequency_minutes: int

    @field_validator("frequency_minutes")
    @classmethod
    def validate_frequency_minutes(cls, value: int):
        if value not in [5, 10, 15, 20]:
            raise ValueError(
                "frequency_minutes must be 5, 10, 15, or 20"
            )
        return value


class UserCreateRequest(BaseModel):
    fullName: str
    employeeId: str
    email: EmailStr
    mobile: str
    department: str
    password: str

    @field_validator("fullName", "employeeId", "mobile", "department")
    @classmethod
    def required_fields(cls, value):
        value = value.strip()
        if not value:
            raise ValueError("Field cannot be empty")
        return value

    @field_validator("mobile")
    @classmethod
    def validate_mobile(cls, value):
        if not value.isdigit() or len(value) != 10 or value[0] not in "6789":
            raise ValueError("Enter a valid 10-digit mobile number")
        return value

    @field_validator("password")
    @classmethod
    def validate_password(cls, value):
        if len(value) < 8:
            raise ValueError("Password must be at least 8 characters")
        if not any(c.isupper() for c in value):
            raise ValueError("Password must contain an uppercase letter")
        if not any(c.islower() for c in value):
            raise ValueError("Password must contain a lowercase letter")
        if not any(c.isdigit() for c in value):
            raise ValueError("Password must contain a number")
        if not any(not c.isalnum() for c in value):
            raise ValueError("Password must contain a special character")
        return value


class UserUpdateRequest(BaseModel):
    fullName: str
    employeeId: str
    mobile: str
    department: str
    password: Optional[str] = None

    @field_validator("fullName", "employeeId", "mobile", "department")
    @classmethod
    def required_fields(cls, value):
        value = value.strip()
        if not value:
            raise ValueError("Field cannot be empty")
        return value

    @field_validator("mobile")
    @classmethod
    def validate_mobile(cls, value):
        if not value.isdigit() or len(value) != 10 or value[0] not in "6789":
            raise ValueError("Enter a valid 10-digit mobile number")
        return value

    @field_validator("password")
    @classmethod
    def validate_password(cls, value):
        if value in (None, ""):
            return None
        if len(value) < 8:
            raise ValueError("Password must be at least 8 characters")
        if not any(c.isupper() for c in value):
            raise ValueError("Password must contain an uppercase letter")
        if not any(c.islower() for c in value):
            raise ValueError("Password must contain a lowercase letter")
        if not any(c.isdigit() for c in value):
            raise ValueError("Password must contain a number")
        if not any(not c.isalnum() for c in value):
            raise ValueError("Password must contain a special character")
        return value


class UserStatusRequest(BaseModel):
    is_active: bool


class CountingMonitoringRequest(BaseModel):
    camera_ids: list[int]

class CountingLineRequest(BaseModel):
    camera_id: int
    name: str
    points: list[list[float]]

    direction: str

    color: str = "#1683ff"
    width: int = 4

    show_arrows: bool = True
    show_label: bool = True
    is_active: bool = True

    @field_validator("camera_id")
    @classmethod
    def validate_camera_id(cls, value: int):
        if value <= 0:
            raise ValueError(
                "camera_id must be greater than 0"
            )

        return value

    @field_validator("name")
    @classmethod
    def validate_name(cls, value: str):
        value = str(value or "").strip()

        if not value:
            raise ValueError(
                "Line name is required"
            )

        return value

    @field_validator("direction")
    @classmethod
    def validate_direction(cls, value: str):
        value = str(value or "").strip().lower()

        if value not in {
            "ltr",
            "rtl",
        }:
            raise ValueError(
                "direction must be ltr or rtl"
            )

        return value

    @field_validator("points")
    @classmethod
    def validate_points(
        cls,
        value: list[list[float]],
    ):
        if (
            not isinstance(value, list)
            or len(value) != 2
        ):
            raise ValueError(
                "points must contain exactly 2 points"
            )

        normalized = []

        for point in value:
            if (
                not isinstance(point, list)
                or len(point) != 2
            ):
                raise ValueError(
                    "Each line point must contain x and y"
                )

            x = float(point[0])
            y = float(point[1])

            if not (
                0.0 <= x <= 1.0
                and
                0.0 <= y <= 1.0
            ):
                raise ValueError(
                    "Line coordinates must be between 0 and 1"
                )

            normalized.append(
                [x, y]
            )

        if normalized[0] == normalized[1]:
            raise ValueError(
                "Line start and end points cannot be the same"
            )

        return normalized

    @field_validator("width")
    @classmethod
    def validate_width(cls, value: int):
        if value < 1 or value > 20:
            raise ValueError(
                "width must be between 1 and 20"
            )

        return value
    

class EnrolledPersonUpdateRequest(BaseModel):
    fullName: str
    department: str
    role: str
    mobile: Optional[str] = None
    email: Optional[str] = None


class EnrolledPersonStatusRequest(BaseModel):
    isActive: bool


@app.on_event("startup")
def startup_event():
    create_tables()

    # Models are intentionally lazy-loaded on first detection request.
    # This keeps normal camera/live-view startup lighter on constrained servers.
    result = start_email_worker()
    print(result["message"])

     # ADD FROM CODE 2
    print(start_episode_alerts()["message"])

    # Restore continuous monitoring if it was on before the restart, so that
    # "monitoring on" survives deploys and reboots rather than silently
    # stopping the moment the service is touched.
    try:
        init_monitoring()
    except Exception as error:
        print(f"[WARN] Could not restore monitoring state: {error}")


@app.on_event("shutdown")
def shutdown_event():
    # Stop model/output workers first so they stop reading shared camera frames.
    try:
        shutdown_all_detection_workers()
        print("All detection workers stopped")
    except Exception as error:
        print(f"[WARN] Detection worker shutdown error: {error}")

    # Then release all RTSP/webcam/USB capture objects.
    try:
        shutdown_all_camera_workers()
        print("All camera workers stopped")
    except Exception as error:
        print(f"[WARN] Camera worker shutdown error: {error}")

    # Preserve the existing email-worker shutdown behavior.
    try:
        result = stop_email_worker(
            wait_for_pending_jobs=True,
        )
        print(result["message"])
    except Exception as error:
        print(f"[WARN] Email worker shutdown error: {error}")


# =========================================================
# Authentication request models
# =========================================================
class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class LoginOTPVerifyRequest(BaseModel):
    email: EmailStr
    otp: str

class ForgotPasswordSendOTPRequest(BaseModel):
    email: EmailStr


class ForgotPasswordVerifyOTPRequest(BaseModel):
    email: EmailStr
    otp: str


class ForgotPasswordResetRequest(BaseModel):
    resetToken: str
    newPassword: str


# =========================================================
# AUTHENTICATION APIs - PHASE 1
# =========================================================
@app.post("/api/auth/login")
async def login_user(payload: LoginRequest):
    db = get_db_session()

    try:
        result = request_login_otp_service(
            db=db,
            email=str(payload.email),
            password=payload.password,
        )

        if not result.get("success"):
            return JSONResponse(
                {
                    "ok": False,
                    "message": result.get(
                        "message",
                        "Login failed",
                    ),
                },
                status_code=result.get(
                    "status_code",
                    400,
                ),
            )

        return JSONResponse(
            {
                "ok": True,
                "message": result.get(
                    "message",
                    "OTP sent successfully",
                ),
                "email": result.get("email"),
                "expiresInMinutes": result.get(
                    "expiresInMinutes",
                    5,
                ),
            },
            status_code=200,
        )

    except Exception as error:
        print(f"[ERROR] Login request failed: {error}")

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not process login request",
            },
            status_code=500,
        )

    finally:
        db.close()


@app.post("/api/auth/verify-otp")
async def verify_login_otp(payload: LoginOTPVerifyRequest):
    db = get_db_session()

    try:
        result = verify_login_otp_service(
            db=db,
            email=str(payload.email),
            otp=payload.otp,
        )

        if not result.get("success"):
            return JSONResponse(
                {
                    "ok": False,
                    "message": result.get(
                        "message",
                        "OTP verification failed",
                    ),
                },
                status_code=result.get(
                    "status_code",
                    400,
                ),
            )

        return JSONResponse(
            {
                "ok": True,
                "message": result.get(
                    "message",
                    "Login successful",
                ),
                "accessToken": result.get("accessToken"),
                "tokenType": result.get(
                    "tokenType",
                    "bearer",
                ),
                "expiresInMinutes": result.get(
                    "expiresInMinutes",
                    60,
                ),
                "user": result.get("user"),
            },
            status_code=200,
        )

    except Exception as error:
        print(f"[ERROR] OTP verification failed: {error}")

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not verify login OTP",
            },
            status_code=500,
        )

    finally:
        db.close()

# =========================================================
# AUTHENTICATION APIs - PHASE 2
# Forgot Password
# =========================================================

@app.post("/api/auth/forgot-password/send-otp")
async def forgot_password_send_otp(
    payload: ForgotPasswordSendOTPRequest,
):
    db = get_db_session()

    try:
        result = request_forgot_password_otp_service(
            db=db,
            email=str(payload.email),
        )

        if not result.get("success"):
            return JSONResponse(
                {
                    "ok": False,
                    "message": result.get(
                        "message",
                        "Could not send password reset OTP",
                    ),
                },
                status_code=result.get(
                    "status_code",
                    400,
                ),
            )

        return JSONResponse(
            {
                "ok": True,
                "message": result.get(
                    "message",
                    "Password reset OTP sent successfully",
                ),
                "email": result.get("email"),
                "expiresInMinutes": result.get(
                    "expiresInMinutes",
                    5,
                ),
            },
            status_code=200,
        )

    except Exception as error:
        logger.exception(
            "Forgot password OTP request failed"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": (
                    "Could not process password reset request"
                ),
            },
            status_code=500,
        )

    finally:
        db.close()


@app.post("/api/auth/forgot-password/verify-otp")
async def forgot_password_verify_otp(
    payload: ForgotPasswordVerifyOTPRequest,
):
    db = get_db_session()

    try:
        result = verify_forgot_password_otp_service(
            db=db,
            email=str(payload.email),
            otp=payload.otp,
        )

        if not result.get("success"):
            return JSONResponse(
                {
                    "ok": False,
                    "message": result.get(
                        "message",
                        "OTP verification failed",
                    ),
                },
                status_code=result.get(
                    "status_code",
                    400,
                ),
            )

        return JSONResponse(
            {
                "ok": True,
                "message": result.get(
                    "message",
                    "OTP verified successfully",
                ),
                "resetToken": result.get(
                    "resetToken"
                ),
                "expiresInMinutes": result.get(
                    "expiresInMinutes",
                    10,
                ),
            },
            status_code=200,
        )

    except Exception as error:
        logger.exception(
            "Forgot password OTP verification failed"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": (
                    "Could not verify password reset OTP"
                ),
            },
            status_code=500,
        )

    finally:
        db.close()


@app.post("/api/auth/forgot-password/reset")
async def forgot_password_reset(
    payload: ForgotPasswordResetRequest,
):
    db = get_db_session()

    try:
        result = reset_forgot_password_service(
            db=db,
            reset_token=payload.resetToken,
            new_password=payload.newPassword,
        )

        if not result.get("success"):
            return JSONResponse(
                {
                    "ok": False,
                    "message": result.get(
                        "message",
                        "Password reset failed",
                    ),
                },
                status_code=result.get(
                    "status_code",
                    400,
                ),
            )

        return JSONResponse(
            {
                "ok": True,
                "message": result.get(
                    "message",
                    "Password updated successfully",
                ),
            },
            status_code=200,
        )

    except Exception as error:
        logger.exception(
            "Password reset request failed"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": (
                    "Could not update password"
                ),
            },
            status_code=500,
        )

    finally:
        db.close()


# =========================================================
# Application health
# =========================================================
@app.get("/api/health", dependencies=[Depends(get_current_user)])
async def application_health():
    health = {"ok": True, "status": "healthy", "components": {}}

    try:
        db_status = check_database_health()
    except Exception as error:
        db_status = {"ok": False, "error": str(error)}

    health["components"]["database"] = db_status

    try:
        health["components"]["monitoring"] = get_monitoring_status()
    except Exception as error:
        health["components"]["monitoring"] = {"error": str(error)}

    if not db_status.get("ok", False):
        health["ok"] = False
        health["status"] = "degraded"

    return JSONResponse(health)


@app.get("/")
async def root():
    return {
        "ok": True,
        "message": "PPE Camera Management API is running",
    }


@app.post("/api/camera-groups", dependencies=[Depends(get_current_user)])
async def create_camera_group(payload: CameraGroupCreateRequest):
    name = payload.name.strip()

    if not name:
        return JSONResponse(
            {"ok": False, "message": "Group name is required"},
            status_code=400,
        )

    db = get_db_session()

    try:
        result = create_camera_group_service(
            db=db,
            name=name,
            description=payload.description,
        )

        if not result["success"]:
            return JSONResponse(
                {"ok": False, "message": result["message"]},
                status_code=result["status_code"],
            )

        return JSONResponse(
            {
                "ok": True,
                "message": "Camera group created successfully",
                "data": result["data"],
            }
        )

    finally:
        db.close()


@app.get("/api/camera-groups", dependencies=[Depends(get_current_user)])
async def get_camera_groups():
    db = get_db_session()

    try:
        data = get_camera_groups_service(db)
        return JSONResponse({"ok": True, "data": data})

    finally:
        db.close()


@app.delete("/api/camera-groups/{group_id}", dependencies=[Depends(get_current_user)])
async def delete_camera_group(group_id: int):
    db = get_db_session()

    try:
        result = delete_camera_group_service(db=db, group_id=group_id)

        if not result["success"]:
            return JSONResponse(
                {"ok": False, "message": result["message"]},
                status_code=result["status_code"],
            )

        return JSONResponse({"ok": True, "message": result["message"]})

    finally:
        db.close()


@app.post("/api/ingest/frame/{camera_id}")
async def ingest_frame(camera_id: int, request: Request):
    """
    Receive one frame from a capture agent running on the camera's network.

    Body is a raw JPEG. The agent posts one per camera every couple of seconds,
    which is all detection needs - and a fraction of the bandwidth of pulling
    video across the internet.
    """
    if INGEST_TOKEN:
        supplied = request.headers.get("x-ingest-token", "")

        if supplied != INGEST_TOKEN:
            return JSONResponse(
                {"ok": False, "message": "Invalid ingest token"},
                status_code=401,
            )

    body = await request.body()

    if not body:
        return JSONResponse(
            {"ok": False, "message": "Empty body - send a JPEG"},
            status_code=400,
        )

    if len(body) > INGEST_MAX_BYTES:
        return JSONResponse(
            {"ok": False, "message": f"Frame too large ({len(body)} bytes)"},
            status_code=413,
        )

    frame = decode_pushed_jpeg(body)

    if frame is None:
        return JSONResponse(
            {"ok": False, "message": "Body is not a valid JPEG"},
            status_code=400,
        )

    sequence = store_pushed_frame(camera_id, frame)
    height, width = frame.shape[:2]

    return JSONResponse(
        {
            "ok": True,
            "data": {
                "camera_id": int(camera_id),
                "sequence": sequence,
                "width": int(width),
                "height": int(height),
                "bytes": len(body),
            },
        }
    )


@app.get("/api/ingest/cameras")
async def ingest_cameras(request: Request):
    """
    The camera list for the capture agent, authenticated by the ingest token
    (the agent cannot log in - login needs an emailed OTP). Returns only what
    the agent needs: which RTSP cameras to capture and which are excluded
    from monitoring, so it does not ship frames nobody will analyse.
    """
    if INGEST_TOKEN:
        supplied = request.headers.get("x-ingest-token", "")

        if supplied != INGEST_TOKEN:
            return JSONResponse(
                {"ok": False, "message": "Invalid ingest token"},
                status_code=401,
            )

    db = get_db_session()

    try:
        cameras = get_cameras_service(db)
    finally:
        db.close()

    try:
        status = get_monitoring_status()
    except Exception:
        status = {}

    wanted = [
        {
            "id": camera.get("id"),
            "camera_name": camera.get("camera_name"),
            "source_type": camera.get("source_type"),
            "rtsp_url": camera.get("rtsp_url"),
            "is_active": camera.get("is_active", True),
        }
        for camera in (cameras or [])
        if (camera.get("source_type") or "").lower() == "rtsp"
        and camera.get("rtsp_url")
    ]

    return JSONResponse({
        "ok": True,
        "data": {
            "cameras": wanted,
            "excluded_camera_ids": status.get("excluded_camera_ids", []),
            "monitoring_enabled": status.get("enabled", False),
        },
    })


@app.get("/api/ingest/status")
async def ingest_status():
    """What the capture agent has delivered, per camera, and how fresh it is."""
    try:
        return JSONResponse({"ok": True, "data": get_ingest_status()})
    except Exception as error:
        print("Ingest status error:", error)
        return JSONResponse(
            {"ok": False, "message": "Could not read ingest status"},
            status_code=500,
        )


@app.post("/api/monitoring/start", dependencies=[Depends(get_current_user)])
async def api_start_monitoring():
    """
    Turn on continuous detection for every active camera.

    Independent of the dashboard - cameras are monitored whether or not anyone
    has a tile open, which is the point: an alert from an unwatched camera is
    the one that matters.
    """
    try:
        return JSONResponse({"ok": True, "data": start_monitoring()})
    except Exception as error:
        print("Start monitoring error:", error)
        return JSONResponse(
            {"ok": False, "message": "Could not start monitoring"},
            status_code=500,
        )


@app.post("/api/monitoring/stop", dependencies=[Depends(get_current_user)])
async def api_stop_monitoring():
    try:
        return JSONResponse({"ok": True, "data": stop_monitoring()})
    except Exception as error:
        print("Stop monitoring error:", error)
        return JSONResponse(
            {"ok": False, "message": "Could not stop monitoring"},
            status_code=500,
        )


@app.post("/api/monitoring/cameras/{camera_id}/{action}", dependencies=[Depends(get_current_user)])
async def api_set_camera_monitoring(camera_id: int, action: str):
    """
    Include or exclude one camera from continuous monitoring.

    action = "enable" | "disable". An excluded camera is not analysed, but can
    still be opened in a tile and watched live.
    """
    action = (action or "").lower().strip()

    if action not in ("enable", "disable"):
        return JSONResponse(
            {"ok": False, "message": "action must be enable or disable"},
            status_code=400,
        )

    try:
        data = set_camera_monitoring(camera_id, action == "enable")
        return JSONResponse({"ok": True, "data": data})
    except Exception as error:
        print("Set camera monitoring error:", error)
        return JSONResponse(
            {"ok": False, "message": "Could not change camera monitoring"},
            status_code=500,
        )


@app.get("/api/monitoring/status", dependencies=[Depends(get_current_user)])
async def api_monitoring_status():
    try:
        return JSONResponse({"ok": True, "data": get_monitoring_status()})
    except Exception as error:
        print("Monitoring status error:", error)
        return JSONResponse(
            {"ok": False, "message": "Could not read monitoring status"},
            status_code=500,
        )


@app.get("/api/camera-issues", dependencies=[Depends(get_current_user)])
async def get_camera_issues():
    db = get_db_session()

    try:
        data = get_camera_issues_service(db)
        return JSONResponse({"ok": True, "data": data})

    finally:
        db.close()


@app.get("/api/camera-issues/{camera_id}", dependencies=[Depends(get_current_user)])
async def get_camera_issue(camera_id: int):
    db = get_db_session()

    try:
        data = get_camera_issue_service(db, camera_id)

        if not data:
            return JSONResponse(
                {"ok": False, "message": "No active issue found"},
                status_code=404,
            )

        return JSONResponse({"ok": True, "data": data})

    finally:
        db.close()


@app.post("/api/cameras", dependencies=[Depends(get_current_user)])
async def create_camera(payload: CameraCreateRequest):
    print("payload : ",payload)
    camera_name = payload.camera_name.strip()
    source_type = payload.source_type.lower().strip()

    if not camera_name:
        return JSONResponse(
            {"ok": False, "message": "Camera name is required"},
            status_code=400,
        )

    if source_type == "rtsp" and not payload.rtsp_url:
        return JSONResponse(
            {"ok": False, "message": "RTSP URL is required"},
            status_code=400,
        )

    if source_type == "webcam" and payload.webcam_index is None:
        return JSONResponse(
            {"ok": False, "message": "Webcam index is required"},
            status_code=400,
        )

    if source_type == "usb" and payload.usb_index is None:
        return JSONResponse(
            {"ok": False, "message": "USB camera index is required"},
            status_code=400,
        )

    db = get_db_session()

    try:
        result = create_camera_service(
            db=db,
            camera_name=camera_name,
            source_type=source_type,
            rtsp_url=payload.rtsp_url,
            webcam_index=payload.webcam_index,
            usb_index=payload.usb_index,
            group_id=payload.group_id,
            location=payload.location,
            is_recording=payload.is_recording,
        )

        if not result["success"]:
            return JSONResponse(
                {"ok": False, "message": result["message"]},
                status_code=result["status_code"],
            )

        return JSONResponse(
            {
                "ok": True,
                "message": "Camera added successfully",
                "data": result["data"],
            }
        )

    finally:
        db.close()


# =========================================================
# Counting Management - Evidence Image
# =========================================================

@app.get("/api/counting/evidence/{summary_id}")
async def get_counting_evidence(
    summary_id: int,
    token: str = Query(
        ...,
        description="JWT access token",
    ),
):
    """
    Open the evidence image for one Counting Management
    summary/event.

    Token is accepted through query string because this
    endpoint can be opened directly in a browser/new tab.
    """

    db = get_db_session()

    try:
        # -------------------------------------------------
        # Authenticate user
        # -------------------------------------------------
        user_from_access_token(
            token,
            db,
        )

        # -------------------------------------------------
        # Find Counting Management row
        # -------------------------------------------------
        summary = (
            db.query(CountingSummary)
            .filter(
                CountingSummary.id == summary_id
            )
            .first()
        )

        if not summary:
            return JSONResponse(
                {
                    "ok": False,
                    "message": (
                        "Counting event not found"
                    ),
                },
                status_code=404,
            )

        # -------------------------------------------------
        # Check evidence
        # -------------------------------------------------
        if not summary.evidence_image:
            return JSONResponse(
                {
                    "ok": False,
                    "message": (
                        "Evidence image not available "
                        "for this event"
                    ),
                },
                status_code=404,
            )

        # -------------------------------------------------
        # Get filename only.
        #
        # We do NOT trust a full path coming from DB.
        # All counting evidence must stay inside
        # COUNTING_EVIDENCE_DIR.
        # -------------------------------------------------
        stored_path = str(
            summary.evidence_image
        ).replace("\\", "/")

        filename = Path(
            stored_path
        ).name

        # Camera-specific folder
        camera_folder = (
            COUNTING_EVIDENCE_DIR
            / f"camera_{summary.camera_id}"
        )

        image_path = (
            camera_folder
            / filename
        )

        # -------------------------------------------------
        # File validation
        # -------------------------------------------------
        if (
            not image_path.exists()
            or not image_path.is_file()
        ):
            return JSONResponse(
                {
                    "ok": False,
                    "message": (
                        "Counting evidence image "
                        "file not found"
                    ),
                },
                status_code=404,
            )

        # -------------------------------------------------
        # Open image directly in browser
        # -------------------------------------------------
        return FileResponse(
            path=str(image_path),
            media_type="image/jpeg",
            filename=image_path.name,
            content_disposition_type="inline",
            headers={
                "Cache-Control": "no-store",
            },
        )

    except Exception as error:
        print(
            "[ERROR] Counting evidence: "
            f"{error}"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": (
                    "Could not load counting "
                    "evidence image"
                ),
            },
            status_code=500,
        )

    finally:
        db.close()


@app.get("/api/cameras", dependencies=[Depends(get_current_user)])
async def get_cameras():
    db = get_db_session()

    try:
        data = get_cameras_service(db)
        return JSONResponse({"ok": True, "data": data})

    finally:
        db.close()


# =========================================================
# Face Enrollment - Dashboard Stats
# =========================================================
@app.get("/api/face-enrollment/stats", dependencies=[Depends(get_current_user)])
async def get_face_enrollment_stats():
    db = get_db_session()

    try:
        data = get_face_enrollment_stats_service(db)

        return JSONResponse(
            {
                "ok": True,
                "data": data,
            }
        )

    except Exception as error:
        print(f"[ERROR] Face enrollment stats: {error}")

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not load face enrollment stats",
            },
            status_code=500,
        )

    finally:
        db.close()


@app.delete("/api/cameras/{camera_id}", dependencies=[Depends(get_current_user)])
async def delete_camera(camera_id: int):
    db = get_db_session()

    try:
        # Stop model/output work first. delete_camera_service() releases the
        # shared physical camera worker after the database update.
        stop_detection_workers_for_camera(camera_id)

        result = delete_camera_service(db=db, camera_id=camera_id)

        if not result["success"]:
            return JSONResponse(
                {"ok": False, "message": result["message"]},
                status_code=result["status_code"],
            )

        return JSONResponse({"ok": True, "message": result["message"]})

    finally:
        db.close()


@app.put("/api/cameras/{camera_id}", dependencies=[Depends(get_current_user)])
async def update_camera(camera_id: int, payload: CameraCreateRequest):
    db = get_db_session()

    try:
        camera = get_camera_by_id_service(db, camera_id)

        if not camera:
            return JSONResponse(
                {"ok": False, "message": "Camera not found"},
                status_code=404,
            )

        # Source URL/device index may change. Stop old detection and capture
        # workers before applying the new configuration.
        stop_detection_workers_for_camera(camera_id)
        stop_camera_worker(camera_id)

        camera_name = payload.camera_name.strip()
        source_type = payload.source_type.lower().strip()

        if not camera_name:
            return JSONResponse(
                {"ok": False, "message": "Camera name is required"},
                status_code=400,
            )

        if source_type == "rtsp" and not payload.rtsp_url:
            return JSONResponse(
                {"ok": False, "message": "RTSP URL is required"},
                status_code=400,
            )

        if source_type == "webcam" and payload.webcam_index is None:
            return JSONResponse(
                {"ok": False, "message": "Webcam index is required"},
                status_code=400,
            )

        if source_type == "usb" and payload.usb_index is None:
            return JSONResponse(
                {"ok": False, "message": "USB camera index is required"},
                status_code=400,
            )

        camera.camera_name = camera_name
        camera.source_type = source_type
        camera.rtsp_url = payload.rtsp_url if source_type == "rtsp" else None
        camera.webcam_index = payload.webcam_index if source_type == "webcam" else None
        camera.usb_index = payload.usb_index if source_type == "usb" else None
        camera.group_id = payload.group_id
        camera.location = payload.location

        db.commit()
        db.refresh(camera)

        return JSONResponse({
            "ok": True,
            "message": "Camera updated successfully",
            "data": serialize_camera(camera),
        })

    finally:
        db.close()


@app.get("/api/cameras/{camera_id}/stream")
async def stream_camera(camera_id: int):
    db = get_db_session()

    try:
        camera = get_camera_by_id_service(db, camera_id)

        if not camera:
            return JSONResponse(
                {"ok": False, "message": "Camera not found"},
                status_code=404,
            )

        try:
            stream_generator = generate_camera_stream_service(camera)

        except Exception as error:
            print(
                f"[ERROR] Could not create normal stream for "
                f"camera {camera_id}: {error}"
            )

            return JSONResponse(
                {
                    "ok": False,
                    "message": "Could not start camera stream",
                },
                status_code=503,
            )

        return StreamingResponse(
            stream_generator,
            media_type="multipart/x-mixed-replace; boundary=frame",
            headers={
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0",
                "X-Accel-Buffering": "no",
                "Connection": "keep-alive",
            },
        )

    finally:
        db.close()


@app.get("/api/cameras/{camera_id}/snapshot.jpg")
async def camera_snapshot(
    camera_id: int,
    token: str = Query(..., description="Access token (<img> cannot send headers)"),
):
    """
    One fresh JPEG from the shared camera worker. The Ops Board shows this
    for camera tiles when viewed from outside the plant network: a picture
    every few seconds per camera instead of a full video stream per viewer.
    Token goes in the query string because <img> cannot send headers. The
    database session is closed before the (up to 3 s) wait for a frame so
    it never sits checked out of the pool.
    """
    def _load():
        db = get_db_session()
        try:
            user_from_access_token(token, db)
            return get_camera_by_id_service(db, camera_id)
        finally:
            db.close()

    camera = await run_in_threadpool(_load)

    if not camera:
        return JSONResponse(
            {"ok": False, "message": "Camera not found"},
            status_code=404,
        )

    # The worker only encodes JPEGs while a video stream is subscribed (to
    # save CPU), so take the latest raw frame - always kept while the camera
    # is running - and encode one picture for this request.
    def _grab():
        worker = get_shared_camera_worker(camera)
        frame = worker.wait_for_frame(timeout=3.0)

        if frame is None:
            return None

        ok, buffer = cv2.imencode(
            ".jpg",
            frame,
            [int(cv2.IMWRITE_JPEG_QUALITY), 70],
        )

        return buffer.tobytes() if ok else None

    try:
        jpeg = await run_in_threadpool(_grab)

    except Exception as error:
        print(f"[WARN] Snapshot failed for camera {camera_id}: {error}")
        jpeg = None

    if not jpeg:
        return JSONResponse(
            {"ok": False, "message": "No picture available"},
            status_code=503,
        )

    return Response(
        content=bytes(jpeg),
        media_type="image/jpeg",
        headers={"Cache-Control": "no-store"},
    )


@app.get("/api/cameras/{camera_id}/detection-stream")
async def detection_stream_camera(
    camera_id: int,
    ppe_filter: str = "all",
    frame_id=1,
):
    db = get_db_session()

    try:
        camera = get_camera_by_id_service(db, camera_id)

        if not camera:
            return JSONResponse(
                {"ok": False, "message": "Camera not found"},
                status_code=404,
            )

        try:
            stream_generator = generate_detection_stream_service(
                camera,
                ppe_filter=ppe_filter,
                frame_id=frame_id,
            )

        except Exception as error:
            print(
                f"[ERROR] Could not create detection stream for "
                f"camera {camera_id}: {error}"
            )

            return JSONResponse(
                {
                    "ok": False,
                    "message": "Could not start detection stream",
                },
                status_code=503,
            )

        return StreamingResponse(
            stream_generator,
            media_type="multipart/x-mixed-replace; boundary=frame",
            headers={
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0",
                "X-Accel-Buffering": "no",
                "Connection": "keep-alive",
            },
        )

    finally:
        db.close()


# =========================================================
# Per-frame object/face detection control
# Camera stream remains open and real-time when detection is stopped.
# =========================================================
@app.post("/api/cameras/{camera_id}/frames/{frame_id}/detection/start", dependencies=[Depends(get_current_user)])
async def start_frame_detection(camera_id: int, frame_id: str):
    db = get_db_session()

    try:
        camera = get_camera_by_id_service(db, camera_id)

        if not camera:
            return JSONResponse(
                {"ok": False, "message": "Camera not found"},
                status_code=404,
            )

        state = set_frame_detection_enabled(
            camera_id=camera_id,
            frame_id=frame_id,
            enabled=True,
        )

        return JSONResponse(
            {
                "ok": True,
                "message": "Object detection and face recognition started",
                "data": state,
            }
        )

    finally:
        db.close()


@app.post("/api/cameras/{camera_id}/frames/{frame_id}/detection/stop", dependencies=[Depends(get_current_user)])
async def stop_frame_detection(camera_id: int, frame_id: str):
    db = get_db_session()

    try:
        camera = get_camera_by_id_service(db, camera_id)

        if not camera:
            return JSONResponse(
                {"ok": False, "message": "Camera not found"},
                status_code=404,
            )

        state = set_frame_detection_enabled(
            camera_id=camera_id,
            frame_id=frame_id,
            enabled=False,
        )

        return JSONResponse(
            {
                "ok": True,
                "message": (
                    "Object detection and face recognition stopped; "
                    "camera stream remains live"
                ),
                "data": state,
            }
        )

    finally:
        db.close()


@app.get("/api/cameras/{camera_id}/frames/{frame_id}/detection/status", dependencies=[Depends(get_current_user)])
async def frame_detection_status(camera_id: int, frame_id: str):
    return JSONResponse(
        {
            "ok": True,
            "data": get_frame_detection_status(camera_id, frame_id),
        }
    )


# =========================================================
# Detection stats for frontend camera cards
# =========================================================
@app.get("/api/cameras/{camera_id}/detection-stats", dependencies=[Depends(get_current_user)])
async def detection_stats_camera(camera_id: int):
    return JSONResponse(
        {
            "ok": True,
            "data": get_detection_stats(camera_id),
        }
    )


# =========================================================
# Per-camera recording APIs
# =========================================================
@app.post("/api/cameras/{camera_id}/recording/start", dependencies=[Depends(get_current_user)])
async def start_recording_camera(camera_id: int):
    db = get_db_session()

    try:
        camera = get_camera_by_id_service(db, camera_id)

        if not camera:
            return JSONResponse(
                {"ok": False, "message": "Camera not found"},
                status_code=404,
            )

        result = start_camera_recording(camera)

        if not result["success"]:
            return JSONResponse(
                {"ok": False, "message": result["message"]},
                status_code=result["status_code"],
            )

        return JSONResponse(
            {
                "ok": True,
                "message": result["message"],
                "data": get_detection_stats(camera_id),
            }
        )

    finally:
        db.close()


@app.post("/api/cameras/{camera_id}/recording/stop", dependencies=[Depends(get_current_user)])
async def stop_recording_camera(camera_id: int):
    result = stop_camera_recording(camera_id)

    if not result["success"]:
        return JSONResponse(
            {"ok": False, "message": result["message"]},
            status_code=result["status_code"],
        )

    return JSONResponse(
        {
            "ok": True,
            "message": result["message"],
            "download_url": result["download_url"],
            "data": get_detection_stats(camera_id),
        }
    )


# =========================================================
# Face Enrollment Recognition APIs
# =========================================================
@app.post("/api/face-enrollment/{camera_id}/recognition/start", dependencies=[Depends(get_current_user)])
async def start_face_recognition(camera_id: int):
    db = get_db_session()

    try:
        camera = get_camera_by_id_service(db, camera_id)

        if not camera:
            return JSONResponse(
                {"ok": False, "message": "Camera not found"},
                status_code=404,
            )

        result = start_face_recognition_service(camera, camera_id)

        return JSONResponse(
            {
                "ok": True,
                "message": result["message"],
                "data": result["data"],
            }
        )

    finally:
        db.close()


@app.post("/api/face-enrollment/{camera_id}/recognition/stop", dependencies=[Depends(get_current_user)])
async def stop_face_recognition(camera_id: int):
    result = stop_face_recognition_service(camera_id)

    return JSONResponse(
        {
            "ok": True,
            "message": result["message"],
            "data": result["data"],
        }
    )


@app.get("/api/face-enrollment/{camera_id}/recognition-stream")
async def face_recognition_stream(camera_id: int):
    db = get_db_session()

    try:
        camera = get_camera_by_id_service(db, camera_id)

        if not camera:
            return JSONResponse(
                {"ok": False, "message": "Camera not found"},
                status_code=404,
            )

        start_face_recognition_service(camera, camera_id)

        return StreamingResponse(
            generate_face_recognition_stream_service(camera, camera_id),
            media_type="multipart/x-mixed-replace; boundary=frame",
        )

    finally:
        db.close()

@app.get("/api/face-enrollment/{camera_id}/recognition/status", dependencies=[Depends(get_current_user)])
async def face_recognition_status(camera_id: int):
    result = get_face_recognition_status_service(camera_id)

    return JSONResponse(
        {
            "ok": True,
            "message": result["message"],
            "data": result["data"],
        }
    )

# =========================================================
# Face Enrollment - Capture from selected camera
# =========================================================
@app.post("/api/face-enrollment/{camera_id}/capture", dependencies=[Depends(get_current_user)])
async def capture_face(camera_id: int):
    db = get_db_session()

    try:
        camera = get_camera_by_id_service(db, camera_id)

        if not camera:
            return JSONResponse(
                {"ok": False, "message": "Camera not found"},
                status_code=404,
            )

        result = capture_face_service(camera, camera_id)

        if not result.get("success"):
            return JSONResponse(
                {
                    "ok": False,
                    "message": result.get("message", "Face capture rejected"),
                    "data": result.get("data"),
                    "detail": result,
                },
                status_code=200,
            )

        return JSONResponse(
            {
                "ok": True,
                "message": result["message"],
                "data": result["data"],
            }
        )
    finally:
        db.close()


# =========================================================
# Face Enrollment - Import multiple face images
# =========================================================
@app.post("/api/face-enrollment/import", dependencies=[Depends(get_current_user)])
async def import_faces(files: List[UploadFile] = File(...)):
    result = await import_faces_service(files)

    if not result["success"]:
        return JSONResponse(
            {
                "ok": False,
                "message": result["message"],
                "data": result.get("data"),
            },
            status_code=400,
        )

    return JSONResponse(
        {
            "ok": True,
            "message": result["message"],
            "data": result["data"],
        }
    )

@app.get("/api/departments", dependencies=[Depends(get_current_user)])
async def get_departments():
    db = get_db_session()

    try:
        data = get_departments_service(db)
        return JSONResponse({"ok": True, "data": data})

    finally:
        db.close()


@app.post("/api/departments", dependencies=[Depends(get_current_user)])
async def create_department(payload: MasterNameRequest):
    name = payload.name.strip()

    if not name:
        return JSONResponse({"ok": False, "message": "Department name is required"}, status_code=400)

    db = get_db_session()

    try:
        result = create_department_service(db=db, name=name)

        if not result["success"]:
            return JSONResponse({"ok": False, "message": result["message"]}, status_code=result["status_code"])

        return JSONResponse({"ok": True, "message": "Department added successfully", "data": result["data"]})

    finally:
        db.close()


@app.delete("/api/departments/{department_id}", dependencies=[Depends(get_current_user)])
async def delete_department(department_id: int):
    db = get_db_session()

    try:
        result = delete_department_service(db=db, department_id=department_id)

        if not result["success"]:
            return JSONResponse({"ok": False, "message": result["message"]}, status_code=result["status_code"])

        return JSONResponse({"ok": True, "message": result["message"]})

    finally:
        db.close()


@app.get("/api/roles", dependencies=[Depends(get_current_user)])
async def get_roles():
    db = get_db_session()

    try:
        data = get_roles_service(db)
        return JSONResponse({"ok": True, "data": data})

    finally:
        db.close()


@app.post("/api/roles", dependencies=[Depends(get_current_user)])
async def create_role(payload: MasterNameRequest):
    name = payload.name.strip()

    if not name:
        return JSONResponse({"ok": False, "message": "Role name is required"}, status_code=400)

    db = get_db_session()

    try:
        result = create_role_service(db=db, name=name)

        if not result["success"]:
            return JSONResponse({"ok": False, "message": result["message"]}, status_code=result["status_code"])

        return JSONResponse({"ok": True, "message": "Role added successfully", "data": result["data"]})

    finally:
        db.close()


@app.delete("/api/roles/{role_id}", dependencies=[Depends(get_current_user)])
async def delete_role(role_id: int):
    db = get_db_session()

    try:
        result = delete_role_service(db=db, role_id=role_id)

        if not result["success"]:
            return JSONResponse({"ok": False, "message": result["message"]}, status_code=result["status_code"])

        return JSONResponse({"ok": True, "message": result["message"]})

    finally:
        db.close()


@app.post("/api/face-enrollment/enroll", dependencies=[Depends(get_current_user)])
async def enroll_person(payload: FaceEnrollRequest):
    db = get_db_session()

    try:
        payload_data = (
            payload.model_dump()
            if hasattr(payload, "model_dump")
            else payload.dict()
        )

        result = enroll_person_service(
            db=db,
            payload=payload_data,
        )

        # Enrollment validation / duplicate error
        if not result.get("success"):
            response_data = {
                "ok": False,
                "message": result.get(
                    "message",
                    "Enrollment failed",
                ),
            }

            # Send exact field name to frontend.
            # Example:
            # employeeId -> Employee ID already enrolled
            # fullName   -> Full name is required
            # department -> Department is required
            # role       -> Role / Access is required
            # images     -> Face image validation error
            if result.get("field"):
                response_data["field"] = result["field"]

            return JSONResponse(
                response_data,
                status_code=result.get(
                    "status_code",
                    400,
                ),
            )

        # Successful enrollment
        return JSONResponse(
            {
                "ok": True,
                "message": result.get(
                    "message",
                    "Person enrolled successfully",
                ),
                "data": result.get("data"),
            }
        )

    except Exception as error:
        db.rollback()

        print(
            f"[ERROR] Face enrollment failed: {error}"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": (
                    "Face enrollment failed due to server error"
                ),
            },
            status_code=500,
        )

    finally:
        db.close()


# =========================================================
# Face Enrollment - Recent enrollment logs
# =========================================================
@app.get("/api/face-enrollment/logs", dependencies=[Depends(get_current_user)])
async def get_face_enrollment_logs(limit: int = 50):
    # Protect the API from accidentally requesting a huge result set.
    limit = max(1, min(limit, 200))

    db = get_db_session()

    try:
        data = get_recent_enrollment_logs_service(db=db, limit=limit)

        return JSONResponse(
            {
                "ok": True,
                "count": len(data),
                "data": data,
            }
        )

    except Exception as error:
        print(f"[ERROR] Could not load face enrollment logs: {error}")
        return JSONResponse(
            {
                "ok": False,
                "message": "Could not load recent enrollment logs",
                "data": [],
            },
            status_code=500,
        )

    finally:
        db.close()


# =========================================================
# Face Enrollment - Serve saved Primary Face Template
# =========================================================
@app.get("/api/face-enrollment/persons/{person_id}/face", dependencies=[Depends(get_current_user)])
async def get_enrolled_person_face(person_id: int):
    db = get_db_session()

    try:
        person = (
            db.query(FaceEnrollmentPerson)
            .filter(FaceEnrollmentPerson.id == person_id)
            .first()
        )

        if not person:
            return JSONResponse(
                {"ok": False, "message": "Enrolled person not found"},
                status_code=404,
            )

        if not person.primary_face_path:
            return JSONResponse(
                {"ok": False, "message": "Primary face image not available"},
                status_code=404,
            )

        face_path = Path(person.primary_face_path)

        if not face_path.exists() or not face_path.is_file():
            return JSONResponse(
                {"ok": False, "message": "Primary face image file not found"},
                status_code=404,
            )

        return FileResponse(
            path=str(face_path),
            media_type="image/jpeg",
            filename=face_path.name,
            content_disposition_type="inline",
        )

    finally:
        db.close()


# =========================================================
# Email alert control APIs
# =========================================================
@app.get("/api/email-alerts/status", dependencies=[Depends(get_current_user)])
async def get_email_alert_status():
    result = get_email_alert_status_service()

    return JSONResponse(
        {
            "ok": True,
            "enabled": result["enabled"],
            "frequency_minutes": result["frequency_minutes"],
        }
    )


@app.put("/api/email-alerts/status", dependencies=[Depends(get_current_user)])
async def update_email_alert_status(
    payload: EmailAlertStatusRequest,
):
    result = update_email_alert_status_service(
        enabled=payload.enabled,
        frequency_minutes=payload.frequency_minutes,
    )

    return JSONResponse(
        {
            "ok": True,
            "enabled": result["enabled"],
            "frequency_minutes": result["frequency_minutes"],
            "message": result["message"],
        }
    )


@app.get("/api/email-alerts/active-violations", dependencies=[Depends(get_current_user)])
async def get_active_email_violations():
    result = get_active_email_violations_service()

    return JSONResponse(
        {
            "ok": True,
            "count": result["count"],
            "data": result["data"],
        }
    )


@app.get("/api/email-alerts/worker-status", dependencies=[Depends(get_current_user)])
async def get_email_worker_status():
    result = get_email_worker_status_service()

    return JSONResponse(
        {
            "ok": True,
            "data": {
                "running": result["running"],
                "queueSize": result["queueSize"],
                "alertsEnabled": result["alertsEnabled"],
                "frequencyMinutes": result["frequencyMinutes"],
                "initialDelaySeconds": result["initialDelaySeconds"],
                "activeViolations": result["activeViolations"],
            },
        }
    )

@app.get("/api/email-alerts/latest-sent", dependencies=[Depends(get_current_user)])
async def get_latest_email_sent_notification():
    result = get_latest_email_sent_notification_service()

    return JSONResponse(
        {
            "ok": True,
            "data": result["data"],
        }
    )


@app.get("/api/email-recipients", dependencies=[Depends(get_current_user)])
async def get_email_recipients():
    db = get_db_session()

    try:
        data = get_email_recipients_service(db)
        return JSONResponse({"ok": True, "data": data})

    finally:
        db.close()


@app.post("/api/email-recipients", dependencies=[Depends(get_current_user)])
async def create_email_recipient(payload: EmailRecipientRequest):
    db = get_db_session()

    try:
        result = create_email_recipient_service(
            db=db,
            email=str(payload.email).strip().lower(),
            name=payload.name.strip(),
            position=payload.position.strip(),
            alert_type=payload.alertType.strip(),
            status=payload.status.strip(),
        )

        if not result["success"]:
            return JSONResponse(
                {"ok": False, "message": result["message"]},
                status_code=result["status_code"],
            )

        return JSONResponse(
            {
                "ok": True,
                "message": "Email recipient added successfully",
                "data": result["data"],
            }
        )

    finally:
        db.close()

@app.put("/api/email-recipients/{recipient_id}", dependencies=[Depends(get_current_user)])
async def update_email_recipient(recipient_id: int, payload: EmailRecipientRequest):
    db = get_db_session()

    try:
        result = update_email_recipient_service(
            db=db,
            recipient_id=recipient_id,
            email=str(payload.email).strip().lower(),
            name=payload.name.strip(),
            position=payload.position.strip(),
            alert_type=payload.alertType.strip(),
            status=payload.status.strip(),
        )

        if not result["success"]:
            return JSONResponse(
                {"ok": False, "message": result["message"]},
                status_code=result["status_code"],
            )

        return JSONResponse(
            {
                "ok": True,
                "message": "Email recipient updated successfully",
                "data": result["data"],
            }
        )

    finally:
        db.close()

@app.delete("/api/email-recipients/{recipient_id}", dependencies=[Depends(get_current_user)])
async def delete_email_recipient(recipient_id: int):
    db = get_db_session()

    try:
        result = delete_email_recipient_service(
            db=db,
            recipient_id=recipient_id,
        )

        if not result["success"]:
            return JSONResponse(
                {"ok": False, "message": result["message"]},
                status_code=result["status_code"],
            )

        return JSONResponse(
            {
                "ok": True,
                "message": result["message"],
            }
        )

    finally:
        db.close()


@app.post("/api/email-recipients/{recipient_id}/test", dependencies=[Depends(get_current_user)])
async def send_test_email_recipient(recipient_id: int):
    db = get_db_session()

    try:
        result = send_test_email_recipient_service(
            db=db,
            recipient_id=recipient_id,
        )

        if not result["success"]:
            return JSONResponse(
                {"ok": False, "message": result["message"]},
                status_code=result["status_code"],
            )

        return JSONResponse(
            {
                "ok": True,
                "message": result["message"],
            }
        )

    finally:
        db.close()

@app.get("/api/live-events", dependencies=[Depends(get_current_user)])
async def get_live_events():
    """
    The Live Events table now reads from the episode engine (one row per
    episode, every kind), so it shows the same things as the Ops Board.
    The legacy live_events table is still written for the e-mail alerts.
    """
    try:
        data = await run_in_threadpool(episodes.as_live_event_rows, limit=100)
        return JSONResponse({"ok": True, "data": data})

    except Exception as error:
        print("Live events error:", error)
        return JSONResponse({"ok": False, "message": "Could not load live events", "data": []}, status_code=500)


@app.get("/api/live-events/export", dependencies=[Depends(get_current_user)])
async def export_live_events(
    start_time: datetime,
    end_time: datetime,
    camera_id: Optional[int] = None,
):
    """
    Return all live events inside the selected date/time range.

    Example:
    /api/live-events/export
        ?start_time=2026-07-17T08:00:00
        &end_time=2026-07-17T12:00:00
    """

    if start_time > end_time:
        return JSONResponse(
            {
                "ok": False,
                "message": "Start time must be before end time",
                "data": [],
            },
            status_code=400,
        )

    try:
        data = await run_in_threadpool(
            episodes.as_live_event_rows,
            limit=None,
            since=start_time,
            until=end_time,
            camera_id=camera_id,
        )

        return JSONResponse(
            {
                "ok": True,
                "message": f"{len(data)} event(s) found",
                "count": len(data),
                "data": data,
            }
        )

    except Exception as error:
        print("Live events export error:", error)

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not load historical live events",
                "data": [],
            },
            status_code=500,
        )

@app.get("/api/face-enrollment/recognition-performance", dependencies=[Depends(get_current_user)])
async def get_recognition_performance():
    db = get_db_session()

    try:
        recognized = (
            db.query(FaceRecognitionEvent)
            .filter(
                FaceRecognitionEvent.event_type == "recognized",
                func.date(FaceRecognitionEvent.created_at) == func.current_date(),
            )
            .count()
        )

        unknown = (
            db.query(FaceRecognitionEvent)
            .filter(
                FaceRecognitionEvent.event_type == "unknown",
                func.date(FaceRecognitionEvent.created_at) == func.current_date(),
            )
            .count()
        )

        failed = (
            db.query(FaceRecognitionEvent)
            .filter(
                FaceRecognitionEvent.event_type == "failed_match",
                func.date(FaceRecognitionEvent.created_at) == func.current_date(),
            )
            .count()
        )

        total = recognized + unknown + failed

        recognition_rate = (
            round((recognized / total) * 100, 1)
            if total > 0
            else 0
        )

        return JSONResponse({
            "ok": True,
            "data": {
                "recognitionRate": recognition_rate,
                "recognizedFaces": recognized,
                "unknownDetections": unknown,
                "failedMatches": failed,
            },
        })

    except Exception as error:
        print(f"[ERROR] Recognition performance: {error}")

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not load recognition performance",
            },
            status_code=500,
        )

    finally:
        db.close()


@app.get(
    "/api/face-enrollment/alerts",
    dependencies=[Depends(get_current_user)],
)
async def get_face_enrollment_alerts(limit: int = 20):
    db = get_db_session()

    try:
        limit = max(1, min(limit, 100))

        persons = (
            db.query(FaceEnrollmentPerson)
            .order_by(
                FaceEnrollmentPerson.created_at.desc(),
                FaceEnrollmentPerson.id.desc(),
            )
            .limit(limit)
            .all()
        )

        data = []

        for person in persons:
            data.append(
                {
                    "id": person.id,
                    "type": "new_enrollment",
                    "personName": person.full_name,
                    "employeeId": person.employee_id,
                    "cameraName": person.camera_name,
                    "qualityScore": (
                        person.primary_quality_score or 0
                    ),
                    "similarityScore": None,
                    "reason": "Person enrolled successfully",
                    "createdAt": (
                        person.created_at.isoformat()
                        if person.created_at
                        else None
                    ),
                }
            )

        return JSONResponse(
            {
                "ok": True,
                "count": len(data),
                "data": data,
            }
        )

    except Exception as error:
        logger.exception(
            "Face enrollment alerts load failed"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not load face enrollment alerts",
                "data": [],
            },
            status_code=500,
        )

    finally:
        db.close()

# =========================================================
# USER MANAGEMENT APIs
# =========================================================

@app.get("/api/users", dependencies=[Depends(require_super_admin)])
async def get_users():
    db = get_db_session()
    try:
        return JSONResponse({"ok": True, "data": get_users_service(db)})
    finally:
        db.close()


@app.get("/api/users/stats", dependencies=[Depends(require_super_admin)])
async def get_user_stats():
    db = get_db_session()
    try:
        return JSONResponse({"ok": True, "data": get_user_stats_service(db)})
    finally:
        db.close()


@app.post("/api/users", dependencies=[Depends(require_super_admin)])
async def create_user(payload: UserCreateRequest):
    db = get_db_session()

    try:
        result = create_user_service(
            db=db,
            email=str(payload.email),
            employee_id=payload.employeeId,
            full_name=payload.fullName,
            mobile=payload.mobile,
            department=payload.department,
            password=payload.password,
        )

        if not result["success"]:
            return JSONResponse({"ok": False, "message": result["message"]}, status_code=result["status_code"])

        email_result = send_new_user_welcome_email_service(
            email=str(payload.email).strip().lower(),
            full_name=payload.fullName.strip().title(),
            password=payload.password,
        )

        message = "User created and welcome email sent successfully" if email_result["success"] else "User created successfully, but welcome email could not be sent"

        return JSONResponse(
            {
                "ok": True,
                "message": message,
                "data": result["data"],
                "emailSent": email_result["success"],
                "emailMessage": email_result["message"],
            },
            status_code=201,
        )

    finally:
        db.close()

@app.put("/api/users/{email}", dependencies=[Depends(require_super_admin)])
async def update_user(email: str, payload: UserUpdateRequest):
    db = get_db_session()

    try:
        result = update_user_service(
            db=db,
            email=email,
            employee_id=payload.employeeId,
            full_name=payload.fullName,
            mobile=payload.mobile,
            department=payload.department,
            password=payload.password,
        )

        if not result["success"]:
            return JSONResponse(
                {"ok": False, "message": result["message"]},
                status_code=result["status_code"],
            )

        return JSONResponse(
            {
                "ok": True,
                "message": result["message"],
                "data": result["data"],
            }
        )
    finally:
        db.close()


@app.patch("/api/users/{email}/status")
async def update_user_status(email: str, payload: UserStatusRequest):
    db = get_db_session()

    try:
        result = update_user_status_service(
            db=db,
            email=email,
            is_active=payload.is_active,
        )

        if not result["success"]:
            return JSONResponse(
                {"ok": False, "message": result["message"]},
                status_code=result["status_code"],
            )

        return JSONResponse(
            {
                "ok": True,
                "message": result["message"],
                "data": result["data"],
            }
        )
    finally:
        db.close()


@app.delete("/api/users/{email}", dependencies=[Depends(require_super_admin)])
async def delete_user(email: str):
    db = get_db_session()

    try:
        result = delete_user_service(db=db, email=email)

        if not result["success"]:
            return JSONResponse(
                {"ok": False, "message": result["message"]},
                status_code=result["status_code"],
            )

        return JSONResponse(
            {
                "ok": True,
                "message": result["message"],
            }
        )
    finally:
        db.close()
        
        # ---------------------------------------------------------------
# Prevent caching of API responses.
#
# nginx was storing /api/ responses and serving stale copies. The
# stored copy was made from a non-browser request, so it carried no
# CORS headers - the dashboard then discarded every response and
# showed an empty screen. Telling caches not to store these replies
# fixes both the stale data and the blank dashboard.
# ---------------------------------------------------------------
@app.middleware("http")
async def no_store_on_api(request, call_next):
    response = await call_next(request)

    if request.url.path.startswith("/api/"):
        response.headers["Cache-Control"] = (
            "no-store, no-cache, must-revalidate, max-age=0"
        )
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"

    return response

# =========================================================
# Counting Management APIs
# =========================================================

@app.get(
    "/api/counting/settings",
    dependencies=[Depends(get_current_user)],
)
async def get_counting_settings_api():
    try:
        data = await run_in_threadpool(
            get_counting_setting
        )

        return JSONResponse({
            "ok": True,
            "data": data,
        })

    except Exception as error:
        print(
            f"[ERROR] Counting settings: {error}"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not load counting settings",
            },
            status_code=500,
        )

@app.put(
    "/api/counting/settings",
    dependencies=[Depends(get_current_user)],
)
async def update_counting_settings_api(
    payload: CountingIntervalRequest,
):
    try:
        data = await run_in_threadpool(
            update_counting_setting,
            payload.interval_minutes,
        )

        return JSONResponse({
            "ok": True,
            "message": "Counting interval updated successfully",
            "data": data,
        })

    except ValueError as error:
        return JSONResponse(
            {
                "ok": False,
                "message": str(error),
            },
            status_code=400,
        )

    except Exception as error:
        print(
            f"[ERROR] Update counting settings: {error}"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not update counting interval",
            },
            status_code=500,
        )

@app.get(
    "/api/counting/summaries",
    dependencies=[Depends(get_current_user)],
)
async def get_counting_summaries_api(
    limit: int = Query(100, ge=1, le=500),
    camera_id: Optional[int] = Query(None),
):
    try:
        data = await run_in_threadpool(
            get_counting_summaries,
            limit,
            camera_id,
        )

        return JSONResponse({
            "ok": True,
            "count": len(data),
            "data": data,
        })

    except Exception as error:
        print(
            f"[ERROR] Counting summaries: {error}"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not load counting history",
                "data": [],
            },
            status_code=500,
        )

@app.get(
    "/api/counting/live/{camera_id}",
    dependencies=[Depends(get_current_user)],
)
async def get_camera_live_count_api(
    camera_id: int,
):
    try:
        data = await run_in_threadpool(
            get_live_count,
            camera_id,
        )

        return JSONResponse({
            "ok": True,
            "data": data,
        })

    except Exception as error:
        print(
            f"[ERROR] Live count camera {camera_id}: {error}"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not load live count",
            },
            status_code=500,
        )

@app.get(
    "/api/counting/live",
    dependencies=[Depends(get_current_user)],
)
async def get_all_live_counts_api():
    try:
        data = await run_in_threadpool(
            get_all_live_counts
        )

        return JSONResponse({
            "ok": True,
            "count": len(data),
            "data": data,
        })

    except Exception as error:
        print(
            f"[ERROR] Counting live counts: {error}"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not load live counts",
                "data": [],
            },
            status_code=500,
        )


@app.post(
    "/api/counting/email/test",
    dependencies=[Depends(get_current_user)],
)
async def send_counting_test_email_api():
    try:
        result = await run_in_threadpool(
            send_counting_test_email_service
        )

        if not result.get("success"):
            return JSONResponse(
                {
                    "ok": False,
                    "message": result.get(
                        "message",
                        "Counting test email could not be sent",
                    ),
                },
                status_code=result.get(
                    "status_code",
                    500,
                ),
            )

        return JSONResponse({
            "ok": True,
            "message": result.get(
                "message",
                "Counting test email sent successfully",
            ),
            "recipient_count": result.get(
                "recipient_count",
                0,
            ),
        })

    except Exception as error:
        print(
            f"[ERROR] Counting test email: {error}"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": (
                    "Counting test email could not be sent"
                ),
            },
            status_code=500,
        )


@app.post(
    "/api/counting/monitoring/start",
    dependencies=[
        Depends(get_current_user)
    ],
)
async def start_counting_monitoring_api(
    payload: CountingMonitoringRequest,
):
    try:
        if not payload.camera_ids:
            return JSONResponse(
                {
                    "ok": False,
                    "message": (
                        "Select at least one camera"
                    ),
                },
                status_code=400,
            )

        data = await run_in_threadpool(
            start_counting_monitoring,
            payload.camera_ids,
        )

        return JSONResponse(
            {
                "ok": True,
                "message": (
                    "Counting monitoring started"
                ),
                "data": data,
            }
        )

    except ValueError as error:
        # Examples:
        # - camera not found
        # - camera inactive
        # - no counting line configured
        return JSONResponse(
            {
                "ok": False,
                "message": str(error),
            },
            status_code=400,
        )

    except Exception as error:
        print(
            "[ERROR] Start counting monitoring: "
            f"{error}"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": (
                    "Could not start counting monitoring"
                ),
            },
            status_code=500,
        )

@app.post(
    "/api/counting/monitoring/stop",
    dependencies=[Depends(get_current_user)],
)
async def stop_counting_monitoring_api(
    payload: CountingMonitoringRequest,
):
    try:
        data = await run_in_threadpool(
            stop_counting_monitoring,
            payload.camera_ids,
        )

        return JSONResponse({
            "ok": True,
            "message": "Counting monitoring stopped",
            "data": data,
        })

    except Exception as error:
        print(
            f"[ERROR] Stop counting monitoring: {error}"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not stop counting monitoring",
            },
            status_code=500,
        )


@app.get(
    "/api/counting/monitoring/status",
    dependencies=[Depends(get_current_user)],
)
async def get_counting_monitoring_status_api():
    try:
        data = await run_in_threadpool(
            get_counting_monitoring_status
        )

        return JSONResponse({
            "ok": True,
            "data": data,
        })

    except Exception as error:
        print(
            f"[ERROR] Counting monitoring status: {error}"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not load counting monitoring status",
            },
            status_code=500,
        )


@app.get(
    "/api/cameras/{camera_id}/counting-stream"
)
async def counting_stream_camera(
    camera_id: int,
    token: str = Query(
        ...,
        description="JWT access token",
    ),
):
    db = get_db_session()

    try:
        user_from_access_token(
            token,
            db,
        )

        camera = get_camera_by_id_service(
            db,
            camera_id,
        )

        if not camera:
            return JSONResponse(
                {
                    "ok": False,
                    "message": "Camera not found",
                },
                status_code=404,
            )

    finally:
        db.close()

    try:
        stream_generator = (
            generate_counting_stream(
                camera_id
            )
        )

        return StreamingResponse(
            stream_generator,
            media_type=(
                "multipart/x-mixed-replace; "
                "boundary=frame"
            ),
            headers={
                "Cache-Control": (
                    "no-cache, no-store, "
                    "must-revalidate"
                ),
                "Pragma": "no-cache",
                "Expires": "0",
                "X-Accel-Buffering": "no",
                "Connection": "keep-alive",
            },
        )

    except Exception as error:
        print(
            "[ERROR] Counting stream camera "
            f"{camera_id}: {error}"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": (
                    "Could not start counting stream"
                ),
            },
            status_code=503,
        )


# =========================================================
# Counting Lines APIs
# =========================================================


@app.get(
    "/api/counting-lines",
    dependencies=[
        Depends(get_current_user)
    ],
)
async def get_counting_lines_api(
    camera_id: Optional[int] = Query(
        None,
        ge=1,
    ),
):
    """
    Get active counting lines.

    If camera_id is supplied:
        return lines for that camera only.

    JWT authentication:
        Authorization: Bearer <access_token>
    """

    try:
        data = await run_in_threadpool(
            get_counting_lines,
            camera_id,
        )

        return JSONResponse(
            {
                "ok": True,
                "count": len(data),
                "data": data,
            }
        )

    except Exception as error:
        print(
            "[ERROR] Get counting lines: "
            f"{error}"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": (
                    "Could not load counting lines"
                ),
                "data": [],
            },
            status_code=500,
        )


@app.post(
    "/api/counting-lines",
    dependencies=[
        Depends(get_current_user)
    ],
)
async def create_counting_line_api(
    payload: CountingLineRequest,
):
    """
    Create one counting line.

    Protected by JWT.
    """

    try:
        payload_data = (
            payload.model_dump()
            if hasattr(
                payload,
                "model_dump",
            )
            else payload.dict()
        )

        data = await run_in_threadpool(
            create_counting_line,
            payload_data,
        )

        return JSONResponse(
            {
                "ok": True,
                "message": (
                    "Counting line created successfully"
                ),
                "data": data,
            },
            status_code=201,
        )

    except ValueError as error:
        return JSONResponse(
            {
                "ok": False,
                "message": str(error),
            },
            status_code=400,
        )

    except Exception as error:
        print(
            "[ERROR] Create counting line: "
            f"{error}"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": (
                    "Could not create counting line"
                ),
            },
            status_code=500,
        )


@app.put(
    "/api/counting-lines/{line_id}",
    dependencies=[
        Depends(get_current_user)
    ],
)
async def update_counting_line_api(
    line_id: int,
    payload: CountingLineRequest,
):
    """
    Update an existing counting line.

    Protected by JWT.
    """

    try:
        payload_data = (
            payload.model_dump()
            if hasattr(
                payload,
                "model_dump",
            )
            else payload.dict()
        )

        data = await run_in_threadpool(
            update_counting_line,
            line_id,
            payload_data,
        )

        return JSONResponse(
            {
                "ok": True,
                "message": (
                    "Counting line updated successfully"
                ),
                "data": data,
            }
        )

    except ValueError as error:
        message = str(error)

        status_code = (
            404
            if "not found" in message.lower()
            else 400
        )

        return JSONResponse(
            {
                "ok": False,
                "message": message,
            },
            status_code=status_code,
        )

    except Exception as error:
        print(
            "[ERROR] Update counting line "
            f"{line_id}: {error}"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": (
                    "Could not update counting line"
                ),
            },
            status_code=500,
        )


@app.delete(
    "/api/counting-lines/{line_id}",
    dependencies=[
        Depends(get_current_user)
    ],
)
async def delete_counting_line_api(
    line_id: int,
):
    """
    Soft-delete a counting line.

    Protected by JWT.
    """

    try:
        data = await run_in_threadpool(
            delete_counting_line,
            line_id,
        )

        return JSONResponse(
            {
                "ok": True,
                "message": (
                    "Counting line deleted successfully"
                ),
                "data": data,
            }
        )

    except ValueError as error:
        message = str(error)

        status_code = (
            404
            if "not found" in message.lower()
            else 400
        )

        return JSONResponse(
            {
                "ok": False,
                "message": message,
            },
            status_code=status_code,
        )

    except Exception as error:
        print(
            "[ERROR] Delete counting line "
            f"{line_id}: {error}"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": (
                    "Could not delete counting line"
                ),
            },
            status_code=500,
        )


# =========================================================
# ENROLLED PERSON MANAGEMENT APIs
# =========================================================

@app.get(
    "/api/face-enrollment/persons",
    dependencies=[Depends(get_current_user)],
)
async def get_enrolled_persons(
    search: Optional[str] = None,
    status: Optional[str] = None,
    department: Optional[str] = None,
    role: Optional[str] = None,
):
    db = get_db_session()

    try:
        data = get_enrolled_persons_service(
            db=db,
            search=search,
            status=status,
            department=department,
            role=role,
        )

        return JSONResponse(
            {
                "ok": True,
                "count": len(data),
                "data": data,
            }
        )

    except Exception as error:
        logger.exception(
            "Could not load enrolled persons"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not load enrolled persons",
                "data": [],
            },
            status_code=500,
        )

    finally:
        db.close()


@app.get(
    "/api/face-enrollment/persons/{person_id}",
    dependencies=[Depends(get_current_user)],
)
async def get_enrolled_person(person_id: int):
    db = get_db_session()

    try:
        result = get_enrolled_person_service(
            db=db,
            person_id=person_id,
        )

        if not result.get("success"):
            return JSONResponse(
                {
                    "ok": False,
                    "message": result.get(
                        "message",
                        "Person not found",
                    ),
                },
                status_code=result.get(
                    "status_code",
                    404,
                ),
            )

        return JSONResponse(
            {
                "ok": True,
                "data": result["data"],
            }
        )

    except Exception:
        logger.exception(
            "Could not load enrolled person"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not load person details",
            },
            status_code=500,
        )

    finally:
        db.close()


@app.put(
    "/api/face-enrollment/persons/{person_id}",
    dependencies=[Depends(get_current_user)],
)
async def update_enrolled_person(
    person_id: int,
    payload: EnrolledPersonUpdateRequest,
):
    db = get_db_session()

    try:
        payload_data = (
            payload.model_dump()
            if hasattr(payload, "model_dump")
            else payload.dict()
        )

        result = update_enrolled_person_service(
            db=db,
            person_id=person_id,
            payload=payload_data,
        )

        if not result.get("success"):
            return JSONResponse(
                {
                    "ok": False,
                    "message": result.get(
                        "message",
                        "Could not update person",
                    ),
                },
                status_code=result.get(
                    "status_code",
                    400,
                ),
            )

        return JSONResponse(
            {
                "ok": True,
                "message": result.get(
                    "message",
                    "Person updated successfully",
                ),
                "data": result.get("data"),
            }
        )

    except Exception:
        db.rollback()

        logger.exception(
            "Could not update enrolled person"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not update person",
            },
            status_code=500,
        )

    finally:
        db.close()


@app.put(
    "/api/face-enrollment/persons/{person_id}/status",
    dependencies=[Depends(get_current_user)],
)
async def update_enrolled_person_status(
    person_id: int,
    payload: EnrolledPersonStatusRequest,
):
    db = get_db_session()

    try:
        result = update_enrolled_person_status_service(
            db=db,
            person_id=person_id,
            is_active=payload.isActive,
        )

        if not result.get("success"):
            return JSONResponse(
                {
                    "ok": False,
                    "message": result.get(
                        "message",
                        "Could not update person status",
                    ),
                },
                status_code=result.get(
                    "status_code",
                    400,
                ),
            )

        return JSONResponse(
            {
                "ok": True,
                "message": result.get("message"),
                "data": result.get("data"),
            }
        )

    except Exception:
        db.rollback()

        logger.exception(
            "Could not update person status"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not update person status",
            },
            status_code=500,
        )

    finally:
        db.close()


@app.delete(
    "/api/face-enrollment/persons/{person_id}",
    dependencies=[Depends(get_current_user)],
)
async def delete_enrolled_person(person_id: int):
    db = get_db_session()

    try:
        result = delete_enrolled_person_service(
            db=db,
            person_id=person_id,
        )

        if not result.get("success"):
            return JSONResponse(
                {
                    "ok": False,
                    "message": result.get(
                        "message",
                        "Could not delete person",
                    ),
                },
                status_code=result.get(
                    "status_code",
                    400,
                ),
            )

        return JSONResponse(
            {
                "ok": True,
                "message": result.get(
                    "message",
                    "Person deleted permanently",
                ),
            }
        )

    except Exception:
        db.rollback()

        logger.exception(
            "Could not permanently delete enrolled person"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not delete person",
            },
            status_code=500,
        )

    finally:
        db.close()

# =========================================================
# Sent PPE Email Alert History
# Table + Pagination + Total Alerts
# =========================================================

@app.get(
    "/api/email-alerts/history",
    dependencies=[Depends(get_current_user)],
)
async def get_email_alert_history(
    page: int = 1,
    page_size: int = 10,
):
    db = get_db_session()

    try:
        result = get_email_alert_history_service(
            db=db,
            page=page,
            page_size=page_size,
        )

        return JSONResponse(
            {
                "ok": True,
                "data": result["data"],
                "pagination": result["pagination"],
            },
            status_code=200,
        )

    except Exception as error:
        logger.exception(
            "Could not load email alert history"
        )

        return JSONResponse(
            {
                "ok": False,
                "message": "Could not load email alert history",
                "data": [],
                "pagination": {
                    "page": page,
                    "pageSize": page_size,
                    "total": 0,
                    "totalPages": 0,
                },
            },
            status_code=500,
        )

    finally:
        db.close()
