"""
One-off schema step for the Enrolled Persons release (Sep 2026).

create_all() never ALTERs an existing table, so the five columns Prateek added
to FaceEnrollmentPerson have to be added by hand. Idempotent - safe to re-run.
email_alert_history is a new table; create_all() makes it on the next start.

Run on the server from the live backend directory (the script may live in
the repo clone; it imports `app` from the current directory):
    venv/bin/python /home/paperlessops/visionai-repo/backend/scripts/add_enrollment_columns.py
"""
import os
import sys

sys.path.insert(0, os.getcwd())

from dotenv import load_dotenv  # noqa: E402

load_dotenv(".env")

from sqlalchemy import text  # noqa: E402

from app.database import engine  # noqa: E402

COLUMNS = [
    "is_archived BOOLEAN NOT NULL DEFAULT false",
    "archived_at TIMESTAMPTZ",
    "last_seen_at TIMESTAMPTZ",
    "recognition_count INTEGER NOT NULL DEFAULT 0",
    "updated_at TIMESTAMPTZ NOT NULL DEFAULT now()",
]

with engine.begin() as conn:
    for col in COLUMNS:
        conn.execute(text(
            f"ALTER TABLE face_enrollment_persons ADD COLUMN IF NOT EXISTS {col}"
        ))
        print("ok:", col.split()[0])
