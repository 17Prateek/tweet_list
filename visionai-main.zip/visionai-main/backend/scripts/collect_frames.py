"""
Build the training picture set. Two sources, one folder: dataset/

  frames/cam<id>/<time>.jpg   one frame per camera every INTERVAL seconds,
                              but only when the picture changed since the last
                              one saved (an empty yard at 3 am teaches nothing)
  negatives/<episode>.jpg     evidence of episodes marked "Not a real issue"
                              on or after NEGATIVES_SINCE (earlier clicks were
                              just clearing the board, not judging the model)

Run on the server from the LIVE backend folder (uses its venv, .env, models):

    cd /home/paperlessops/public_html/visionai-backend
    nohup venv/bin/python /home/paperlessops/visionai-repo/backend/scripts/collect_frames.py 60 > collect.log 2>&1 &

Stop with:  pkill -f collect_frames.py
Copy to the laptop with:  scp -r root@<server>:/home/paperlessops/public_html/visionai-backend/dataset .
"""
import os
import shutil
import sys
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

import cv2
import numpy as np

LIVE = Path(os.getcwd())
sys.path.insert(0, str(LIVE))

from dotenv import load_dotenv  # noqa: E402

load_dotenv(LIVE / ".env")

from app.auth_service import create_access_token  # noqa: E402
from app.database import Camera, Episode, User, get_db_session  # noqa: E402

INTERVAL = int(sys.argv[1]) if len(sys.argv) > 1 else 60
NEGATIVES_SINCE = datetime(2026, 9, 17, 9, 0, tzinfo=timezone.utc)   # 14:30 IST, 17 Sep
CHANGE_MIN = 6.0   # mean pixel difference (0-255) below which a frame is "the same picture"
OUT = LIVE / "dataset"
base = os.getenv("PUBLIC_API_BASE", "https://visionai-backend.paperlessops.com")


def token():
    db = get_db_session()
    try:
        return create_access_token(db.query(User).filter(User.role == "super_admin").first())
    finally:
        db.close()


def cameras():
    db = get_db_session()
    try:
        return [(c.id, c.camera_name) for c in db.query(Camera).filter(Camera.is_active.is_(True)).all()]
    finally:
        db.close()


def export_negatives():
    """Copy the evidence of every 'not a real issue' episode not copied yet."""
    dest = OUT / "negatives"
    dest.mkdir(parents=True, exist_ok=True)
    db = get_db_session()
    try:
        rows = db.query(Episode).filter(Episode.status == "false_positive",
                                        Episode.resolved_at >= NEGATIVES_SINCE).all()
        n = 0
        for row in rows:
            for rel in (row.evidence_first, row.evidence_last):
                if not rel:
                    continue
                src = LIVE / rel.lstrip("/")
                if src.is_file() and not (dest / src.name).exists():
                    shutil.copy2(src, dest / src.name)
                    n += 1
        return n
    finally:
        db.close()


def changed(cam_id, data):
    """True when this frame differs from the last one saved for the camera."""
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_GRAYSCALE)
    if img is None:
        return False
    small = cv2.resize(img, (160, 90)).astype(np.float32)
    prev = last_small.get(cam_id)
    last_small[cam_id] = small
    return prev is None or float(np.abs(small - prev).mean()) >= CHANGE_MIN


last_small = {}
print(f"== collecting one frame per camera every {INTERVAL} s into {OUT} (only when the picture changes) ==", flush=True)
tok, tok_at = token(), time.time()
while True:
    if time.time() - tok_at > 3600:            # tokens expire; mint a fresh one hourly
        tok, tok_at = token(), time.time()
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    for cam_id, name in cameras():
        folder = OUT / "frames" / f"cam{cam_id}"
        folder.mkdir(parents=True, exist_ok=True)
        try:
            with urllib.request.urlopen(f"{base}/api/cameras/{cam_id}/snapshot.jpg?token={tok}", timeout=15) as r:
                data = r.read()
            if changed(cam_id, data):
                (folder / f"{stamp}.jpg").write_bytes(data)
        except Exception as exc:                # offline camera: skip this round
            print(f"{stamp} cam{cam_id} {name}: {exc}", flush=True)
    negs = export_negatives()
    if negs:
        print(f"{stamp} copied {negs} 'not a real issue' picture(s)", flush=True)
    time.sleep(INTERVAL)
