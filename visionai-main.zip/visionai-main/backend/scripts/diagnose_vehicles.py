"""
Why is there no vehicle episode? Grab one frame from a camera, run the same
model the monitor runs, and print every detection with its confidence, its
ground point, and which zone (if any) that point falls in.

Run on the server from the LIVE backend folder (uses its venv, .env, models):

    cd /home/paperlessops/public_html/visionai-backend
    venv/bin/python /home/paperlessops/visionai-repo/backend/scripts/diagnose_vehicles.py <camera_id>
"""
import json
import os
import sys
import urllib.request
from pathlib import Path

LIVE = Path(os.getcwd())
sys.path.insert(0, str(LIVE))

from dotenv import load_dotenv  # noqa: E402

load_dotenv(LIVE / ".env")

import cv2  # noqa: E402
import numpy as np  # noqa: E402

from app import zones  # noqa: E402
from app.auth_service import create_access_token  # noqa: E402
from app.database import User, get_db_session  # noqa: E402

camera_id = int(sys.argv[1]) if len(sys.argv) > 1 else 1
base = os.getenv("PUBLIC_API_BASE", "https://visionai-backend.paperlessops.com")

db = get_db_session()
user = db.query(User).filter(User.role == "super_admin").first()
db.close()
token = create_access_token(user)

print(f"== camera {camera_id}: fetching one frame ==")
url = f"{base}/api/cameras/{camera_id}/snapshot.jpg?token={token}"
try:
    with urllib.request.urlopen(url, timeout=15) as resp:
        data = resp.read()
except Exception as exc:
    print("snapshot failed:", exc)
    sys.exit(1)
frame = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
if frame is None:
    print("could not decode the picture")
    sys.exit(1)
h, w = frame.shape[:2]
print(f"frame {w}x{h}")

print("== zones on this camera ==")
cam_zones = zones.zones_for_camera(camera_id)
for z in cam_zones:
    print(f"  #{z['id']} {z['name']} ({z['zone_type']}) limit={z['limit_sec']} polygon={json.dumps(z['polygon'])}")
if not cam_zones:
    print("  none")

print("== running the person/vehicle model at a low floor (0.15) ==")
from ultralytics import YOLO  # noqa: E402

model = YOLO(os.getenv("PERSON_MODEL_PATH"))
results = model.predict(source=frame, conf=0.15, imgsz=640, verbose=False)
names = model.names
vehicle_ids = {2: "car", 3: "motorcycle", 5: "bus", 7: "truck"}
vehicle_conf = float(os.getenv("VEHICLE_CONF", "0.50"))
person_conf = float(os.getenv("PERSON_CONF", "0.70"))

rows = []
for r in results:
    if r.boxes is None:
        continue
    for b in r.boxes:
        cls_id = int(b.cls[0].item())
        conf = float(b.conf[0].item())
        x1, y1, x2, y2 = map(int, b.xyxy[0].tolist())
        gx, gy = zones.ground_point((x1, y1, x2, y2), (h, w))
        hit = None
        for z in cam_zones:
            if zones.point_in_polygon(gx, gy, z["polygon"]):
                hit = z["name"]
                break
        kind = vehicle_ids.get(cls_id, names.get(cls_id, str(cls_id)))
        cut = vehicle_conf if cls_id in vehicle_ids else person_conf
        rows.append((conf, kind, (x1, y1, x2, y2), (round(gx, 3), round(gy, 3)), hit, conf >= cut))

rows.sort(reverse=True)
if not rows:
    print("  the model found nothing at all in this frame")
for conf, kind, box, gp, hit, kept in rows:
    print(f"  {kind:<11} conf={conf:.2f}  box={box}  ground={gp}  zone={hit or '-'}  {'COUNTS' if kept else 'below cut-off'}")

out = LIVE / f"diagnose-cam{camera_id}.jpg"
for conf, kind, box, gp, hit, kept in rows:
    colour = (0, 200, 0) if kept else (0, 140, 255)
    cv2.rectangle(frame, box[:2], box[2:], colour, 2)
    cv2.circle(frame, (int(gp[0] * w), int(gp[1] * h)), 6, (0, 0, 255), -1)
    cv2.putText(frame, f"{kind} {conf:.2f}", (box[0], max(12, box[1] - 4)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, colour, 1)
for z in cam_zones:
    pts = np.array([[int(x * w), int(y * h)] for x, y in z["polygon"]], np.int32)
    cv2.polylines(frame, [pts], True, (255, 200, 0), 2)
    cv2.putText(frame, z["name"], tuple(pts[0]), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 200, 0), 2)
cv2.imwrite(str(out), frame)
print(f"== picture with boxes, red ground points and zones written to {out} ==")
print("   copy it to evidence/ to view it in the browser:  cp", out.name, "evidence/  ->", f"{base}/evidence/{out.name}")
