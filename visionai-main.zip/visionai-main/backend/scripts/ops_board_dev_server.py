"""
Local API for developing the Ops Board without cameras or a login.

Runs the REAL episodes router (app.episodes_api) on a throwaway SQLite
database, with authentication replaced by a fixed user and small stubs for
the two other routes the board reads (/api/cameras, /api/monitoring/status).
Seeds a realistic set of episodes so every section of the board has data,
and keeps opening/closing episodes in the background so the live stream
can be watched moving.

    cd backend
    .venv/Scripts/python scripts/ops_board_dev_server.py      # http://127.0.0.1:8000

Then `npm run dev` in frontend/ (its .env.development already points here)
and put a fake session in the browser (see the bottom of this file).
"""
from __future__ import annotations

import os
import random
import sys
import tempfile
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

_TMP = Path(tempfile.mkdtemp(prefix="visionai-opsboard-"))
os.environ["DATABASE_URL"] = f"sqlite:///{(_TMP / 'dev.db').as_posix()}"
os.environ.setdefault("JWT_SECRET_KEY", "dev-only")
os.environ.setdefault("JWT_ALGORITHM", "HS256")

import uvicorn  # noqa: E402
from fastapi import FastAPI  # noqa: E402
from fastapi.middleware.cors import CORSMiddleware  # noqa: E402
from fastapi.responses import JSONResponse  # noqa: E402

from app import database, episodes, episodes_api  # noqa: E402
from app.auth_dependencies import get_current_user, get_current_user_from_query  # noqa: E402

CAMERAS = [
    {"id": 1, "camera_name": "in room", "location": "Office", "status": "online"},
    {"id": 2, "camera_name": "Main Gate", "location": "Gate", "status": "online"},
    {"id": 3, "camera_name": "Weighbridge", "location": "Weighbridge", "status": "online"},
    {"id": 4, "camera_name": "Truck Yard", "location": "Yard (east)", "status": "online"},
    {"id": 5, "camera_name": "Loading Bay 3", "location": "Loading", "status": "online"},
    {"id": 6, "camera_name": "Styrene Unloading", "location": "Unloading bay", "status": "online"},
    {"id": 7, "camera_name": "Reactor Section", "location": "Process area", "status": "online"},
    {"id": 8, "camera_name": "Yard East", "location": "Yard (east)", "status": "offline"},
]


class DevUser:
    email = "dev@example.com"
    full_name = "Dev User"
    role = "super_admin"


def build_app() -> FastAPI:
    app = FastAPI(title="Ops Board dev API")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.include_router(episodes_api.router)
    app.include_router(episodes_api.zones_router)
    from app import arrivals
    app.include_router(arrivals.router)
    database.create_tables()   # expected_vehicles is registered by the import above
    app.dependency_overrides[get_current_user] = lambda: DevUser()
    app.dependency_overrides[get_current_user_from_query] = lambda: DevUser()
    episodes_api._authenticate_query_token = lambda token: DevUser()   # the stream checks tokens itself

    @app.get("/api/cameras")
    def cameras():
        return JSONResponse({"ok": True, "data": [dict(c, last_seen="12:40") for c in CAMERAS]})

    @app.get("/api/live-events")
    def live_events():
        return JSONResponse({"ok": True, "data": episodes.as_live_event_rows(limit=100)})

    @app.get("/api/monitoring/status")
    def monitoring():
        return JSONResponse({"ok": True, "data": {"enabled": True, "monitored_count": 7, "monitored_camera_ids": [1, 2, 3, 4, 5, 6, 7]}})

    @app.get("/api/cameras/{camera_id}/snapshot.jpg")
    def snapshot(camera_id: int):
        # A drawn "yard" so the zone editor has something to draw on.
        import cv2
        import numpy as np
        from fastapi.responses import Response
        img = np.full((720, 1280, 3), (40, 46, 56), np.uint8)
        cv2.rectangle(img, (0, 420), (1280, 720), (70, 78, 90), -1)            # ground
        cv2.rectangle(img, (120, 300), (520, 470), (150, 140, 60), -1)          # a truck
        cv2.rectangle(img, (760, 380), (1000, 470), (60, 60, 160), -1)          # a car
        cv2.circle(img, (1120, 380), 40, (200, 200, 200), -1); cv2.rectangle(img, (1095, 420), (1145, 560), (200, 200, 200), -1)  # a person
        cv2.putText(img, f"CAM-{camera_id} dev picture", (20, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (230, 236, 243), 2)
        ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
        return Response(content=buf.tobytes(), media_type="image/jpeg", headers={"Cache-Control": "no-store"})

    @app.post("/dev/open")
    async def dev_open(body: dict):
        """Dev only: open an episode with any fields (defaults filled in)."""
        cam = _cam(int(body.get("camera_id", 1)))
        kw = dict(camera_id=cam["id"], camera_name=cam["camera_name"], camera_location=cam["location"],
                  kind="vehicle_in_zone", title="Truck in zone", subject_type="vehicle", subject_label="Truck",
                  subject_id=None, severity="info", attributes={"vehicle_class": "truck"})
        kw.update({k: v for k, v in body.items() if k in kw or k in ("zone_id", "zone_name", "people_count")})
        eid = episodes.open_episode(**kw)
        if body.get("evidence"):
            db = database.get_db_session()
            try:
                row = db.query(database.Episode).filter_by(episode_id=eid).one()
                row.evidence_first = row.evidence_last = body["evidence"]
                db.commit()
            finally:
                db.close()
        return JSONResponse({"ok": True, "episode_id": eid})

    return app


def _cam(camera_id: int) -> dict:
    return next(c for c in CAMERAS if c["id"] == camera_id)


def _open(camera_id, **kw):
    cam = _cam(camera_id)
    base = dict(camera_id=camera_id, camera_name=cam["camera_name"], camera_location=cam["location"],
                kind="ppe_violation", title="Helmet missing", subject_type="unknown", subject_label="Unknown Person",
                subject_id=None, severity="warning", attributes={"helmet": False, "vest": True})
    base.update(kw)
    return episodes.open_episode(**base)


def _backdate(episode_id: str, started_ago_sec: float, ended_ago_sec: float | None = None,
              resolved_by: str | None = None, note: str | None = None, acked_after_sec: float | None = None):
    """Move a freshly opened episode into the past so history has shape."""
    db = database.get_db_session()
    try:
        row = db.query(database.Episode).filter_by(episode_id=episode_id).one()
        now = datetime.now(timezone.utc)
        row.started_at = now - timedelta(seconds=started_ago_sec)
        row.last_seen_at = row.started_at
        if ended_ago_sec is not None:
            row.ended_at = now - timedelta(seconds=ended_ago_sec)
            row.last_seen_at = row.ended_at
        if acked_after_sec is not None:
            row.status = "acknowledged"
            row.acknowledged_by = "Shift Supervisor"
            row.acknowledged_at = row.started_at + timedelta(seconds=acked_after_sec)
        if resolved_by:
            row.status = "resolved"
            row.resolved_by = resolved_by
            row.resolved_at = (row.ended_at or now) + timedelta(seconds=60)
            row.resolve_note = note or "Handled"
            if row.acknowledged_at is None:
                row.acknowledged_by = resolved_by
                row.acknowledged_at = row.resolved_at
        db.commit()
    finally:
        db.close()
    with episodes._lock:
        episodes._open_index.pop(episode_id, None)


def seed():
    random.seed(7)
    # --- live now -----------------------------------------------------------
    e = _open(6, kind="restricted_presence", severity="critical", subject_type="vehicle", subject_label="UP 32 KT 7710",
              title="Driver still in cabin while tanker is being unloaded", attributes={"earthing": True, "chocks": True, "driver_out": False})
    _backdate(e, 240)
    e = _open(7, kind="restricted_presence", severity="critical", title="Unknown person in restricted process area", attributes={})
    _backdate(e, 180)
    e = _open(5, severity="warning", title="Helmet missing", subject_type="person", subject_label="Abhishek Kumar", subject_id="03", people_count=2)
    _backdate(e, 720)
    e = _open(1, severity="warning", title="Helmet and vest missing", attributes={"helmet": False, "vest": False})
    _backdate(e, 95, acked_after_sec=40)
    e = _open(8, kind="system", severity="notice", subject_type="camera", subject_label="Yard East", subject_id="8",
              title="Yard East is offline - Yard (east) is unwatched", attributes={})
    _backdate(e, 8400)
    e = _open(4, kind="vehicle_in_zone", severity="info", subject_type="vehicle", subject_label="HR 55 AE 3921", title="Truck waiting in yard", attributes={})
    _backdate(e, 2 * 3600 + 41 * 60)
    e = _open(3, kind="vehicle_in_zone", severity="info", subject_type="vehicle", subject_label="PB 11 CT 0912", title="On weighbridge", attributes={"cabin_empty": True})
    _backdate(e, 6 * 60)
    e = _open(2, kind="vehicle_in_zone", severity="info", subject_type="vehicle", subject_label="Plate not read", title="Truck at gate", attributes={})
    _backdate(e, 150)
    # one warning that already ended on camera but nobody closed out
    e = _open(1, severity="warning", title="Vest missing", subject_type="person", subject_label="Ajay", subject_id="01", attributes={"helmet": True, "vest": False})
    _backdate(e, 1900, ended_ago_sec=600)

    # --- history for AI noticed / progress ---------------------------------
    people = [("person", "Abhishek Kumar", "03"), ("person", "Ajay", "01"), ("unknown", "Unknown Person", None), ("unknown", "Unknown Person", None)]
    for day in range(1, 58):
        n = random.choice([0, 1, 1, 2, 3]) if day > 30 else random.choice([0, 1, 1, 2])
        for _ in range(n):
            cam_id = random.choice([1, 1, 1, 5, 5, 6, 7])
            hour = random.choice([9, 10, 14, 14, 15, 15, 16, 18])
            st, sl, sid = random.choice(people)
            eid = _open(cam_id, subject_type=st, subject_label=sl, subject_id=sid,
                        title=random.choice(["Helmet missing", "Vest missing", "Helmet and vest missing"]))
            ago = day * 86400 - (hour - 12) * 3600 + random.randint(0, 3000)
            ack = random.choice([None, 120, 300, 600, 900]) if day > 7 else random.choice([60, 120, 180, 240, None])
            _backdate(eid, ago, ended_ago_sec=ago - random.randint(60, 900),
                      resolved_by="Shift Supervisor",
                      note=random.choice(["Helmet issued", "Contractor briefed", "Loader sent to PPE store"]),
                      acked_after_sec=ack)
    print("seeded", len(episodes.live_state()["open"]), "live episodes")


def churn():
    """Every ~40 s open a new warning on the office camera and close one, so the stream moves."""
    while True:
        time.sleep(40)
        try:
            eid = _open(1, title=random.choice(["Helmet missing", "Vest missing"]))
            time.sleep(25)
            episodes.close_episode(eid)
        except Exception as exc:  # pragma: no cover
            print("churn error:", exc)


if __name__ == "__main__":
    database.create_tables()
    seed()
    threading.Thread(target=churn, daemon=True).start()
    print("""
Browser session (run once in DevTools console on http://localhost:5173):
  sessionStorage.setItem("isLoggedIn","true");
  sessionStorage.setItem("accessToken","dev");
  sessionStorage.setItem("currentUser", JSON.stringify({email:"dev@example.com", full_name:"Dev User", role:"super_admin"}));
  location.href = "/ops";
""")
    uvicorn.run(build_app(), host="127.0.0.1", port=8000, log_level="warning")
