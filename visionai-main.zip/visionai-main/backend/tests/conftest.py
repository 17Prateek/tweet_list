"""
Every test session gets its own SQLite file. DATABASE_URL must be set BEFORE
app.database is imported, because that module builds the engine at import.
"""
import os
import sys
import tempfile
from pathlib import Path

_TMP = Path(tempfile.mkdtemp(prefix="visionai-tests-"))
os.environ["DATABASE_URL"] = f"sqlite:///{(_TMP / 'test.db').as_posix()}"
os.environ.setdefault("JWT_SECRET_KEY", "test-secret-key-not-for-production")
os.environ.setdefault("JWT_ALGORITHM", "HS256")
os.environ.setdefault("VISIONAI_TIMEZONE", "Asia/Kolkata")

# Make `app.*` importable when pytest runs from backend/
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest  # noqa: E402

from app import database  # noqa: E402


@pytest.fixture(scope="session", autouse=True)
def _create_schema():
    database.create_tables()
    yield


@pytest.fixture()
def db():
    session = database.get_db_session()
    try:
        yield session
    finally:
        session.close()
