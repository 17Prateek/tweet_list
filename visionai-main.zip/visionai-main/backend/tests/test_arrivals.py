"""
Expected vehicles: add today's trucks, link one to the vehicle the camera
sees, watch its status and location follow the episode, mark it departed.
"""
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from app import arrivals, database, episodes
from app.auth_dependencies import get_current_user


class _User:
    email = "gate@example.com"
    full_name = "Gate Office"
    role = "user"


@pytest.fixture()
def client(db):
    database.create_tables()          # expected_vehicles is registered by importing app.arrivals
    app = FastAPI()
    app.include_router(arrivals.router)
    app.dependency_overrides[get_current_user] = lambda: _User()
    return TestClient(app)


def _truck(zone="Weighbridge"):
    return episodes.open_episode(camera_id=2, camera_name="Gate cam", camera_location="Main gate",
                                 kind="vehicle_in_zone", title="Truck in zone", subject_type="vehicle",
                                 subject_label="Truck", subject_id=None, severity="info",
                                 zone_id=5, zone_name=zone, attributes={"vehicle_class": "truck"})


def test_lifecycle(client):
    r = client.post("/api/arrivals", json={"date": "2026-09-17", "plate": "hr 55 ab 1234", "transporter": "Shree Logistics",
                                           "material": "Styrene", "purpose": "unloading", "expected_time": "10:30"})
    assert r.status_code == 200
    a = r.json()["data"]
    assert a["plate"] == "HR55AB1234" and a["status"] == "expected" and a["created_by"] == "Gate Office"

    assert client.post("/api/arrivals", json={"date": "2026-09-17", "plate": "x"}).status_code == 400

    rows = client.get("/api/arrivals", params={"date": "2026-09-17"}).json()["data"]
    assert [x["plate"] for x in rows] == ["HR55AB1234"]
    assert client.get("/api/arrivals", params={"date": "2026-09-18"}).json()["data"] == []

    # camera sees a truck at the weighbridge; the gate links it
    eid = _truck()
    r = client.post(f"/api/arrivals/{a['id']}/link", json={"episode_id": eid})
    a = r.json()["data"]
    assert a["status"] == "on_site" and a["location"]["zone_name"] == "Weighbridge" and a["arrived_epoch"]
    ep = episodes.get_episode(eid)
    assert ep["attributes"]["plate"] == "HR55AB1234" and ep["attributes"]["transporter"] == "Shree Logistics"

    # it leaves the weighbridge: still arrived, last known place kept
    episodes.close_episode(eid)
    a = client.get("/api/arrivals", params={"date": "2026-09-17"}).json()["data"][0]
    assert a["status"] == "arrived" and a["location"]["zone_name"] == "Weighbridge" and a["location"]["ended_epoch"]

    # second visit at the bay, then departed
    eid2 = _truck("Bay 3")
    a = client.post(f"/api/arrivals/{a['id']}/link", json={"episode_id": eid2}).json()["data"]
    assert a["status"] == "on_site" and a["location"]["zone_name"] == "Bay 3" and len(a["visits"]) == 2
    a = client.post(f"/api/arrivals/{a['id']}/departed").json()["data"]
    assert a["status"] == "departed" and a["departed_epoch"]

    assert client.post(f"/api/arrivals/{a['id']}/link", json={"episode_id": "EP-nope"}).status_code == 404
    assert client.delete(f"/api/arrivals/{a['id']}").json()["ok"] is True
    assert client.get("/api/arrivals", params={"date": "2026-09-17"}).json()["data"] == []


def test_manual_arrived_without_camera(client):
    a = client.post("/api/arrivals", json={"date": "2026-09-17", "plate": "PB10CC0001"}).json()["data"]
    a = client.post(f"/api/arrivals/{a['id']}/arrived").json()["data"]
    assert a["status"] == "arrived" and a["location"] is None
    a = client.put(f"/api/arrivals/{a['id']}", json={"date": "2026-09-17", "plate": "PB10CC0001", "material": "Coal"}).json()["data"]
    assert a["material"] == "Coal" and a["status"] == "arrived"
