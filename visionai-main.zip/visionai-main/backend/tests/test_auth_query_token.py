import os
import pytest
from datetime import datetime, timedelta, timezone
from jose import jwt


def _make_user(db, email="ops@example.com", role="user"):
    from app.database import User
    u = db.query(User).filter(User.email == email).first()
    if u is None:
        u = User(email=email, employee_id="E1", full_name="Ops Person", mobile="9999999999",
                 department="Safety", password_hash="x", role=role, is_active=True)
        db.add(u); db.commit()
    return u


def _token(email, purpose="access"):
    payload = {"sub": email, "purpose": purpose, "exp": datetime.now(timezone.utc) + timedelta(minutes=5)}
    return jwt.encode(payload, os.environ["JWT_SECRET_KEY"], algorithm=os.environ["JWT_ALGORITHM"])


def test_valid_access_token_returns_user(db):
    from app.auth_dependencies import user_from_access_token
    _make_user(db)
    user = user_from_access_token(_token("ops@example.com"), db)
    assert user.email == "ops@example.com"


def test_reset_token_is_rejected(db):
    from fastapi import HTTPException
    from app.auth_dependencies import user_from_access_token
    _make_user(db)
    with pytest.raises(HTTPException):
        user_from_access_token(_token("ops@example.com", purpose="reset"), db)


def test_garbage_token_is_rejected(db):
    from fastapi import HTTPException
    from app.auth_dependencies import user_from_access_token
    with pytest.raises(HTTPException):
        user_from_access_token("not-a-jwt", db)
