import queue


def test_subscriber_receives_open_update_close_and_action(db):
    from app import episodes
    q = episodes.subscribe()
    try:
        eid = episodes.open_episode(camera_id=3, camera_name="Gate", camera_location=None, kind="ppe_violation",
                                    title="Vest missing", subject_type="person", subject_label="Unknown person",
                                    subject_id=None, severity="warning")
        episodes.touch_episode(eid, people_count=2)      # arrival -> "updated"
        episodes.acknowledge(eid, "Ops")                 # -> "action"
        episodes.close_episode(eid)                      # -> "closed"
        types = [q.get(timeout=1)["type"] for _ in range(4)]
        assert types == ["opened", "updated", "action", "closed"]
    finally:
        episodes.unsubscribe(q)


def test_slow_subscriber_never_blocks_publisher(db):
    from app import episodes
    q = episodes.subscribe()
    try:
        for _ in range(600):                              # queue maxsize is 500
            episodes.publish({"type": "opened", "episode": {}})
        assert q.qsize() == 500                           # extras dropped, no exception
    finally:
        episodes.unsubscribe(q)


def test_unsubscribed_queue_gets_nothing(db):
    from app import episodes
    q = episodes.subscribe(); episodes.unsubscribe(q)
    episodes.publish({"type": "opened", "episode": {}})
    assert q.empty()
