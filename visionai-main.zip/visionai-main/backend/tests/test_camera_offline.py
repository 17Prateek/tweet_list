from datetime import datetime, timedelta, timezone


def _camera(db, name, status="offline", seen_ago_sec=900):
    from app.database import Camera
    cam = Camera(camera_name=name, source_type="rtsp", rtsp_url="rtsp://x", is_active=True, status=status,
                 location="Truck Yard (east)",
                 last_seen_at=(datetime.now(timezone.utc) - timedelta(seconds=seen_ago_sec)) if seen_ago_sec is not None else None)
    db.add(cam); db.commit(); db.refresh(cam)
    return cam


def _notices(db, camera_id):
    from app.database import Episode
    db.expire_all()
    return db.query(Episode).filter(Episode.kind == "system", Episode.camera_id == camera_id).all()


def test_offline_camera_opens_one_notice_after_grace_and_closes_when_back(db):
    from app import episodes
    from app.database import Camera
    cam = _camera(db, "CAM-06 Yard East", status="offline")
    t0 = 5000.0

    episodes.sweep_camera_health(offline_after_sec=300, now_mono=t0)          # just noticed: inside grace
    assert _notices(db, cam.id) == []

    episodes.sweep_camera_health(offline_after_sec=300, now_mono=t0 + 301)    # grace over -> one notice
    episodes.sweep_camera_health(offline_after_sec=300, now_mono=t0 + 400)    # idempotent
    rows = _notices(db, cam.id)
    assert len(rows) == 1
    row = rows[0]
    assert row.severity == "notice" and row.subject_type == "camera" and row.ended_at is None
    assert "offline" in row.title.lower() and "unwatched" in row.title
    assert row.camera_location == "Truck Yard (east)"

    cam = db.get(Camera, cam.id)
    cam.status = "online"; cam.last_seen_at = datetime.now(timezone.utc); db.commit()
    episodes.sweep_camera_health(offline_after_sec=300, now_mono=t0 + 500)
    row = _notices(db, cam.id)[0]
    assert row.ended_at is not None
    assert row.status == "open"            # a person still closes it out (audit trail)


def test_flapping_camera_that_recovers_inside_grace_raises_nothing(db):
    from app import episodes
    from app.database import Camera
    cam = _camera(db, "CAM-02 Gate", status="connecting")
    episodes.sweep_camera_health(offline_after_sec=300, now_mono=100.0)
    cam = db.get(Camera, cam.id); cam.status = "online"; db.commit()
    episodes.sweep_camera_health(offline_after_sec=300, now_mono=200.0)
    cam = db.get(Camera, cam.id); cam.status = "offline"; db.commit()
    episodes.sweep_camera_health(offline_after_sec=300, now_mono=300.0)       # clock restarted at 200
    assert _notices(db, cam.id) == []


def test_never_seen_camera_is_left_alone(db):
    from app import episodes
    cam = _camera(db, "new cam", status="offline", seen_ago_sec=None)
    episodes.sweep_camera_health(offline_after_sec=0, now_mono=1.0)
    assert _notices(db, cam.id) == []


def test_unmonitored_camera_is_left_alone(db):
    from app import episodes
    cam = _camera(db, "CAM-09 Store", status="offline")
    episodes.sweep_camera_health(offline_after_sec=0, now_mono=1.0, is_watched=lambda cid: cid != cam.id)
    assert _notices(db, cam.id) == []
