"""Line-crossing geometry for Counting Management.

The counting decision is: a tracked box counts when its centre is seen on one
stable side of the drawn line and later on the other. The deadband around the
line is what stops a box jittering on the line from counting over and over, so
these are the cases worth pinning down.
"""
import os

os.environ.setdefault("VISIONAI_BOX_MODEL_PATH", "/nonexistent/box.pt")


class _Frame:
    """Just enough of a numpy frame for the geometry helpers (.shape)."""

    def __init__(self, width=640, height=480):
        self.shape = (height, width, 3)


def test_line_pixels_scales_fractions_to_the_frame():
    from app.counting_service import _line_pixels

    line = {"points": [[0.0, 0.5], [1.0, 0.5]]}
    start, end = _line_pixels(line, _Frame(640, 480))
    assert start == (0, 240)
    # 1.0 scales to width, one past the last column. Harmless: the endpoints are
    # only drawn (cv2 clips) and fed to the signed distance, never used to index.
    assert end == (640, 240)


def test_line_pixels_rejects_a_line_that_is_not_two_points():
    import pytest

    from app.counting_service import _line_pixels

    for bad in ([], [[0.1, 0.1]], [[0, 0], [1, 1], [0.5, 0.5]]):
        with pytest.raises(ValueError):
            _line_pixels({"points": bad}, _Frame())


def test_line_side_is_opposite_either_side_and_zero_inside_the_deadband():
    from app.counting_service import _line_side

    frame = _Frame(640, 480)
    start, end = (0, 240), (639, 240)

    above = _line_side((320, 40), start, end, frame)
    below = _line_side((320, 440), start, end, frame)

    assert above != 0 and below != 0
    assert above == -below

    # Sitting on the line is "no stable side yet", so it never counts.
    assert _line_side((320, 240), start, end, frame) == 0


def test_crossed_line_needs_two_opposite_stable_sides():
    from app.counting_service import _crossed_line

    assert _crossed_line(-1, 1)
    assert _crossed_line(1, -1)

    # Same side, or no stable side established yet: not a crossing.
    assert not _crossed_line(1, 1)
    assert not _crossed_line(-1, -1)
    assert not _crossed_line(0, 1)
    assert not _crossed_line(1, 0)


def test_only_allowed_intervals_are_accepted():
    import pytest

    from app.counting_service import ALLOWED_INTERVALS, update_counting_setting

    assert ALLOWED_INTERVALS == {5, 10, 15, 30, 60}
    with pytest.raises(ValueError):
        update_counting_setting(7)


def test_box_model_reports_a_missing_path_instead_of_killing_the_backend():
    """Importing this module must never raise - main.py imports it at startup."""
    import pytest

    from app.counting_service import get_box_model

    with pytest.raises((RuntimeError, FileNotFoundError)):
        get_box_model()
