"""
Exercise save_detection_events / _record_new_arrivals / _close_incident with
a fake DB, fake clock and a recording stand-in for app.episodes.

detection_service imports the vision models at module level, so the incident
section of its source is exec'd here with fakes instead of importing it.
"""
import os, threading, time, types
from pathlib import Path
from datetime import datetime

os.environ["VISIONAI_INCIDENT_GRACE_SEC"] = "30"
os.environ["VISIONAI_INCIDENT_CONFIRM_SEC"] = "3"

SRC = Path(__file__).resolve().parents[1].joinpath("app", "detection_service.py").read_text(encoding="utf-8")


def cut(start, end):
    s = SRC.index(start); e = SRC.index(end, s)
    return SRC[s:e]


class Recorder:
    def __init__(self): self.calls = []; self.n = 0
    def open_episode(self, **kw): self.n += 1; self.calls.append(("open", kw)); return f"EP-test-{self.n}"
    def touch_episode(self, eid, **kw): self.calls.append(("touch", eid, kw))
    def close_episode(self, eid, **kw): self.calls.append(("close", eid, kw))


def build(rec):
    code = "\n".join([
        cut("# Violation incidents - two events per episode", "# Email alert evidence snapshots"),
        cut("def get_event_type(person):", "def save_latest_email_evidence("),
        cut("def _ppe_title(", "def _incident_key("),
        cut("def _incident_key(", "def _sweep_evidence("),
        cut("def save_detection_events(", "def draw_text_white_bg("),
        "from collections import Counter",
    ])

    class FakeClock: t = 1000.0
    saved_rows = []
    saved_pictures = []
    class FakeDB:
        def add(self, ev): saved_rows.append(ev)
        def commit(self): pass
        def refresh(self, ev): pass
        def rollback(self): pass
        def close(self): pass
    class LiveEvent:
        def __init__(self, **kw): self.__dict__.update(kw)

    ns = dict(
        os=os, shutil=__import__("shutil"), threading=threading, datetime=datetime, Path=Path,
        time=types.SimpleNamespace(monotonic=lambda: FakeClock.t, time=time.time, sleep=lambda s: None),
        BASE_DIR=Path("."), EVIDENCE_DIR=Path("./nonexistent"), EVIDENCE_MIN_FREE_GB=0,
        LiveEvent=LiveEvent, get_db_session=lambda: FakeDB(), save_evidence_image=lambda f, i: saved_pictures.append((i, f)) or f"/evidence/{i}.jpg",
        UNKNOWN_LABEL="Monitoring", MONITOR_FRAME_ID="monitor",
        normalize_event_person_name=lambda n: "unknown person" if str(n).lower() in ("monitoring", "unknown") else str(n).lower(),
        save_latest_email_evidence=lambda **k: None, process_violation_observation=lambda **k: None,
        _evidence_disk_ok=lambda: True, _db_frame_id=lambda f: 0, _reap_idle_detection_workers=lambda: None,
        episodes=rec,
    )
    exec(code, ns)
    ns["_ensure_incident_sweeper"] = lambda: None
    ns["_saved_rows"] = saved_rows          # anything written through the fake DB (must stay empty)
    return ns, FakeClock


def test_incident_opens_touches_arrives_and_closes_an_episode():
    rec = Recorder()
    ns, clock = build(rec)
    cam = types.SimpleNamespace(id=3, camera_name="in room", location="office")
    violator = {"face_name": "Monitoring", "helmet": False, "vest": True}
    second = dict(violator)

    for _ in range(12):                       # 4 s -> confirmed and opened
        ns["save_detection_events"](cam, [violator], "FRAME", "monitor"); clock.t += 0.33
    opens = [c for c in rec.calls if c[0] == "open"]
    assert len(opens) == 1
    kw = opens[0][1]
    assert kw["kind"] == "ppe_violation" and kw["severity"] == "warning"
    assert kw["title"] == "Helmet missing" and kw["subject_type"] == "unknown"
    assert kw["camera_id"] == 3 and kw["attributes"] == {"helmet": False, "vest": True}
    assert ns["_incidents"][(3, "unknown person")]["episode_id"] == "EP-test-1"
    assert ns["_saved_rows"] == []            # no legacy live_events row any more

    for _ in range(30):                       # still going -> touches
        ns["save_detection_events"](cam, [violator], "FRAME", "monitor"); clock.t += 0.33
    assert any(c[0] == "touch" and c[1] == "EP-test-1" for c in rec.calls)

    for _ in range(9):                        # second violator joins -> arrival touch with people_count=2
        ns["save_detection_events"](cam, [violator, second], "FRAME", "monitor"); clock.t += 0.33
    assert any(c[0] == "touch" and c[2].get("people_count") == 2 for c in rec.calls)

    clock.t += 40; ns["_sweep_incidents"]()   # gone past grace -> closed
    closes = [c for c in rec.calls if c[0] == "close"]
    assert closes and closes[-1][1] == "EP-test-1" and closes[-1][2]["frame"] == "FRAME"
    assert ns["_saved_rows"] == []            # still nothing in live_events


def test_ppe_title_mapping():
    rec = Recorder(); ns, _ = build(rec)
    t = ns["_ppe_title"]
    assert t("Helmet and Vest Violation") == "Helmet and vest missing"
    assert t("Helmet Violation") == "Helmet missing"
    assert t("Vest Violation") == "Vest missing"
    assert t("Something Else") == "Something Else"


def test_evidence_uses_the_best_frame_not_the_last_one():
    """
    The person is fully in view early, then walks to the edge of the frame.
    The opening picture must be the full-view frame; the closing picture the
    best of the last few seconds, not the final glimpse at the edge.
    """
    rec = Recorder()
    ns, clock = build(rec)
    cam = types.SimpleNamespace(id=3, camera_name="in room", location="office")
    shape = (720, 1280, 3)

    def person(box):
        return [{"face_name": "Monitoring", "helmet": False, "vest": True, "box": box}]

    # 0-1.5 s: big, centred (best). 1.5-4 s: sliding to the right edge.
    frames = []
    for i in range(12):
        box = (400, 100, 700, 700) if i < 5 else (1100 + i * 15, 100, 1279, 700)
        frames.append(f"F{i}")
        ns["save_detection_events"](cam, person(box), f"F{i}", "monitor", frame_shape=shape); clock.t += 0.33
    opens = [c for c in rec.calls if c[0] == "open"]
    assert opens and opens[0][1]["frame"] in ("F0", "F1", "F2", "F3", "F4")   # the centred frames, never the edge

    # keep going at the edge, then one last full-view frame 20 s later, then leave
    for i in range(12, 30):
        ns["save_detection_events"](cam, person((1150, 100, 1279, 700)), f"F{i}", "monitor", frame_shape=shape); clock.t += 0.33
    ns["save_detection_events"](cam, person((400, 100, 700, 700)), "GOOD", "monitor", frame_shape=shape); clock.t += 0.33
    for i in range(31, 36):
        ns["save_detection_events"](cam, person((1200, 100, 1279, 700)), f"EDGE{i}", "monitor", frame_shape=shape); clock.t += 0.33
    clock.t += 40; ns["_sweep_incidents"]()
    closes = [c for c in rec.calls if c[0] == "close"]
    assert closes and closes[-1][2]["frame"] == "GOOD"


def test_failed_open_backs_off_and_retries():
    class Failing(Recorder):
        def open_episode(self, **kw):
            self.calls.append(("open", kw)); return None
    rec = Failing()
    ns, clock = build(rec)
    cam = types.SimpleNamespace(id=3, camera_name="in room", location="office")
    violator = {"face_name": "Monitoring", "helmet": False, "vest": True}
    for _ in range(40):                       # 13 s of violation, engine down
        ns["save_detection_events"](cam, [violator], "FRAME", "monitor"); clock.t += 0.33
    opens = [c for c in rec.calls if c[0] == "open"]
    assert 1 <= len(opens) <= 3               # retried after a back-off, not every frame
    assert (3, "unknown person") not in ns["_incidents"]
