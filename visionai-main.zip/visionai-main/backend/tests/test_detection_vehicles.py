"""
run_yolo_detection_full splits the one inference pass into persons and
vehicles. Exec'd from source with fake models (no ultralytics on the laptop).
"""
import os
import threading
import time
import types
from pathlib import Path

SRC = Path(__file__).resolve().parents[1].joinpath("app", "detection_service.py").read_text(encoding="utf-8")


def cut(start, end):
    s = SRC.index(start); e = SRC.index(end, s)
    return SRC[s:e]


class _Box:
    def __init__(self, cls_id, conf, xyxy):
        self.cls = [types.SimpleNamespace(item=lambda c=cls_id: c)]
        self.conf = [types.SimpleNamespace(item=lambda c=conf: c)]
        self.xyxy = [types.SimpleNamespace(tolist=lambda b=xyxy: list(b))]


class _Model:
    def __init__(self, boxes):
        self._boxes = boxes
        self.calls = []

    def predict(self, **kw):
        self.calls.append(kw)
        return [types.SimpleNamespace(boxes=self._boxes)]


def build(person_boxes):
    code = "\n".join([
        "PERSON_CLASS_ID = 0",
        cut("VEHICLE_CLASS_IDS = {", "\n\n"),
        "PERSON_CONF = 0.70\nPPE_CONF = 0.15\nDETECT_DEBUG_SCORES = False\nDETECT_DEBUG_FLOOR = 0.15\nIMG_SIZE = 640\nHELMET_CLASS_ID = 0\nVEST_CLASS_ID = 1\nUNKNOWN_LABEL = 'Monitoring'",
        cut("def run_yolo_detection(frame):", "def assign_ppe_to_persons("),
    ])
    person_model = _Model(person_boxes)
    ppe_model = _Model([])
    ns = dict(
        os=os, time=time, threading=threading, model_lock=threading.Lock(),
        get_models=lambda: (person_model, ppe_model),
        assign_ppe_to_persons=lambda persons, ppe_objects, frame_shape: persons,
    )
    exec(code, ns)
    return ns, person_model


def test_vehicles_kept_from_the_same_pass_and_persons_unchanged():
    ns, person_model = build([
        _Box(0, 0.91, (10, 10, 60, 160)),      # person
        _Box(7, 0.82, (200, 100, 500, 300)),   # truck
        _Box(2, 0.30, (600, 100, 700, 160)),   # car below VEHICLE_CONF -> dropped
        _Box(0, 0.40, (700, 10, 720, 60)),     # person below PERSON_CONF -> dropped
        _Box(5, 0.66, (0, 200, 300, 400)),     # bus
    ])
    frame = types.SimpleNamespace(shape=(480, 800, 3))
    persons, ppe, vehicles = ns["run_yolo_detection_full"](frame)
    assert [p["box"] for p in persons] == [(10, 10, 60, 160)]
    assert persons[0]["face_name"] == "Monitoring" and persons[0]["helmet"] is False
    assert [(v["cls"], v["box"]) for v in vehicles] == [("truck", (200, 100, 500, 300)), ("bus", (0, 200, 300, 400))]
    assert set(person_model.calls[0]["classes"]) == {0, 2, 3, 5, 7}
    # the model runs at the lowest floor; each class is cut in Python
    assert person_model.calls[0]["conf"] <= 0.50

    # the old entry point still returns exactly two things
    persons2, ppe2 = ns["run_yolo_detection"](frame)
    assert [p["box"] for p in persons2] == [(10, 10, 60, 160)]


def test_model_floor_no_longer_hides_vehicles_between_the_two_cutoffs():
    ns, person_model = build([
        _Box(7, 0.60, (200, 100, 500, 300)),   # truck: above VEHICLE_CONF, below PERSON_CONF
        _Box(0, 0.60, (10, 10, 60, 160)),      # person at the same score -> dropped
        _Box(2, 0.30, (600, 100, 700, 160)),   # car below the vehicle cut-off -> dropped
    ])
    frame = types.SimpleNamespace(shape=(480, 800, 3))
    persons, _, vehicles = ns["run_yolo_detection_full"](frame, camera_id=12)
    assert persons == [] and [v["cls"] for v in vehicles] == ["truck"]
