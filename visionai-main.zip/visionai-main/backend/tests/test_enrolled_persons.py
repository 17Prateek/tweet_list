"""
Enrolled Persons + email alert history services (Prateek, Sep 2026), run
against the SQLite test schema so the new FaceEnrollmentPerson columns and the
email_alert_history table are exercised without a pickle or a camera.
"""
from datetime import datetime, timezone


def _person(db, emp="EMP-1"):
    from app.database import FaceEnrollmentPerson
    p = FaceEnrollmentPerson(full_name="Asha", employee_id=emp, department="Ops",
                             role="Driver", pickle_key=emp, total_images=1,
                             primary_quality_score=80, is_active=True)
    db.add(p)
    db.commit()
    db.refresh(p)
    return p


def test_list_get_update_delete(db, tmp_path, monkeypatch):
    from app import face_enrollment as fe
    monkeypatch.setattr(fe, "FACE_DB_PATH", tmp_path / "face_db.pkl", raising=False)
    monkeypatch.setattr(fe, "FACE_ENROLLMENT_IMAGE_DIR", tmp_path / "faces", raising=False)
    p = _person(db)

    rows = fe.get_enrolled_persons_service(db, search="asha")
    assert [r["employeeId"] for r in rows] == ["EMP-1"]
    assert fe.get_enrolled_persons_service(db, status="inactive") == []
    assert fe.get_enrolled_person_service(db, p.id)["data"]["status"] == "Active"

    bad = fe.update_enrolled_person_service(db, p.id, {"fullName": "", "department": "x", "role": "y"})
    assert bad["status_code"] == 400
    ok = fe.update_enrolled_person_service(db, p.id, {"fullName": "Asha K", "department": "Ops", "role": "Driver"})
    assert ok["data"]["fullName"] == "Asha K"

    # No pickle entry -> status change refused, SQL untouched.
    assert fe.update_enrolled_person_status_service(db, p.id, False)["status_code"] == 409

    # With a pickle entry the flag lands in both places.
    fe.save_face_pickle_db({"EMP-1": {"full_name": "Asha K", "embeddings": []}})
    res = fe.update_enrolled_person_status_service(db, p.id, False)
    assert res["success"] and res["data"]["isActive"] is False
    assert fe.load_face_pickle_db()["EMP-1"]["is_active"] is False

    assert fe.delete_enrolled_person_service(db, p.id)["success"]
    assert "EMP-1" not in fe.load_face_pickle_db()
    assert fe.get_enrolled_person_service(db, p.id)["status_code"] == 404


def test_email_alert_history_pagination(db):
    from app import email_service as es
    from app.database import EmailAlertHistory
    for i in range(3):
        db.add(EmailAlertHistory(camera_id=1, camera_name="Gate", event_type="PPE Violation",
                                 helmet=False, vest=True, recipients="a@x.com,b@x.com",
                                 email_sent_at=datetime(2026, 9, 16, 10, i, tzinfo=timezone.utc)))
    db.commit()
    page = es.get_email_alert_history_service(db, page=1, page_size=2)
    assert page["pagination"] == {"page": 1, "pageSize": 2, "total": 3, "totalPages": 2}
    assert len(page["data"]) == 2 and page["data"][0]["recipientCount"] == 2
    assert page["data"][0]["emailSentAt"] > page["data"][1]["emailSentAt"]
