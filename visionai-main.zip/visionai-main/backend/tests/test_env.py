def test_database_is_sqlite(db):
    from app import database
    assert database.DATABASE_URL.startswith("sqlite:///")
