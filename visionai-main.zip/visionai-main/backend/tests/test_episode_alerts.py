"""
Emails for the non-PPE episode kinds: which bus messages deserve one, that an
episode is mailed once only, what the email says, and that the worker really
sends when an episode opens.
"""
import time

import pytest

from app import episode_alerts, episodes
from app.database import EmailRecipient


@pytest.fixture(autouse=True)
def _clean(db, monkeypatch):
    episode_alerts.forget_all()
    db.query(EmailRecipient).delete()
    db.commit()
    monkeypatch.setattr(episode_alerts, "are_email_alerts_enabled", lambda: True)
    yield


def _recipient(db, email, alert_type):
    row = EmailRecipient(email=email, name=email.split("@")[0], position="Safety", alert_type=alert_type,
                         status="Active", is_active=True)
    db.add(row)
    db.commit()


def _episode(**over):
    base = {"episode_id": "EP-1", "camera_id": 3, "camera_name": "Gate 1", "camera_location": "Main gate",
            "zone_id": 9, "zone_name": "Weighbridge", "kind": "vehicle_in_zone", "title": "Truck waiting",
            "subject_type": "vehicle", "subject_label": "Truck", "severity": "info", "status": "open",
            "started_at": "2026-09-16T10:00:00+05:30", "duration_sec": 125.0, "attributes": {}}
    base.update(over)
    return base


def test_which_messages_get_an_email():
    f = episode_alerts.alert_type_for
    assert f({"type": "opened", "episode": _episode(kind="person_in_zone", subject_type="person",
                                                    attributes={"zone_type": "restricted"})}) == "Restricted Zone"
    assert f({"type": "opened", "episode": _episode(kind="vehicle_in_zone")}) is None
    assert f({"type": "updated", "episode": _episode(severity="warning", attributes={"over_limit": True, "limit_sec": 120})}) == "Vehicle Over Limit"
    assert f({"type": "updated", "episode": _episode(severity="info", attributes={})}) is None
    assert f({"type": "opened", "episode": _episode(kind="system", subject_type="camera")}) == "Camera Offline"
    assert f({"type": "opened", "episode": _episode(kind="ppe_violation", subject_type="person")}) is None
    assert f({"type": "closed", "episode": _episode(kind="person_in_zone")}) is None
    assert f({"type": "action", "episode": _episode(kind="system", subject_type="camera")}) is None


def test_message_content():
    ep = _episode(severity="warning", title="Truck waiting 2 m 05 s - over the 2 min limit",
                  attributes={"over_limit": True, "limit_sec": 120})
    msg = episode_alerts.build_message(ep, "Vehicle Over Limit")
    assert msg["Subject"] == "[Warning] Truck waiting 2 m 05 s - over the 2 min limit - Main gate"
    text = msg.get_body(preferencelist=("plain",)).get_content()
    assert "Waiting for: 2 m 05 s" in text and "Time limit: 2 m 00 s" in text and "Weighbridge" in text
    html = msg.get_body(preferencelist=("html",)).get_content()
    assert "Vehicle Over Limit" in html and "/ops" in html

    ep = _episode(kind="person_in_zone", subject_type="person", subject_label="Ajay", severity="critical",
                  title="Ajay in restricted area", zone_name="Tank farm")
    msg = episode_alerts.build_message(ep, "Restricted Zone")
    assert msg["Subject"].startswith("[Critical] Ajay in restricted area")
    assert "Who: Ajay" in msg.get_body(preferencelist=("plain",)).get_content()


def test_sends_once_to_matching_recipients_only(db):
    _recipient(db, "all@example.com", "All Alerts")
    _recipient(db, "yard@example.com", "Vehicle Over Limit")
    _recipient(db, "ppe@example.com", "Helmet Missing")
    sent = []

    def fake_send(message, recipients):
        sent.append((message["Subject"], sorted(recipients)))
        return True, None

    msg = {"type": "updated", "episode": _episode(severity="warning", attributes={"over_limit": True, "limit_sec": 120})}
    report = episode_alerts.handle_message(msg, sender=fake_send)
    assert report["sent"] and sorted(report["recipients"]) == ["all@example.com", "yard@example.com"]
    # The same episode is never mailed twice, however many updates follow.
    assert episode_alerts.handle_message(msg, sender=fake_send) is None
    assert len(sent) == 1

    # Restricted zone goes to All Alerts only here (nobody chose Restricted Zone).
    msg = {"type": "opened", "episode": _episode(episode_id="EP-2", kind="person_in_zone", subject_type="person",
                                                 severity="critical", attributes={"zone_type": "restricted"})}
    report = episode_alerts.handle_message(msg, sender=fake_send)
    assert report["recipients"] == ["all@example.com"]


def test_no_recipients_or_disabled(db, monkeypatch):
    msg = {"type": "opened", "episode": _episode(kind="system", subject_type="camera", severity="notice")}
    report = episode_alerts.handle_message(msg, sender=lambda m, r: (True, None))
    assert report["sent"] is False and report["reason"] == "no recipients"

    episode_alerts.forget_all()
    monkeypatch.setattr(episode_alerts, "are_email_alerts_enabled", lambda: False)
    report = episode_alerts.handle_message(msg, sender=lambda m, r: (True, None))
    assert report["sent"] is False and report["reason"] == "disabled"


def test_worker_mails_when_a_real_episode_opens(db):
    _recipient(db, "guard@example.com", "Restricted Zone")
    sent = []
    episode_alerts.start_episode_alerts(sender=lambda m, r: (sent.append((m["Subject"], r)) or True, None))
    try:
        eid = episodes.open_episode(camera_id=4, camera_name="Tank farm cam", camera_location="Tank farm",
                                    kind="person_in_zone", title="Unknown person in restricted area",
                                    subject_type="unknown", subject_label="Unknown person", subject_id=None,
                                    severity="critical", zone_id=2, zone_name="Tank farm",
                                    attributes={"zone_type": "restricted"})
        deadline = time.monotonic() + 5
        while not sent and time.monotonic() < deadline:
            time.sleep(0.05)
    finally:
        episode_alerts.stop_episode_alerts()
    assert sent and sent[0][1] == ["guard@example.com"]
    assert sent[0][0] == "[Critical] Unknown person in restricted area - Tank farm"
    assert eid


def test_helmet_recipient_gets_ppe_alerts():
    from app.email_service import _recipient_accepts_alert
    assert _recipient_accepts_alert("Helmet Missing", "PPE Alerts")
    assert _recipient_accepts_alert("Vest Missing", "PPE Alerts")
    assert not _recipient_accepts_alert("Helmet Missing", "Restricted Zone")
    assert _recipient_accepts_alert("All Alerts", "Restricted Zone")
