import time
from datetime import datetime, timezone


def _open(kind="ppe_violation", severity="warning", **kw):
    from app import episodes
    base = dict(camera_id=1, camera_name="in room", camera_location="office", kind=kind,
                title="Helmet missing", subject_type="person", subject_label="Abhishek Kumar",
                subject_id="03", severity=severity, attributes={"helmet": False, "vest": True})
    base.update(kw)
    return episodes.open_episode(**base)


def test_open_creates_one_open_row_with_epochs(db):
    from app import episodes
    from app.database import Episode
    eid = _open()
    assert eid and eid.startswith("EP-1-")
    row = db.query(Episode).filter_by(episode_id=eid).one()
    assert row.status == "open" and row.ended_at is None and row.people_count == 1
    ser = episodes.serialize_episode(row)
    assert ser["episode_id"] == eid and ser["needs_action"] is True
    assert abs(ser["started_epoch"] - time.time()) < 5
    assert ser["ended_epoch"] is None and ser["duration_sec"] >= 0
    assert ser["attributes"] == {"helmet": False, "vest": True}


def test_touch_updates_people_count_and_last_seen(db):
    from app import episodes
    from app.database import Episode
    eid = _open()
    episodes.touch_episode(eid, people_count=2)
    row = db.query(Episode).filter_by(episode_id=eid).one()
    assert row.people_count == 2


def test_close_sets_ended_and_keeps_open_for_humans(db):
    from app import episodes
    from app.database import Episode
    eid = _open(severity="warning")
    episodes.close_episode(eid)
    row = db.query(Episode).filter_by(episode_id=eid).one()
    assert row.ended_at is not None
    assert row.status == "open"            # a person still has to close it out
    assert episodes.serialize_episode(row)["needs_action"] is True


def test_close_auto_resolves_info_episodes(db):
    from app import episodes
    from app.database import Episode
    eid = _open(kind="vehicle_in_zone", severity="info", subject_type="vehicle", subject_label="HR 26 CX 5580")
    episodes.close_episode(eid)
    row = db.query(Episode).filter_by(episode_id=eid).one()
    assert row.status == "resolved" and row.resolve_note == "Ended on camera"
    assert episodes.serialize_episode(row)["needs_action"] is False


def test_live_state_counts_only_unfinished_or_unresolved(db):
    from app import episodes
    a = _open(severity="critical", kind="restricted_presence", title="Unknown person in restricted area")
    b = _open(severity="info", kind="vehicle_in_zone", subject_type="vehicle", subject_label="PB 11 CT 0912")
    episodes.close_episode(b)                      # info + ended -> gone from live
    state = episodes.live_state()
    ids = [e["episode_id"] for e in state["open"]]
    assert a in ids and b not in ids
    assert state["counts"]["critical"] >= 1 and state["counts"]["needs_action"] >= 1
    assert "generated_epoch" in state


def test_live_counts_treat_unknown_person_as_people(db):
    from app import episodes
    before = episodes.live_state()["counts"]["people"]
    _open(subject_type="unknown", subject_label="Unknown Person", subject_id=None)
    assert episodes.live_state()["counts"]["people"] == before + 1


def test_list_and_get(db):
    from app import episodes
    eid = _open()
    got = episodes.get_episode(eid)
    assert got and got["episode_id"] == eid
    rows = episodes.list_episodes(status="open", camera_id=1, limit=5)
    assert any(r["episode_id"] == eid for r in rows)
    assert episodes.get_episode("EP-does-not-exist") is None


def test_find_adoptable_and_open_unended(db):
    from datetime import datetime, timedelta, timezone
    from app import episodes
    from app.database import Episode
    a = _open(kind="vehicle_in_zone", severity="info", subject_type="vehicle", subject_label="Truck", zone_id=77, zone_name="Bay 7", camera_id=9)
    b = _open(kind="vehicle_in_zone", severity="info", subject_type="vehicle", subject_label="Truck", zone_id=77, zone_name="Bay 7", camera_id=9)
    assert episodes.find_adoptable(kind="vehicle_in_zone", camera_id=9, zone_id=77, subject_type="vehicle", max_age_sec=900) == a
    assert episodes.find_adoptable(kind="vehicle_in_zone", camera_id=9, zone_id=77, subject_type="vehicle", max_age_sec=900, exclude=[a]) == b
    assert episodes.find_adoptable(kind="vehicle_in_zone", camera_id=9, zone_id=78, subject_type="vehicle", max_age_sec=900) is None
    assert episodes.find_adoptable(kind="vehicle_in_zone", camera_id=9, zone_id=77, subject_type="person", max_age_sec=900) is None

    # idle for > 60 s -> orphan candidate; freshly touched -> not
    row = db.query(Episode).filter_by(episode_id=a).one()
    row.last_seen_at = datetime.now(timezone.utc) - timedelta(seconds=120); db.commit()
    idle = episodes.open_unended(("vehicle_in_zone",), idle_for_sec=60)
    assert a in idle and b not in idle
    assert episodes.find_adoptable(kind="vehicle_in_zone", camera_id=9, zone_id=77, subject_type="vehicle", max_age_sec=90) == b


def test_as_live_event_rows_has_the_old_shape_for_every_kind(db):
    from app import episodes
    v = _open(kind="vehicle_in_zone", severity="info", subject_type="vehicle", subject_label="Car", subject_id=None,
              title="Car in Thar parking", zone_id=5, zone_name="Thar parking", camera_id=14, attributes={"vehicle_class": "car"})
    p = _open(camera_id=14)                                  # ppe_violation with helmet False / vest True
    episodes.close_episode(v)
    rows = episodes.as_live_event_rows(limit=50, camera_id=14)
    by_id = {r["event_id"]: r for r in rows}
    car, ppe = by_id[v], by_id[p]
    assert car["event_type"].startswith("Car in Thar parking — ended after") and car["helmet"] == "-" and car["zone_name"] == "Thar parking"
    assert car["status"] == "resolved" and car["person_name"] == "Car"
    assert ppe["event_type"] == "Helmet missing" and ppe["helmet"] == "No" and ppe["vest"] == "Yes" and ppe["face_match"] == "Yes"
    assert ppe["camera_name"] == "in room" and ppe["time"] and ppe["created_at"]
    assert rows[0]["event_id"] == p                          # newest first
