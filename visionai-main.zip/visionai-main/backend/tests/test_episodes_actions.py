import pytest


def _open():
    from app import episodes
    return episodes.open_episode(camera_id=2, camera_name="Bay 3", camera_location="Loading", kind="ppe_violation",
                                 title="Helmet missing", subject_type="person", subject_label="Unknown person",
                                 subject_id=None, severity="warning")


def test_acknowledge_then_resolve_with_note(db):
    from app import episodes
    eid = _open()
    acked = episodes.acknowledge(eid, "Ajitesh Dewan")
    assert acked["status"] == "acknowledged" and acked["acknowledged_by"] == "Ajitesh Dewan"
    assert acked["needs_action"] is True
    done = episodes.resolve(eid, "Ajitesh Dewan", "Loader given a helmet")
    assert done["status"] == "resolved" and done["resolve_note"] == "Loader given a helmet"
    assert done["needs_action"] is False


def test_resolve_requires_note(db):
    from app import episodes
    eid = _open()
    with pytest.raises(ValueError):
        episodes.resolve(eid, "Ajitesh Dewan", "   ")


def test_false_positive_closes_and_records_who(db):
    from app import episodes
    eid = _open()
    fp = episodes.mark_false_positive(eid, "Ajitesh Dewan")
    assert fp["status"] == "false_positive" and fp["resolved_by"] == "Ajitesh Dewan"
    assert fp["needs_action"] is False


def test_actions_on_unknown_id_return_none(db):
    from app import episodes
    assert episodes.acknowledge("EP-nope", "x") is None
    assert episodes.mark_false_positive("EP-nope", "x") is None
