import json
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient


class _FakeUser:
    email = "ops@example.com"
    full_name = "Ops Person"
    role = "user"


@pytest.fixture()
def client(db):
    from app import episodes_api
    from app.auth_dependencies import get_current_user, get_current_user_from_query
    app = FastAPI()
    app.include_router(episodes_api.router)
    app.dependency_overrides[get_current_user] = lambda: _FakeUser()
    app.dependency_overrides[get_current_user_from_query] = lambda: _FakeUser()
    return TestClient(app)


def _open(kind="ppe_violation", severity="warning"):
    from app import episodes
    return episodes.open_episode(camera_id=7, camera_name="Bay 5", camera_location="Loading", kind=kind,
                                 title="Helmet missing", subject_type="person", subject_label="Unknown person",
                                 subject_id=None, severity=severity)


def test_live_and_list_and_get(client):
    eid = _open()
    live = client.get("/api/episodes/live").json()
    assert live["ok"] and any(e["episode_id"] == eid for e in live["data"]["open"])
    assert live["data"]["counts"]["needs_action"] >= 1
    lst = client.get("/api/episodes", params={"status": "open", "camera_id": 7}).json()
    assert any(e["episode_id"] == eid for e in lst["data"])
    one = client.get(f"/api/episodes/{eid}").json()
    assert one["data"]["episode_id"] == eid
    assert client.get("/api/episodes/EP-missing").status_code == 404


def test_actions_via_http(client):
    eid = _open()
    r = client.post(f"/api/episodes/{eid}/acknowledge")
    assert r.status_code == 200 and r.json()["data"]["acknowledged_by"] == "Ops Person"
    r = client.post(f"/api/episodes/{eid}/resolve", json={"note": ""})
    assert r.status_code == 400 and r.json()["ok"] is False
    r = client.post(f"/api/episodes/{eid}/resolve", json={"note": "Helmet issued"})
    assert r.status_code == 200 and r.json()["data"]["status"] == "resolved"
    eid2 = _open()
    r = client.post(f"/api/episodes/{eid2}/false-positive")
    assert r.status_code == 200 and r.json()["data"]["status"] == "false_positive"


def test_stream_delivers_an_opened_event(db):
    """
    Starlette's TestClient buffers a response until the app finishes, which an
    SSE stream never does - so this test talks to a real uvicorn server on a
    local port, exactly as the browser and the phone app will.
    """
    import socket, threading, time
    import httpx
    import uvicorn
    from app import episodes_api
    from app.auth_dependencies import get_current_user

    app = FastAPI()
    app.include_router(episodes_api.router)
    app.dependency_overrides[get_current_user] = lambda: _FakeUser()

    # The stream checks a real token itself (no Depends session held open).
    import os
    from datetime import datetime, timedelta, timezone
    from jose import jwt
    from app.database import User
    if db.query(User).filter(User.email == "stream@example.com").first() is None:
        db.add(User(email="stream@example.com", employee_id="S1", full_name="Stream User", mobile="1",
                    department="Ops", password_hash="x", role="user", is_active=True)); db.commit()
    token = jwt.encode({"sub": "stream@example.com", "purpose": "access",
                        "exp": datetime.now(timezone.utc) + timedelta(minutes=5)},
                       os.environ["JWT_SECRET_KEY"], algorithm=os.environ["JWT_ALGORITHM"])

    with socket.socket() as s:
        s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
    server_thread = threading.Thread(target=server.run, daemon=True); server_thread.start()
    deadline = time.time() + 10
    while not server.started and time.time() < deadline:
        time.sleep(0.05)
    assert server.started, "uvicorn did not start"

    got = {}

    def reader():
        with httpx.stream("GET", f"http://127.0.0.1:{port}/api/episodes/stream",
                          params={"token": token}, timeout=10) as resp:
            got["status"] = resp.status_code
            got["ctype"] = resp.headers.get("content-type", "")
            got["buffering"] = resp.headers.get("x-accel-buffering", "")
            for line in resp.iter_lines():
                if line.startswith("data:"):
                    got["payload"] = json.loads(line[5:].strip())
                    break

    try:
        bad_status = httpx.get(f"http://127.0.0.1:{port}/api/episodes/stream", params={"token": "garbage"}, timeout=10).status_code
        t = threading.Thread(target=reader, daemon=True); t.start()
        time.sleep(1.0)                                   # let the subscription attach
        eid = _open()
        t.join(timeout=20)                                # generous: a loaded laptop must not fail this
    finally:
        server.should_exit = True
        server_thread.join(timeout=5)

    assert got["status"] == 200 and got["ctype"].startswith("text/event-stream")
    assert got["buffering"] == "no"                       # nginx must not buffer the stream
    assert got["payload"]["type"] == "opened" and got["payload"]["episode"]["episode_id"] == eid
    assert bad_status == 401                              # a garbage token is refused before streaming


def test_bulk_actions(client):
    a, b, c = _open(), _open(), _open()
    r = client.post("/api/episodes/bulk", json={"ids": [a, b, "EP-gone"], "action": "acknowledge"})
    assert r.status_code == 200
    data = r.json()["data"]
    assert sorted(e["episode_id"] for e in data["updated"]) == sorted([a, b])
    assert data["missing"] == ["EP-gone"]
    assert all(e["status"] == "acknowledged" and e["acknowledged_by"] == "Ops Person" for e in data["updated"])

    r = client.post("/api/episodes/bulk", json={"ids": [a, b], "action": "resolve", "note": ""})
    assert r.status_code == 400 and "note" in r.json()["message"].lower()

    r = client.post("/api/episodes/bulk", json={"ids": [a, b, a], "action": "resolve", "note": "Night shift briefed"})
    data = r.json()["data"]
    assert len(data["updated"]) == 2 and all(e["status"] == "resolved" and e["resolve_note"] == "Night shift briefed" for e in data["updated"])

    r = client.post("/api/episodes/bulk", json={"ids": [c], "action": "false_positive"})
    assert r.json()["data"]["updated"][0]["status"] == "false_positive"

    assert client.post("/api/episodes/bulk", json={"ids": [], "action": "acknowledge"}).status_code == 400
    assert client.post("/api/episodes/bulk", json={"ids": [c], "action": "delete"}).status_code == 400
    # Nothing is left needing action.
    live = client.get("/api/episodes/live").json()["data"]
    assert not any(e["episode_id"] in (a, b, c) for e in live["open"])


def test_keep_flag(client):
    from app import episodes
    a, b = _open(), _open()
    r = client.post(f"/api/episodes/{a}/keep", json={"keep": True})
    assert r.status_code == 200 and r.json()["data"]["attributes"]["keep"] is True
    assert r.json()["data"]["attributes"]["kept_by"] == "Ops Person"
    assert episodes.kept_episode_ids() == [a]
    r = client.post(f"/api/episodes/{a}/keep", json={"keep": False})
    assert "keep" not in r.json()["data"]["attributes"]
    assert episodes.kept_episode_ids() == []
    assert client.post("/api/episodes/EP-missing/keep", json={"keep": True}).status_code == 404
    assert b
