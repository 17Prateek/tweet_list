import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient


class _User:
    email = "ops@example.com"
    full_name = "Ops Person"
    role = "user"


class _Admin(_User):
    role = "super_admin"


def _open():
    from app import episodes
    return episodes.open_episode(camera_id=7, camera_name="Bay 5", camera_location="Loading", kind="ppe_violation",
                                 title="Helmet missing", subject_type="person", subject_label="Unknown person",
                                 subject_id=None, severity="warning")


def _client(user):
    from app import episodes_api
    from app.auth_dependencies import get_current_user
    app = FastAPI()
    app.include_router(episodes_api.router)
    app.dependency_overrides[get_current_user] = lambda: user
    return TestClient(app)


def test_delete_removes_rows_and_pictures(db, tmp_path, monkeypatch):
    from app import episodes
    monkeypatch.setattr(episodes, "EVIDENCE_DIR", tmp_path)
    a, b, c = _open(), _open(), _open()
    for name in (f"{a}.jpg", f"{a}-2.jpg", f"{a}-end.jpg", f"{b}.jpg", f"{c}.jpg"):
        (tmp_path / name).write_bytes(b"x")
    q = episodes.subscribe()
    try:
        out = episodes.delete_episodes([a, b, "EP-nope"], "Boss")
        assert sorted(out["deleted"]) == sorted([a, b]) and out["missing"] == ["EP-nope"]
        assert episodes.get_episode(a) is None and episodes.get_episode(c) is not None
        assert sorted(p.name for p in tmp_path.iterdir()) == [f"{c}.jpg"]
        msg = q.get(timeout=1)
        assert msg["type"] == "deleted" and sorted(msg["ids"]) == sorted([a, b])
    finally:
        episodes.unsubscribe(q)
    with pytest.raises(ValueError):
        episodes.delete_episodes([], "Boss")


def test_delete_route_is_super_admin_only(db):
    eid = _open()
    assert _client(_User()).post("/api/episodes/delete", json={"ids": [eid]}).status_code == 403
    r = _client(_Admin()).post("/api/episodes/delete", json={"ids": [eid]})
    assert r.status_code == 200 and r.json()["data"]["deleted"] == [eid]
    assert _client(_Admin()).post("/api/episodes/delete", json={"ids": []}).status_code == 400
