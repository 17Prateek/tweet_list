def _open_info():
    from app import episodes
    return episodes.open_episode(camera_id=4, camera_name="Truck Yard", camera_location="Yard", kind="vehicle_in_zone",
                                 title="Truck in Truck yard", subject_type="vehicle", subject_label="Truck", subject_id=None,
                                 severity="info", zone_id=7, zone_name="Truck yard", attributes={"vehicle_class": "truck", "limit_sec": 7200})


def test_escalate_raises_severity_and_publishes_updated(db):
    from app import episodes
    q = episodes.subscribe()
    try:
        eid = _open_info()
        q.get(timeout=1)                                          # the "opened" message
        out = episodes.escalate_episode(eid, severity="warning", title="Truck waiting 2 h 05 m — over the 2 h limit",
                                        attributes={"over_limit": True})
        assert out["severity"] == "warning" and out["needs_action"] is True
        assert out["title"].startswith("Truck waiting") and out["attributes"]["over_limit"] is True
        assert out["attributes"]["vehicle_class"] == "truck"      # merged, not replaced
        msg = q.get(timeout=1)
        assert msg["type"] == "updated" and msg["episode"]["episode_id"] == eid
    finally:
        episodes.unsubscribe(q)


def test_escalate_never_lowers_and_ignores_unknown(db):
    from app import episodes
    eid = _open_info()
    episodes.escalate_episode(eid, severity="critical")
    same = episodes.escalate_episode(eid, severity="info")
    assert same["severity"] == "critical"
    assert episodes.escalate_episode("EP-nope", severity="warning") is None


def test_escalated_episode_still_auto_resolves_only_if_info(db):
    from app import episodes
    eid = _open_info()
    episodes.escalate_episode(eid, severity="warning")
    episodes.close_episode(eid)
    row = episodes.get_episode(eid)
    assert row["ended_epoch"] and row["status"] == "open"        # a person now has to close it out
