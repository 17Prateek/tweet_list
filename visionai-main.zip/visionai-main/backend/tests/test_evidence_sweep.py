"""
The evidence sweep deletes old pictures - but never the pictures of an
episode someone marked keep, and never anything when the database is down.
"""
import os
import time
import types
from pathlib import Path

SRC = Path(__file__).resolve().parents[1].joinpath("app", "detection_service.py").read_text(encoding="utf-8")


def build(tmp_path, kept):
    s = SRC.index("def _sweep_evidence():")
    e = SRC.index("def _incident_sweeper_loop():")
    ns = dict(time=time, Path=Path, EVIDENCE_DIR=tmp_path, EVIDENCE_KEEP_DAYS=14, EVIDENCE_SWEEP_SEC=3600.0,
              _last_evidence_sweep=0.0, episodes=types.SimpleNamespace(kept_episode_ids=kept))
    exec(SRC[s:e], ns)
    return ns["_sweep_evidence"]


def _old(path):
    old = time.time() - 30 * 86400
    path.write_bytes(b"jpg")
    os.utime(path, (old, old))


def test_old_pictures_go_kept_ones_stay(tmp_path):
    _old(tmp_path / "EP-1-aaa.jpg")
    _old(tmp_path / "EP-1-aaa-end.jpg")
    _old(tmp_path / "EP-2-bbb.jpg")
    (tmp_path / "EP-3-ccc.jpg").write_bytes(b"jpg")      # fresh
    build(tmp_path, lambda: ["EP-1-aaa"])()
    assert sorted(p.name for p in tmp_path.iterdir()) == ["EP-1-aaa-end.jpg", "EP-1-aaa.jpg", "EP-3-ccc.jpg"]


def test_database_down_deletes_nothing(tmp_path):
    _old(tmp_path / "EP-2-bbb.jpg")

    def boom():
        raise RuntimeError("db down")
    build(tmp_path, boom)()
    assert (tmp_path / "EP-2-bbb.jpg").exists()
