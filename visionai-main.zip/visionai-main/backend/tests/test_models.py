from datetime import datetime, timezone


def test_episode_and_zone_tables_exist_and_round_trip(db):
    from app.database import Episode, CameraZone

    zone = CameraZone(camera_id=1, name="Loading Bay 3", zone_type="bay",
                      polygon_json="[[0.1,0.1],[0.9,0.1],[0.9,0.9],[0.1,0.9]]", limit_sec=14400)
    db.add(zone); db.commit(); db.refresh(zone)
    assert zone.id is not None and zone.is_active is True

    ep = Episode(
        episode_id="EP-1-20260915120000000000", camera_id=1, camera_name="in room", camera_location="office",
        kind="ppe_violation", title="Helmet missing", subject_type="person", subject_label="Abhishek Kumar",
        subject_id="03", severity="warning", status="open",
        started_at=datetime(2026, 9, 15, 12, 0, tzinfo=timezone.utc),
        last_seen_at=datetime(2026, 9, 15, 12, 0, tzinfo=timezone.utc),
        zone_id=zone.id, zone_name=zone.name, people_count=1, attributes_json='{"helmet": false, "vest": true}',
    )
    db.add(ep); db.commit(); db.refresh(ep)
    assert ep.id is not None
    assert ep.ended_at is None and ep.resolve_note is None and ep.site_id is None
