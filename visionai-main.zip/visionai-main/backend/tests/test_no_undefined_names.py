"""
detection_service imports torch, so it cannot be imported in this test
environment - but a NameError inside it only fires at runtime on the server,
per frame, silently (16 Sep 2026: STATIC_PERSON_SEC and detection_stats).
pyflakes catches both statically.
"""
import subprocess
import sys
from pathlib import Path

APP = Path(__file__).resolve().parent.parent / "app"


def test_pyflakes_finds_no_undefined_names():
    out = subprocess.run(
        [sys.executable, "-m", "pyflakes", str(APP), str(APP.parent / "main.py")],
        capture_output=True, text=True,
    ).stdout
    bad = [l for l in out.splitlines() if "undefined name" in l]
    assert not bad, "\n".join(bad)
