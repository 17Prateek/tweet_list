def _ids(result):
    return [track_id for track_id, _ in result]


def test_same_box_keeps_the_same_id(db):
    from app import tracks
    tracks.forget(1)
    box = (100, 100, 300, 260)
    a = _ids(tracks.update(1, "vehicle", [box], 10.0))
    b = _ids(tracks.update(1, "vehicle", [box], 10.5))
    c = _ids(tracks.update(1, "vehicle", [box], 11.0))
    assert a == b == c and len(a) == 1


def test_second_non_overlapping_box_gets_a_second_id(db):
    from app import tracks
    tracks.forget(2)
    first = tracks.update(2, "vehicle", [(0, 0, 100, 100)], 1.0)
    both = tracks.update(2, "vehicle", [(0, 0, 100, 100), (400, 400, 500, 500)], 1.5)
    ids = _ids(both)
    assert ids[0] == _ids(first)[0] and ids[1] != ids[0]


def test_slow_drift_keeps_the_id_and_a_jump_does_not(db):
    from app import tracks
    tracks.forget(3)
    box = [100, 100, 300, 260]
    first = _ids(tracks.update(3, "vehicle", [tuple(box)], 0.0))[0]
    for i in range(1, 20):
        box[0] += 10; box[2] += 10
        assert _ids(tracks.update(3, "vehicle", [tuple(box)], i * 0.5))[0] == first
    jumped = _ids(tracks.update(3, "vehicle", [(900, 900, 1100, 1060)], 11.0))[0]
    assert jumped != first


def test_track_is_forgotten_after_the_grace(db):
    from app import tracks
    tracks.forget(4)
    box = (10, 10, 60, 60)
    first = _ids(tracks.update(4, "vehicle", [box], 0.0))[0]
    assert _ids(tracks.update(4, "vehicle", [box], 30.0, forget_sec=60))[0] == first   # inside grace
    assert _ids(tracks.update(4, "vehicle", [box], 200.0, forget_sec=60))[0] != first  # 170 s unseen -> new


def test_kinds_do_not_share_tracks(db):
    from app import tracks
    tracks.forget(5)
    box = (10, 10, 60, 60)
    v = _ids(tracks.update(5, "vehicle", [box], 0.0))[0]
    p = _ids(tracks.update(5, "person", [box], 0.0))[0]
    assert v != p
