"""
The yard observers with a fake clock and a recording stand-in for the episode
engine. Zones are real rows on the test database.
"""
import types

import pytest


class Recorder:
    def __init__(self):
        self.calls = []
        self.n = 0

    def open_episode(self, **kw):
        self.n += 1
        self.calls.append(("open", kw))
        return f"EP-y-{self.n}"

    def touch_episode(self, eid, **kw):
        self.calls.append(("touch", eid, kw))

    def close_episode(self, eid, **kw):
        self.calls.append(("close", eid, kw))

    def escalate_episode(self, eid, **kw):
        self.calls.append(("escalate", eid, kw))
        return {"episode_id": eid}

    # restart resilience hooks (tests override these attributes as needed)
    adoptable = None
    orphans = []
    rows = {}

    def find_adoptable(self, **kw):
        self.calls.append(("find", kw))
        return self.adoptable

    def adopt_episode(self, eid, **kw):
        self.calls.append(("adopt", eid, kw))

    def get_episode(self, eid):
        return self.rows.get(eid)

    def open_unended(self, kinds, *, idle_for_sec):
        return list(self.orphans)

    def of(self, kind):
        return [c for c in self.calls if c[0] == kind]


SHAPE = (200, 400)  # h, w


def _zone(db, camera_id, name, zone_type, polygon, limit_sec=None):
    from app import zones
    from app.database import CameraZone
    z = CameraZone(camera_id=camera_id, name=name, zone_type=zone_type, polygon_json=str(polygon).replace("'", '"'), limit_sec=limit_sec)
    db.add(z); db.commit(); db.refresh(z)
    zones.bump_zone_version()
    return z


@pytest.fixture()
def yard(monkeypatch):
    from app import yard as yard_mod, tracks
    rec = Recorder()
    monkeypatch.setattr(yard_mod, "episodes", rec)
    yard_mod.reset_for_tests()
    tracks._tracks.clear()
    return yard_mod, rec


def _cam(cid, name="Truck Yard"):
    return types.SimpleNamespace(id=cid, camera_name=name, location="Yard (east)")


# Right half of the frame is "Bay 1"; a box at x 300-380 stands in it, x 20-100 does not.
BAY = [[0.5, 0], [1, 0], [1, 1], [0.5, 1]]
IN_BAY = (300, 100, 380, 190)
OUTSIDE = (20, 100, 100, 190)


def test_truck_in_bay_opens_one_episode_then_touches_then_closes_after_grace(db, yard):
    y, rec = yard
    _zone(db, 21, "Bay 1", "bay", BAY)
    cam = _cam(21)
    truck = [{"box": IN_BAY, "cls": "truck", "conf": 0.8}]

    for t in range(0, 7):                                  # 0..6 s, confirm is 5 s
        y.observe_vehicles(cam, truck, "FRAME", float(t), frame_shape=SHAPE)
    opens = rec.of("open")
    assert len(opens) == 1
    kw = opens[0][1]
    assert kw["kind"] == "vehicle_in_zone" and kw["severity"] == "info" and kw["subject_type"] == "vehicle"
    assert kw["subject_label"] == "Truck" and kw["title"] == "Truck in Bay 1"
    assert kw["zone_name"] == "Bay 1" and kw["attributes"]["vehicle_class"] == "truck"

    for t in range(7, 30):
        y.observe_vehicles(cam, truck, "FRAME", float(t), frame_shape=SHAPE)
    assert len(rec.of("open")) == 1 and rec.of("touch")

    y.sweep_yard(now_mono=40.0)                            # 10 s unseen: inside the 60 s grace
    assert not rec.of("close")
    y.sweep_yard(now_mono=95.0)                            # 65 s unseen: closed with the last picture
    closes = rec.of("close")
    assert closes and closes[0][1] == "EP-y-1" and closes[0][2]["frame"] == "FRAME"
    assert y.yard_state() == []


def test_flicker_inside_grace_keeps_the_same_episode(db, yard):
    y, rec = yard
    _zone(db, 22, "Bay 1", "bay", BAY)
    cam = _cam(22)
    truck = [{"box": IN_BAY, "cls": "truck", "conf": 0.8}]
    for t in range(0, 8):
        y.observe_vehicles(cam, truck, "FRAME", float(t), frame_shape=SHAPE)
    y.sweep_yard(now_mono=20.0)                            # gone 12 s
    for t in range(28, 40):                                # back again, same spot
        y.observe_vehicles(cam, truck, "FRAME", float(t), frame_shape=SHAPE)
    assert len(rec.of("open")) == 1 and not rec.of("close")


def test_vehicle_outside_every_zone_opens_nothing(db, yard):
    y, rec = yard
    _zone(db, 23, "Bay 1", "bay", BAY)
    for t in range(0, 20):
        y.observe_vehicles(_cam(23), [{"box": OUTSIDE, "cls": "car", "conf": 0.9}], "F", float(t), frame_shape=SHAPE)
    assert not rec.of("open")


def test_camera_without_zones_costs_nothing(db, yard):
    y, rec = yard
    for t in range(0, 20):
        y.observe_vehicles(_cam(24), [{"box": IN_BAY, "cls": "truck", "conf": 0.9}], "F", float(t), frame_shape=SHAPE)
    assert not rec.of("open") and y.yard_state() == []


def test_dwell_limit_escalates_once(db, yard):
    y, rec = yard
    _zone(db, 25, "Truck yard", "yard", BAY, limit_sec=120)
    cam = _cam(25)
    truck = [{"box": IN_BAY, "cls": "truck", "conf": 0.8}]
    for t in range(0, 101):                                # a frame every second, like a camera
        y.observe_vehicles(cam, truck, "FRAME", float(t), frame_shape=SHAPE)
    y.sweep_yard(now_mono=100.0)                           # opened at 5 s -> 95 s in zone: not yet
    assert not rec.of("escalate")
    for t in range(101, 131):
        y.observe_vehicles(cam, truck, "FRAME", float(t), frame_shape=SHAPE)
    y.sweep_yard(now_mono=130.0)                           # 125 s in zone: over the 120 s limit
    esc = rec.of("escalate")
    assert len(esc) == 1 and esc[0][1] == "EP-y-1"
    assert esc[0][2]["severity"] == "warning"
    assert esc[0][2]["title"] == "Truck waiting 2 m 05 s — over the 2 min limit"
    assert esc[0][2]["attributes"]["over_limit"] is True
    for t in range(131, 201):
        y.observe_vehicles(cam, truck, "FRAME", float(t), frame_shape=SHAPE)
    y.sweep_yard(now_mono=200.0)
    assert len(rec.of("escalate")) == 1                    # never twice


def test_person_in_restricted_zone_is_critical_and_named(db, yard):
    y, rec = yard
    _zone(db, 26, "Reactor door", "restricted", BAY)
    _zone(db, 26, "Bay 2", "bay", [[0, 0], [0.5, 0], [0.5, 1], [0, 1]])
    cam = _cam(26, "Reactor Section")
    unknown = [{"box": IN_BAY, "face_name": "Monitoring", "employee_id": "N/A", "helmet": True, "vest": True}]
    for t in range(0, 5):                                  # 3 s confirm
        y.observe_people_in_zones(cam, unknown, "FRAME", float(t), frame_shape=SHAPE)
    opens = rec.of("open")
    assert len(opens) == 1
    kw = opens[0][1]
    assert kw["kind"] == "person_in_zone" and kw["severity"] == "critical"
    assert kw["subject_type"] == "unknown" and kw["title"] == "Unknown person in restricted area"
    assert kw["zone_name"] == "Reactor door"

    ajay = [{"box": OUTSIDE, "face_name": "Ajay", "employee_id": "01", "helmet": True, "vest": True}]
    for t in range(0, 5):                                  # in Bay 2, not restricted -> nothing
        y.observe_people_in_zones(cam, ajay, "FRAME", float(t), frame_shape=SHAPE)
    assert len(rec.of("open")) == 1

    ajay_in = [{"box": IN_BAY, "face_name": "Ajay", "employee_id": "01", "helmet": True, "vest": True}]
    for t in range(10, 15):
        y.observe_people_in_zones(cam, ajay_in, "FRAME", float(t), frame_shape=SHAPE)
    kw = rec.of("open")[-1][1]
    assert kw["subject_type"] == "person" and kw["subject_label"] == "Ajay" and kw["title"] == "Ajay in restricted area"


def test_restrict_ppe_to_zones(db, yard):
    y, _ = yard
    people = [{"box": IN_BAY, "face_name": "x"}, {"box": OUTSIDE, "face_name": "y"}]
    assert y.restrict_ppe_to_zones(27, people, SHAPE) == people        # no ppe zone: whole frame
    _zone(db, 27, "Loading floor", "ppe", BAY)
    kept = y.restrict_ppe_to_zones(27, people, SHAPE)
    assert kept == [people[0]]


def test_after_restart_a_sighting_adopts_the_open_episode_and_keeps_its_clock(db, yard):
    import time
    y, rec = yard
    _zone(db, 28, "Bay 9", "bay", BAY, limit_sec=120)
    cam = _cam(28)
    truck = [{"box": IN_BAY, "cls": "truck", "conf": 0.8}]
    # an episode that was open before the restart, started 100 s ago on the wall clock
    rec.adoptable = "EP-old"
    rec.rows["EP-old"] = {"episode_id": "EP-old", "started_epoch": time.time() - 100, "severity": "info", "attributes": {}}
    for t in range(0, 7):
        y.observe_vehicles(cam, truck, "FRAME", 1000.0 + t, frame_shape=SHAPE)
    assert not rec.of("open") and rec.of("adopt")[0][1] == "EP-old"
    assert rec.of("find")[0][1]["zone_id"] is not None and rec.of("find")[0][1]["kind"] == "vehicle_in_zone"
    for t in range(7, 30):
        y.observe_vehicles(cam, truck, "FRAME", 1000.0 + t, frame_shape=SHAPE)
    assert any(c[0] == "touch" and c[1] == "EP-old" for c in rec.calls)
    y.sweep_yard(now_mono=1030.0)                          # 100 s before + 30 s now = 130 s > 120 s limit
    esc = rec.of("escalate")
    assert esc and esc[0][1] == "EP-old" and "over the 2 min limit" in esc[0][2]["title"]


def test_orphaned_open_episodes_are_closed_by_the_sweep(db, yard):
    y, rec = yard
    rec.orphans = ["EP-orphan"]
    y.sweep_yard(now_mono=5000.0)
    assert rec.of("close") and rec.of("close")[0][1] == "EP-orphan"
    rec.orphans = []
    y.sweep_yard(now_mono=5010.0)                          # throttled: no second pass inside 30 s anyway
    assert len(rec.of("close")) == 1


def test_zone_evidence_is_the_best_frame(db, yard):
    y, rec = yard
    _zone(db, 29, "Door", "restricted", BAY)
    cam = _cam(29)
    big = {"box": (300, 20, 390, 190), "face_name": "Monitoring"}            # large, inside, away from the edge
    edge = {"box": (330, 30, 400, 190), "face_name": "Monitoring"}           # same person, now cut off at the right edge
    y.observe_people_in_zones(cam, [big], "GOOD", 0.0, frame_shape=SHAPE)
    for t in range(1, 6):
        y.observe_people_in_zones(cam, [edge], f"EDGE{t}", float(t), frame_shape=SHAPE)
    opens = rec.of("open")
    assert opens and opens[0][1]["frame"] == "GOOD"
