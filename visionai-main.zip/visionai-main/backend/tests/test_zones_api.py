import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient


class _FakeUser:
    email = "ops@example.com"; full_name = "Ops Person"; role = "user"


@pytest.fixture()
def client(db):
    from app import episodes_api
    from app.auth_dependencies import get_current_user
    app = FastAPI()
    app.include_router(episodes_api.zones_router)
    app.dependency_overrides[get_current_user] = lambda: _FakeUser()
    return TestClient(app)


def test_zone_crud(client):
    body = {"camera_id": 4, "name": "Loading Bay 3", "zone_type": "bay",
            "polygon": [[0.1, 0.1], [0.9, 0.1], [0.9, 0.9], [0.1, 0.9]], "limit_sec": 14400}
    r = client.post("/api/zones", json=body)
    assert r.status_code == 200, r.text
    zid = r.json()["data"]["id"]
    assert r.json()["data"]["polygon"] == body["polygon"]

    r = client.get("/api/zones", params={"camera_id": 4}).json()
    assert any(z["id"] == zid for z in r["data"])

    r = client.put(f"/api/zones/{zid}", json={"limit_sec": 7200, "name": "Bay 3"})
    assert r.json()["data"]["limit_sec"] == 7200 and r.json()["data"]["name"] == "Bay 3"

    r = client.delete(f"/api/zones/{zid}")
    assert r.status_code == 200
    r = client.get("/api/zones", params={"camera_id": 4}).json()
    assert not any(z["id"] == zid for z in r["data"])


def test_zone_polygon_needs_three_points(client):
    r = client.post("/api/zones", json={"camera_id": 4, "name": "x", "zone_type": "bay", "polygon": [[0, 0], [1, 1]]})
    assert r.status_code == 400
