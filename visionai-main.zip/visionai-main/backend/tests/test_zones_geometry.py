def test_point_in_polygon_square_and_concave():
    from app.zones import point_in_polygon
    sq = [[0.1, 0.1], [0.9, 0.1], [0.9, 0.9], [0.1, 0.9]]
    assert point_in_polygon(0.5, 0.5, sq) and not point_in_polygon(0.05, 0.5, sq)
    l_shape = [[0, 0], [1, 0], [1, 0.5], [0.5, 0.5], [0.5, 1], [0, 1]]
    assert point_in_polygon(0.25, 0.75, l_shape) and not point_in_polygon(0.75, 0.75, l_shape)


def test_polygon_with_fewer_than_three_points_never_matches():
    from app.zones import point_in_polygon
    assert not point_in_polygon(0.5, 0.5, [[0, 0], [1, 1]])
    assert not point_in_polygon(0.5, 0.5, [])


def test_ground_point_is_bottom_centre_as_fractions():
    from app.zones import ground_point
    assert ground_point((100, 50, 300, 450), (480, 640)) == (200 / 640, 450 / 480)
    # clamped to the frame
    x, y = ground_point((-20, 0, 20, 900), (480, 640))
    assert x == 0.0 and y == 1.0


def test_zone_of_uses_cache_and_version(db):
    from app import zones
    from app.database import CameraZone
    z = CameraZone(camera_id=9, name="Bay 1", zone_type="bay",
                   polygon_json="[[0,0.5],[1,0.5],[1,1],[0,1]]", limit_sec=60)
    db.add(z); db.commit()
    zones.bump_zone_version()

    assert zones.zone_of(9, (0, 0, 100, 60), (200, 200)) is None            # ground point (0.25, 0.3): outside
    hit = zones.zone_of(9, (0, 150, 100, 190), (200, 200))                  # ground point (0.25, 0.95): inside
    assert hit and hit["name"] == "Bay 1" and hit["limit_sec"] == 60 and hit["zone_type"] == "bay"

    z.is_active = False; db.commit()
    assert zones.zone_of(9, (0, 150, 100, 190), (200, 200))                 # cached copy still served
    zones.bump_zone_version()
    assert zones.zone_of(9, (0, 150, 100, 190), (200, 200)) is None         # refreshed after the bump


def test_zone_of_can_be_limited_to_types(db):
    from app import zones
    from app.database import CameraZone
    db.add(CameraZone(camera_id=10, name="Door", zone_type="restricted", polygon_json="[[0,0],[1,0],[1,1],[0,1]]"))
    db.commit(); zones.bump_zone_version()
    assert zones.zone_of(10, (10, 10, 50, 50), (100, 100), types=("bay",)) is None
    assert zones.zone_of(10, (10, 10, 50, 50), (100, 100), types=("restricted",))["name"] == "Door"
    assert zones.has_zones(10, types=("ppe",)) is False
    assert zones.has_zones(10, types=("restricted",)) is True
