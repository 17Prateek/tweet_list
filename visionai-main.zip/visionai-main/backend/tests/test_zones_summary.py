import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient


class _FakeUser:
    email = "ops@example.com"; full_name = "Ops Person"; role = "user"


@pytest.fixture()
def client(db):
    from app import episodes_api
    from app.auth_dependencies import get_current_user
    app = FastAPI()
    app.include_router(episodes_api.zones_router)
    app.dependency_overrides[get_current_user] = lambda: _FakeUser()
    return TestClient(app)


def test_summary_lists_every_active_zone_with_live_counts(client):
    from app import episodes, zones
    poly = [[0, 0], [1, 0], [1, 1], [0, 1]]
    a = client.post("/api/zones", json={"camera_id": 31, "name": "Bay 1", "zone_type": "bay", "polygon": poly, "limit_sec": 3600}).json()["data"]
    b = client.post("/api/zones", json={"camera_id": 31, "name": "Gate", "zone_type": "gate", "polygon": poly}).json()["data"]

    eid = episodes.open_episode(camera_id=31, camera_name="Yard cam", camera_location=None, kind="vehicle_in_zone",
                                title="Truck in Bay 1", subject_type="vehicle", subject_label="Truck", subject_id=None,
                                severity="info", zone_id=a["id"], zone_name="Bay 1")
    episodes.open_episode(camera_id=31, camera_name="Yard cam", camera_location=None, kind="person_in_zone",
                          title="Unknown person in restricted area", subject_type="unknown", subject_label="Unknown Person",
                          subject_id=None, severity="critical", zone_id=a["id"], zone_name="Bay 1")

    rows = client.get("/api/zones/summary").json()["data"]
    by_name = {r["zone"]["name"]: r for r in rows}
    assert set(by_name) >= {"Bay 1", "Gate"}
    bay = by_name["Bay 1"]
    assert bay["vehicles"] == 1 and bay["people"] == 1 and bay["needs_action"] == 1
    assert eid in bay["open"] and bay["longest_sec"] >= 0 and bay["zone"]["limit_sec"] == 3600
    gate = by_name["Gate"]
    assert gate["open"] == [] and gate["vehicles"] == 0 and gate["longest_sec"] is None


def test_zone_writes_bump_the_detector_cache(client):
    from app import zones
    before = zones._version
    z = client.post("/api/zones", json={"camera_id": 32, "name": "x", "zone_type": "bay", "polygon": [[0, 0], [1, 0], [1, 1]]}).json()["data"]
    client.put(f"/api/zones/{z['id']}", json={"name": "y"})
    client.delete(f"/api/zones/{z['id']}")
    assert zones._version == before + 3
