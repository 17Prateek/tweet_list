# One-time server setup — link the VPS to GitHub

Everything below is typed into **WHM > Terminal** (you are root).
Replace `OWNER/visionai` with the real GitHub path once the repo exists.

## 1. Create a read-only "deploy key" on the server

A deploy key is a lock-and-key pair. The private half stays on the server;
the public half is registered on GitHub with **read-only** rights to this one
repo. The server can pull code but can never push, and the key is useless for
any other repo.

```
ssh-keygen -t ed25519 -N "" -C "visionai-vps-deploy" -f /root/.ssh/visionai_deploy
printf 'Host github.com\n  IdentityFile /root/.ssh/visionai_deploy\n  IdentitiesOnly yes\n' >> /root/.ssh/config
chmod 600 /root/.ssh/config /root/.ssh/visionai_deploy
cat /root/.ssh/visionai_deploy.pub
```

Copy the single line that `cat` prints (starts with `ssh-ed25519`).

## 2. Register it on GitHub

GitHub > the repo > **Settings > Deploy keys > Add deploy key**
- Title: `VPS QHSERC3`
- Key: paste the line
- Leave **Allow write access** UNTICKED
- Add key

## 3. Test and clone

```
ssh -T git@github.com
```
Expected: `Hi OWNER/visionai! You've successfully authenticated, but GitHub does not provide shell access.`
(If it hangs, port 22 is blocked — tell Claude; there is a port-443 fallback.)

```
git clone git@github.com:OWNER/visionai.git /home/paperlessops/visionai-repo
```

## 4. Replace the draft requirements.txt with the real one

```
cd /home/paperlessops/public_html/visionai-backend && venv/bin/pip freeze
```
Paste the output to Claude — it goes into `backend/requirements.txt` in the
repo, then gets committed. Until that is done the deploy script's
`pip install` step is a no-op for existing packages.

## 5. First deploy (should change nothing — main == production)

```
bash /home/paperlessops/visionai-repo/deploy/deploy-backend.sh
```

## 6. Node 22 for the frontend build (one-time)

The server's own Node is 16 (too old for Vite 8) and is left untouched.
This puts Node 22 LTS in `/opt/node22`, used only by `deploy-frontend.sh`:

```
cd /tmp && F=$(curl -s https://nodejs.org/dist/latest-v22.x/ | grep -o 'node-v22[0-9.]*-linux-x64.tar.xz' | head -1) && curl -sO "https://nodejs.org/dist/latest-v22.x/$F" && mkdir -p /opt/node22 && tar -xJf "$F" -C /opt/node22 --strip-components=1 && /opt/node22/bin/node -v && rm -f "$F"
```

## Rollback

Every deploy leaves `/home/paperlessops/visionai-backend-pre-deploy-<stamp>.tar.gz`.
To roll back: `git checkout <older commit>` in the repo clone and re-run the
deploy script, or untar the backup over the live folder and restart.

## Episodes API smoke test (after deploying the episode engine)

Run as root in the WHM Terminal after `deploy-backend.sh` reports `-> OK` and `active (running)`.
Everything below is read-only against the plant except step 5, which creates and closes one test episode.

### 1. The two new tables exist (created by `create_tables()` on startup)

```bash
cd /home/paperlessops/public_html/visionai-backend && venv/bin/python -c "from dotenv import load_dotenv; load_dotenv('.env'); from app.database import engine; from sqlalchemy import inspect; i=inspect(engine); print(sorted(t for t in i.get_table_names() if t in ('episodes','camera_zones')))"
```
Expected: `['camera_zones', 'episodes']`

### 2. Mint an access token (login is email + OTP, so mint it server-side instead)

```bash
cd /home/paperlessops/public_html/visionai-backend && TOKEN=$(venv/bin/python -c "from dotenv import load_dotenv; load_dotenv('.env'); from app.database import get_db_session, User; from app.auth_service import create_access_token; db=get_db_session(); u=db.query(User).filter(User.email=='ajiteshdewan@gmail.com').first(); print(create_access_token(u))") && echo "token ok: ${#TOKEN} chars"
```
Expected: `token ok: 2xx chars`

### 3. Live state answers

```bash
curl -s https://visionai-backend.paperlessops.com/api/episodes/live -H "Authorization: Bearer $TOKEN" | head -c 400; echo
```
Expected: `{"ok": true, "data": {"open": [...], "counts": {"critical": 0, ...}, "generated_epoch": ...}}`

### 4. The live stream stays open through nginx

```bash
curl -N --max-time 40 "https://visionai-backend.paperlessops.com/api/episodes/stream?token=$TOKEN"
```
Expected: `: connected`, then `: ping` roughly every 15 s until curl stops at 40 s.
If it closes before the first ping, raise `proxy_read_timeout` to `600s` in the nginx location for the backend and reload nginx.

### 5. An incident becomes an episode, and can be closed out

With monitoring on, stand in front of the "in room" camera without a helmet for ~5 s, then:

```bash
journalctl -u visionai-backend --no-pager -n 300 | grep -E "\[INCIDENT\] opened|\[EPISODE\]" | tail -5
```
Expected: an `[INCIDENT] opened ...` line and **no** `[EPISODE] open failed` line.

```bash
curl -s https://visionai-backend.paperlessops.com/api/episodes/live -H "Authorization: Bearer $TOKEN" | python3 -c "import sys,json; d=json.load(sys.stdin)['data']; print(d['counts']); print([(e['episode_id'], e['title'], e['subject_label'], e['severity'], e['needs_action']) for e in d['open']])"
```
Expected: a row like `('EP-1-...', 'Helmet missing', 'Unknown Person' or a name, 'warning', True)`.

```bash
EID=$(curl -s https://visionai-backend.paperlessops.com/api/episodes/live -H "Authorization: Bearer $TOKEN" | python3 -c "import sys,json; print(json.load(sys.stdin)['data']['open'][0]['episode_id'])") && curl -s -X POST "https://visionai-backend.paperlessops.com/api/episodes/$EID/acknowledge" -H "Authorization: Bearer $TOKEN" | head -c 200; echo
```
Expected: `"status": "acknowledged"`.

```bash
curl -s -X POST "https://visionai-backend.paperlessops.com/api/episodes/$EID/resolve" -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"note":"smoke test close-out"}' | head -c 200; echo
```
Expected: `"status": "resolved"` with the note; `/api/episodes/live` no longer lists it.

### 6. Existing behaviour untouched

The dashboard's live events and the alert emails must look exactly as before: one opening row with a picture, one "ended after" row. `/api/live-events` is unchanged.

## Yard engine smoke test (after deploying zones / vehicles)

Nothing here needs a plant. Deploy backend then frontend, hard-refresh, then:

### 1. Draw two zones on the office camera (Sidebar → Zones)

- **Reactor door** — type *Restricted area* — a box around the doorway.
- **Desk bay** — type *Loading bay* — time limit **1** minute — a box on the desk or the floor in front of the camera.

Both save with "created — the cameras use it within seconds". Back on the Ops Board the Plant map now shows the two zones instead of the camera tile.

### 2. Restricted zone raises a critical card

Walk into the doorway box and stand still ~3 s. Expected: a **critical** "Unknown person in restricted area" card (or your name if enrolled) within a few seconds; walk out and the row says "gone from camera" ~30 s later; resolve it with a note.

### 3. A vehicle gets a timer and escalates

Vehicles need a real vehicle in view — point a camera at the street (`--webcam` on the laptop, or a phone RTSP app aimed out of the window) and draw a *Yard / parking* zone on the road with a 1-minute limit. Expected in Happening now: "Car in <zone>" info row with a counting timer and "of 1 m 00 s"; after a minute the same row becomes a warning "Car waiting 1 m 05 s — over the 1 min limit" and a card appears; when the car leaves, the row closes ~60 s later.

```bash
journalctl -u visionai-backend --no-pager -n 300 | grep -E "\[YARD\]|\[ZONES\]|Yard processing|Yard sweep" | tail
```
Expected: nothing (these lines only appear on failures).

### 4. Nothing else changed

The office camera's helmet/vest alerts behave exactly as before (no *PPE required here* zone was drawn, so the whole frame still counts).

## Email alerts for zones and cameras (after deploying episode_alerts)

PPE emails are unchanged. Three more episode kinds now email, once per episode,
from a separate worker (`app/episode_alerts.py`) — the journal shows
`Episode alert worker started` at boot.

1. **Email Settings → recipient → Alert type**: pick *Restricted Zone*,
   *Vehicle Over Limit* or *Camera Offline* (or *All Alerts* for everything).
   A recipient set to *Helmet Missing* / *Vest Missing* now also receives PPE
   emails (before, only *All Alerts* did).
2. Walk into a restricted zone for 3 s → one email `[Critical] … in restricted area - <location>`
   with the picture attached and a link to the Ops Board.
3. Leave a car in a zone past its limit → one email `[Warning] Car waiting … - over the … limit`.
4. Repeat updates of the same episode send nothing more:
   `journalctl -u visionai-backend | grep "Episode alert"` shows one `sent` line per episode.
