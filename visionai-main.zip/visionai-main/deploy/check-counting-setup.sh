#!/usr/bin/env bash
# Check that Counting Management can actually start on this server, BEFORE
# deploying. Read-only: changes nothing, prints no secrets.
#
# Run on the server:  bash /home/paperlessops/visionai-repo/deploy/check-counting-setup.sh
#
# Counting needs one thing the deploy scripts cannot supply: the custom-trained
# box model. It lives on the server, not in git, and .env is never touched by a
# deploy - so the path has to be set by hand, once.
set -uo pipefail

LIVE=/home/paperlessops/public_html/visionai-backend
ENV_FILE="$LIVE/.env"
VAR=VISIONAI_BOX_MODEL_PATH

echo "== 1/3  Box model files actually on this server =="
FOUND=$(find "$LIVE" -name '*.pt' -not -path '*/venv/*' -size +1k 2>/dev/null)
if [ -z "$FOUND" ]; then
    echo "   !! No .pt model files found under $LIVE"
else
    echo "$FOUND" | while read -r f; do
        printf '   %s  (%s)\n' "$f" "$(du -h "$f" | cut -f1)"
    done
fi

echo
echo "== 2/3  What .env says =="
if [ ! -f "$ENV_FILE" ]; then
    echo "   !! $ENV_FILE does not exist"
    exit 1
fi

# Read the value without printing it to the screen.
CONFIGURED=$(grep -E "^${VAR}=" "$ENV_FILE" | tail -1 | cut -d= -f2- | tr -d '"' | tr -d "'")

if [ -z "$CONFIGURED" ]; then
    echo "   !! $VAR is NOT set in .env."
    echo "      Counting Management will refuse to start (the rest of the"
    echo "      backend is unaffected). Pick the right path from step 1 and add:"
    echo
    echo "        echo '${VAR}=/full/path/to/best.pt' >> $ENV_FILE"
    echo "        systemctl restart visionai-backend"
    exit 1
fi

echo "   $VAR is set."
if [ -f "$CONFIGURED" ]; then
    echo "   -> file exists: $CONFIGURED ($(du -h "$CONFIGURED" | cut -f1))"
else
    echo "   !! file does NOT exist at that path: $CONFIGURED"
    echo "      This is the usual mistake - the path was copied from a local"
    echo "      machine. Correct it to one of the paths listed in step 1."
    exit 1
fi

echo
echo "== 3/3  Can the model be loaded? =="
cd "$LIVE" || exit 1
if "$LIVE/venv/bin/python" - <<'PY'
import os, sys
from dotenv import load_dotenv
load_dotenv(".env")
path = os.getenv("VISIONAI_BOX_MODEL_PATH", "").strip()
try:
    from ultralytics import YOLO
    model = YOLO(path)
    names = getattr(model, "names", {}) or {}
    print(f"   -> loaded OK. classes: {names}")
    if 0 not in names and "0" not in names:
        print("   !! class id 0 is not in this model. Set VISIONAI_BOX_CLASS_ID")
        print("      to the id of the 'box' class listed above.")
except Exception as error:
    print(f"   !! could not load: {error}")
    sys.exit(1)
PY
then
    echo
    echo "Counting Management is ready. Safe to deploy."
else
    echo
    echo "!! Model did not load. Counting will not start; the rest of the"
    echo "   backend is unaffected, so deploying is still safe."
    exit 1
fi
