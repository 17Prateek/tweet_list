#!/usr/bin/env bash
# Deploy the backend from GitHub to production.
# Run on the server as root:  bash /home/paperlessops/visionai-repo/deploy/deploy-backend.sh
#
# What it does, in order:
#   1. backs up the live backend folder (tar.gz, timestamped)
#   2. pulls the latest main branch from GitHub into the repo clone
#   3. copies ONLY the code (main.py + app/) over the live folder
#      — .env, model files, evidence/, recordings/, monitoring_state.json are never touched
#   4. installs any new Python packages into the existing venv
#   5. checks the code imports cleanly BEFORE restarting
#   6. restarts the service and shows its status
set -euo pipefail

REPO=/home/paperlessops/visionai-repo
LIVE=/home/paperlessops/public_html/visionai-backend
SERVICE=visionai-backend
STAMP=$(date +%d%b-%H%M)

echo "== 1/6  Backing up $LIVE (code only, not media) =="
tar -czf "/home/paperlessops/visionai-backend-pre-deploy-$STAMP.tar.gz" \
    -C "$(dirname "$LIVE")" \
    --exclude='visionai-backend/evidence' \
    --exclude='visionai-backend/email_evidence' \
    --exclude='visionai-backend/recordings' \
    --exclude='visionai-backend/runs' \
    --exclude='visionai-backend/venv' \
    "$(basename "$LIVE")"
echo "   -> /home/paperlessops/visionai-backend-pre-deploy-$STAMP.tar.gz"

echo "== 2/6  Pulling latest main from GitHub =="
cd "$REPO"
git fetch origin
git checkout -q main
git reset -q --hard origin/main
echo "   -> now at $(git log -1 --format='%h  %s  (%an, %ad)' --date=short)"

echo "== 3/6  Copying code over live folder (rsync, code only) =="
rsync -a --delete \
    --exclude='__pycache__' \
    "$REPO/backend/app/" "$LIVE/app/"
cp "$REPO/backend/main.py" "$LIVE/main.py"
cp "$REPO/backend/requirements.txt" "$LIVE/requirements.txt"
chown -R paperlessops:paperlessops "$LIVE/app" "$LIVE/main.py" "$LIVE/requirements.txt"

echo "== 4/6  Installing Python packages (no-op if nothing changed) =="
"$LIVE/venv/bin/pip" install -q -r "$LIVE/requirements.txt"

echo "== 5/6  Import check before restart =="
cd "$LIVE"
if ! "$LIVE/venv/bin/python" -c "import main" 2>/tmp/visionai-import-err.txt; then
    echo "!! main.py does not import. NOT restarting. Error:"
    cat /tmp/visionai-import-err.txt
    echo "!! Live service is still running the previous code. Fix and re-run."
    exit 1
fi
echo "   -> OK"

echo "== 6/6  Restarting $SERVICE =="
systemctl restart "$SERVICE"
sleep 3
systemctl --no-pager --lines=15 status "$SERVICE" || true
echo
echo "Deploy finished. Check https://visionai.paperlessops.com"
