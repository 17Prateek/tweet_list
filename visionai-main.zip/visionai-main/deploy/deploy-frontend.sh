#!/usr/bin/env bash
# Build the frontend from GitHub and publish it to the live site.
# Run on the server as root:  bash /home/paperlessops/visionai-repo/deploy/deploy-frontend.sh
#
#   1. pulls latest main
#   2. npm ci + npm run build  (uses frontend/.env.production for the API URL)
#   3. backs up the current live site
#   4. copies dist/ into public_html/visionai, keeping .htaccess
set -euo pipefail

REPO=/home/paperlessops/visionai-repo
LIVE=/home/paperlessops/public_html/visionai
STAMP=$(date +%d%b-%H%M)

# Vite 8 needs Node >= 20.19. The system Node (16, AlmaLinux package) is left
# alone; a separate Node 22 lives in /opt/node22 just for this build.
[ -x /opt/node22/bin/node ] && export PATH=/opt/node22/bin:$PATH
command -v node >/dev/null || { echo "!! node not found. See deploy/SERVER-SETUP.md (Node 22 in /opt/node22)"; exit 1; }
NODE_MAJOR=$(node -v | cut -c2- | cut -d. -f1)
[ "$NODE_MAJOR" -ge 20 ] || { echo "!! node $(node -v) is too old for Vite 8 (need >= 20.19). Install Node 22 into /opt/node22 - see SERVER-SETUP.md"; exit 1; }

echo "== 1/4  Pulling latest main =="
cd "$REPO"
git fetch origin && git checkout -q main && git reset -q --hard origin/main
echo "   -> $(git log -1 --format='%h  %s' )"

echo "== 2/4  Building (node $(node -v)) =="
cd "$REPO/frontend"
npm ci --no-audit --no-fund
npm run build
[ -f dist/index.html ] || { echo "!! build produced no dist/index.html — aborting, live site untouched"; exit 1; }

echo "== 3/4  Backing up live site =="
tar -czf "/home/paperlessops/visionai-frontend-pre-deploy-$STAMP.tar.gz" -C "$(dirname "$LIVE")" "$(basename "$LIVE")"

echo "== 4/4  Publishing dist/ (keeping .htaccess) =="
rsync -a --delete --exclude='.htaccess' "$REPO/frontend/dist/" "$LIVE/"
chown -R paperlessops:paperlessops "$LIVE"
echo "Done. Hard-refresh https://visionai.paperlessops.com (Ctrl+Shift+R)"
