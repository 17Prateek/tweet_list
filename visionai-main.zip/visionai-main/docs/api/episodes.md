# Episodes API (for the Ops Board and the Android app)

Base URL: production `https://visionai-backend.paperlessops.com`; on-prem box `http://<box-ip>:8000`.
Auth: `Authorization: Bearer <access token>` from `POST /api/auth/login` (same as every other route).
All responses are JSON of the shape `{"ok": true, "data": ...}` or `{"ok": false, "message": "..."}`.

## What an episode is

One thing-in-progress seen by a camera: a PPE violation, a person in a restricted area, a vehicle
sitting in a bay, a camera gone offline. Exactly one record per episode; it is created when the
camera confirms the situation, updated while it continues, and marked ended when it stops — and
separately it is acknowledged / resolved by a person. Fields that matter to a client:

| field | meaning |
|---|---|
| `episode_id` | stable id, e.g. `EP-7-20260915153045123456-a1b2` |
| `kind` | `ppe_violation` · `restricted_presence` · `vehicle_in_zone` · `person_in_zone` · `system` |
| `title` | plain English, show as-is ("Helmet missing", "CAM-06 offline") |
| `subject_type` / `subject_label` | `person` "Abhishek Kumar", `vehicle` "HR 26 CX 5580", `camera` "CAM-06", `unknown` "Unknown person" |
| `subject_id` | enrolled person id / plate / camera id, or null |
| `camera_id`, `camera_name`, `camera_location` | where it was seen |
| `zone_id`, `zone_name` | the drawn zone, when the camera has zones (null today) |
| `severity` | `critical` · `warning` · `notice` · `info` (info = informational, never needs a person) |
| `status` | `open` → `acknowledged` → `resolved` / `false_positive` |
| `needs_action` | true while a human still has to deal with it — **this drives the Needs-action list and push notifications** |
| `started_epoch`, `ended_epoch` | seconds since 1970 (UTC). Timer = now − started_epoch while `ended_epoch` is null |
| `last_seen_epoch` | last time the camera still saw it (updated at most every 10 s) |
| `started_at`, `ended_at`, `acknowledged_at`, `resolved_at` | the same instants as ISO-8601 strings in plant local time, for display |
| `duration_sec` | server-computed duration at the time of the response |
| `acknowledged_by`, `resolved_by`, `resolve_note` | who did what; `resolved_by` is `"system"` for info episodes that simply ended |
| `evidence_first`, `evidence_last` | picture paths, e.g. `/evidence/EP-....jpg` — prefix with the base URL |
| `people_count` | how many people were involved (rises on new arrivals; `evidence_last` refreshes then) |
| `attributes` | free JSON: `{"helmet": false, "vest": true}` today; zone checks later |
| `site_id` | null today; reserved for multi-site accounts |

## Routes

- `GET /api/episodes/live`
  → `{ok, data: {open: [...], counts: {critical, warning, notice, info, needs_action, vehicles, people}, generated_epoch}}`
  Everything live right now (`status` open or acknowledged), oldest first. Poll this every 5 s if you are not using the stream. `counts.people` includes unrecognised people (`subject_type` `unknown`).
- `GET /api/episodes?status=open&kind=&camera_id=&since=<ISO>&until=<ISO>&limit=200` — history, newest first. `limit` 1–1000.
- `GET /api/episodes/{episode_id}` — one episode; 404 if unknown.
- `POST /api/episodes/{episode_id}/acknowledge` — "someone's on it". Idempotent.
- `POST /api/episodes/{episode_id}/resolve` body `{"note": "what was done"}` — note is **required** (400 `{"ok": false, "message": "A note is required to resolve"}` without one).
- `POST /api/episodes/{episode_id}/false-positive` — "not a real issue".
- `POST /api/episodes/{episode_id}/keep` — body `{keep: true|false}`. Kept episodes' pictures are never removed by the evidence sweep (`VISIONAI_EVIDENCE_KEEP_DAYS`, default 14); sets `attributes.keep` / `attributes.kept_by`.
- `POST /api/episodes/bulk` — the same three actions on many episodes at once. Body `{ids: ["EP-…", …], action: "acknowledge"|"resolve"|"false_positive", note: "…"}` (note required for resolve; max 200 ids). Reply `data: {updated: [episode, …], missing: ["EP-…"]}` — ids the server no longer knows come back in `missing` instead of failing the batch. Each updated episode is also published on the stream as an `action` message.
- `GET /api/episodes/stream?token=<access token>` — Server-Sent Events (`text/event-stream`). The token goes in the query string because `EventSource` cannot send headers.
  Each message is `event: episode` with JSON data `{type: "opened"|"updated"|"closed"|"action", episode: {...}}`.
  A `: ping` comment arrives every 15 s. On reconnect, call `/live` first to resync, then reopen the stream.

## Message types on the stream

| `type` | when |
|---|---|
| `opened` | the camera confirmed a new situation |
| `updated` | more people joined (people_count rose, fresh picture), **or the severity was raised** — e.g. a truck crossed its zone's time limit and went info → warning (same `episode_id`, `needs_action` flips to true) |
| `closed` | it ended on camera (`ended_epoch` now set; `needs_action` may still be true) |
| `action` | a person acknowledged / resolved / marked it not a real issue |

## Push notifications (phone app)

Send a notification when a stream message has `type == "opened"` **or** `type == "updated"` and `episode.needs_action == true` and you have not already notified for that `episode_id`;
title = `episode.title`, body = `subject_label · camera_name · zone_name`. Clear it when a later
message for the same `episode_id` has `needs_action == false`. Never notify for `severity == "info"`.

## Camera zones (`/api/zones`)

Named areas drawn on a camera picture; polygon points are fractions 0..1 of the frame width/height.

- `GET /api/zones?camera_id=` — list active zones (all cameras when `camera_id` is omitted).
- `GET /api/zones/summary?camera_id=` — every active zone with what is live in it: `{zone, open: [episode ids], vehicles, people, needs_action, worst (severity or null), longest_sec, lead (the first live episode or null)}`. The Plant map is drawn from this.
- `POST /api/zones` body `{camera_id, name, zone_type, polygon: [[x,y],...], limit_sec}` — create. `zone_type` is one of `gate`, `weighbridge`, `yard`, `bay`, `unloading_bay`, `restricted`, `ppe`, `custom`; `polygon` needs at least 3 points (400 otherwise); `limit_sec` is the "too long" threshold, null for none.
- `PUT /api/zones/{id}` — update any of the same fields.
- `DELETE /api/zones/{id}` — soft delete (`is_active = false`; it disappears from the list).

Zone shape: `{id, site_id, camera_id, name, zone_type, polygon, limit_sec, is_active}`.


## Arrivals (expected vehicles)

The gate office's list of trucks due on a day, each linked to the vehicle the cameras see. Status: `expected → arrived → on_site (location = zone of the open linked episode) → departed`.

- `GET /api/arrivals?date=YYYY-MM-DD` — rows for that plant-local day: `{id, date, plate, transporter, material, purpose, expected_time, notes, status, arrived_epoch, departed_epoch, location: {zone_name, camera_name, started_epoch, ended_epoch, over_limit} | null, visits: [...], created_by}`.
- `POST /api/arrivals` / `PUT /api/arrivals/{id}` — body `{date, plate, transporter?, material?, purpose: loading|unloading|other, expected_time?: "HH:MM", notes?}`. Plates are normalised to upper-case alphanumerics.
- `DELETE /api/arrivals/{id}`
- `POST /api/arrivals/{id}/arrived`, `POST /api/arrivals/{id}/departed` — manual stamps.
- `POST /api/arrivals/{id}/link` — body `{episode_id}` of a vehicle episode. Sets `arrived` if not yet, appends the visit, and stamps `attributes.plate` / `transporter` / `arrival_id` on the episode (so cards and Live Events show the plate). ANPR will call the same link by plate later.
