# Training the detection models on our own pictures

For the developer who owns model quality. Everything here is free-tier.

## What runs today

| Job | Model | File (`.env`) | Classes |
|---|---|---|---|
| People + vehicles | YOLOv8n, COCO pretrained | `PERSON_MODEL_PATH=yolov8n.pt` | person(0), car(2), motorcycle(3), bus(5), truck(7) |
| Helmet / vest | YOLOv8, custom | `PPE_MODEL_PATH` | helmet(0), vest(1) |
| Faces | YuNet + SFace (ONNX) | `YUNET_MODEL_PATH`, `SFACE_MODEL_PATH` | improves by enrolling more photos, no training |

Ultralytics `8.4.38` is pinned in `backend/requirements.txt`; train with the same version so the exported weights load unchanged.

The models do **not** learn from live video. They only change when we retrain and copy a new `.pt` file to the server.

## When to retrain

- Helmet/vest misses on the client's cameras (their lighting, angles, uniforms).
- A new class nobody has a pretrained model for: wheel chock, earthing clamp, tanker hose connected, cone.

Do **not** retrain the person/vehicle model first — COCO is already good at those; fix camera placement, resolution and `PERSON_CONF` / `VEHICLE_CONF` before touching it.

## 1. Collect pictures

Aim for **300–500 pictures per class** to start, from the real cameras, across day/night/rain and with people at different distances. Sources, in order of value:

1. **Evidence pictures** already saved in `backend/evidence/` on the server — every alert is a labelled-ish example, and every "Not a real issue" click is a *negative* example (the model was wrong there; those are the most valuable pictures of all).
2. `backend/scripts/collect_frames.py` on the server: one frame per camera per minute into `dataset/frames/`, plus every "Not a real issue" picture into `dataset/negatives/` (how to run it is at the top of the file).
3. Pictures from other factories (ask for them at the same resolution as a CCTV camera; phone photos help less).

Keep the client's pictures off public services — see the note under Roboflow.

## 2. Label

Draw one box per object, one class per box. Consistency matters more than volume: decide the rules first (is a helmet in hand a helmet? no; is a vest under a jacket a vest? no) and write them in the project's README.

Free tools:

| Tool | Cost | Privacy | Pick when |
|---|---|---|---|
| **CVAT** self-hosted | free, open source | pictures stay on your PC | client footage — **default choice** |
| Label Studio | free, open source | on your PC | you prefer its UI; same idea |
| Roboflow | free plan | **public workspace** — anyone can see the pictures | practice / non-client pictures only |

CVAT install (any PC with Docker Desktop):

```bash
git clone https://github.com/cvat-ai/cvat && cd cvat
docker compose up -d
docker exec -it cvat_server python3 manage.py createsuperuser
```

Open `http://localhost:8080`, create a project with labels `helmet`, `vest` (and any new class), upload the pictures, label, then **Export → YOLO 1.1** (a zip with `images/` and `labels/`).

CVAT has an "automatic annotation" mode that runs an existing model to pre-draw boxes so a person only corrects them — use our current `PPE_MODEL_PATH` weights for that once the first batch is labelled; it cuts labelling time by ~70%.

## 3. Train (free GPU)

Google Colab's free tier gives a T4 GPU — enough for YOLOv8n/s on a few thousand pictures in under an hour.

Dataset layout (unzip the CVAT export like this; 80/20 split between train and val):

```
ppe/
  data.yaml
  train/images/*.jpg   train/labels/*.txt
  val/images/*.jpg     val/labels/*.txt
```

`data.yaml`:

```yaml
path: /content/ppe
train: train/images
val: val/images
names: {0: helmet, 1: vest}
```

Colab cell:

```python
!pip install ultralytics==8.4.38
from ultralytics import YOLO
model = YOLO("yolov8n.pt")            # or the current PPE weights to continue from them
model.train(data="/content/ppe/data.yaml", epochs=60, imgsz=640, batch=32, patience=15)
```

Read `runs/detect/train/results.png`: `mAP50` on val is the number. Above ~0.85 for helmet/vest is fine for a plant; below 0.7 means more/better pictures, not more epochs.

Test on pictures the model has never seen (a different day, ideally a different camera) before trusting the number.

## 4. Deploy

1. Copy `runs/detect/train/weights/best.pt` to the server (`scp`), e.g. `/home/paperlessops/public_html/visionai-backend/models/ppe-2026-09.pt`.
2. Point `.env` at it: `PPE_MODEL_PATH=models/ppe-2026-09.pt`.
3. `sudo systemctl restart visionai-backend`, then walk in front of a camera without a helmet and check the Ops Board.
4. Keep the previous file; if the new one is worse, change the path back and restart.

Class ids must stay `helmet=0, vest=1` (`HELMET_CLASS_ID` / `VEST_CLASS_ID` in `detection_service.py`). A new class gets the next id and needs a matching few lines in `detection_service.py` before it shows up anywhere.

## Rules of thumb

- Camera 3 m above the bay beats a better model on a camera 20 m away. Fix placement first.
- 200 pictures from the client's camera beat 2,000 from the internet.
- Retrain every time the site changes (new uniforms, new camera, monsoon lighting). Keep every dataset version; never delete labelled pictures.
