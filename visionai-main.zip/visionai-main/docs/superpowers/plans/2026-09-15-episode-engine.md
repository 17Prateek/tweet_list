# Episode Engine Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Turn the in-memory "two text rows per incident" model into first-class **Episode** rows (one row per thing-in-progress, with start/end, subject, zone, severity and an acknowledge → resolve-with-note lifecycle), exposed through a live-state API and a Server-Sent-Events feed, while the existing dashboard keeps working unchanged.

**Architecture:** A new module `backend/app/episodes.py` owns episode state (DB rows + a small in-memory index of open episodes + an in-process publish/subscribe bus). `detection_service.py` keeps its proven confirm/grace/arrival logic and is edited in four surgical places to *also* open/touch/close an episode (dual-write; `LiveEvent` rows continue exactly as today). A new FastAPI router `backend/app/episodes_api.py` serves live state, history, actions (acknowledge / resolve / not-a-real-issue), an SSE stream, and camera-zone CRUD. The new Ops Board frontend and the Android app build only on this router.

**Tech Stack:** Python 3.12, FastAPI 0.136 / Starlette 1.6, SQLAlchemy 2.0.49, PostgreSQL in production (SQLite for tests), python-jose JWT (existing), pytest + httpx for tests.

## Global Constraints

- All code goes through the GitHub repo `ajdewan/visionai`, deployed with `deploy/deploy-backend.sh`. Never zip uploads.
- **No database migrations exist.** New *tables* are created automatically by `create_tables()` at startup (`Base.metadata.create_all`). Never add a column to an existing table in this plan — only new tables (`episodes`, `camera_zones`).
- `backend/app/episodes.py` and `backend/app/episodes_api.py` must import **nothing heavy** (no `ultralytics`, no `detection_service`, no `camera_management`). They may import `app.database`, `app.live_event_service` (cv2 only), `app.timezone_util`, `app.auth_dependencies`.
- Existing behaviour must not change: `LiveEvent` rows, email alerts, `/api/live-events`, the incident confirm (3 s) / grace (120 s) / arrival logic all stay exactly as they are.
- Times are stored **UTC**, shown local via `app.timezone_util.to_local_time` (same as today). Every serialised episode also carries `started_epoch` / `ended_epoch` (seconds since 1970, UTC) so the frontend can run counting timers without timezone maths.
- Severity values: `critical` | `warning` | `notice` | `info`. Status values: `open` | `acknowledged` | `resolved` | `false_positive`. Kinds: `ppe_violation` | `restricted_presence` | `vehicle_in_zone` | `person_in_zone` | `system`.
- **Resolving requires a note.** An empty note is rejected with HTTP 400.
- Episodes with severity `info` auto-resolve when they end on camera (nothing for a human to do). Every other severity stays open after ending until a person resolves it — that is the audit trail.
- `site_id` and `zone_id` exist on the new tables from day one (nullable, no foreign key yet) so multi-tenant and zones can be added without touching the schema again.
- Commit after every task with the message shown; end commit messages with `Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>`.

## File Structure

| File | Responsibility |
|---|---|
| `backend/requirements-dev.txt` | (new) light test dependencies pinned to the server's versions |
| `backend/pytest.ini` | (new) pytest config; points `DATABASE_URL` at SQLite for tests |
| `backend/tests/conftest.py` | (new) fresh SQLite DB per test session, `db` fixture |
| `backend/app/database.py` | (modify) add `Episode` and `CameraZone` models |
| `backend/app/episodes.py` | (new) episode engine: open/touch/close, actions, live state, serialisation, publish/subscribe bus, camera-offline sweep |
| `backend/app/auth_dependencies.py` | (modify) extract `user_from_access_token()`; add `get_current_user_from_query()` for SSE |
| `backend/app/episodes_api.py` | (new) `APIRouter`: `/api/episodes/*` and `/api/zones/*` |
| `backend/main.py` | (modify) `include_router`; call the camera-offline sweep from startup |
| `backend/app/detection_service.py` | (modify) dual-write into the episode engine at open / touch / arrival / close; call the camera sweep from the existing sweeper loop |
| `backend/.env.example` | (modify) document new knobs |
| `docs/api/episodes.md` | (new) the API contract the Android developer builds against |
| `backend/tests/test_models.py`, `test_episodes.py`, `test_episodes_actions.py`, `test_bus.py`, `test_auth_query_token.py`, `test_episodes_api.py`, `test_zones_api.py`, `test_detection_dualwrite.py`, `test_camera_offline.py` | (new) one test file per task |

---

### Task 0: Local test environment

**Files:**
- Create: `backend/requirements-dev.txt`
- Create: `backend/pytest.ini`
- Create: `backend/tests/__init__.py` (empty)
- Create: `backend/tests/conftest.py`

**Interfaces:**
- Produces: a `db` pytest fixture yielding a SQLAlchemy `Session` on a fresh SQLite file; `app.database` importable in tests with `DATABASE_URL` set before import.

- [ ] **Step 1: Write the dev requirements (pinned to what the server runs)**

```text
# backend/requirements-dev.txt
# Light subset for running the test-suite on a laptop. Production uses requirements.txt.
fastapi==0.136.0
starlette==1.6.0
SQLAlchemy==2.0.49
pydantic==2.13.2
python-jose==3.5.0
passlib==1.7.4
bcrypt==5.0.0
python-dotenv==1.2.2
python-multipart==0.0.26
email-validator==2.3.0
uvicorn==0.44.0
httpx==0.28.1
pytest==8.4.1
```

- [ ] **Step 2: Write pytest.ini so tests never touch a real database**

```ini
# backend/pytest.ini
[pytest]
testpaths = tests
env =
addopts = -q
```

(`DATABASE_URL` is set in `conftest.py` before `app.database` is imported — pytest.ini cannot set env vars without a plugin, so the fixture file does it.)

- [ ] **Step 3: Write conftest.py**

```python
# backend/tests/conftest.py
"""
Every test session gets its own SQLite file. DATABASE_URL must be set BEFORE
app.database is imported, because that module builds the engine at import.
"""
import os
import sys
import tempfile
from pathlib import Path

_TMP = Path(tempfile.mkdtemp(prefix="visionai-tests-"))
os.environ["DATABASE_URL"] = f"sqlite:///{(_TMP / 'test.db').as_posix()}"
os.environ.setdefault("JWT_SECRET_KEY", "test-secret-key-not-for-production")
os.environ.setdefault("JWT_ALGORITHM", "HS256")
os.environ.setdefault("VISIONAI_TIMEZONE", "Asia/Kolkata")

# Make `app.*` importable when pytest runs from backend/
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest  # noqa: E402

from app import database  # noqa: E402


@pytest.fixture(scope="session", autouse=True)
def _create_schema():
    database.create_tables()
    yield


@pytest.fixture()
def db():
    session = database.get_db_session()
    try:
        yield session
    finally:
        session.close()
```

- [ ] **Step 4: Create the venv and install**

Run (from `backend/`, Git Bash):
```bash
python -m venv .venv && source .venv/Scripts/activate && pip install -q -r requirements-dev.txt && python -c "import fastapi, sqlalchemy, jose, pytest; print('dev env OK')"
```
Expected: `dev env OK`

- [ ] **Step 5: Prove the fixture works with a trivial test**

```python
# backend/tests/test_env.py
def test_database_is_sqlite(db):
    from app import database
    assert database.DATABASE_URL.startswith("sqlite:///")
```

Run: `pytest tests/test_env.py -v`
Expected: `1 passed`

- [ ] **Step 6: Ignore the venv and test db; commit**

Add to `backend/.gitignore` (create if missing):
```text
.venv/
tests/_*.db
```

```bash
git add backend/requirements-dev.txt backend/pytest.ini backend/tests/__init__.py backend/tests/conftest.py backend/tests/test_env.py backend/.gitignore
git commit -m "test: local pytest environment on SQLite, pinned to server versions

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

### Task 1: Episode and CameraZone models

**Files:**
- Modify: `backend/app/database.py` (add two classes after `LiveEvent`, before `FaceRecognitionEvent`)
- Test: `backend/tests/test_models.py`

**Interfaces:**
- Produces: `app.database.Episode` and `app.database.CameraZone` ORM classes with the exact columns below. Everything later reads/writes these.

- [ ] **Step 1: Write the failing test**

```python
# backend/tests/test_models.py
from datetime import datetime, timezone


def test_episode_and_zone_tables_exist_and_round_trip(db):
    from app.database import Episode, CameraZone

    zone = CameraZone(camera_id=1, name="Loading Bay 3", zone_type="bay",
                      polygon_json="[[0.1,0.1],[0.9,0.1],[0.9,0.9],[0.1,0.9]]", limit_sec=14400)
    db.add(zone); db.commit(); db.refresh(zone)
    assert zone.id is not None and zone.is_active is True

    ep = Episode(
        episode_id="EP-1-20260915120000000000", camera_id=1, camera_name="in room", camera_location="office",
        kind="ppe_violation", title="Helmet missing", subject_type="person", subject_label="Abhishek Kumar",
        subject_id="03", severity="warning", status="open",
        started_at=datetime(2026, 9, 15, 12, 0, tzinfo=timezone.utc),
        last_seen_at=datetime(2026, 9, 15, 12, 0, tzinfo=timezone.utc),
        zone_id=zone.id, zone_name=zone.name, people_count=1, attributes_json='{"helmet": false, "vest": true}',
    )
    db.add(ep); db.commit(); db.refresh(ep)
    assert ep.id is not None
    assert ep.ended_at is None and ep.resolve_note is None and ep.site_id is None
```

- [ ] **Step 2: Run it to confirm it fails**

Run: `pytest tests/test_models.py -v`
Expected: FAIL — `ImportError: cannot import name 'Episode'`

- [ ] **Step 3: Add the models**

In `backend/app/database.py`, immediately after the `LiveEvent` class (after its `camera = relationship("Camera")` line) add:

```python
class CameraZone(Base):
    """
    A named area drawn on one camera's picture: gate, weighbridge, yard,
    a loading bay, a restricted area. polygon_json holds [[x, y], ...] with
    x/y as fractions 0..1 of the frame, so it survives resolution changes.
    limit_sec is the "too long" threshold for that zone (None = no limit).
    """
    __tablename__ = "camera_zones"

    id = Column(Integer, primary_key=True, index=True)
    site_id = Column(Integer, nullable=True)
    camera_id = Column(Integer, ForeignKey("cameras.id"), nullable=False, index=True)
    name = Column(String(150), nullable=False)
    zone_type = Column(String(40), nullable=False, default="custom")
    polygon_json = Column(Text, nullable=False)
    limit_sec = Column(Integer, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class Episode(Base):
    """
    One thing-in-progress seen by a camera: a PPE violation, a person in a
    restricted zone, a vehicle sitting in a bay, a camera gone offline.
    Exactly one row per episode; started_at..ended_at is its life on camera,
    status is the human side (open -> acknowledged -> resolved / false_positive).
    """
    __tablename__ = "episodes"

    id = Column(Integer, primary_key=True, index=True)
    episode_id = Column(String(80), unique=True, nullable=False, index=True)
    site_id = Column(Integer, nullable=True)

    camera_id = Column(Integer, ForeignKey("cameras.id"), nullable=False, index=True)
    camera_name = Column(String(150), nullable=False)
    camera_location = Column(String(150), nullable=True)
    zone_id = Column(Integer, nullable=True)
    zone_name = Column(String(150), nullable=True)

    kind = Column(String(40), nullable=False, index=True)
    title = Column(String(200), nullable=False)
    subject_type = Column(String(20), nullable=False, default="unknown")
    subject_label = Column(String(150), nullable=False, default="Unknown")
    subject_id = Column(String(80), nullable=True)

    severity = Column(String(20), nullable=False, default="warning", index=True)
    status = Column(String(20), nullable=False, default="open", index=True)

    started_at = Column(DateTime(timezone=True), nullable=False, index=True)
    last_seen_at = Column(DateTime(timezone=True), nullable=False)
    ended_at = Column(DateTime(timezone=True), nullable=True)

    acknowledged_by = Column(String(150), nullable=True)
    acknowledged_at = Column(DateTime(timezone=True), nullable=True)
    resolved_by = Column(String(150), nullable=True)
    resolved_at = Column(DateTime(timezone=True), nullable=True)
    resolve_note = Column(Text, nullable=True)

    evidence_first = Column(Text, nullable=True)
    evidence_last = Column(Text, nullable=True)
    people_count = Column(Integer, nullable=False, default=1)
    attributes_json = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    camera = relationship("Camera")
```

- [ ] **Step 4: Run the test**

Run: `pytest tests/test_models.py -v`
Expected: `1 passed`

- [ ] **Step 5: Commit**

```bash
git add backend/app/database.py backend/tests/test_models.py
git commit -m "feat(episodes): Episode and CameraZone tables

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

### Task 2: Episode engine core — open, touch, close, serialise, live state

**Files:**
- Create: `backend/app/episodes.py`
- Test: `backend/tests/test_episodes.py`

**Interfaces:**
- Produces (all in `app.episodes`):
  - `open_episode(*, camera_id:int, camera_name:str, camera_location:str|None, kind:str, title:str, subject_type:str, subject_label:str, subject_id:str|None, severity:str, frame=None, zone_id:int|None=None, zone_name:str|None=None, people_count:int=1, attributes:dict|None=None, site_id:int|None=None) -> str | None` — returns the `episode_id`, or `None` if the row could not be saved.
  - `touch_episode(episode_id:str, *, frame=None, people_count:int|None=None) -> None`
  - `close_episode(episode_id:str, *, frame=None) -> None`
  - `serialize_episode(row) -> dict`
  - `live_state() -> dict` with keys `open` (list of serialised open episodes), `counts` (`{"critical":n,"warning":n,"notice":n,"info":n,"needs_action":n,"vehicles":n,"people":n}`), `generated_epoch` (float)
  - `list_episodes(*, status=None, kind=None, camera_id=None, since=None, until=None, limit=200) -> list[dict]`
  - `get_episode(episode_id) -> dict | None`
  - Module constant `TOUCH_DB_WRITE_SEC = 10.0`

- [ ] **Step 1: Write the failing tests**

```python
# backend/tests/test_episodes.py
import time
from datetime import datetime, timezone


def _open(kind="ppe_violation", severity="warning", **kw):
    from app import episodes
    base = dict(camera_id=1, camera_name="in room", camera_location="office", kind=kind,
                title="Helmet missing", subject_type="person", subject_label="Abhishek Kumar",
                subject_id="03", severity=severity, attributes={"helmet": False, "vest": True})
    base.update(kw)
    return episodes.open_episode(**base)


def test_open_creates_one_open_row_with_epochs(db):
    from app import episodes
    from app.database import Episode
    eid = _open()
    assert eid and eid.startswith("EP-1-")
    row = db.query(Episode).filter_by(episode_id=eid).one()
    assert row.status == "open" and row.ended_at is None and row.people_count == 1
    ser = episodes.serialize_episode(row)
    assert ser["episode_id"] == eid and ser["needs_action"] is True
    assert abs(ser["started_epoch"] - time.time()) < 5
    assert ser["ended_epoch"] is None and ser["duration_sec"] >= 0
    assert ser["attributes"] == {"helmet": False, "vest": True}


def test_touch_updates_people_count_and_last_seen(db):
    from app import episodes
    from app.database import Episode
    eid = _open()
    episodes.touch_episode(eid, people_count=2)
    row = db.query(Episode).filter_by(episode_id=eid).one()
    assert row.people_count == 2


def test_close_sets_ended_and_keeps_open_for_humans(db):
    from app import episodes
    from app.database import Episode
    eid = _open(severity="warning")
    episodes.close_episode(eid)
    row = db.query(Episode).filter_by(episode_id=eid).one()
    assert row.ended_at is not None
    assert row.status == "open"            # a person still has to close it out
    assert episodes.serialize_episode(row)["needs_action"] is True


def test_close_auto_resolves_info_episodes(db):
    from app import episodes
    from app.database import Episode
    eid = _open(kind="vehicle_in_zone", severity="info", subject_type="vehicle", subject_label="HR 26 CX 5580")
    episodes.close_episode(eid)
    row = db.query(Episode).filter_by(episode_id=eid).one()
    assert row.status == "resolved" and row.resolve_note == "Ended on camera"
    assert episodes.serialize_episode(row)["needs_action"] is False


def test_live_state_counts_only_unfinished_or_unresolved(db):
    from app import episodes
    a = _open(severity="critical", kind="restricted_presence", title="Unknown person in restricted area")
    b = _open(severity="info", kind="vehicle_in_zone", subject_type="vehicle", subject_label="PB 11 CT 0912")
    episodes.close_episode(b)                      # info + ended -> gone from live
    state = episodes.live_state()
    ids = [e["episode_id"] for e in state["open"]]
    assert a in ids and b not in ids
    assert state["counts"]["critical"] >= 1 and state["counts"]["needs_action"] >= 1
    assert "generated_epoch" in state


def test_list_and_get(db):
    from app import episodes
    eid = _open()
    got = episodes.get_episode(eid)
    assert got and got["episode_id"] == eid
    rows = episodes.list_episodes(status="open", camera_id=1, limit=5)
    assert any(r["episode_id"] == eid for r in rows)
    assert episodes.get_episode("EP-does-not-exist") is None
```

- [ ] **Step 2: Run to confirm they fail**

Run: `pytest tests/test_episodes.py -v`
Expected: FAIL — `ModuleNotFoundError: No module named 'app.episodes'`

- [ ] **Step 3: Write the module**

```python
# backend/app/episodes.py
"""
Episode engine.

One Episode row per thing-in-progress seen by a camera. detection_service
opens/touches/closes episodes; the API reads live state and records human
actions; the Ops Board and the phone app subscribe to the live bus.

Keep this module light: it must import without the detection models.
"""
from __future__ import annotations

import json
import queue
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from app.database import Episode, get_db_session
from app.live_event_service import save_evidence_image
from app.timezone_util import to_local_time

SEVERITIES = ("critical", "warning", "notice", "info")
STATUSES = ("open", "acknowledged", "resolved", "false_positive")

# Write last_seen_at to the database at most this often per open episode.
TOUCH_DB_WRITE_SEC = 10.0

# Open episodes: episode_id -> {"last_db_write": mono, "people_count": int}
_open_index: Dict[str, Dict[str, Any]] = {}
_lock = threading.Lock()

# ---------------------------------------------------------------------------
# Time helpers
# ---------------------------------------------------------------------------

def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _as_utc(value: Optional[datetime]) -> Optional[datetime]:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def _epoch(value: Optional[datetime]) -> Optional[float]:
    value = _as_utc(value)
    return value.timestamp() if value else None


def _local_iso(value: Optional[datetime]) -> Optional[str]:
    return to_local_time(_as_utc(value)).isoformat() if value else None


# ---------------------------------------------------------------------------
# Serialisation
# ---------------------------------------------------------------------------

def needs_action(row: Episode) -> bool:
    """True while a person still has to deal with this episode."""
    return row.status in ("open", "acknowledged") and row.severity != "info"


def serialize_episode(row: Episode) -> Dict[str, Any]:
    started = _as_utc(row.started_at)
    ended = _as_utc(row.ended_at)
    end_for_duration = ended or _utcnow()
    duration = max(0.0, (end_for_duration - started).total_seconds()) if started else 0.0

    try:
        attributes = json.loads(row.attributes_json) if row.attributes_json else {}
    except ValueError:
        attributes = {}

    return {
        "episode_id": row.episode_id,
        "site_id": row.site_id,
        "camera_id": row.camera_id,
        "camera_name": row.camera_name,
        "camera_location": row.camera_location,
        "zone_id": row.zone_id,
        "zone_name": row.zone_name,
        "kind": row.kind,
        "title": row.title,
        "subject_type": row.subject_type,
        "subject_label": row.subject_label,
        "subject_id": row.subject_id,
        "severity": row.severity,
        "status": row.status,
        "needs_action": needs_action(row),
        "started_at": _local_iso(row.started_at),
        "started_epoch": _epoch(row.started_at),
        "last_seen_epoch": _epoch(row.last_seen_at),
        "ended_at": _local_iso(row.ended_at),
        "ended_epoch": _epoch(row.ended_at),
        "duration_sec": round(duration, 1),
        "acknowledged_by": row.acknowledged_by,
        "acknowledged_at": _local_iso(row.acknowledged_at),
        "resolved_by": row.resolved_by,
        "resolved_at": _local_iso(row.resolved_at),
        "resolve_note": row.resolve_note,
        "evidence_first": row.evidence_first,
        "evidence_last": row.evidence_last,
        "people_count": row.people_count,
        "attributes": attributes,
    }


# ---------------------------------------------------------------------------
# Lifecycle: open / touch / close
# ---------------------------------------------------------------------------

def _new_episode_id(camera_id: int) -> str:
    return f"EP-{int(camera_id)}-{datetime.now().strftime('%Y%m%d%H%M%S%f')}"


def open_episode(
    *,
    camera_id: int,
    camera_name: str,
    camera_location: Optional[str],
    kind: str,
    title: str,
    subject_type: str,
    subject_label: str,
    subject_id: Optional[str],
    severity: str,
    frame=None,
    zone_id: Optional[int] = None,
    zone_name: Optional[str] = None,
    people_count: int = 1,
    attributes: Optional[Dict[str, Any]] = None,
    site_id: Optional[int] = None,
) -> Optional[str]:
    """Create the row (database first, picture second). Returns episode_id or None."""
    if severity not in SEVERITIES:
        severity = "warning"

    episode_id = _new_episode_id(camera_id)
    now = _utcnow()
    db = get_db_session()

    try:
        row = Episode(
            episode_id=episode_id, site_id=site_id,
            camera_id=int(camera_id), camera_name=camera_name, camera_location=camera_location,
            zone_id=zone_id, zone_name=zone_name,
            kind=kind, title=str(title)[:200],
            subject_type=subject_type, subject_label=str(subject_label)[:150], subject_id=subject_id,
            severity=severity, status="open",
            started_at=now, last_seen_at=now,
            people_count=max(1, int(people_count)),
            attributes_json=json.dumps(attributes or {}),
        )
        db.add(row)
        db.commit()

        if frame is not None:
            picture = save_evidence_image(frame, episode_id)
            if picture:
                row.evidence_first = picture
                row.evidence_last = picture
                db.commit()

        with _lock:
            _open_index[episode_id] = {"last_db_write": time.monotonic(), "people_count": row.people_count}

        publish({"type": "opened", "episode": serialize_episode(row)})
        return episode_id

    except Exception as exc:
        try:
            db.rollback()
        except Exception:
            pass
        print("[EPISODE] open failed:", exc)
        return None

    finally:
        db.close()


def touch_episode(episode_id: str, *, frame=None, people_count: Optional[int] = None) -> None:
    """
    Still being seen. Cheap by design: the database is written at most every
    TOUCH_DB_WRITE_SEC, or immediately when the people count rises (that is a
    new arrival and deserves a fresh picture + a live update).
    """
    now_mono = time.monotonic()

    with _lock:
        entry = _open_index.get(episode_id)
        if entry is None:
            return
        arrival = people_count is not None and people_count > entry["people_count"]
        due = now_mono - entry["last_db_write"] >= TOUCH_DB_WRITE_SEC
        if not (arrival or due):
            return
        entry["last_db_write"] = now_mono
        if people_count is not None:
            entry["people_count"] = max(entry["people_count"], people_count)
        new_count = entry["people_count"]

    db = get_db_session()
    try:
        row = db.query(Episode).filter(Episode.episode_id == episode_id).first()
        if row is None:
            return
        row.last_seen_at = _utcnow()
        if new_count != row.people_count:
            row.people_count = new_count
        if arrival and frame is not None:
            picture = save_evidence_image(frame, f"{episode_id}-{new_count}")
            if picture:
                row.evidence_last = picture
        db.commit()
        if arrival:
            publish({"type": "updated", "episode": serialize_episode(row)})
    except Exception as exc:
        try:
            db.rollback()
        except Exception:
            pass
        print("[EPISODE] touch failed:", exc)
    finally:
        db.close()


def close_episode(episode_id: str, *, frame=None) -> None:
    """Ended on camera. Info-severity episodes need nobody, so they auto-resolve."""
    with _lock:
        _open_index.pop(episode_id, None)

    db = get_db_session()
    try:
        row = db.query(Episode).filter(Episode.episode_id == episode_id).first()
        if row is None or row.ended_at is not None:
            return
        now = _utcnow()
        row.ended_at = now
        row.last_seen_at = now
        if frame is not None:
            picture = save_evidence_image(frame, f"{episode_id}-end")
            if picture:
                row.evidence_last = picture
        if row.severity == "info" and row.status in ("open", "acknowledged"):
            row.status = "resolved"
            row.resolved_by = "system"
            row.resolved_at = now
            row.resolve_note = "Ended on camera"
        db.commit()
        publish({"type": "closed", "episode": serialize_episode(row)})
    except Exception as exc:
        try:
            db.rollback()
        except Exception:
            pass
        print("[EPISODE] close failed:", exc)
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Reads
# ---------------------------------------------------------------------------

def _live_query(db):
    """Live = still on camera, or ended but a human has not closed it out."""
    return db.query(Episode).filter(
        (Episode.ended_at.is_(None)) | (Episode.status.in_(("open", "acknowledged")))
    ).filter(Episode.status.in_(("open", "acknowledged")))


def live_state() -> Dict[str, Any]:
    db = get_db_session()
    try:
        rows = _live_query(db).order_by(Episode.started_at.asc()).all()
        items = [serialize_episode(r) for r in rows]
    finally:
        db.close()

    counts = {"critical": 0, "warning": 0, "notice": 0, "info": 0, "needs_action": 0, "vehicles": 0, "people": 0}
    for item in items:
        counts[item["severity"]] = counts.get(item["severity"], 0) + 1
        if item["needs_action"]:
            counts["needs_action"] += 1
        if item["subject_type"] == "vehicle":
            counts["vehicles"] += 1
        elif item["subject_type"] == "person":
            counts["people"] += 1

    return {"open": items, "counts": counts, "generated_epoch": time.time()}


def list_episodes(*, status=None, kind=None, camera_id=None, since=None, until=None, limit=200) -> List[Dict[str, Any]]:
    db = get_db_session()
    try:
        q = db.query(Episode)
        if status:
            q = q.filter(Episode.status == status)
        if kind:
            q = q.filter(Episode.kind == kind)
        if camera_id is not None:
            q = q.filter(Episode.camera_id == int(camera_id))
        if since is not None:
            q = q.filter(Episode.started_at >= since)
        if until is not None:
            q = q.filter(Episode.started_at <= until)
        rows = q.order_by(Episode.started_at.desc()).limit(max(1, min(int(limit), 1000))).all()
        return [serialize_episode(r) for r in rows]
    finally:
        db.close()


def get_episode(episode_id: str) -> Optional[Dict[str, Any]]:
    db = get_db_session()
    try:
        row = db.query(Episode).filter(Episode.episode_id == episode_id).first()
        return serialize_episode(row) if row else None
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Live bus (in-process publish/subscribe; filled in by Task 4)
# ---------------------------------------------------------------------------

_subscribers: List["queue.Queue"] = []
_subscribers_lock = threading.Lock()


def subscribe() -> "queue.Queue":
    q: "queue.Queue" = queue.Queue(maxsize=500)
    with _subscribers_lock:
        _subscribers.append(q)
    return q


def unsubscribe(q: "queue.Queue") -> None:
    with _subscribers_lock:
        if q in _subscribers:
            _subscribers.remove(q)


def publish(message: Dict[str, Any]) -> None:
    with _subscribers_lock:
        targets = list(_subscribers)
    for q in targets:
        try:
            q.put_nowait(message)
        except queue.Full:
            # A dead or very slow listener must never block the camera loop.
            pass
```

- [ ] **Step 4: Run the tests**

Run: `pytest tests/test_episodes.py -v`
Expected: `6 passed`

- [ ] **Step 5: Commit**

```bash
git add backend/app/episodes.py backend/tests/test_episodes.py
git commit -m "feat(episodes): engine core - open/touch/close, live state, serialisation

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

### Task 3: Human actions — acknowledge, resolve (note required), not a real issue

**Files:**
- Modify: `backend/app/episodes.py` (append)
- Test: `backend/tests/test_episodes_actions.py`

**Interfaces:**
- Produces: `acknowledge(episode_id, user_label:str) -> dict | None`, `resolve(episode_id, user_label:str, note:str) -> dict | None` (raises `ValueError("A note is required to resolve")` when `note.strip()` is empty), `mark_false_positive(episode_id, user_label:str) -> dict | None`. Each returns the serialised episode after the change, or `None` if not found.

- [ ] **Step 1: Write the failing tests**

```python
# backend/tests/test_episodes_actions.py
import pytest


def _open():
    from app import episodes
    return episodes.open_episode(camera_id=2, camera_name="Bay 3", camera_location="Loading", kind="ppe_violation",
                                 title="Helmet missing", subject_type="person", subject_label="Unknown person",
                                 subject_id=None, severity="warning")


def test_acknowledge_then_resolve_with_note(db):
    from app import episodes
    eid = _open()
    acked = episodes.acknowledge(eid, "Ajitesh Dewan")
    assert acked["status"] == "acknowledged" and acked["acknowledged_by"] == "Ajitesh Dewan"
    assert acked["needs_action"] is True
    done = episodes.resolve(eid, "Ajitesh Dewan", "Loader given a helmet")
    assert done["status"] == "resolved" and done["resolve_note"] == "Loader given a helmet"
    assert done["needs_action"] is False


def test_resolve_requires_note(db):
    from app import episodes
    eid = _open()
    with pytest.raises(ValueError):
        episodes.resolve(eid, "Ajitesh Dewan", "   ")


def test_false_positive_closes_and_records_who(db):
    from app import episodes
    eid = _open()
    fp = episodes.mark_false_positive(eid, "Ajitesh Dewan")
    assert fp["status"] == "false_positive" and fp["resolved_by"] == "Ajitesh Dewan"
    assert fp["needs_action"] is False


def test_actions_on_unknown_id_return_none(db):
    from app import episodes
    assert episodes.acknowledge("EP-nope", "x") is None
    assert episodes.mark_false_positive("EP-nope", "x") is None
```

- [ ] **Step 2: Run to confirm they fail**

Run: `pytest tests/test_episodes_actions.py -v`
Expected: FAIL — `AttributeError: module 'app.episodes' has no attribute 'acknowledge'`

- [ ] **Step 3: Append the actions to `app/episodes.py`**

```python
# ---------------------------------------------------------------------------
# Human actions
# ---------------------------------------------------------------------------

def _apply_action(episode_id: str, mutate) -> Optional[Dict[str, Any]]:
    db = get_db_session()
    try:
        row = db.query(Episode).filter(Episode.episode_id == episode_id).first()
        if row is None:
            return None
        mutate(row)
        db.commit()
        result = serialize_episode(row)
        publish({"type": "action", "episode": result})
        return result
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def acknowledge(episode_id: str, user_label: str) -> Optional[Dict[str, Any]]:
    def mutate(row: Episode):
        if row.status == "open":
            row.status = "acknowledged"
            row.acknowledged_by = str(user_label)[:150]
            row.acknowledged_at = _utcnow()
    return _apply_action(episode_id, mutate)


def resolve(episode_id: str, user_label: str, note: str) -> Optional[Dict[str, Any]]:
    note = (note or "").strip()
    if not note:
        raise ValueError("A note is required to resolve")

    def mutate(row: Episode):
        row.status = "resolved"
        row.resolved_by = str(user_label)[:150]
        row.resolved_at = _utcnow()
        row.resolve_note = note
        if row.acknowledged_at is None:
            row.acknowledged_by = row.resolved_by
            row.acknowledged_at = row.resolved_at
    return _apply_action(episode_id, mutate)


def mark_false_positive(episode_id: str, user_label: str) -> Optional[Dict[str, Any]]:
    def mutate(row: Episode):
        row.status = "false_positive"
        row.resolved_by = str(user_label)[:150]
        row.resolved_at = _utcnow()
        row.resolve_note = "Marked not a real issue"
    return _apply_action(episode_id, mutate)
```

- [ ] **Step 4: Run the tests**

Run: `pytest tests/test_episodes_actions.py tests/test_episodes.py -v`
Expected: `10 passed`

- [ ] **Step 5: Commit**

```bash
git add backend/app/episodes.py backend/tests/test_episodes_actions.py
git commit -m "feat(episodes): acknowledge / resolve-with-note / not-a-real-issue

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

### Task 4: Live bus behaviour

**Files:**
- Test: `backend/tests/test_bus.py` (the bus code already exists in `app/episodes.py` from Task 2; this task proves it and fixes anything the test reveals)

**Interfaces:**
- Consumes: `episodes.subscribe()`, `episodes.unsubscribe(q)`, `episodes.publish(msg)`; messages are dicts `{"type": "opened"|"updated"|"closed"|"action", "episode": <serialised>}`.

- [ ] **Step 1: Write the failing test**

```python
# backend/tests/test_bus.py
import queue


def test_subscriber_receives_open_update_close_and_action(db):
    from app import episodes
    q = episodes.subscribe()
    try:
        eid = episodes.open_episode(camera_id=3, camera_name="Gate", camera_location=None, kind="ppe_violation",
                                    title="Vest missing", subject_type="person", subject_label="Unknown person",
                                    subject_id=None, severity="warning")
        episodes.touch_episode(eid, people_count=2)      # arrival -> "updated"
        episodes.acknowledge(eid, "Ops")                 # -> "action"
        episodes.close_episode(eid)                      # -> "closed"
        types = [q.get(timeout=1)["type"] for _ in range(4)]
        assert types == ["opened", "updated", "action", "closed"]
    finally:
        episodes.unsubscribe(q)


def test_slow_subscriber_never_blocks_publisher(db):
    from app import episodes
    q = episodes.subscribe()
    try:
        for _ in range(600):                              # queue maxsize is 500
            episodes.publish({"type": "opened", "episode": {}})
        assert q.qsize() == 500                           # extras dropped, no exception
    finally:
        episodes.unsubscribe(q)


def test_unsubscribed_queue_gets_nothing(db):
    from app import episodes
    q = episodes.subscribe(); episodes.unsubscribe(q)
    episodes.publish({"type": "opened", "episode": {}})
    assert q.empty()
```

- [ ] **Step 2: Run it**

Run: `pytest tests/test_bus.py -v`
Expected: `3 passed` (if a test fails, fix `publish`/`touch_episode` in `app/episodes.py` until it passes — the contract is the test)

- [ ] **Step 3: Commit**

```bash
git add backend/tests/test_bus.py backend/app/episodes.py
git commit -m "test(episodes): live bus contract

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

### Task 5: Token-in-query authentication for the SSE stream

Browsers' `EventSource` cannot send an `Authorization` header, so the stream accepts `?token=<access JWT>`. The JWT rules stay in one place.

**Files:**
- Modify: `backend/app/auth_dependencies.py`
- Test: `backend/tests/test_auth_query_token.py`

**Interfaces:**
- Produces: `user_from_access_token(token: str, db: Session) -> User` (raises the same `HTTPException`s `get_current_user` raises); `get_current_user_from_query(token: str = Query(...), db: Session = Depends(get_db)) -> User`.

- [ ] **Step 1: Write the failing test**

```python
# backend/tests/test_auth_query_token.py
import os
import pytest
from datetime import datetime, timedelta, timezone
from jose import jwt


def _make_user(db, email="ops@example.com", role="user"):
    from app.database import User
    u = db.query(User).filter(User.email == email).first()
    if u is None:
        u = User(email=email, employee_id="E1", full_name="Ops Person", mobile="9999999999",
                 department="Safety", password_hash="x", role=role, is_active=True)
        db.add(u); db.commit()
    return u


def _token(email, purpose="access"):
    payload = {"sub": email, "purpose": purpose, "exp": datetime.now(timezone.utc) + timedelta(minutes=5)}
    return jwt.encode(payload, os.environ["JWT_SECRET_KEY"], algorithm=os.environ["JWT_ALGORITHM"])


def test_valid_access_token_returns_user(db):
    from app.auth_dependencies import user_from_access_token
    _make_user(db)
    user = user_from_access_token(_token("ops@example.com"), db)
    assert user.email == "ops@example.com"


def test_reset_token_is_rejected(db):
    from fastapi import HTTPException
    from app.auth_dependencies import user_from_access_token
    _make_user(db)
    with pytest.raises(HTTPException):
        user_from_access_token(_token("ops@example.com", purpose="reset"), db)


def test_garbage_token_is_rejected(db):
    from fastapi import HTTPException
    from app.auth_dependencies import user_from_access_token
    with pytest.raises(HTTPException):
        user_from_access_token("not-a-jwt", db)
```

- [ ] **Step 2: Run to confirm it fails**

Run: `pytest tests/test_auth_query_token.py -v`
Expected: FAIL — `ImportError: cannot import name 'user_from_access_token'`

- [ ] **Step 3: Refactor `get_current_user` around a shared helper**

In `backend/app/auth_dependencies.py`, add `Query` to the fastapi import:
```python
from fastapi import (
    Depends,
    HTTPException,
    Query,
    status,
)
```

Then, immediately **above** `def get_current_user(`, add the helper. Its body is steps 4–9 of the existing `get_current_user` moved verbatim (decode, purpose check, email, DB load, active, role):

```python
def user_from_access_token(token: str, db: Session) -> User:
    """
    The one place that turns an access JWT into the current database User.
    Used by the Authorization-header path and by the ?token= path for the
    live stream (EventSource cannot send headers).
    """
    try:
        payload = jwt.decode(token, JWT_SECRET_KEY, algorithms=[JWT_ALGORITHM])
    except JWTError:
        raise authentication_error("Invalid or expired access token")

    purpose = str(payload.get("purpose") or "").strip().lower()
    if purpose != "access":
        raise authentication_error("Invalid access token")

    email = str(payload.get("sub") or payload.get("email") or "").strip().lower()
    if not email:
        raise authentication_error("Invalid access token")

    user = db.query(User).filter(User.email == email).first()
    if user is None:
        raise authentication_error("User account no longer exists")

    if not bool(user.is_active):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="User account is inactive")

    role = str(user.role or "").strip().lower()
    if role not in {"user", "super_admin"}:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="User role is not authorized")

    return user
```

Now replace the body of `get_current_user` from its step 4 (`try: payload = jwt.decode(`) through its final `return user` with a single line:

```python
    return user_from_access_token(token, db)
```

(Keep steps 1–3 of `get_current_user` — the header/credentials reading that produces `token` and the "Access token is missing" error — exactly as they are.)

Finally add, after `get_current_user`:

```python
def get_current_user_from_query(
    token: str = Query(..., description="Access token, for clients that cannot send headers (EventSource)"),
    db: Session = Depends(get_db),
) -> User:
    if not token:
        raise authentication_error("Access token is missing")
    return user_from_access_token(token, db)
```

- [ ] **Step 4: Run the tests**

Run: `pytest tests/test_auth_query_token.py -v`
Expected: `3 passed`

- [ ] **Step 5: Commit**

```bash
git add backend/app/auth_dependencies.py backend/tests/test_auth_query_token.py
git commit -m "auth: share JWT->user logic; accept ?token= for the live stream

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

### Task 6: Episodes API router + SSE stream + API contract doc

**Files:**
- Create: `backend/app/episodes_api.py`
- Modify: `backend/main.py` (one import + one `include_router` line, next to the other `from app...` imports and after `app = FastAPI(...)`)
- Create: `docs/api/episodes.md`
- Test: `backend/tests/test_episodes_api.py`

**Interfaces:**
- Produces HTTP endpoints (all require auth):
  - `GET /api/episodes/live` → `{"ok": true, "data": live_state()}`
  - `GET /api/episodes?status=&kind=&camera_id=&since=&until=&limit=` → `{"ok": true, "data": [ ... ]}`
  - `GET /api/episodes/{episode_id}` → `{"ok": true, "data": {...}}` or 404
  - `POST /api/episodes/{episode_id}/acknowledge` → `{"ok": true, "data": {...}}`
  - `POST /api/episodes/{episode_id}/resolve` body `{"note": "..."}` → 200, or 400 `{"ok": false, "message": "A note is required to resolve"}`
  - `POST /api/episodes/{episode_id}/false-positive` → 200
  - `GET /api/episodes/stream?token=<jwt>` → `text/event-stream`; events named `episode` with a JSON body `{"type": ..., "episode": {...}}`; a `: ping` comment every 15 s
- Consumes: everything from `app.episodes` (Tasks 2–4), `get_current_user` / `get_current_user_from_query` (Task 5).

- [ ] **Step 1: Write the failing tests**

```python
# backend/tests/test_episodes_api.py
import json
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient


class _FakeUser:
    email = "ops@example.com"
    full_name = "Ops Person"
    role = "user"


@pytest.fixture()
def client(db):
    from app import episodes_api
    from app.auth_dependencies import get_current_user, get_current_user_from_query
    app = FastAPI()
    app.include_router(episodes_api.router)
    app.dependency_overrides[get_current_user] = lambda: _FakeUser()
    app.dependency_overrides[get_current_user_from_query] = lambda: _FakeUser()
    return TestClient(app)


def _open(kind="ppe_violation", severity="warning"):
    from app import episodes
    return episodes.open_episode(camera_id=7, camera_name="Bay 5", camera_location="Loading", kind=kind,
                                 title="Helmet missing", subject_type="person", subject_label="Unknown person",
                                 subject_id=None, severity=severity)


def test_live_and_list_and_get(client):
    eid = _open()
    live = client.get("/api/episodes/live").json()
    assert live["ok"] and any(e["episode_id"] == eid for e in live["data"]["open"])
    assert live["data"]["counts"]["needs_action"] >= 1
    lst = client.get("/api/episodes", params={"status": "open", "camera_id": 7}).json()
    assert any(e["episode_id"] == eid for e in lst["data"])
    one = client.get(f"/api/episodes/{eid}").json()
    assert one["data"]["episode_id"] == eid
    assert client.get("/api/episodes/EP-missing").status_code == 404


def test_actions_via_http(client):
    eid = _open()
    r = client.post(f"/api/episodes/{eid}/acknowledge")
    assert r.status_code == 200 and r.json()["data"]["acknowledged_by"] == "Ops Person"
    r = client.post(f"/api/episodes/{eid}/resolve", json={"note": ""})
    assert r.status_code == 400 and r.json()["ok"] is False
    r = client.post(f"/api/episodes/{eid}/resolve", json={"note": "Helmet issued"})
    assert r.status_code == 200 and r.json()["data"]["status"] == "resolved"
    eid2 = _open()
    r = client.post(f"/api/episodes/{eid2}/false-positive")
    assert r.status_code == 200 and r.json()["data"]["status"] == "false_positive"


def test_stream_delivers_an_opened_event(client):
    import threading, time
    from app import episodes
    got = {}

    def reader():
        with client.stream("GET", "/api/episodes/stream", params={"token": "ignored-by-override"}) as resp:
            got["status"] = resp.status_code
            got["ctype"] = resp.headers.get("content-type", "")
            for line in resp.iter_lines():
                if line.startswith("data:"):
                    got["payload"] = json.loads(line[5:].strip())
                    break

    t = threading.Thread(target=reader, daemon=True); t.start()
    time.sleep(0.3)
    eid = _open()
    t.join(timeout=5)
    assert got["status"] == 200 and got["ctype"].startswith("text/event-stream")
    assert got["payload"]["type"] == "opened" and got["payload"]["episode"]["episode_id"] == eid
```

- [ ] **Step 2: Run to confirm they fail**

Run: `pytest tests/test_episodes_api.py -v`
Expected: FAIL — `ModuleNotFoundError: No module named 'app.episodes_api'`

- [ ] **Step 3: Write the router**

```python
# backend/app/episodes_api.py
"""
HTTP surface of the episode engine. The Ops Board and the phone app talk
only to these routes.
"""
from __future__ import annotations

import asyncio
import json
import queue
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, Query
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel

from app import episodes
from app.auth_dependencies import get_current_user, get_current_user_from_query
from app.database import User

router = APIRouter(prefix="/api/episodes", tags=["episodes"])

STREAM_PING_SEC = 15.0


def _who(user: User) -> str:
    return (getattr(user, "full_name", None) or getattr(user, "email", None) or "user")


class ResolveBody(BaseModel):
    note: str = ""


@router.get("/live", dependencies=[Depends(get_current_user)])
def live():
    return JSONResponse({"ok": True, "data": episodes.live_state()})


@router.get("", dependencies=[Depends(get_current_user)])
def list_(
    status: Optional[str] = None,
    kind: Optional[str] = None,
    camera_id: Optional[int] = None,
    since: Optional[datetime] = None,
    until: Optional[datetime] = None,
    limit: int = Query(200, ge=1, le=1000),
):
    data = episodes.list_episodes(status=status, kind=kind, camera_id=camera_id, since=since, until=until, limit=limit)
    return JSONResponse({"ok": True, "data": data})


@router.get("/stream")
async def stream(user: User = Depends(get_current_user_from_query)):
    """
    Server-Sent Events. One `episode` event per change; a comment line every
    STREAM_PING_SEC so proxies keep the connection open.
    """
    q = episodes.subscribe()
    loop = asyncio.get_event_loop()

    async def gen():
        try:
            yield ": connected\n\n"
            while True:
                try:
                    msg = await loop.run_in_executor(None, q.get, True, STREAM_PING_SEC)
                except queue.Empty:
                    yield ": ping\n\n"
                    continue
                yield f"event: episode\ndata: {json.dumps(msg)}\n\n"
        finally:
            episodes.unsubscribe(q)

    headers = {"Cache-Control": "no-cache", "X-Accel-Buffering": "no", "Connection": "keep-alive"}
    return StreamingResponse(gen(), media_type="text/event-stream", headers=headers)


@router.get("/{episode_id}", dependencies=[Depends(get_current_user)])
def get_one(episode_id: str):
    data = episodes.get_episode(episode_id)
    if data is None:
        return JSONResponse({"ok": False, "message": "Episode not found"}, status_code=404)
    return JSONResponse({"ok": True, "data": data})


@router.post("/{episode_id}/acknowledge")
def acknowledge(episode_id: str, user: User = Depends(get_current_user)):
    data = episodes.acknowledge(episode_id, _who(user))
    if data is None:
        return JSONResponse({"ok": False, "message": "Episode not found"}, status_code=404)
    return JSONResponse({"ok": True, "data": data})


@router.post("/{episode_id}/resolve")
def resolve(episode_id: str, body: ResolveBody, user: User = Depends(get_current_user)):
    try:
        data = episodes.resolve(episode_id, _who(user), body.note)
    except ValueError as exc:
        return JSONResponse({"ok": False, "message": str(exc)}, status_code=400)
    if data is None:
        return JSONResponse({"ok": False, "message": "Episode not found"}, status_code=404)
    return JSONResponse({"ok": True, "data": data})


@router.post("/{episode_id}/false-positive")
def false_positive(episode_id: str, user: User = Depends(get_current_user)):
    data = episodes.mark_false_positive(episode_id, _who(user))
    if data is None:
        return JSONResponse({"ok": False, "message": "Episode not found"}, status_code=404)
    return JSONResponse({"ok": True, "data": data})
```

Route order matters: `/live` and `/stream` are declared **before** `/{episode_id}` so they are not swallowed by the path parameter.

- [ ] **Step 4: Wire it into main.py**

In `backend/main.py`, with the other `from app...` imports add:
```python
from app.episodes_api import router as episodes_router
```
and directly after the `app.add_middleware(` block (line ~165) add:
```python
app.include_router(episodes_router)
```

- [ ] **Step 5: Run the tests**

Run: `pytest tests/test_episodes_api.py -v`
Expected: `3 passed`

- [ ] **Step 6: Write the API contract for the Android developer**

```markdown
<!-- docs/api/episodes.md -->
# Episodes API (for the Ops Board and the Android app)

Base URL: production `https://visionai-backend.paperlessops.com`, on-prem `http://<box-ip>:8001`.
Auth: `Authorization: Bearer <access token>` from `/api/auth/login` (same as every other route).

## What an episode is
One thing-in-progress seen by a camera. Fields that matter to a client:

| field | meaning |
|---|---|
| `episode_id` | stable id, e.g. `EP-7-20260915153045123456` |
| `kind` | `ppe_violation` · `restricted_presence` · `vehicle_in_zone` · `person_in_zone` · `system` |
| `title` | plain English, show as-is ("Helmet missing", "CAM-06 offline") |
| `subject_type` / `subject_label` | `person` "Abhishek Kumar", `vehicle` "HR 26 CX 5580", `camera` "CAM-06", `unknown` "Unknown person" |
| `severity` | `critical` · `warning` · `notice` · `info` (info = informational, never needs a person) |
| `status` | `open` → `acknowledged` → `resolved` / `false_positive` |
| `needs_action` | true while a human still has to deal with it — **this drives the Needs-action list and push notifications** |
| `started_epoch`, `ended_epoch` | seconds since 1970 (UTC). Timer = now − started_epoch while ended_epoch is null |
| `duration_sec` | server-computed duration at the time of the response |
| `evidence_first`, `evidence_last` | picture paths, e.g. `/evidence/EP-....jpg` — prefix with the base URL |
| `people_count` | how many violators were in the picture (rises on new arrivals) |
| `attributes` | free JSON: `{"helmet": false, "vest": true}` today; zone checks later |

## Routes
- `GET /api/episodes/live` → `{ok, data: {open: [...], counts: {critical, warning, notice, info, needs_action, vehicles, people}, generated_epoch}}` — everything live right now. Poll this every 5 s if you are not using the stream.
- `GET /api/episodes?status=open&kind=&camera_id=&since=<ISO>&until=<ISO>&limit=200` — history.
- `GET /api/episodes/{episode_id}` — one episode.
- `POST /api/episodes/{episode_id}/acknowledge` — "someone's on it".
- `POST /api/episodes/{episode_id}/resolve` body `{"note": "what was done"}` — note is **required** (400 without).
- `POST /api/episodes/{episode_id}/false-positive` — "not a real issue".
- `GET /api/episodes/stream?token=<access token>` — Server-Sent Events. Each message is `event: episode` with JSON `{type: "opened"|"updated"|"closed"|"action", episode: {...}}`. A `: ping` comment arrives every 15 s. Reconnect on drop with a fresh `/live` call first.

## Push notifications (phone app)
Send a notification when a stream message has `type == "opened"` and `episode.needs_action == true`; title = `episode.title`, body = `subject_label · camera_name · zone_name`. Cancel/clear it when a later message for the same `episode_id` has `needs_action == false`.
```

- [ ] **Step 7: Commit**

```bash
git add backend/app/episodes_api.py backend/main.py backend/tests/test_episodes_api.py docs/api/episodes.md
git commit -m "feat(episodes): API router - live state, history, actions, SSE stream; API contract doc

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

### Task 7: Camera zones CRUD

**Files:**
- Modify: `backend/app/episodes_api.py` (append a second router)
- Modify: `backend/main.py` (include the zones router)
- Test: `backend/tests/test_zones_api.py`

**Interfaces:**
- Produces: `GET /api/zones?camera_id=`, `POST /api/zones` body `{camera_id, name, zone_type, polygon:[[x,y],...], limit_sec?}`, `PUT /api/zones/{id}` (same body, all optional), `DELETE /api/zones/{id}` (soft: `is_active=false`). Serialised zone: `{id, site_id, camera_id, name, zone_type, polygon, limit_sec, is_active}`.

- [ ] **Step 1: Write the failing test**

```python
# backend/tests/test_zones_api.py
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient


class _FakeUser:
    email = "ops@example.com"; full_name = "Ops Person"; role = "user"


@pytest.fixture()
def client(db):
    from app import episodes_api
    from app.auth_dependencies import get_current_user
    app = FastAPI()
    app.include_router(episodes_api.zones_router)
    app.dependency_overrides[get_current_user] = lambda: _FakeUser()
    return TestClient(app)


def test_zone_crud(client):
    body = {"camera_id": 4, "name": "Loading Bay 3", "zone_type": "bay",
            "polygon": [[0.1, 0.1], [0.9, 0.1], [0.9, 0.9], [0.1, 0.9]], "limit_sec": 14400}
    r = client.post("/api/zones", json=body)
    assert r.status_code == 200, r.text
    zid = r.json()["data"]["id"]
    assert r.json()["data"]["polygon"] == body["polygon"]

    r = client.get("/api/zones", params={"camera_id": 4}).json()
    assert any(z["id"] == zid for z in r["data"])

    r = client.put(f"/api/zones/{zid}", json={"limit_sec": 7200, "name": "Bay 3"})
    assert r.json()["data"]["limit_sec"] == 7200 and r.json()["data"]["name"] == "Bay 3"

    r = client.delete(f"/api/zones/{zid}")
    assert r.status_code == 200
    r = client.get("/api/zones", params={"camera_id": 4}).json()
    assert not any(z["id"] == zid for z in r["data"])


def test_zone_polygon_needs_three_points(client):
    r = client.post("/api/zones", json={"camera_id": 4, "name": "x", "zone_type": "bay", "polygon": [[0, 0], [1, 1]]})
    assert r.status_code == 400
```

- [ ] **Step 2: Run to confirm it fails**

Run: `pytest tests/test_zones_api.py -v`
Expected: FAIL — `AttributeError: module 'app.episodes_api' has no attribute 'zones_router'`

- [ ] **Step 3: Append the zones router to `app/episodes_api.py`**

```python
# ---------------------------------------------------------------------------
# Camera zones
# ---------------------------------------------------------------------------
from typing import List  # noqa: E402

from app.database import CameraZone, get_db_session  # noqa: E402

zones_router = APIRouter(prefix="/api/zones", tags=["zones"], dependencies=[Depends(get_current_user)])

ZONE_TYPES = ("gate", "weighbridge", "yard", "bay", "unloading_bay", "restricted", "ppe", "custom")


class ZoneBody(BaseModel):
    camera_id: Optional[int] = None
    name: Optional[str] = None
    zone_type: Optional[str] = None
    polygon: Optional[List[List[float]]] = None
    limit_sec: Optional[int] = None
    site_id: Optional[int] = None


def _zone_out(z: CameraZone) -> dict:
    return {
        "id": z.id, "site_id": z.site_id, "camera_id": z.camera_id, "name": z.name, "zone_type": z.zone_type,
        "polygon": json.loads(z.polygon_json), "limit_sec": z.limit_sec, "is_active": bool(z.is_active),
    }


def _bad(message: str):
    return JSONResponse({"ok": False, "message": message}, status_code=400)


def _valid_polygon(poly) -> bool:
    return isinstance(poly, list) and len(poly) >= 3 and all(
        isinstance(p, list) and len(p) == 2 and all(isinstance(v, (int, float)) and 0 <= v <= 1 for v in p) for p in poly
    )


@zones_router.get("")
def list_zones(camera_id: Optional[int] = None):
    db = get_db_session()
    try:
        q = db.query(CameraZone).filter(CameraZone.is_active.is_(True))
        if camera_id is not None:
            q = q.filter(CameraZone.camera_id == camera_id)
        return JSONResponse({"ok": True, "data": [_zone_out(z) for z in q.order_by(CameraZone.id).all()]})
    finally:
        db.close()


@zones_router.post("")
def create_zone(body: ZoneBody):
    if body.camera_id is None or not (body.name or "").strip():
        return _bad("camera_id and name are required")
    if body.zone_type not in ZONE_TYPES:
        return _bad(f"zone_type must be one of {', '.join(ZONE_TYPES)}")
    if not _valid_polygon(body.polygon):
        return _bad("polygon needs at least 3 points, each [x, y] between 0 and 1")
    db = get_db_session()
    try:
        z = CameraZone(camera_id=body.camera_id, name=body.name.strip()[:150], zone_type=body.zone_type,
                       polygon_json=json.dumps(body.polygon), limit_sec=body.limit_sec, site_id=body.site_id)
        db.add(z); db.commit(); db.refresh(z)
        return JSONResponse({"ok": True, "data": _zone_out(z)})
    finally:
        db.close()


@zones_router.put("/{zone_id}")
def update_zone(zone_id: int, body: ZoneBody):
    db = get_db_session()
    try:
        z = db.query(CameraZone).filter(CameraZone.id == zone_id, CameraZone.is_active.is_(True)).first()
        if z is None:
            return JSONResponse({"ok": False, "message": "Zone not found"}, status_code=404)
        if body.name is not None:
            z.name = body.name.strip()[:150]
        if body.zone_type is not None:
            if body.zone_type not in ZONE_TYPES:
                return _bad(f"zone_type must be one of {', '.join(ZONE_TYPES)}")
            z.zone_type = body.zone_type
        if body.polygon is not None:
            if not _valid_polygon(body.polygon):
                return _bad("polygon needs at least 3 points, each [x, y] between 0 and 1")
            z.polygon_json = json.dumps(body.polygon)
        if body.limit_sec is not None:
            z.limit_sec = body.limit_sec
        if body.camera_id is not None:
            z.camera_id = body.camera_id
        db.commit(); db.refresh(z)
        return JSONResponse({"ok": True, "data": _zone_out(z)})
    finally:
        db.close()


@zones_router.delete("/{zone_id}")
def delete_zone(zone_id: int):
    db = get_db_session()
    try:
        z = db.query(CameraZone).filter(CameraZone.id == zone_id).first()
        if z is None:
            return JSONResponse({"ok": False, "message": "Zone not found"}, status_code=404)
        z.is_active = False
        db.commit()
        return JSONResponse({"ok": True, "message": "Zone removed"})
    finally:
        db.close()
```

- [ ] **Step 4: Include it in main.py**

Change the import to `from app.episodes_api import router as episodes_router, zones_router` and add `app.include_router(zones_router)` right after `app.include_router(episodes_router)`.

- [ ] **Step 5: Run the tests**

Run: `pytest tests/test_zones_api.py tests/test_episodes_api.py -v`
Expected: `5 passed`

- [ ] **Step 6: Commit**

```bash
git add backend/app/episodes_api.py backend/main.py backend/tests/test_zones_api.py
git commit -m "feat(zones): camera zone CRUD

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

### Task 8: Dual-write from the incident model into episodes

The incident logic in `detection_service.py` is untouched; it additionally calls the episode engine at four points. `LiveEvent` rows keep being written exactly as before.

**Files:**
- Modify: `backend/app/detection_service.py`
  - imports (near `from app.email_service import process_violation_observation`)
  - `save_detection_events` — the "still going" branch and the "opened" branch
  - `_record_new_arrivals` — where the arrival picture is saved
  - `_close_incident`
- Test: `backend/tests/test_detection_dualwrite.py`

**Interfaces:**
- Consumes: `app.episodes.open_episode / touch_episode / close_episode` (Task 2).
- Produces: each incident dict carries `"episode_id"`; a PPE incident becomes an episode with `kind="ppe_violation"`, `severity=PPE_EPISODE_SEVERITY` (env `VISIONAI_PPE_SEVERITY`, default `warning`), `title` from `_ppe_title(event_type)`, `subject_type="person"` when recognised else `"unknown"`.

- [ ] **Step 1: Write the failing test**

This test loads the incident section of `detection_service.py` with fakes (the same technique as the earlier `test_incidents.py`), replacing `episodes` with a recorder. It runs without the vision models.

```python
# backend/tests/test_detection_dualwrite.py
"""
Exercise save_detection_events / _record_new_arrivals / _close_incident with
a fake DB, fake clock and a recording stand-in for app.episodes.
"""
import os, threading, time, types
from pathlib import Path
from datetime import datetime

os.environ["VISIONAI_INCIDENT_GRACE_SEC"] = "30"
os.environ["VISIONAI_INCIDENT_CONFIRM_SEC"] = "3"

SRC = Path(__file__).resolve().parents[1].joinpath("app", "detection_service.py").read_text(encoding="utf-8")


def cut(start, end):
    s = SRC.index(start); e = SRC.index(end, s)
    return SRC[s:e]


class Recorder:
    def __init__(self): self.calls = []; self.n = 0
    def open_episode(self, **kw): self.n += 1; self.calls.append(("open", kw)); return f"EP-test-{self.n}"
    def touch_episode(self, eid, **kw): self.calls.append(("touch", eid, kw))
    def close_episode(self, eid, **kw): self.calls.append(("close", eid, kw))


def build(rec):
    code = "\n".join([
        cut("# Violation incidents - two events per episode", "# Email alert evidence snapshots"),
        cut("def get_event_type(person):", "def save_latest_email_evidence("),
        cut("def _ppe_title(", "def _incident_key("),
        cut("def _incident_key(", "def _sweep_evidence("),
        cut("def save_detection_events(camera, persons, frame, frame_id):", "def draw_text_white_bg("),
        "from collections import Counter",
    ])

    class FakeClock: t = 1000.0
    class FakeDB:
        def add(self, ev): pass
        def commit(self): pass
        def refresh(self, ev): pass
        def rollback(self): pass
        def close(self): pass
    class LiveEvent:
        def __init__(self, **kw): self.__dict__.update(kw)

    ns = dict(
        os=os, shutil=__import__("shutil"), threading=threading, datetime=datetime, Path=Path,
        time=types.SimpleNamespace(monotonic=lambda: FakeClock.t, time=time.time, sleep=lambda s: None),
        BASE_DIR=Path("."), EVIDENCE_DIR=Path("./nonexistent"), EVIDENCE_MIN_FREE_GB=0,
        LiveEvent=LiveEvent, get_db_session=lambda: FakeDB(), save_evidence_image=lambda f, i: f"/evidence/{i}.jpg",
        UNKNOWN_LABEL="Monitoring", MONITOR_FRAME_ID="monitor",
        normalize_event_person_name=lambda n: "unknown person" if str(n).lower() in ("monitoring", "unknown") else str(n).lower(),
        save_latest_email_evidence=lambda **k: None, process_violation_observation=lambda **k: None,
        _evidence_disk_ok=lambda: True, _db_frame_id=lambda f: 0, _reap_idle_detection_workers=lambda: None,
        episodes=rec,
    )
    exec(code, ns)
    ns["_ensure_incident_sweeper"] = lambda: None
    return ns, FakeClock


def test_incident_opens_touches_arrives_and_closes_an_episode():
    rec = Recorder()
    ns, clock = build(rec)
    cam = types.SimpleNamespace(id=3, camera_name="in room", location="office")
    violator = {"face_name": "Monitoring", "helmet": False, "vest": True}
    second = dict(violator)

    for _ in range(12):                       # 4 s -> confirmed and opened
        ns["save_detection_events"](cam, [violator], "FRAME", "monitor"); clock.t += 0.33
    opens = [c for c in rec.calls if c[0] == "open"]
    assert len(opens) == 1
    kw = opens[0][1]
    assert kw["kind"] == "ppe_violation" and kw["severity"] == "warning"
    assert kw["title"] == "Helmet missing" and kw["subject_type"] == "unknown"
    assert kw["camera_id"] == 3 and kw["attributes"] == {"helmet": False, "vest": True}
    assert ns["_incidents"][(3, "unknown person")]["episode_id"] == "EP-test-1"

    for _ in range(30):                       # still going -> touches
        ns["save_detection_events"](cam, [violator], "FRAME", "monitor"); clock.t += 0.33
    assert any(c[0] == "touch" and c[1] == "EP-test-1" for c in rec.calls)

    for _ in range(9):                        # second violator joins -> arrival touch with people_count=2
        ns["save_detection_events"](cam, [violator, second], "FRAME", "monitor"); clock.t += 0.33
    assert any(c[0] == "touch" and c[2].get("people_count") == 2 for c in rec.calls)

    clock.t += 40; ns["_sweep_incidents"]()   # gone past grace -> closed
    closes = [c for c in rec.calls if c[0] == "close"]
    assert closes and closes[-1][1] == "EP-test-1" and closes[-1][2]["frame"] == "FRAME"


def test_ppe_title_mapping():
    rec = Recorder(); ns, _ = build(rec)
    t = ns["_ppe_title"]
    assert t("Helmet and Vest Violation") == "Helmet and vest missing"
    assert t("Helmet Violation") == "Helmet missing"
    assert t("Vest Violation") == "Vest missing"
    assert t("Something Else") == "Something Else"
```

- [ ] **Step 2: Run to confirm it fails**

Run: `pytest tests/test_detection_dualwrite.py -v`
Expected: FAIL — `ValueError: substring not found` (the `_ppe_title` marker does not exist yet)

- [ ] **Step 3: Edit `detection_service.py`**

(a) Imports — after `from app.email_service import process_violation_observation` add:
```python
from app import episodes
```

(b) Settings — after `EVENT_SAVE_RETRY_SEC = 30.0` add:
```python
# Severity given to PPE episodes on the Ops Board ("critical" | "warning" | "notice").
PPE_EPISODE_SEVERITY = os.getenv("VISIONAI_PPE_SEVERITY", "warning").strip().lower() or "warning"
```

(c) Title helper — insert immediately **before** `def _incident_key(camera_id, person_name):`:
```python
def _ppe_title(event_type):
    """Plain-English episode title from the PPE event type."""
    text = str(event_type or "")
    lower = text.lower()
    if "helmet" in lower and "vest" in lower:
        return "Helmet and vest missing"
    if "helmet" in lower:
        return "Helmet missing"
    if "vest" in lower:
        return "Vest missing"
    return text


```

(d) In `save_detection_events`, the "still going" branch currently reads:
```python
            if incident is not None:
                # Still going - just remember the latest picture and time.
                incident["last_seen_mono"] = now_mono
                incident["last_frame"] = frame
                continue
```
Change it to:
```python
            if incident is not None:
                # Still going - just remember the latest picture and time.
                incident["last_seen_mono"] = now_mono
                incident["last_frame"] = frame
                episode_id = incident.get("episode_id")
                if episode_id:
                    episodes.touch_episode(episode_id)
                continue
```

(e) In `save_detection_events`, the incident dict gets an `episode_id` slot. Change:
```python
                "person_baseline": None,
                "low_since": None,
            }
            _incidents[key] = incident
```
to:
```python
                "person_baseline": None,
                "low_since": None,
                "episode_id": None,
            }
            _incidents[key] = incident
```

(f) Still in `save_detection_events`, after the `LiveEvent` row is saved. Change:
```python
        if saved:
            print(
                f"[INCIDENT] opened on {camera_name}: {event_type} "
                f"({person_name})"
            )
            continue
```
to:
```python
        if saved:
            print(
                f"[INCIDENT] opened on {camera_name}: {event_type} "
                f"({person_name})"
            )
            episode_id = episodes.open_episode(
                camera_id=camera_id,
                camera_name=camera_name,
                camera_location=camera_location,
                kind="ppe_violation",
                title=_ppe_title(event_type),
                subject_type="person" if is_recognized else "unknown",
                subject_label=person_name,
                subject_id=person_id if is_recognized else None,
                severity=PPE_EPISODE_SEVERITY,
                frame=frame,
                attributes={"helmet": helmet_status, "vest": vest_status},
            )
            with _incidents_lock:
                if key in _incidents:
                    _incidents[key]["episode_id"] = episode_id
            continue
```

(g) In `_record_new_arrivals`, find where the arrival picture is saved — the block that calls `_save_event_row(` with an event type ending in `people now"` (the `f"{incident['event_type']} - {count} people now"` line). Immediately after that `_save_event_row(...)` call completes (whatever it is assigned to), add:
```python
        episode_id = incident.get("episode_id")
        if episode_id:
            episodes.touch_episode(episode_id, frame=frame, people_count=count)
```
(`incident`, `frame` and `count` are already in scope at that point.)

(h) In `_close_incident`, after the `print(` call that logs `[INCIDENT] closed on`, add:
```python
    episode_id = incident.get("episode_id")
    if episode_id:
        episodes.close_episode(episode_id, frame=incident.get("last_frame"))
```

- [ ] **Step 4: Run the tests**

Run: `pytest tests/test_detection_dualwrite.py -v`
Expected: `2 passed`. If `test_incident_opens_touches_arrives_and_closes_an_episode` fails on the arrival assertion, open `_record_new_arrivals` and confirm step (g) sits inside the loop **after** the baseline check that decides an arrival really happened (the code path that saves the "- N people now" row), not before it.

- [ ] **Step 5: Syntax-check the real module and commit**

Run: `python -m py_compile app/detection_service.py && echo OK`
Expected: `OK`

```bash
git add backend/app/detection_service.py backend/tests/test_detection_dualwrite.py
git commit -m "feat(episodes): dual-write PPE incidents into the episode engine

LiveEvent rows and email alerts are unchanged; each incident now also
opens/touches/closes one Episode row.

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

### Task 9: Camera-offline notices ("if it needs a human, it's a card")

**Files:**
- Modify: `backend/app/episodes.py` (append)
- Modify: `backend/app/detection_service.py` (`_incident_sweeper_loop`: one extra call)
- Modify: `backend/.env.example`
- Test: `backend/tests/test_camera_offline.py`

**Interfaces:**
- Produces: `episodes.sweep_camera_health(offline_after_sec: float = CAMERA_OFFLINE_SEC) -> None` — opens one `kind="system"`, `severity="notice"` episode per active camera whose `last_seen_at` is older than the threshold, and closes it when the camera reports again. Env `VISIONAI_CAMERA_OFFLINE_SEC` (default `300`).

- [ ] **Step 1: Write the failing test**

```python
# backend/tests/test_camera_offline.py
from datetime import datetime, timedelta, timezone


def _camera(db, name, seen_ago_sec):
    from app.database import Camera
    cam = Camera(camera_name=name, source_type="rtsp", rtsp_url="rtsp://x", is_active=True,
                 last_seen_at=datetime.now(timezone.utc) - timedelta(seconds=seen_ago_sec))
    db.add(cam); db.commit(); db.refresh(cam)
    return cam


def test_offline_camera_opens_one_notice_and_closes_when_back(db):
    from app import episodes
    from app.database import Episode, Camera
    cam = _camera(db, "CAM-06 Yard East", seen_ago_sec=900)

    episodes.sweep_camera_health(offline_after_sec=300)
    episodes.sweep_camera_health(offline_after_sec=300)          # idempotent
    rows = db.query(Episode).filter(Episode.kind == "system", Episode.camera_id == cam.id).all()
    assert len(rows) == 1
    assert rows[0].severity == "notice" and rows[0].subject_type == "camera" and rows[0].ended_at is None
    assert "unwatched" in rows[0].title or "offline" in rows[0].title.lower()

    cam = db.query(Camera).get(cam.id)
    cam.last_seen_at = datetime.now(timezone.utc); db.commit()
    episodes.sweep_camera_health(offline_after_sec=300)
    db.expire_all()
    row = db.query(Episode).filter(Episode.kind == "system", Episode.camera_id == cam.id).one()
    assert row.ended_at is not None


def test_never_seen_camera_is_left_alone(db):
    from app import episodes
    from app.database import Camera, Episode
    cam = Camera(camera_name="new cam", source_type="rtsp", rtsp_url="rtsp://y", is_active=True, last_seen_at=None)
    db.add(cam); db.commit(); db.refresh(cam)
    episodes.sweep_camera_health(offline_after_sec=300)
    assert db.query(Episode).filter(Episode.camera_id == cam.id).count() == 0
```

- [ ] **Step 2: Run to confirm it fails**

Run: `pytest tests/test_camera_offline.py -v`
Expected: FAIL — `AttributeError: ... has no attribute 'sweep_camera_health'`

- [ ] **Step 3: Append to `app/episodes.py`**

Add `import os` at the top of the module, and `Camera` to the `from app.database import ...` line, then append:

```python
# ---------------------------------------------------------------------------
# Camera health -> "Notice" episodes
# ---------------------------------------------------------------------------

CAMERA_OFFLINE_SEC = float(os.getenv("VISIONAI_CAMERA_OFFLINE_SEC", "300"))


def sweep_camera_health(offline_after_sec: float = CAMERA_OFFLINE_SEC) -> None:
    """
    An active camera that has not delivered a picture for offline_after_sec
    gets one open system episode ("CAM-06 is offline - the area is
    unwatched"); it closes automatically when the camera reports again.
    Cameras that have never reported are ignored (still being set up).
    """
    now = _utcnow()
    db = get_db_session()
    try:
        cameras = db.query(Camera).filter(Camera.is_active.is_(True)).all()
        open_notices = {
            row.camera_id: row
            for row in db.query(Episode).filter(Episode.kind == "system", Episode.ended_at.is_(None)).all()
        }
    finally:
        db.close()

    for cam in cameras:
        seen = _as_utc(cam.last_seen_at)
        if seen is None:
            continue
        is_offline = (now - seen).total_seconds() >= offline_after_sec
        notice = open_notices.get(cam.id)

        if is_offline and notice is None:
            where = f" - {cam.location} is unwatched" if cam.location else " - its area is unwatched"
            open_episode(
                camera_id=cam.id, camera_name=cam.camera_name, camera_location=cam.location,
                kind="system", title=f"{cam.camera_name} is offline{where}",
                subject_type="camera", subject_label=cam.camera_name, subject_id=str(cam.id),
                severity="notice", attributes={"last_seen_epoch": seen.timestamp()},
            )
        elif not is_offline and notice is not None:
            close_episode(notice.episode_id)
```

- [ ] **Step 4: Call it from the existing sweeper**

In `backend/app/detection_service.py`, inside `_incident_sweeper_loop`, after the `_reap_idle_detection_workers()` try/except block, add:
```python
        try:
            episodes.sweep_camera_health()
        except Exception as exc:
            print("Camera health sweep error:", exc)
```

- [ ] **Step 5: Document the knobs**

Append to `backend/.env.example` under the detection section:
```text
# --- Ops Board episodes ---
# Severity shown for PPE episodes: critical | warning | notice
VISIONAI_PPE_SEVERITY=warning
# A camera silent for this many seconds raises a "Notice" (its area is unwatched)
VISIONAI_CAMERA_OFFLINE_SEC=300
```

- [ ] **Step 6: Run the whole suite**

Run: `pytest -v`
Expected: all tests pass (`test_env` 1, models 1, episodes 6, actions 4, bus 3, auth 3, api 3, zones 2, dualwrite 2, camera 2 = **27 passed**)

- [ ] **Step 7: Commit**

```bash
git add backend/app/episodes.py backend/app/detection_service.py backend/.env.example backend/tests/test_camera_offline.py
git commit -m "feat(episodes): camera-offline Notice episodes from the sweeper

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
```

---

### Task 10: Deploy and prove it on the server

**Files:**
- Modify: `deploy/SERVER-SETUP.md` (append the smoke-test section below)

**Interfaces:**
- Consumes: everything above. Nothing new produced; this task verifies the deployed behaviour end-to-end.

- [ ] **Step 1: Push and deploy**

```bash
git push origin main
```
Then in the WHM Terminal (root):
```bash
bash /home/paperlessops/visionai-repo/deploy/deploy-backend.sh
```
Expected: `-> OK` at the import check; service `active (running)`. Startup `create_tables()` creates `episodes` and `camera_zones`.

- [ ] **Step 2: Confirm the tables exist**

```bash
cd /home/paperlessops/public_html/visionai-backend && venv/bin/python -c "from dotenv import load_dotenv; load_dotenv('.env'); from app.database import engine; from sqlalchemy import inspect; i=inspect(engine); print([t for t in i.get_table_names() if t in ('episodes','camera_zones')])"
```
Expected: `['camera_zones', 'episodes']`

- [ ] **Step 3: Smoke-test the API with a real login**

```bash
TOKEN=$(curl -s -X POST https://visionai-backend.paperlessops.com/api/auth/login -H 'Content-Type: application/json' -d '{"email":"ajiteshdewan@gmail.com","password":"<password>"}' | python3 -c "import sys,json; print(json.load(sys.stdin)['data']['access_token'])")
curl -s https://visionai-backend.paperlessops.com/api/episodes/live -H "Authorization: Bearer $TOKEN" | head -c 400; echo
```
Expected: `{"ok": true, "data": {"open": [...], "counts": {...}, "generated_epoch": ...}}` (login route/field names: check `main.py` `/api/auth/login` response shape and adjust the `python3 -c` path if it differs).

- [ ] **Step 4: Prove the stream stays open through nginx**

```bash
curl -N --max-time 40 "https://visionai-backend.paperlessops.com/api/episodes/stream?token=$TOKEN"
```
Expected: `: connected` then a `: ping` about every 15 s for the 40 s. If the connection closes before the first ping, raise nginx `proxy_read_timeout` for the backend location to `600s` and reload nginx.

- [ ] **Step 5: Prove an incident becomes an episode**

With monitoring on and a person without a helmet in front of the "in room" camera for ~5 s:
```bash
journalctl -u visionai-backend --no-pager -n 200 | grep -E "\[INCIDENT\] opened|\[EPISODE\]" | tail -5
curl -s https://visionai-backend.paperlessops.com/api/episodes/live -H "Authorization: Bearer $TOKEN" | python3 -c "import sys,json; d=json.load(sys.stdin)['data']; print(d['counts']); print([(e['title'], e['subject_label'], e['severity'], e['needs_action']) for e in d['open']])"
```
Expected: `[INCIDENT] opened ...` with no `[EPISODE] open failed`, and the live list showing `('Helmet missing', 'Unknown person' or a name, 'warning', True)`.

- [ ] **Step 6: Acknowledge and resolve it from the API**

```bash
EID=$(curl -s https://visionai-backend.paperlessops.com/api/episodes/live -H "Authorization: Bearer $TOKEN" | python3 -c "import sys,json; print(json.load(sys.stdin)['data']['open'][0]['episode_id'])")
curl -s -X POST https://visionai-backend.paperlessops.com/api/episodes/$EID/acknowledge -H "Authorization: Bearer $TOKEN"; echo
curl -s -X POST https://visionai-backend.paperlessops.com/api/episodes/$EID/resolve -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' -d '{"note":"test close-out"}'; echo
```
Expected: first returns `"status": "acknowledged"`, second `"status": "resolved"` with the note; `/api/episodes/live` no longer lists it.

- [ ] **Step 7: Record the smoke test in SERVER-SETUP.md and commit**

Append a section `## Episodes API smoke test` to `deploy/SERVER-SETUP.md` containing steps 2–6 verbatim, then:
```bash
git add deploy/SERVER-SETUP.md
git commit -m "docs: episodes API smoke test for the server

Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>"
git push origin main
```

---

## Self-review

**Spec coverage**
- One row per episode with start/end/subject/zone/severity/status → Task 1, 2. ✓
- Acknowledge / resolve-with-note / false-positive → Task 3, 6. ✓
- Live state + history + one → Task 2, 6. ✓
- SSE live feed (with proxy keep-alive) → Task 4, 6, 10. ✓
- Dual-write, `LiveEvent` untouched → Task 8. ✓
- Zones + `site_id` designed in → Task 1, 7. ✓
- Android contract → Task 6 doc. ✓
- "If it needs a human, it's a card" (camera offline) → Task 9. ✓
- No column changes to existing tables → all tasks create new tables only. ✓
- Not in this plan (deliberately): vehicle/zone dwell detection (needs the zone editor UI + vehicle classes — the yard-engine plan), the insight pipeline ("AI noticed"), multi-tenant enforcement, the new frontend. Each is its own plan.

**Placeholder scan** — no TBD/TODO; every code step has code; Task 8 step (g) names the exact code landmark (`- {count} people now`) rather than a line number because that function is long.

**Type consistency** — `open_episode` keyword names match between Task 2, Task 8 (f) and Task 9; `touch_episode(episode_id, *, frame=None, people_count=None)` matches Task 8 (d)/(g); `serialize_episode` keys used in the API doc (`needs_action`, `started_epoch`, `ended_epoch`, `evidence_first/last`, `people_count`, `attributes`) all exist in Task 2; `zones_router` name matches Task 7 test and main.py include; `get_current_user_from_query` matches Task 5 and the stream route.
