# Yard Engine Implementation Plan

> **For agentic workers:** Execute task-by-task with the same discipline as the episode-engine plan (test first, one commit per task, `pytest` green before each commit). Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Turn the plant's cameras into a live picture of *where every vehicle and person is and for how long*: zones drawn on each camera (gate, weighbridge, yard, bays, unloading bay, restricted areas), vehicles detected and tracked inside those zones, counting dwell timers, and automatic escalation when a zone's time limit is crossed — all feeding the existing episode engine so the Ops Board's **Plant map** shows zones instead of cameras and **Happening now** shows trucks with plates-to-come.

**Architecture:** No new detection models. The COCO person model already recognises `car / motorcycle / bus / truck`; today the inference call throws them away with `classes=[PERSON_CLASS_ID]`. The yard engine keeps them, tests each detection's ground point against the camera's zone polygons (already stored as 0..1 fractions in `camera_zones`), keeps a tiny per-camera IoU tracker so the same truck stays the same episode across frames, and opens/touches/closes `vehicle_in_zone` / `person_in_zone` episodes through `app.episodes` exactly like PPE incidents do. Zones are edited in the frontend on top of a camera snapshot (`/api/cameras/{id}/snapshot.jpg`, shipped 15 Sep). The plant map is **generated from the zones** — nobody has to draw a site plan.

**Tech Stack:** unchanged — Python 3.12, FastAPI, SQLAlchemy, YOLOv8n (ultralytics, CPU), React 19 + Vite on the frontend.

## Decisions taken here (so the tasks do not re-open them)

1. **Ground point, not box centre.** A vehicle "is in" a zone when the bottom-centre of its box (where the wheels meet the ground) is inside the polygon. Box centres put a tall truck in the zone behind it.
2. **Confirm 5 s, grace 60 s** for vehicles (`VISIONAI_VEHICLE_CONFIRM_SEC`, `VISIONAI_VEHICLE_GRACE_SEC`). Trucks stand still for hours; a detector blink must not split one visit into two episodes. Persons in restricted zones use the existing 3 s confirm.
3. **One episode per (camera, zone, track).** A truck that moves gate → weighbridge → bay produces three episodes; linking them into one *visit* needs plate reading and is a later plan (ANPR).
4. **Escalation edits the same row.** When a `vehicle_in_zone` info episode passes `zone.limit_sec`, its severity becomes `warning` and its title becomes "Truck waiting 2 h 41 m — over the 2 h limit". Same `episode_id`, one card, one timer. `escalate_episode()` is added to `app.episodes` for this.
5. **Restricted zones are critical, always.** Any person inside a `restricted` zone → `person_in_zone`, severity `critical`, title "Unknown person in restricted area" or "Ajay in restricted area". No permit system yet; that hook is `attributes.permit`.
6. **PPE zones narrow, never widen.** If a camera has one or more `ppe` zones, PPE violations count only for people standing in them; a camera with no `ppe` zone keeps today's whole-frame behaviour. Nothing changes at the office camera.
7. **Subject label before ANPR** is the vehicle class in plain words: "Truck", "Car", "Bus", "Two-wheeler". When ANPR lands, `subject_label` becomes the plate and `attributes.vehicle_class` keeps the class.
8. **No site drawing.** The plant map is a grid generated from zones ordered gate → weighbridge → yard → bays → unloading → restricted → other. An optional site-plan picture with pins is a later, separate table (`site_layouts`), never a column on `camera_zones`.
9. **Zone cache in the detector refreshes every 30 s** (`VISIONAI_ZONE_REFRESH_SEC`) and immediately after any `/api/zones` write via a module-level version counter — no restart to see a new zone.
10. **Hazardous-bay procedure checks (earthing clamp, chocks, driver out of cabin, hose)** are *not* in this plan. They need pilot footage from ISRPL to train on; the zone types `unloading_bay` and the episode kinds are already shaped to receive them.

## File Structure

| File | Responsibility |
|---|---|
| `backend/app/zones.py` | (new) pure geometry + zone cache: `point_in_polygon`, `ground_point`, `zones_for_camera(camera_id)`, `bump_zone_version()`, `zone_of(camera_id, box, frame_shape, types=None)` |
| `backend/app/tracks.py` | (new) tiny IoU tracker per camera: `update(camera_id, kind, boxes, now) -> list[(track_id, box)]`, forgets after `grace`; no numpy, no models |
| `backend/app/yard.py` | (new) the yard logic: `observe_vehicles(camera, vehicles, frame, now)`, `observe_people_in_zones(camera, persons, frame, now)`, `sweep_yard()` (grace close + escalation), `restrict_ppe_to_zones(camera_id, persons, frame_shape)` |
| `backend/app/episodes.py` | (modify) add `escalate_episode(episode_id, *, severity, title=None, attributes=None)` |
| `backend/app/episodes_api.py` | (modify) zones writes call `zones.bump_zone_version()`; `GET /api/zones/summary` (open counts per zone for the map) |
| `backend/app/detection_service.py` | (modify) keep vehicle classes in the inference call; `run_yolo_detection` returns persons as before and stores vehicles per camera via `run_yolo_detection_full`; call `yard.observe_*` next to `save_detection_events`; call `yard.sweep_yard()` from `_incident_sweeper_loop` |
| `backend/.env.example` | (modify) new knobs |
| `frontend/src/setup/ZoneEditor.jsx` + `zones.css` | (new) draw/edit polygons on a camera snapshot |
| `frontend/src/ops/OpsBoard.jsx` | (modify) Plant map renders zones when any exist; yard counters in the header; vehicle rows show class + zone |
| `backend/tests/test_zones_geometry.py`, `test_tracks.py`, `test_yard.py`, `test_escalate.py`, `test_zones_summary.py` | (new) |

---

### Task 1: Geometry and the zone cache (`app/zones.py`)

**Interfaces:**
- `point_in_polygon(x, y, polygon) -> bool` — ray casting; polygon is `[[x, y], ...]` fractions 0..1.
- `ground_point(box, frame_shape) -> (x, y)` — bottom-centre of `(x1, y1, x2, y2)` as fractions of `(h, w)`.
- `zones_for_camera(camera_id) -> list[dict]` — active zones `{id, name, zone_type, polygon, limit_sec}`, cached, refreshed every `ZONE_REFRESH_SEC` or when `_version` changed.
- `bump_zone_version()` — called by the API after any zone write.
- `zone_of(camera_id, box, frame_shape, types=None) -> dict | None` — first matching zone (optionally limited to types).

- [ ] **Step 1: Failing tests** (`tests/test_zones_geometry.py`)

```python
def test_point_in_polygon_square_and_concave():
    from app.zones import point_in_polygon
    sq = [[0.1, 0.1], [0.9, 0.1], [0.9, 0.9], [0.1, 0.9]]
    assert point_in_polygon(0.5, 0.5, sq) and not point_in_polygon(0.05, 0.5, sq)
    l_shape = [[0, 0], [1, 0], [1, 0.5], [0.5, 0.5], [0.5, 1], [0, 1]]
    assert point_in_polygon(0.25, 0.75, l_shape) and not point_in_polygon(0.75, 0.75, l_shape)

def test_ground_point_is_bottom_centre_as_fractions():
    from app.zones import ground_point
    assert ground_point((100, 50, 300, 450), (480, 640)) == (200 / 640, 450 / 480)

def test_zone_of_uses_cache_and_version(db):
    from app import zones
    from app.database import CameraZone
    z = CameraZone(camera_id=9, name="Bay 1", zone_type="bay", polygon_json="[[0,0.5],[1,0.5],[1,1],[0,1]]", limit_sec=60)
    db.add(z); db.commit()
    assert zones.zone_of(9, (0, 0, 100, 100), (200, 200)) is None          # ground point (0.25, 0.5) -> on the edge, treat as out
    hit = zones.zone_of(9, (0, 150, 100, 200), (200, 200))                  # ground point (0.25, 1.0)
    assert hit and hit["name"] == "Bay 1"
    z.is_active = False; db.commit()
    assert zones.zone_of(9, (0, 150, 100, 200), (200, 200))                # still cached
    zones.bump_zone_version()
    assert zones.zone_of(9, (0, 150, 100, 200), (200, 200)) is None        # refreshed
```

- [ ] **Step 2: Implement** — ray casting with `>` on one edge and `>=` on the other so shared edges are not double-counted; cache is `{camera_id: (loaded_at, version, zones)}` under a lock; `zones_for_camera` reads `CameraZone` via `get_db_session()`; imports nothing heavy.

- [ ] **Step 3: Commit** — `feat(yard): zone geometry + cached zone lookup`

---

### Task 2: The IoU tracker (`app/tracks.py`)

Vehicles do not have faces; the incident key must be a track. Same idea as `_static_tracks` in `detection_service`, kept separate so it is testable without cv2.

**Interfaces:**
- `update(camera_id, kind, boxes, now_mono, *, iou_min=0.3, forget_sec=60) -> list[tuple[int, tuple]]` — returns `(track_id, box)` per input box; a box that overlaps an existing track by ≥ `iou_min` keeps that id; others get a new id; tracks not seen for `forget_sec` are dropped. `kind` separates `"vehicle"` and `"person"` tracks on the same camera.
- `forget(camera_id)`.

- [ ] **Step 1: Failing tests** (`tests/test_tracks.py`): same box three frames → same id; a second, non-overlapping box → second id; box gone for 61 s → new id afterwards; a slowly drifting box (10 px per frame) keeps its id.

- [ ] **Step 2: Implement** greedy matching by highest IoU, module-level `_tracks: dict[(camera_id, kind)] -> list[{id, box, last_seen}]` + lock.

- [ ] **Step 3: Commit** — `feat(yard): per-camera IoU tracker`

---

### Task 3: `escalate_episode` in the episode engine

**Interfaces:**
- `episodes.escalate_episode(episode_id, *, severity, title=None, attributes=None) -> dict | None` — raises severity (never lowers), optionally replaces title, merges attributes, publishes `{"type": "updated"}`. Info → warning makes `needs_action` true, so the card appears on the board and the phone app notifies (the app's rule keys off `needs_action` flipping to true on an `updated` message — add that line to `docs/api/episodes.md`).

- [ ] **Step 1: Failing test** (`tests/test_escalate.py`): open info vehicle episode → escalate to warning with title "Truck waiting 2 h 05 m — over the 2 h limit" → row severity warning, `needs_action` true, bus got `updated`; escalating to `info` again is ignored; unknown id → None.

- [ ] **Step 2: Implement** as another `_apply_action`-style function (it is a system action, `resolved_by` untouched).

- [ ] **Step 3: Update `docs/api/episodes.md`** (message table: `updated` also means "severity raised"; push rule: notify when `needs_action` becomes true on `opened` **or** `updated`).

- [ ] **Step 4: Commit** — `feat(episodes): escalate_episode for dwell-limit breaches`

---

### Task 4: The yard logic (`app/yard.py`)

**Interfaces (all cheap; called per processed frame from the detection worker):**
- `observe_vehicles(camera, vehicles, frame, now_mono)` — `vehicles` = `[{"box": (x1,y1,x2,y2), "cls": "truck", "conf": 0.8}, ...]`. For each vehicle: `zone_of(camera.id, box, frame.shape)`; if none → ignore. Track id from `tracks.update`. Key `(camera_id, zone_id, track_id)`. Pending until seen for `VEHICLE_CONFIRM_SEC`; then `open_episode(kind="vehicle_in_zone", severity="info", subject_type="vehicle", subject_label=<class word>, title=f"{Class} in {zone.name}", zone_id, zone_name, attributes={"vehicle_class": cls, "limit_sec": zone.limit_sec})`. While seen: `touch_episode`. State lives in `_vehicle_visits: dict[key] -> {"episode_id", "opened_mono", "last_seen_mono", "escalated": bool, "last_frame"}`.
- `observe_people_in_zones(camera, persons, frame, now_mono)` — persons are the existing person dicts (with `face_name`). Restricted zones only: key `(camera_id, zone_id, normalized name or track id)`; 3 s confirm; `open_episode(kind="person_in_zone", severity="critical", subject_type="person"|"unknown", title=...)`.
- `restrict_ppe_to_zones(camera_id, persons, frame_shape) -> list` — if the camera has `ppe` zones, return only persons whose ground point is inside one; else return `persons` unchanged. Called **before** `save_detection_events` in the worker.
- `sweep_yard()` — every 5 s from `_incident_sweeper_loop`: close visits unseen for `VEHICLE_GRACE_SEC` (`close_episode(frame=last_frame)`); for still-open visits with `limit_sec` and `now - opened >= limit_sec` and not escalated → `escalate_episode(severity="warning", title=f"{Class} waiting {duration} — over the {limit} limit")`, mark escalated.
- `yard_state()` — for `/api/monitoring/status` debugging: open visits per zone.

- [ ] **Step 1: Failing tests** (`tests/test_yard.py`) with a fake clock (`yard._mono = lambda: clock.t` pattern, or pass `now_mono` explicitly everywhere — prefer explicit) and a `Recorder` stand-in for `app.episodes` like `test_detection_dualwrite.py`:
  - a truck inside "Bay 1" for 6 s opens exactly one `vehicle_in_zone` info episode with `zone_name == "Bay 1"`; frames 7–30 only touch; 61 s unseen → closed with the last frame.
  - a truck that flickers away for 20 s and comes back keeps the same episode (grace).
  - a truck outside every zone opens nothing.
  - a `limit_sec=120` zone: at 121 s `sweep_yard` escalates once to warning with the "over the 2 min limit" title; a second sweep does not escalate again.
  - an unknown person inside a `restricted` zone for 3 s opens a critical `person_in_zone`; a person in a non-restricted zone opens nothing.
  - `restrict_ppe_to_zones` keeps everyone when the camera has no `ppe` zone and filters to the zone when it has one.

- [ ] **Step 2: Implement** `app/yard.py` (imports: `app.zones`, `app.tracks`, `app.episodes`, `app.timezone_util`; nothing heavy). Use `detection_service.normalize_event_person_name`'s rule re-implemented locally (`"unknown person"` for Monitoring/Unknown/N/A) to avoid importing the heavy module.

- [ ] **Step 3: Commit** — `feat(yard): vehicle visits, dwell escalation, restricted zones, PPE zone narrowing`

---

### Task 5: Wire the detector (`detection_service.py`)

- [ ] **Step 1:** Add `VEHICLE_CLASS_IDS = {2: "car", 3: "two-wheeler", 5: "bus", 7: "truck"}` and `VEHICLE_CONF = float(os.getenv("VEHICLE_CONF", "0.50"))`. In `run_yolo_detection` change `classes=[PERSON_CLASS_ID]` to `classes=[PERSON_CLASS_ID, *VEHICLE_CLASS_IDS]` and split boxes by `cls_id`: persons as today (unchanged dict), vehicles into a list of `{"box", "cls", "conf"}` kept when `conf >= VEHICLE_CONF`. Store the vehicles in a module-level `_last_vehicles[camera_id]`... **no** — `run_yolo_detection(frame)` has no camera id. Instead: rename the body to `run_yolo_detection_full(frame) -> (persons, vehicles)` and keep `run_yolo_detection(frame)` returning `persons` only (every existing caller unchanged). The 24/7 monitor worker (the one that calls `save_detection_events`) switches to the `_full` variant.
- [ ] **Step 2:** In the worker, right where `save_detection_events` is called: `event_persons = yard.restrict_ppe_to_zones(self.camera_id, event_persons, display_frame.shape)` before it; after it `yard.observe_vehicles(self.camera, vehicles_scaled, evidence_frame, now)` and `yard.observe_people_in_zones(self.camera, persons_draw, evidence_frame, now)` — each in its own `try/except` that prints and continues (video must never stop). Boxes are in `display_frame` pixel space; pass `display_frame.shape` for the fractions (the evidence frame is only the picture).
- [ ] **Step 3:** In `_incident_sweeper_loop` add `yard.sweep_yard()` in its own try/except.
- [ ] **Step 4:** Test with the exec-of-source technique (`tests/test_detection_vehicles.py`): the `run_yolo_detection_full` postprocess section, fed fake `person_results` with class ids 0 and 7, yields one person and one truck and drops a 0.3-confidence car.
- [ ] **Step 5:** `python -m py_compile app/detection_service.py`; full `pytest`; commit — `feat(yard): vehicles from the existing person model; yard observers in the monitor loop`

---

### Task 6: Zone summary for the map + version bump (`episodes_api.py`)

- [ ] `POST/PUT/DELETE /api/zones` call `zones.bump_zone_version()` after commit.
- [ ] `GET /api/zones/summary` → `{ok, data: [{zone: {...}, open: [episode ids], vehicles: n, people: n, needs_action: n, longest_sec: float}]}` for all active zones (including empty ones — the map must show empty bays). Computed from `episodes.live_state()` grouped by `zone_id`.
- [ ] Test (`tests/test_zones_summary.py`): two zones, one with an open vehicle episode → summary lists both, counts right, `longest_sec` ≥ 0.
- [ ] Commit — `feat(zones): live summary per zone; detector sees zone edits immediately`

---

### Task 7: Zone editor (frontend, `src/setup/ZoneEditor.jsx`)

Route `/setup/zones` (sidebar: **Setup → Zones**). Left: camera list (`/api/cameras`). Main: the camera's latest snapshot (`getCameraSnapshotUrl`, refreshed on demand with a "New picture" button) with an SVG overlay the same size as the image.

- Existing zones drawn as translucent polygons in their type colour with the name at the centroid; click one to select/edit.
- **Draw:** "Add zone" → click points on the picture (stored as fractions of the *rendered* image size, so they are resolution-independent); Enter or clicking the first point closes; Backspace removes the last point; Esc cancels. Minimum 3 points (the API rejects fewer).
- **Edit form** (right): name, type (select: gate / weighbridge / yard / bay / unloading_bay / restricted / ppe / custom), time limit (minutes, blank = none), Save / Delete. Drag a vertex to move it (pointer events on `<circle>`s).
- Type colours: gate/weighbridge/yard accent, bay ok, unloading_bay warning, restricted critical, ppe info, custom muted.
- All writes through `api.js` helpers (`getZones`, `createZone`, `updateZone`, `deleteZone` — add them).
- Works at 1024 px; on narrow screens the camera list becomes a select.

- [ ] Build it against `ops_board_dev_server.py` (it already mounts the zones router; add a static test picture at `/api/cameras/{id}/snapshot.jpg` for dev — a 1280×720 PNG under `backend/scripts/dev_snapshot.png` drawn with cv2 at startup, no binary in git).
- [ ] Commit — `feat(setup): zone editor on camera snapshots`

---

### Task 8: Plant map from zones + yard counters (frontend, `OpsBoard.jsx`)

- [ ] When `/api/zones/summary` returns ≥ 1 zone, the map renders **zones** (ordered gate → weighbridge → yard → bay → unloading_bay → restricted → ppe → custom, then by name) instead of camera tiles; cameras with no zone at all still get a plain camera tile at the end so nothing disappears.
- [ ] Tile content per type: vehicles → "Truck · 2 h 41 m and counting", over limit → warn/crit colouring from the escalated episode; bays → "Empty" when nothing open; restricted → "0 people ✓" or the critical episode.
- [ ] Header counters: `N vehicles inside · M waiting (yard/gate) · B of T bays occupied · P people in restricted zones` computed from the summary.
- [ ] Ledger rows for vehicles: plate/class in mono, zone name in Where, the limit shown as "of 2 h" next to the timer, timer turns warning colour past the limit.
- [ ] Commit — `feat(ops-board): plant map from zones, yard counters, dwell limits in the ledger`

---

### Task 9: Deploy + prove at the office (before any plant)

Nothing here needs a yard. Draw two zones on the office camera:
1. `restricted` zone on the doorway — walk in → critical `person_in_zone` card within 3 s; walk out → "gone from camera"; resolve with a note.
2. `bay` zone with `limit_sec=60` on the desk → put a toy car / phone showing a truck picture? **No** — test vehicles honestly with the phone's *own* camera pointed at the street outside the window (webcam source via `--webcam` on the laptop, or the ISRPL visit footage). Expected: a `vehicle_in_zone` info row appears in Happening now with a counting timer, escalates to warning after 60 s, closes 60 s after the vehicle leaves.
3. Smoke section appended to `deploy/SERVER-SETUP.md`.

---

## Self-review

- Every zone type in the questionnaire (gate, weighbridge, yard, bays, unloading, restricted, PPE areas) has a tile, a rule, and an episode kind. ✓
- Nothing new runs on the GPU-less server except the polygon tests and the tracker; vehicles come from the inference pass that already runs. ✓
- No column added to any existing table (`camera_zones` keeps its shape; layout, if ever, is a new table). ✓
- Plate reading, visit linking across zones, and hazardous-bay procedure checks are explicitly out — each is its own plan. ✓
- The Android app needs one doc change (escalation notifies on `updated`). ✓
