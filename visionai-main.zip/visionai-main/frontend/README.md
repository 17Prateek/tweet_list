# Vision AI — frontend (Vite + React)

## Run locally
```
npm install
npm run dev          # opens on http://localhost:5173, talks to http://localhost:8000
```
The API address comes from `.env.development` (dev) and `.env.production`
(build). Both are committed on purpose — they are not secrets. To override
locally, create a `.env.local` (git-ignored).

## Build for production
```
npm run build        # writes dist/
```
`dist/` is git-ignored. See the root README for how it gets to the server.
