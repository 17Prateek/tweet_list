import {
  BrowserRouter,
  Navigate,
  Route,
  Routes,
} from "react-router-dom";

/* =========================================================
   PUBLIC PAGES
========================================================= */

import Login from "./pages/Login";
import Logout from "./pages/Logout";

/* =========================================================
   ROUTE PROTECTION
========================================================= */

import ProtectedRoute from "./components/ProtectedRoute";
import SuperAdminRoute from "./components/SuperAdminRoute";

/* =========================================================
   MAIN DASHBOARD LAYOUT
========================================================= */

import Dashboard from "./pages/Dashboard";

/* =========================================================
   OPERATIONS
========================================================= */

import OpsBoard from "./ops/OpsBoard";
import HistoryPage from "./ops/HistoryPage";
import ArrivalsPage from "./ops/ArrivalsPage";

import LiveMonitoringPage from "./pages/LiveMonitoringPage";

/*
 * Added from Code 1
 */
import CountingManagement from "./pages/CountingManagement";

/* =========================================================
   INFRASTRUCTURE
========================================================= */

import CameraManagementPage from "./pages/CameraManagementPage";
import ZoneEditor from "./setup/ZoneEditor";

/* =========================================================
   AI MANAGEMENT
========================================================= */

import FaceEnrollmentPage from "./pages/FaceEnrollmentPage";
import EnrolledPersons from "./pages/EnrolledPersons";

/* =========================================================
   SYSTEM
========================================================= */

import NotificationAlerts from "./pages/notificationalerts";
import EmailSettings from "./pages/EmailSettings";
import UserManagement from "./pages/UserManagement";

/* =========================================================
   CONTEXT
========================================================= */

import {
  LiveMonitoringProvider,
} from "./context/LiveMonitoringContext";

/* =========================================================
   APP
========================================================= */

export default function App() {
  return (
    <BrowserRouter>

      <LiveMonitoringProvider>

        <div className="min-h-screen w-full overflow-x-hidden bg-dark text-white">

          <Routes>

            {/* =================================================
                PUBLIC LOGIN
            ================================================= */}

            <Route
              path="/login"
              element={<Login />}
            />

            {/* =================================================
                PUBLIC LOGOUT SUCCESS PAGE
            ================================================= */}

            <Route
              path="/logout"
              element={<Logout />}
            />

            {/* =================================================
                PROTECTED APPLICATION

                Normal User + Super Admin require:
                - isLoggedIn
                - accessToken
                - currentUser
            ================================================= */}

            <Route
              path="/"
              element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              }
            >

              {/* ===============================================
                  DEFAULT ROUTE

                  Code 2 behavior preserved.

                  "/" -> "/ops"
              =============================================== */}

              <Route
                index
                element={
                  <Navigate
                    to="/ops"
                    replace
                  />
                }
              />

              {/* ===============================================
                  OPERATIONS
              =============================================== */}

              {/* OPS BOARD */}

              <Route
                path="ops"
                element={<OpsBoard />}
              />

              {/* LIVE MONITORING */}

              <Route
                path="live-monitoring"
                element={<LiveMonitoringPage />}
              />

              {/* ARRIVALS
                  Code 2 functionality preserved.
              */}

              <Route
                path="arrivals"
                element={<ArrivalsPage />}
              />

              {/* HISTORY & REPORTS
                  Code 2 functionality preserved.
              */}

              <Route
                path="history"
                element={<HistoryPage />}
              />

              {/* COUNTING MANAGEMENT
                  Added from Code 1.
              */}

              <Route
                path="counting-management"
                element={<CountingManagement />}
              />

              {/* ===============================================
                  INFRASTRUCTURE
              =============================================== */}

              {/* CAMERA MANAGEMENT */}

              <Route
                path="camera-management"
                element={<CameraManagementPage />}
              />

              {/* ZONES & LINES

                  Code 2 ZoneEditor preserved.
                  Sidebar label can be "Zones & Lines".
              */}

              <Route
                path="setup/zones"
                element={<ZoneEditor />}
              />

              {/* ===============================================
                  AI MANAGEMENT
              =============================================== */}

              {/* FACE ENROLLMENT */}

              <Route
                path="face-enrollment"
                element={<FaceEnrollmentPage />}
              />

              {/* ENROLLED PERSONS */}

              <Route
                path="enrolled-persons"
                element={<EnrolledPersons />}
              />

              {/* ===============================================
                  SYSTEM
              =============================================== */}

              {/* NOTIFICATIONS & ALERTS */}

              <Route
                path="notifications-alerts"
                element={<NotificationAlerts />}
              />

              {/* EMAIL SETTINGS */}

              <Route
                path="email-settings"
                element={<EmailSettings />}
              />

              {/* ===============================================
                  SUPER ADMIN ONLY
              =============================================== */}

              <Route
                path="user-management"
                element={
                  <SuperAdminRoute>
                    <UserManagement />
                  </SuperAdminRoute>
                }
              />

              {/* ===============================================
                  OLD DASHBOARD URL

                  Dashboard menu/page removed.

                  But if old URL /dashboard is opened,
                  redirect user to Ops Board.

                  This preserves Code 2 compatibility.
              =============================================== */}

              <Route
                path="dashboard"
                element={
                  <Navigate
                    to="/ops"
                    replace
                  />
                }
              />

            </Route>

            {/* =================================================
                INVALID URL
            ================================================= */}

            <Route
              path="*"
              element={
                <Navigate
                  to="/login"
                  replace
                />
              }
            />

          </Routes>

        </div>

      </LiveMonitoringProvider>

    </BrowserRouter>
  );
}
