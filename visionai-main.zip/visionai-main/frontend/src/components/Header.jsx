import {
  useEffect,
  useState,
} from "react";

import {
  Bell,
  ChevronDown,
  Mail,
  Menu,
  X,
} from "lucide-react";

import {
  getCameras,
} from "../data/api";

/* -------------------------------------------------------------------------- */
/*                               PAGE INFORMATION                             */
/* -------------------------------------------------------------------------- */

const pageInfo = {
  /* ------------------------------------------------------------------------ */
  /* LIVE MONITORING                                                         */
  /* ------------------------------------------------------------------------ */

  live: {
    title:
      "Live Monitoring",

    subtitle:
      "Real-time AI monitoring, smart alerts & instant actions",
  },

  /* ------------------------------------------------------------------------ */
  /* COUNTING MANAGEMENT                                                     */
  /* ------------------------------------------------------------------------ */

  /*
   * IMPORTANT:
   *
   * We ONLY use "counting".
   *
   * Dashboard converts:
   *
   * /counting-management
   *        ↓
   * "counting"
   */

  counting: {
    title:
      "Counting Management",

    subtitle:
      "Real-time AI monitoring for bags, boxes and material counting activities",
  },

  /* ------------------------------------------------------------------------ */
  /* CAMERA MANAGEMENT                                                       */
  /* ------------------------------------------------------------------------ */

  "camera-management": {
    title:
      "Camera Management",

    subtitle:
      "Manage, configure and monitor all your camera sources",
  },

  /* ------------------------------------------------------------------------ */
  /* ZONES & LINES                                                           */
  /* ------------------------------------------------------------------------ */

  zones: {
    title:
      "Zones & Lines",

    subtitle:
      "Create and manage monitoring zones and directional counting lines on each camera",
  },

  /* ------------------------------------------------------------------------ */
  /* FACE ENROLLMENT                                                         */
  /* ------------------------------------------------------------------------ */

  face: {
    title:
      "Face Enrollment",

    subtitle:
      "Register and manage face enrollment records",
  },

  /* ------------------------------------------------------------------------ */
  /* ENROLLED PERSONS                                                        */
  /* ------------------------------------------------------------------------ */

  "enrolled-persons": {
    title:
      "Enrolled Persons",

    subtitle:
      "Manage and control all enrolled persons and face recognition records",
  },

  /* ------------------------------------------------------------------------ */
  /* NOTIFICATIONS                                                           */
  /* ------------------------------------------------------------------------ */

  notifications: {
    title:
      "Notifications & Alerts",

    subtitle:
      "Real-time alerts and system notifications",
  },

  /* ------------------------------------------------------------------------ */
  /* EMAIL SETTINGS                                                          */
  /* ------------------------------------------------------------------------ */

  email: {
    title:
      "Email Settings",

    subtitle:
      "Configure email alerts and notifications",
  },

  /* ------------------------------------------------------------------------ */
  /* USER MANAGEMENT                                                         */
  /* ------------------------------------------------------------------------ */

  "user-management": {
    title:
      "User Management",

    subtitle:
      "Manage system users, roles and access permissions",
  },

  /* ------------------------------------------------------------------------ */
  /* COMMON                                                                  */
  /* ------------------------------------------------------------------------ */

  /*
   * Used for pages which already manage their own
   * page/header content:
   *
   * Ops Board
   * Arrivals
   * History & Reports
   */

  common: {
    title:
      "PPE Monitoring System",

    subtitle:
      "Real-time AI monitoring and safety management",
  },
};

/* -------------------------------------------------------------------------- */
/*                           LIVE MONITORING EVENTS                           */
/* -------------------------------------------------------------------------- */

const eventFilterItems = [
  "All Events",
  "Face",
  "Helmet Missing",
  "Vest Missing",
  "Safety Shoes Missing",
  "Welding Suit Missing",
  "Arcflash Suit Missing",
];

/* -------------------------------------------------------------------------- */
/*                              HEADER BUTTON                                 */
/* -------------------------------------------------------------------------- */

function HeaderButton({
  children,
}) {
  return (
    <button
      type="button"
      className="
        h-9
        shrink-0
        rounded-md
        border
        border-[#123250]
        bg-[#020817]
        px-2
        text-[10px]
        text-white
        transition
        hover:bg-[#0b2238]
        2xl:px-3
        2xl:text-[11px]
      "
    >
      {children}
    </button>
  );
}

/* -------------------------------------------------------------------------- */
/*                           NOTIFICATION BUTTON                              */
/* -------------------------------------------------------------------------- */

function NotificationButton({
  count = 12,
}) {
  return (
    <button
      type="button"
      className="
        relative
        grid
        h-9
        w-9
        shrink-0
        place-items-center
        rounded-md
        border
        border-[#123250]
        bg-[#020817]
        text-white
        transition
        hover:bg-[#0b2238]
      "
    >
      <Bell size={16} />

      {count > 0 && (
        <span
          className="
            absolute
            -right-1
            -top-1
            grid
            h-4
            min-w-4
            place-items-center
            rounded-full
            bg-red-600
            px-1
            text-[9px]
            font-bold
            leading-none
            text-white
          "
        >
          {count}
        </span>
      )}
    </button>
  );
}

/* -------------------------------------------------------------------------- */
/*                         COMMON HEADER CONTROLS                             */
/* -------------------------------------------------------------------------- */

function CommonHeaderControls() {
  return (
    <div
      className="
        ml-auto
        flex
        shrink-0
        items-center
        justify-end
        gap-2
      "
    >
      <HeaderButton>
        Mode: RTSP
      </HeaderButton>

      <HeaderButton>
        App: Idle
      </HeaderButton>

      <NotificationButton />
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                       COUNTING MANAGEMENT HEADER                           */
/* -------------------------------------------------------------------------- */

function CountingHeaderControls({
  countingLayout = 4,
  setCountingLayout,
}) {
  return (
    <>
      {/* COUNTING LAYOUT */}

      <div
        className="
          flex
          h-9
          shrink-0
          items-center
          overflow-hidden
          rounded-md
          border
          border-[#123250]
          bg-[#020817]
          text-[10px]
          text-white
        "
      >
        <span
          className="
            px-2
            text-white/70
          "
        >
          Layout:
        </span>

        {[1, 2, 4, 8].map(
          (layout) => (
            <button
              key={layout}
              type="button"
              onClick={() =>
                setCountingLayout?.(
                  layout
                )
              }
              className={`
                h-full
                px-2
                font-semibold
                transition

                ${
                  countingLayout ===
                  layout
                    ? "bg-blue-700 text-white"
                    : "border-l border-[#123250] hover:bg-[#0b2238]"
                }
              `}
            >
              {layout}
            </button>
          )
        )}
      </div>

      {/* MODE + APP + NOTIFICATION */}

      <CommonHeaderControls />
    </>
  );
}

/* -------------------------------------------------------------------------- */
/*                            EMAIL CONTROLS                                  */
/* -------------------------------------------------------------------------- */

function EmailHeaderControls() {
  return (
    <>
      {/* CONNECTION STATUS */}

      <div
        className="
          flex
          shrink-0
          items-center
          gap-1.5
          text-[11px]
          text-white/80
          2xl:text-[12px]
        "
      >
        <span>
          Connection Status
        </span>

        <span
          className="
            h-2
            w-2
            rounded-full
            bg-emerald-500
          "
        />

        <span
          className="
            font-semibold
            text-emerald-500
          "
        >
          Connected
        </span>
      </div>

      {/* SEND EMAIL */}

      <button
        type="button"
        className="
          flex
          h-9
          shrink-0
          items-center
          gap-2
          rounded-md
          border
          border-blue-700/70
          bg-[#020817]
          px-3
          text-[10px]
          font-semibold
          text-blue-500
          transition
          hover:bg-blue-950/40
          2xl:text-[12px]
        "
      >
        <Mail size={16} />

        Send Email
      </button>

      <CommonHeaderControls />
    </>
  );
}

/* -------------------------------------------------------------------------- */
/*                          LIVE HEADER CONTROLS                              */
/* -------------------------------------------------------------------------- */

function LiveHeaderControls({
  selectedEvents = [
    "All Events",
  ],

  setSelectedEvents,

  liveLayout = 4,

  setLiveLayout,
}) {
  /* ------------------------------------------------------------------------ */
  /* LOCAL EVENT STATE                                                       */
  /* ------------------------------------------------------------------------ */

  const [
    localSelectedEvents,
    setLocalSelectedEvents,
  ] = useState([
    "All Events",
  ]);

  /* ------------------------------------------------------------------------ */
  /* FILTER POPUP                                                            */
  /* ------------------------------------------------------------------------ */

  const [
    filterOpen,
    setFilterOpen,
  ] = useState(false);

  /* ------------------------------------------------------------------------ */
  /* CAMERA LIST                                                             */
  /* ------------------------------------------------------------------------ */

  const [
    cameraList,
    setCameraList,
  ] = useState([]);

  const [
    cameraLoading,
    setCameraLoading,
  ] = useState(false);

  const [
    selectedCameraId,
    setSelectedCameraId,
  ] = useState("");

  /* ------------------------------------------------------------------------ */
  /* ACTIVE EVENTS                                                           */
  /* ------------------------------------------------------------------------ */

  const activeEvents =
    setSelectedEvents
      ? selectedEvents
      : localSelectedEvents;

  const safeEvents =
    Array.isArray(
      activeEvents
    ) &&
    activeEvents.length
      ? activeEvents
      : ["All Events"];

  /* ------------------------------------------------------------------------ */
  /* SELECTED CAMERA                                                         */
  /* ------------------------------------------------------------------------ */

  const selectedCamera =
    cameraList.find(
      (camera) =>
        String(camera.id) ===
        String(
          selectedCameraId
        )
    );

  /* ------------------------------------------------------------------------ */
  /* FILTER DISPLAY VALUE                                                    */
  /* ------------------------------------------------------------------------ */

  const filterValue =
    selectedCamera
      ? `${
          selectedCamera.camera_name ||
          selectedCamera.cameraName ||
          selectedCamera.name
        } / ${
          safeEvents.length === 1
            ? safeEvents[0]
            : `${safeEvents.length} Events`
        }`
      : "Select Camera";

  /* ------------------------------------------------------------------------ */
  /* UPDATE EVENTS                                                           */
  /* ------------------------------------------------------------------------ */

  const updateEvents = (
    updater
  ) => {
    if (setSelectedEvents) {
      setSelectedEvents(
        updater
      );
    } else {
      setLocalSelectedEvents(
        updater
      );
    }
  };

  /* ------------------------------------------------------------------------ */
  /* LOAD CAMERAS                                                            */
  /* ------------------------------------------------------------------------ */

  const loadCameras =
    async () => {
      try {
        setCameraLoading(
          true
        );

        const res =
          await getCameras();

        if (res.ok) {
          setCameraList(
            res.data || []
          );
        }
      } catch (error) {
        console.error(
          "Camera list error:",
          error
        );
      } finally {
        setCameraLoading(
          false
        );
      }
    };

  /* ------------------------------------------------------------------------ */
  /* TOGGLE FILTER                                                           */
  /* ------------------------------------------------------------------------ */

  const toggleFilter =
    async () => {
      const next =
        !filterOpen;

      setFilterOpen(
        next
      );

      if (
        next &&
        cameraList.length === 0
      ) {
        await loadCameras();
      }
    };

  /* ------------------------------------------------------------------------ */
  /* TOGGLE EVENT                                                            */
  /* ------------------------------------------------------------------------ */

  const toggleEvent = (
    eventName
  ) => {
    updateEvents(
      (previous) => {
        const current =
          Array.isArray(
            previous
          ) &&
          previous.length
            ? previous
            : [
                "All Events",
              ];

        /*
         * All Events selected.
         */

        if (
          eventName ===
          "All Events"
        ) {
          return [
            "All Events",
          ];
        }

        /*
         * Remove All Events before
         * selecting individual event.
         */

        const withoutAll =
          current.filter(
            (item) =>
              item !==
              "All Events"
          );

        /*
         * Event already selected:
         * remove it.
         */

        if (
          withoutAll.includes(
            eventName
          )
        ) {
          const next =
            withoutAll.filter(
              (item) =>
                item !==
                eventName
            );

          return next.length
            ? next
            : [
                "All Events",
              ];
        }

        /*
         * Add selected event.
         */

        return [
          ...withoutAll,
          eventName,
        ];
      }
    );
  };

  /* ------------------------------------------------------------------------ */
  /* RESET FILTER                                                            */
  /* ------------------------------------------------------------------------ */

  const resetFilter = () => {
    setSelectedCameraId(
      ""
    );

    updateEvents(() => [
      "All Events",
    ]);
  };

  /* ------------------------------------------------------------------------ */
  /* UI                                                                       */
  /* ------------------------------------------------------------------------ */

  return (
    <>
      {/* -------------------------------------------------------------- */}
      {/* LIVE LAYOUT                                                    */}
      {/* -------------------------------------------------------------- */}

      <div
        className="
          flex
          h-9
          shrink-0
          items-center
          overflow-hidden
          rounded-md
          border
          border-[#123250]
          bg-[#020817]
          text-[10px]
          text-white
        "
      >
        <span
          className="
            px-2
            text-white/70
          "
        >
          Layout:
        </span>

        {[1, 2, 4, 8].map(
          (layout) => (
            <button
              key={layout}
              type="button"
              onClick={() =>
                setLiveLayout?.(
                  layout
                )
              }
              className={`
                h-full
                px-2
                font-semibold
                transition

                ${
                  liveLayout ===
                  layout
                    ? "bg-blue-700 text-white"
                    : "border-l border-[#123250] hover:bg-[#0b2238]"
                }
              `}
            >
              {layout}
            </button>
          )
        )}
      </div>

      {/* -------------------------------------------------------------- */}
      {/* CAMERA / EVENT FILTER                                         */}
      {/* -------------------------------------------------------------- */}

      <div className="relative z-50">

        <button
          type="button"
          onClick={
            toggleFilter
          }
          className="
            flex
            h-9
            w-[140px]
            items-center
            justify-between
            gap-1
            rounded-md
            border
            border-[#123250]
            bg-[#020817]
            px-2
            text-[10px]
            text-white
            transition
            hover:bg-[#0b2238]
            xl:w-[180px]
            2xl:w-[220px]
          "
        >
          <span
            className="
              shrink-0
              text-white/70
            "
          >
            Filter:
          </span>

          <span
            className="
              min-w-0
              flex-1
              truncate
              text-left
              font-semibold
            "
          >
            {filterValue}
          </span>

          <ChevronDown
            size={10}
            className={`
              shrink-0
              transition

              ${
                filterOpen
                  ? "rotate-180"
                  : ""
              }
            `}
          />

        </button>

        {/* ------------------------------------------------------------ */}
        {/* FILTER POPUP                                                */}
        {/* ------------------------------------------------------------ */}

        {filterOpen && (
          <div
            className="
              absolute
              right-0
              top-10
              w-[260px]
              rounded-md
              border
              border-[#123250]
              bg-[#061421]
              p-2
              shadow-2xl
            "
          >
            {/* CAMERA */}

            <p
              className="
                mb-1
                text-[9px]
                font-semibold
                text-white/50
              "
            >
              Select Camera
            </p>

            <select
              value={
                selectedCameraId
              }
              onChange={(e) =>
                setSelectedCameraId(
                  e.target.value
                )
              }
              className="
                mb-2
                h-9
                w-full
                rounded-md
                border
                border-[#123250]
                bg-[#020817]
                px-2
                text-[10px]
                text-white
                outline-none
                focus:border-blue-500
              "
            >
              <option value="">
                {cameraLoading
                  ? "Loading cameras..."
                  : "Select Camera Events"}
              </option>

              {cameraList.map(
                (camera) => (
                  <option
                    key={
                      camera.id
                    }
                    value={
                      camera.id
                    }
                  >
                    {camera.camera_name ||
                      camera.cameraName ||
                      camera.name}
                  </option>
                )
              )}
            </select>

            {/* EVENTS */}

            <p
              className="
                mb-1
                text-[9px]
                font-semibold
                text-white/50
              "
            >
              Select Events
            </p>

            <div
              className="
                max-h-[210px]
                overflow-y-auto
              "
            >
              {eventFilterItems.map(
                (item) => (
                  <label
                    key={item}
                    className="
                      flex
                      h-[28px]
                      cursor-pointer
                      items-center
                      gap-2
                      rounded
                      px-2
                      text-[10px]
                      text-white
                      hover:bg-[#0b2238]
                    "
                  >
                    <input
                      type="checkbox"
                      checked={
                        safeEvents.includes(
                          item
                        )
                      }
                      onChange={() =>
                        toggleEvent(
                          item
                        )
                      }
                      className="
                        h-3
                        w-3
                        accent-blue-600
                      "
                    />

                    <span className="truncate">
                      {item}
                    </span>
                  </label>
                )
              )}
            </div>

            {/* ACTIONS */}

            <div
              className="
                mt-2
                flex
                justify-end
                gap-2
                border-t
                border-[#123250]
                pt-2
              "
            >
              <button
                type="button"
                onClick={
                  resetFilter
                }
                className="
                  h-[26px]
                  rounded-md
                  border
                  border-[#123250]
                  px-3
                  text-[9px]
                  text-white
                  hover:bg-[#0b2238]
                "
              >
                Reset
              </button>

              <button
                type="button"
                onClick={() =>
                  setFilterOpen(
                    false
                  )
                }
                className="
                  h-[26px]
                  rounded-md
                  bg-blue-700
                  px-3
                  text-[9px]
                  font-semibold
                  text-white
                  hover:bg-blue-600
                "
              >
                Apply
              </button>
            </div>

          </div>
        )}

      </div>

      {/* COMMON */}

      <CommonHeaderControls />
    </>
  );
}

/* -------------------------------------------------------------------------- */
/*                                MAIN HEADER                                 */
/* -------------------------------------------------------------------------- */

export default function Header({
  activePage = "common",

  /* CAMERA */

  selectedCamera = null,
  setSelectedCamera = null,

  /* LIVE MONITORING */

  liveSelectedEvents = [
    "All Events",
  ],

  setLiveSelectedEvents =
    null,

  liveLayout = 4,
  setLiveLayout = null,

  /* COUNTING MANAGEMENT */

  countingLayout = 4,
  setCountingLayout = null,

  /* MOBILE SIDEBAR */

  menuOpen = false,
  onMenuClick = null,
}) {
  /* ------------------------------------------------------------------------ */
  /* CURRENT PAGE                                                            */
  /* ------------------------------------------------------------------------ */

  const current =
    pageInfo[activePage] ||
    pageInfo.common;

  /* ------------------------------------------------------------------------ */
  /* PAGE FLAGS                                                              */
  /* ------------------------------------------------------------------------ */

  const isLivePage =
    activePage ===
    "live";

  /*
   * ONLY ONE COUNTING KEY.
   */
  const isCountingPage =
    activePage ===
    "counting";

  const isEmailPage =
    activePage ===
    "email";

  /* ------------------------------------------------------------------------ */
  /* PAGES USING CAMERA DROPDOWN                                             */
  /* ------------------------------------------------------------------------ */

  /*
   * Counting is NOT included here.
   *
   * Counting Management should NOT show
   * camera dropdown in top header.
   */

  const useCameraHeader = [
    "face",
    "notifications",
  ].includes(
    activePage
  );

  /* ------------------------------------------------------------------------ */
  /* CAMERA LIST                                                             */
  /* ------------------------------------------------------------------------ */

  const [
    cameraList,
    setCameraList,
  ] = useState([]);

  const [
    cameraLoading,
    setCameraLoading,
  ] = useState(false);

  /* ------------------------------------------------------------------------ */
  /* LOAD CAMERAS                                                            */
  /* ------------------------------------------------------------------------ */

  useEffect(() => {
    if (!useCameraHeader) {
      return;
    }

    const loadCameras =
      async () => {
        try {
          setCameraLoading(
            true
          );

          const res =
            await getCameras();

          if (res.ok) {
            const cameras =
              res.data || [];

            setCameraList(
              cameras
            );

            if (
              !selectedCamera &&
              cameras.length &&
              setSelectedCamera
            ) {
              setSelectedCamera(
                cameras[0]
              );
            }
          }
        } catch (error) {
          console.error(
            "Camera list error:",
            error
          );
        } finally {
          setCameraLoading(
            false
          );
        }
      };

    loadCameras();
  }, [
    useCameraHeader,
    selectedCamera,
    setSelectedCamera,
  ]);

  /* ------------------------------------------------------------------------ */
  /* SELECTED CAMERA ID                                                      */
  /* ------------------------------------------------------------------------ */

  const selectedCameraId =
    selectedCamera?.id
      ? String(
          selectedCamera.id
        )
      : "";

  /* ------------------------------------------------------------------------ */
  /* HEADER                                                                  */
  /* ------------------------------------------------------------------------ */

  return (
    <header
      className="
        flex
        min-h-[54px]
        min-w-0
        flex-wrap
        items-center
        justify-between
        gap-2
        px-3
        pb-4
      "
    >
      {/* -------------------------------------------------------------- */}
      {/* LEFT SIDE                                                      */}
      {/* -------------------------------------------------------------- */}

      <div
        className="
          flex
          min-w-0
          flex-1
          basis-full
          items-center
          gap-3
          overflow-hidden
          sm:basis-0
        "
      >
        {/* ------------------------------------------------------------ */}
        {/* MOBILE MENU BUTTON                                          */}
        {/* ------------------------------------------------------------ */}

        <button
          type="button"
          onClick={
            onMenuClick
          }
          aria-label={
            menuOpen
              ? "Close menu"
              : "Open menu"
          }
          aria-expanded={
            menuOpen
          }
          aria-controls="main-nav"
          className="
            grid
            h-12
            w-12
            shrink-0
            place-items-center
            rounded-lg
            border
            border-[#123250]
            bg-[#07182a]
            text-blue-500
            transition
            hover:bg-[#0b2238]
            lg:hidden
          "
        >
          {menuOpen ? (
            <X size={27} />
          ) : (
            <Menu size={27} />
          )}
        </button>

        {/* ------------------------------------------------------------ */}
        {/* PAGE TITLE                                                   */}
        {/* ------------------------------------------------------------ */}

        <div
          className="
            min-w-0
            overflow-hidden
          "
        >
          <h1
            className="
              truncate
              text-lg
              font-bold
              leading-tight
              text-white
              lg:text-xl
              2xl:text-2xl
            "
          >
            {current.title}
          </h1>

          <p
            className="
              mt-1
              truncate
              text-[10px]
              leading-tight
              text-white/60
              lg:text-[11px]
              2xl:text-sm
            "
          >
            {current.subtitle}
          </p>
        </div>
      </div>

      {/* -------------------------------------------------------------- */}
      {/* RIGHT SIDE                                                     */}
      {/* -------------------------------------------------------------- */}

      <div
        className="
          flex
          min-w-0
          shrink-0
          items-center
          justify-end
          gap-2
          overflow-visible
        "
      >
        {/* ------------------------------------------------------------ */}
        {/* EMAIL SETTINGS                                              */}
        {/* ------------------------------------------------------------ */}

        {isEmailPage ? (

          <EmailHeaderControls />

        ) : isLivePage ? (

          /* ---------------------------------------------------------- */
          /* LIVE MONITORING                                           */
          /* ---------------------------------------------------------- */

          <LiveHeaderControls
            selectedEvents={
              liveSelectedEvents
            }

            setSelectedEvents={
              setLiveSelectedEvents
            }

            liveLayout={
              liveLayout
            }

            setLiveLayout={
              setLiveLayout
            }
          />

        ) : isCountingPage ? (

          /* ---------------------------------------------------------- */
          /* COUNTING MANAGEMENT                                       */
          /* ---------------------------------------------------------- */

          /*
           * Layout 1 / 2 / 4 / 8
           * Mode RTSP
           * App Idle
           * Notification
           *
           * NO CAMERA FILTER
           */

          <CountingHeaderControls
            countingLayout={
              countingLayout
            }

            setCountingLayout={
              setCountingLayout
            }
          />

        ) : useCameraHeader ? (

          /* ---------------------------------------------------------- */
          /* CAMERA-BASED HEADER                                       */
          /* ---------------------------------------------------------- */

          <>
            <div
              className="
                relative
                hidden
                shrink-0
                md:block
              "
            >
              <select
                value={
                  selectedCameraId
                }

                disabled={
                  cameraLoading ||
                  cameraList.length ===
                    0
                }

                onChange={(e) => {
                  const nextCamera =
                    cameraList.find(
                      (camera) =>
                        String(
                          camera.id
                        ) ===
                        e.target.value
                    );

                  if (
                    nextCamera &&
                    setSelectedCamera
                  ) {
                    setSelectedCamera(
                      nextCamera
                    );
                  }
                }}

                className="
                  h-9
                  w-[170px]
                  appearance-none
                  rounded-md
                  border
                  border-[#123250]
                  bg-[#020817]
                  px-3
                  pr-8
                  text-[10px]
                  text-white
                  outline-none
                  transition
                  hover:bg-[#0b2238]
                  focus:border-blue-500
                  disabled:cursor-not-allowed
                  disabled:opacity-60
                  xl:w-[210px]
                "
              >
                <option value="">
                  {cameraLoading
                    ? "Loading cameras..."
                    : "Select Camera"}
                </option>

                {cameraList.map(
                  (camera) => (
                    <option
                      key={
                        camera.id
                      }
                      value={
                        camera.id
                      }
                    >
                      Camera:{" "}
                      {camera.camera_name ||
                        camera.cameraName ||
                        camera.name}
                    </option>
                  )
                )}
              </select>

              <ChevronDown
                size={14}
                className="
                  pointer-events-none
                  absolute
                  right-3
                  top-1/2
                  -translate-y-1/2
                  text-white/70
                "
              />
            </div>

            <CommonHeaderControls />
          </>

        ) : (

          /* ---------------------------------------------------------- */
          /* DEFAULT / COMMON HEADER                                   */
          /* ---------------------------------------------------------- */

          <CommonHeaderControls />

        )}
      </div>

    </header>
  );
}
