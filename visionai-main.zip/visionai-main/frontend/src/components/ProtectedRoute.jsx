import { Navigate, useLocation } from "react-router-dom";

export default function ProtectedRoute({ children }) {
  const location = useLocation();

  // =========================================================
  // Read authentication session
  // =========================================================
  const isLoggedIn =
    sessionStorage.getItem("isLoggedIn") === "true";

  const accessToken =
    sessionStorage.getItem("accessToken");

  const storedUser =
    sessionStorage.getItem("currentUser");

  // =========================================================
  // Validate currentUser
  // =========================================================
  let currentUser = null;

  try {
    if (storedUser) {
      currentUser = JSON.parse(storedUser);
    }
  } catch (error) {
    console.error(
      "Unable to parse current user:",
      error
    );

    currentUser = null;
  }

  // =========================================================
  // Complete authentication check
  //
  // User must have:
  // 1. isLoggedIn = true
  // 2. JWT access token
  // 3. valid currentUser object
  // =========================================================
  const isAuthenticated =
    isLoggedIn &&
    Boolean(accessToken) &&
    Boolean(currentUser);

  // =========================================================
  // Not authenticated
  // =========================================================
  if (!isAuthenticated) {
    // Remove incomplete / invalid frontend session.
    sessionStorage.removeItem("isLoggedIn");
    sessionStorage.removeItem("loggedInEmail");
    sessionStorage.removeItem("accessToken");
    sessionStorage.removeItem("currentUser");

    return (
      <Navigate
        to="/login"
        replace
        state={{
          from:
            location.pathname +
            location.search,
        }}
      />
    );
  }

  // =========================================================
  // Validate supported application role
  // =========================================================
  const role = String(
    currentUser?.role || ""
  )
    .trim()
    .toLowerCase();

  const allowedRoles = [
    "user",
    "super_admin",
  ];

  if (!allowedRoles.includes(role)) {
    sessionStorage.removeItem("isLoggedIn");
    sessionStorage.removeItem("loggedInEmail");
    sessionStorage.removeItem("accessToken");
    sessionStorage.removeItem("currentUser");

    return (
      <Navigate
        to="/login"
        replace
        state={{
          from:
            location.pathname +
            location.search,
        }}
      />
    );
  }

  // =========================================================
  // Authenticated normal user OR super admin
  // =========================================================
  return children;
}