import {
  Bell,
  Camera,
  History,
  Truck,
  LogOut,
  Mail,
  Map,
  Monitor,
  ScanFace,
  Settings,
  TriangleAlert,
  UserCog,
  Users,
} from "lucide-react";

import {
  NavLink,
  useNavigate,
} from "react-router-dom";

import logo from "../assets/vision-ai-logo.png";

/* =========================================================
   MENU CONFIGURATION
========================================================= */

const menuGroups = [
  {
    title: "OPERATIONS",
    items: [
      {
        icon: TriangleAlert,
        label: "Ops Board",
        path: "/ops",
      },
      {
        icon: Monitor,
        label: "Live Monitoring",
        path: "/live-monitoring",
      },

      // Code 2 menu
      {
        icon: Truck,
        label: "Arrivals",
        path: "/arrivals",
      },

      // Code 2 menu
      {
        icon: History,
        label: "History & Reports",
        path: "/history",
      },

      // Added from Code 1
      {
        icon: Truck,
        label: "Counting Management",
        path: "/counting-management",
      },
    ],
  },

  {
    title: "INFRASTRUCTURE",
    items: [
      {
        icon: Camera,
        label: "Camera Management",
        path: "/camera-management",
      },

      // Code 2 route preserved.
      // Only label updated from "Zones" -> "Zones & Lines"
      {
        icon: Map,
        label: "Zones & Lines",
        path: "/setup/zones",
      },
    ],
  },

  {
    title: "AI MANAGEMENT",
    items: [
      {
        icon: ScanFace,
        label: "Face Enrollment",
        path: "/face-enrollment",
      },
      {
        icon: Users,
        label: "Enrolled Persons",
        path: "/enrolled-persons",
      },
    ],
  },

  {
    title: "SYSTEM",
    items: [
      {
        icon: Bell,
        label: "Notifications & Alerts",
        path: "/notifications-alerts",
      },
      {
        icon: Mail,
        label: "Email Settings",
        path: "/email-settings",
      },

      /*
       * Super Admin only
       */
      {
        icon: UserCog,
        label: "User Management",
        path: "/user-management",
        superAdminOnly: true,
      },

      /*
       * Logout
       *
       * Normal User + Super Admin
       * dono ko visible.
       */
      {
        icon: LogOut,
        label: "Logout",
        action: "logout",
      },
    ],
  },
];

/* =========================================================
   GET CURRENT LOGGED-IN USER
========================================================= */

function getCurrentUser() {
  try {
    const storedUser =
      sessionStorage.getItem("currentUser");

    if (!storedUser) {
      return null;
    }

    return JSON.parse(storedUser);
  } catch (error) {
    console.error(
      "Unable to read current user:",
      error
    );

    return null;
  }
}

/* =========================================================
   SIDEBAR
========================================================= */

/**
 * `open` only matters below lg, where the sidebar is the phone's menu and the
 * header's hamburger toggles it. From lg up it is the permanent left column.
 *
 * `onNavigate` closes the menu once a page has been picked.
 */
export default function Sidebar({
  open = false,
  onNavigate,
}) {
  const navigate = useNavigate();

  const currentUser = getCurrentUser();

  /* =======================================================
     ROLE
  ======================================================= */

  const role =
    String(currentUser?.role || "")
      .trim()
      .toLowerCase();

  const isSuperAdmin =
    role === "super_admin";

  /* =======================================================
     USER NAME
  ======================================================= */

  const userName =
    currentUser?.fullName ||
    currentUser?.name ||
    currentUser?.full_name ||
    currentUser?.email ||
    "User";

  /* =======================================================
     ROLE LABEL
  ======================================================= */

  const roleLabel =
    isSuperAdmin
      ? "Super Admin"
      : "User";

  /* =======================================================
     AVATAR LETTER
  ======================================================= */

  const avatarLetter =
    String(userName)
      .trim()
      .charAt(0)
      .toUpperCase() || "U";

  /* =======================================================
     LOGOUT
  ======================================================= */

  const handleLogout = () => {
    /*
     * Remove authentication/session information.
     *
     * JWT access token is stored in sessionStorage,
     * therefore logout removes it from this browser tab.
     */

    sessionStorage.removeItem("isLoggedIn");
    sessionStorage.removeItem("loggedInEmail");
    sessionStorage.removeItem("accessToken");
    sessionStorage.removeItem("currentUser");

    /*
     * Close sidebar on mobile.
     */
    onNavigate?.();

    /*
     * Open public logout success page.
     */

    navigate("/logout", {
      replace: true,
    });
  };

  return (
    <aside
      id="main-nav"
      className={`${
        open ? "flex" : "hidden"
      } w-full flex-col justify-between gap-4 border-r border-[#0f2a44] bg-[#020c16]/95 px-2 py-3 lg:flex lg:w-[185px] lg:shrink-0`}
    >

      {/* ===================================================
          TOP SECTION
      =================================================== */}

      <div className="min-w-0">

        {/* LOGO */}

        {/* LOGO */}

        <div className="mb-4 flex justify-center px-1">
          <div className="flex h-[60px] w-full max-w-[170px] items-center justify-center overflow-hidden rounded-md bg-white p-2 shadow-sm">
            <img
              src={logo}
              alt="Paperless AI"
              className="h-full w-full object-contain"
            />
          </div>
        </div>

        {/* =================================================
            NAVIGATION
        ================================================= */}

        <nav className="space-y-5">

          {menuGroups.map((group) => {

            /*
             * Normal User:
             * remove Super Admin only menu.
             *
             * Super Admin:
             * show all menus.
             */

            const visibleItems =
              group.items.filter((item) => {

                if (
                  item.superAdminOnly &&
                  !isSuperAdmin
                ) {
                  return false;
                }

                return true;
              });

            if (visibleItems.length === 0) {
              return null;
            }

            return (
              <div
                key={group.title}
                className="min-w-0"
              >

                <p className="mb-2 truncate px-1 text-[12px] font-bold uppercase tracking-wide text-[#1686ff]">
                  {group.title}
                </p>

                <div className="space-y-1.5">

                  {visibleItems.map((item) => {

                    const Icon = item.icon;

                    /* =====================================
                       LOGOUT BUTTON
                    ===================================== */

                    if (item.action === "logout") {
                      return (
                        <button
                          key={item.label}
                          type="button"
                          title={item.label}
                          onClick={handleLogout}
                          className="flex w-full min-w-0 items-center gap-2 rounded-md px-2 py-2 text-left text-sm font-semibold text-white/90 transition hover:bg-[#0b2238] hover:text-white"
                        >
                          <Icon
                            size={18}
                            className="shrink-0"
                          />

                          <span className="min-w-0 truncate">
                            {item.label}
                          </span>
                        </button>
                      );
                    }

                    /* =====================================
                       NORMAL NAVIGATION ITEM
                    ===================================== */

                    return (
                      <NavLink
                        key={item.path}
                        to={item.path}
                        title={item.label}

                        // Code 2 responsive functionality
                        onClick={onNavigate}

                        className={({ isActive }) =>
                          `flex w-full min-w-0 items-center gap-2 rounded-md px-2 py-2 text-sm font-semibold transition ${
                            isActive
                              ? "bg-[#0d63e6] text-white shadow-[0_0_12px_rgba(13,99,230,.3)]"
                              : "text-white/90 hover:bg-[#0b2238]"
                          }`
                        }
                      >
                        <Icon
                          size={18}
                          className="shrink-0"
                        />

                        <span className="min-w-0 truncate">
                          {item.label}
                        </span>
                      </NavLink>
                    );
                  })}

                </div>
              </div>
            );
          })}

        </nav>
      </div>

      {/* ===================================================
          LOGGED-IN USER CARD
      =================================================== */}

      <div className="flex min-w-0 items-center gap-2 rounded-lg bg-[#0b1c2f] p-2.5">

        {/* AVATAR */}

        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[#0d63e6] text-sm font-bold text-white">
          {avatarLetter}
        </div>

        {/* NAME + ROLE */}

        <div className="min-w-0 flex-1 leading-tight">

          <div
            className="truncate text-sm font-semibold text-white"
            title={userName}
          >
            {userName}
          </div>

          <div
            className="truncate text-sm text-gray-400"
            title={roleLabel}
          >
            {roleLabel}
          </div>

        </div>

        {/*
          NOTE:
          This Settings icon is only user-card icon.
          It is NOT the removed Settings sidebar menu.
        */}
        <Settings
          size={18}
          className="shrink-0 text-gray-400"
        />

      </div>

    </aside>
  );
}
