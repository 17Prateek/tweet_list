import { Navigate, useLocation } from "react-router-dom";

export default function SuperAdminRoute({ children }) {
  const location = useLocation();

  // =========================================================
  // Read current frontend session
  // =========================================================
  const isLoggedIn =
    sessionStorage.getItem("isLoggedIn") === "true";

  const accessToken =
    sessionStorage.getItem("accessToken");

  const storedUser =
    sessionStorage.getItem("currentUser");

  // =========================================================
  // Parse current user safely
  // =========================================================
  let currentUser = null;

  try {
    if (storedUser) {
      currentUser = JSON.parse(storedUser);
    }
  } catch (error) {
    console.error(
      "Unable to parse current user:",
      error
    );

    currentUser = null;
  }

  // =========================================================
  // User must first be authenticated
  // =========================================================
  const isAuthenticated =
    isLoggedIn &&
    Boolean(accessToken) &&
    Boolean(currentUser);

  if (!isAuthenticated) {
    sessionStorage.removeItem("isLoggedIn");
    sessionStorage.removeItem("loggedInEmail");
    sessionStorage.removeItem("accessToken");
    sessionStorage.removeItem("currentUser");

    return (
      <Navigate
        to="/login"
        replace
        state={{
          from:
            location.pathname +
            location.search,
        }}
      />
    );
  }

  // =========================================================
  // Super Admin role check
  // =========================================================
  const role = String(
    currentUser?.role || ""
  )
    .trim()
    .toLowerCase();

  // Normal user trying to open /user-management
  if (role !== "super_admin") {
    return (
      <Navigate
        to="/dashboard"
        replace
      />
    );
  }

  // =========================================================
  // Authenticated Super Admin
  // =========================================================
  return children;
}