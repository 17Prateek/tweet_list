import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
} from "react";


// =========================================================
// Context
// =========================================================

const LiveMonitoringContext =
  createContext(null);


// =========================================================
// Constants
// =========================================================

const TOTAL_LIVE_SLOTS = 8;


// =========================================================
// Initial states
// =========================================================

function createInitialSelectedSlots() {
  return Array.from(
    { length: TOTAL_LIVE_SLOTS },
    () => null
  );
}


function createInitialRecognitionSlots() {
  return Array.from(
    { length: TOTAL_LIVE_SLOTS },
    () => false
  );
}


// =========================================================
// Provider
// =========================================================

export function LiveMonitoringProvider({
  children,
}) {
  // -------------------------------------------------------
  // Selected camera ID per UI frame
  //
  // Example:
  //
  // [
  //   3,       // Frame 1 -> Camera 3
  //   5,       // Frame 2 -> Camera 5
  //   null,
  //   ...
  // ]
  // -------------------------------------------------------

  const [
    selectedSlots,
    setSelectedSlots,
  ] = useState(
    createInitialSelectedSlots
  );


  // -------------------------------------------------------
  // Detection ON/OFF state per frame
  //
  // true means:
  //   person detection
  //   PPE detection
  //   face recognition
  //
  // are enabled for that slot.
  // -------------------------------------------------------

  const [
    recognitionSlots,
    setRecognitionSlots,
  ] = useState(
    createInitialRecognitionSlots
  );


  // -------------------------------------------------------
  // Global sound alert state
  // -------------------------------------------------------

  const [
    soundAlertsEnabled,
    setSoundAlertsEnabled,
  ] = useState(true);


  // =======================================================
  // Update one selected camera
  // =======================================================

  const updateSelectedCamera =
    useCallback(
      (
        slotIndex,
        cameraId
      ) => {
        const index =
          Number(slotIndex);

        if (
          !Number.isInteger(index) ||
          index < 0 ||
          index >= TOTAL_LIVE_SLOTS
        ) {
          return {
            ok: false,
            message:
              "Invalid camera frame.",
          };
        }


        // -----------------------------------------------
        // Normalize camera ID
        // -----------------------------------------------

        let normalizedCameraId =
          null;

        if (
          cameraId !== null &&
          cameraId !== undefined &&
          cameraId !== ""
        ) {
          const numericId =
            Number(cameraId);

          normalizedCameraId =
            Number.isNaN(numericId)
              ? cameraId
              : numericId;
        }


        // -----------------------------------------------
        // Prevent same physical camera being selected
        // in multiple frames.
        // -----------------------------------------------

        if (
          normalizedCameraId !== null
        ) {
          const alreadyUsedIndex =
            selectedSlots.findIndex(
              (
                selectedCameraId,
                currentIndex
              ) => {
                if (
                  currentIndex === index
                ) {
                  return false;
                }

                if (
                  selectedCameraId === null ||
                  selectedCameraId === undefined
                ) {
                  return false;
                }

                return (
                  Number(
                    selectedCameraId
                  ) ===
                  Number(
                    normalizedCameraId
                  )
                );
              }
            );


          if (
            alreadyUsedIndex !== -1
          ) {
            return {
              ok: false,
              message:
                `This camera is already selected in Frame ${
                  alreadyUsedIndex + 1
                }.`,
            };
          }
        }


        const previousCameraId =
          selectedSlots[index];


        // -----------------------------------------------
        // Same camera selected again.
        // No state change required.
        // -----------------------------------------------

        if (
          previousCameraId !== null &&
          normalizedCameraId !== null &&
          Number(previousCameraId) ===
            Number(
              normalizedCameraId
            )
        ) {
          return {
            ok: true,
            changed: false,
            previousCameraId,
            cameraId:
              normalizedCameraId,
          };
        }


        // -----------------------------------------------
        // Change selected camera.
        // -----------------------------------------------

        setSelectedSlots(
          (current) => {
            const updated = [
              ...current,
            ];

            updated[index] =
              normalizedCameraId;

            return updated;
          }
        );


        // -----------------------------------------------
        // IMPORTANT:
        //
        // Camera A -> Camera B
        //
        // Detection UI must reset OFF.
        //
        // LiveMonitoring.jsx handles backend STOP for
        // Camera A before/while switching.
        //
        // Camera B must NOT automatically inherit
        // Camera A detection state.
        // -----------------------------------------------

        setRecognitionSlots(
          (current) => {
            const updated = [
              ...current,
            ];

            updated[index] =
              false;

            return updated;
          }
        );


        return {
          ok: true,
          changed: true,

          previousCameraId,

          cameraId:
            normalizedCameraId,
        };
      },
      [selectedSlots]
    );


  // =======================================================
  // Clear one camera slot
  // =======================================================

  const clearSelectedCamera =
    useCallback(
      (slotIndex) => {
        const index =
          Number(slotIndex);

        if (
          !Number.isInteger(index) ||
          index < 0 ||
          index >= TOTAL_LIVE_SLOTS
        ) {
          return {
            ok: false,
            message:
              "Invalid camera frame.",
          };
        }


        const previousCameraId =
          selectedSlots[index];


        setSelectedSlots(
          (current) => {
            const updated = [
              ...current,
            ];

            updated[index] =
              null;

            return updated;
          }
        );


        setRecognitionSlots(
          (current) => {
            const updated = [
              ...current,
            ];

            updated[index] =
              false;

            return updated;
          }
        );


        return {
          ok: true,
          previousCameraId,
        };
      },
      [selectedSlots]
    );


  // =======================================================
  // Check whether camera is already used
  // =======================================================

  const isCameraAlreadySelected =
    useCallback(
      (
        cameraId,
        excludeSlotIndex = null
      ) => {
        if (
          cameraId === null ||
          cameraId === undefined ||
          cameraId === ""
        ) {
          return false;
        }


        return selectedSlots.some(
          (
            selectedCameraId,
            index
          ) => {
            if (
              excludeSlotIndex !== null &&
              Number(
                excludeSlotIndex
              ) === index
            ) {
              return false;
            }


            if (
              selectedCameraId === null ||
              selectedCameraId === undefined
            ) {
              return false;
            }


            return (
              Number(
                selectedCameraId
              ) ===
              Number(
                cameraId
              )
            );
          }
        );
      },
      [selectedSlots]
    );


  // =======================================================
  // Reset monitoring UI
  // =======================================================

  const resetLiveMonitoring =
    useCallback(() => {
      setSelectedSlots(
        createInitialSelectedSlots()
      );

      setRecognitionSlots(
        createInitialRecognitionSlots()
      );
    }, []);


  // =======================================================
  // Context value
  // =======================================================

  const value =
    useMemo(
      () => ({
        // -----------------------------------------------
        // Number of slots
        // -----------------------------------------------

        totalSlots:
          TOTAL_LIVE_SLOTS,


        // -----------------------------------------------
        // Camera selection
        // -----------------------------------------------

        selectedSlots,

        setSelectedSlots,

        updateSelectedCamera,

        clearSelectedCamera,

        isCameraAlreadySelected,


        // -----------------------------------------------
        // Detection state
        // -----------------------------------------------

        recognitionSlots,

        setRecognitionSlots,


        // -----------------------------------------------
        // Sound alert
        // -----------------------------------------------

        soundAlertsEnabled,

        setSoundAlertsEnabled,


        // -----------------------------------------------
        // Reset
        // -----------------------------------------------

        resetLiveMonitoring,
      }),
      [
        selectedSlots,
        updateSelectedCamera,
        clearSelectedCamera,
        isCameraAlreadySelected,

        recognitionSlots,

        soundAlertsEnabled,
      ]
    );


  return (
    <LiveMonitoringContext.Provider
      value={value}
    >
      {children}
    </LiveMonitoringContext.Provider>
  );
}


// =========================================================
// Hook expected by LiveMonitoring.jsx
// =========================================================

export function useLiveMonitoringContext() {
  const context =
    useContext(
      LiveMonitoringContext
    );

  if (!context) {
    throw new Error(
      "useLiveMonitoringContext must be used inside LiveMonitoringProvider"
    );
  }

  return context;
}


// =========================================================
// Optional aliases
// =========================================================

export const useLiveMonitoring =
  useLiveMonitoringContext;


export default LiveMonitoringContext;