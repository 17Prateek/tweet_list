const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

// =========================================================
// JWT AUTHENTICATION HELPERS
// =========================================================

export function getAccessToken() {
  return sessionStorage.getItem("accessToken") || "";
}

export function clearAuthSession() {
  sessionStorage.removeItem("isLoggedIn");
  sessionStorage.removeItem("loggedInEmail");
  sessionStorage.removeItem("accessToken");
  sessionStorage.removeItem("currentUser");
}

function buildAuthenticatedHeaders(headers = {}) {
  const token = getAccessToken();

  return {
    ...headers,
    ...(token
      ? {
          Authorization: `Bearer ${token}`,
        }
      : {}),
  };
}

export async function authenticatedFetch(
  url,
  options = {}
) {
  const response = await fetch(url, {
    ...options,
    headers: buildAuthenticatedHeaders(
      options.headers || {}
    ),
  });

  // JWT missing / invalid / expired
  if (response.status === 401) {
    clearAuthSession();

    if (window.location.pathname !== "/login") {
      const returnTo =
        window.location.pathname +
        window.location.search;

      sessionStorage.setItem(
        "authReturnTo",
        returnTo
      );

      window.location.replace("/login");
    }
  }

  return response;
}


// =========================================================
// Camera Groups
// =========================================================

export async function getCameraGroups() {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/camera-groups`
  );

  return res.json();
}


export async function createCameraGroup(payload) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/camera-groups`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );

  return res.json();
}


export async function deleteCameraGroup(groupId) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/camera-groups/${groupId}`,
    {
      method: "DELETE",
    }
  );

  return res.json();
}


// =========================================================
// Cameras
// =========================================================

export async function getCameras() {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/cameras`
  );

  return res.json();
}


export async function createCamera(payload) {
  console.log("Camera Payload:", payload);

  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/cameras`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );

  return res.json();
}


export async function deleteCamera(cameraId) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/cameras/${cameraId}`,
    {
      method: "DELETE",
    }
  );

  return res.json();
}


export async function updateCamera(
  cameraId,
  payload
) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/cameras/${cameraId}`,
    {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );

  return res.json();
}


// =========================================================
// Camera stream URL helpers
//
// IMPORTANT:
// These only return URLs.
// They do NOT attach Authorization headers.
//
// We will secure/render these streams separately.
// =========================================================

export function getCameraStreamUrl(cameraId) {
  return `${API_BASE_URL}/api/cameras/${cameraId}/stream`;
}


export function getCameraDetectionStreamUrl(
  cameraId,
  frameId
) {
  const safeCameraId = encodeURIComponent(
    String(cameraId)
  );

  const safeFrameId = encodeURIComponent(
    String(frameId)
  );

  return `${API_BASE_URL}/api/cameras/${safeCameraId}/detection-stream?frame_id=${safeFrameId}`;
}


// =========================================================
// Detection stats
// =========================================================

export async function getCameraDetectionStats(
  cameraId
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/cameras/${cameraId}/detection-stats`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  const data = await response.json();

  if (!response.ok || data?.ok === false) {
    throw new Error(
      data?.message ||
        "Could not load camera detection stats"
    );
  }

  return data;
}


// =========================================================
// Camera Recording
// =========================================================

export async function startCameraRecording(
  cameraId
) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/cameras/${cameraId}/recording/start`,
    {
      method: "POST",
    }
  );

  return res.json();
}


// =========================================================
// Camera Issues APIs
// =========================================================

export async function getCameraIssues() {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/camera-issues`
  );

  return res.json();
}


export async function getCameraIssue(cameraId) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/camera-issues/${cameraId}`
  );

  return res.json();
}


export async function stopCameraRecording(
  cameraId
) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/cameras/${cameraId}/recording/stop`,
    {
      method: "POST",
    }
  );

  return res.json();
}


// =========================================================
// Recording URL helper
//
// This is only a direct URL.
// Protected recording serving will be handled separately.
// =========================================================

export function getRecordingDownloadUrl(
  downloadUrl
) {
  return `${API_BASE_URL}${downloadUrl}`;
}


// =========================================================
// Face Enrollment Recognition APIs
// =========================================================

export async function startFaceRecognition(
  cameraId
) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/face-enrollment/${cameraId}/recognition/start`,
    {
      method: "POST",
    }
  );

  return res.json();
}


export async function stopFaceRecognition(
  cameraId
) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/face-enrollment/${cameraId}/recognition/stop`,
    {
      method: "POST",
    }
  );

  return res.json();
}


export async function getFaceRecognitionStatus(
  cameraId
) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/face-enrollment/${cameraId}/recognition/status`
  );

  return res.json();
}


// =========================================================
// Face recognition stream URL helper
//
// Does NOT attach Authorization header.
// Stream handling will be updated separately.
// =========================================================

export function getFaceRecognitionStreamUrl(
  cameraId
) {
  return `${API_BASE_URL}/api/face-enrollment/${cameraId}/recognition-stream`;
}


// =========================================================
// Capture Face
// =========================================================

export async function captureFace(cameraId) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/face-enrollment/${cameraId}/capture`,
    {
      method: "POST",
    }
  );

  return res.json();
}


// =========================================================
// Import Faces
// =========================================================

export async function importFaces(files) {
  const formData = new FormData();

  files.forEach((file) => {
    formData.append("files", file);
  });

  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/face-enrollment/import`,
    {
      method: "POST",

      // Do NOT manually add Content-Type here.
      // Browser automatically adds multipart boundary.
      body: formData,
    }
  );

  return res.json();
}


// =========================================================
// Face Enrollment Master Data APIs
// =========================================================

export async function getDepartments() {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/departments`
  );

  return res.json();
}


export async function createDepartment(payload) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/departments`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );

  return res.json();
}


export async function deleteDepartment(
  departmentId
) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/departments/${departmentId}`,
    {
      method: "DELETE",
    }
  );

  return res.json();
}


export async function getRoles() {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/roles`
  );

  return res.json();
}


export async function createRole(payload) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/roles`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );

  return res.json();
}


export async function deleteRole(roleId) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/roles/${roleId}`,
    {
      method: "DELETE",
    }
  );

  return res.json();
}


// =========================================================
// Face Enrollment Save Person API
// =========================================================

export async function enrollFacePerson(
  payload
) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/face-enrollment/enroll`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );

  return res.json();
}


// =========================================================
// Shared Response Handler
// =========================================================

async function handleResponse(response) {
  let data = null;

  try {
    data = await response.json();
  } catch {
    data = null;
  }

  if (!response.ok || data?.ok === false) {
    throw new Error(
      data?.message ||
        data?.detail ||
        "Something went wrong"
    );
  }

  return data;
}


// =========================================================
// Email Recipient APIs
// =========================================================

export async function getEmailRecipients() {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/email-recipients`
  );

  return handleResponse(response);
}


export async function createEmailRecipient(
  payload
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/email-recipients`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );

  return handleResponse(response);
}


export async function updateEmailRecipient(
  id,
  payload
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/email-recipients/${id}`,
    {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );

  return handleResponse(response);
}


export async function deleteEmailRecipient(id) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/email-recipients/${id}`,
    {
      method: "DELETE",
    }
  );

  return handleResponse(response);
}


export async function sendTestEmailRecipient(
  id
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/email-recipients/${id}/test`,
    {
      method: "POST",
    }
  );

  return handleResponse(response);
}


// =========================================================
// Live Events APIs
// =========================================================

export async function getLiveEvents() {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/live-events`
  );

  return res.json();
}


export async function updateLiveEventStatus(
  eventId,
  status
) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/live-events/${eventId}/status?status=${encodeURIComponent(
      status
    )}`,
    {
      method: "PUT",
    }
  );

  return res.json();
}


// =========================================================
// Evidence Image URL Helper
//
// This only returns URL.
// Protected image fetching will be handled separately.
// =========================================================

export function getEvidenceImageUrl(
  evidenceImage
) {
  if (!evidenceImage) {
    return "";
  }

  return `${API_BASE_URL}${evidenceImage}`;
}


// =========================================================
// Email Alert Control APIs
// =========================================================

export async function getEmailAlertStatus() {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/email-alerts/status`
  );

  return handleResponse(response);
}


export async function getEmailAlertHistory(
  page = 1,
  pageSize = 10
) {
  const params = new URLSearchParams({
    page: String(page),
    page_size: String(pageSize),
  });

  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/email-alerts/history?${params.toString()}`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  return handleResponse(response);
}


export async function updateEmailAlertStatus(
  enabled,
  frequency_minutes
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/email-alerts/status`,
    {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        enabled,
        frequency_minutes,
      }),
    }
  );

  return handleResponse(response);
}


export async function getActiveEmailViolations() {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/email-alerts/active-violations`
  );

  return handleResponse(response);
}


export async function getEmailWorkerStatus() {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/email-alerts/worker-status`
  );

  return handleResponse(response);
}


// =========================================================
// Live Events Historical Range
// =========================================================

export async function getLiveEventsByRange(
  startTime,
  endTime
) {
  try {
    const params = new URLSearchParams({
      start_time: startTime,
      end_time: endTime,
    });

    const response =
      await authenticatedFetch(
        `${API_BASE_URL}/api/live-events/export?${params.toString()}`,
        {
          method: "GET",
          headers: {
            Accept: "application/json",
          },
        }
      );

    const result = await response.json();

    if (
      !response.ok ||
      result.ok === false
    ) {
      return {
        ok: false,
        data: [],
        message:
          result.message ||
          "Could not load historical events",
      };
    }

    return {
      ok: true,
      data: Array.isArray(result.data)
        ? result.data
        : [],
      count: result.count || 0,
      message: result.message || "",
    };
  } catch (error) {
    console.error(
      "getLiveEventsByRange error:",
      error
    );

    return {
      ok: false,
      data: [],
      message:
        error.message ||
        "Network error while loading historical events",
    };
  }
}


// =========================================================
// Frame Detection Status
// =========================================================

export async function getFrameDetectionStatus(
  cameraId,
  frameId
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/cameras/${cameraId}/frames/${frameId}/detection/status`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  const data = await response.json();

  if (!response.ok || data?.ok === false) {
    throw new Error(
      data?.message ||
        "Could not load detection status"
    );
  }

  return data;
}


// =========================================================
// Start Detection
// =========================================================

export async function startFrameDetection(
  cameraId,
  frameId
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/cameras/${cameraId}/frames/${frameId}/detection/start`,
    {
      method: "POST",
      headers: {
        Accept: "application/json",
      },
    }
  );

  let data = null;

  try {
    data = await response.json();
  } catch {
    data = null;
  }

  if (!response.ok || data?.ok === false) {
    throw new Error(
      data?.message ||
        "Could not start detection"
    );
  }

  return data;
}


// =========================================================
// Stop Detection
// =========================================================

export async function stopFrameDetection(
  cameraId,
  frameId
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/cameras/${cameraId}/frames/${frameId}/detection/stop`,
    {
      method: "POST",
      headers: {
        Accept: "application/json",
      },
    }
  );

  let data = null;

  try {
    data = await response.json();
  } catch {
    data = null;
  }

  if (!response.ok || data?.ok === false) {
    throw new Error(
      data?.message ||
        "Could not stop detection"
    );
  }

  return data;
}


// =========================================================
// Stop detection during page refresh / exit
// =========================================================

export function stopFrameDetectionOnPageExit(
  cameraId,
  frameId
) {
  if (
    cameraId == null ||
    frameId == null
  ) {
    return;
  }

  authenticatedFetch(
    `${API_BASE_URL}/api/cameras/${cameraId}/frames/${frameId}/detection/stop`,
    {
      method: "POST",
      headers: {
        Accept: "application/json",
      },
      keepalive: true,
    }
  ).catch((error) => {
    console.error(
      `Detection stop during page exit failed for camera ${cameraId}, frame ${frameId}:`,
      error
    );
  });
}


// =========================================================
// Application Health
// =========================================================

export async function getApplicationHealth() {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/health`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  const data = await response.json();

  if (!response.ok) {
    throw new Error(
      data?.message ||
        data?.detail ||
        "Could not load application health"
    );
  }

  return data;
}


// =========================================================
// Latest Sent Email Alert
// =========================================================

export async function getLatestEmailSentAlert() {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/email-alerts/latest-sent`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  return handleResponse(response);
}


// =========================================================
// Face Enrollment Image URL Helper
//
// Direct URL only.
// Protected image loading will be handled separately.
// =========================================================

export function getFaceEnrollmentImageUrl(
  imageUrl
) {
  if (!imageUrl) {
    return "";
  }

  if (
    imageUrl.startsWith("http://") ||
    imageUrl.startsWith("https://") ||
    imageUrl.startsWith("data:") ||
    imageUrl.startsWith("blob:")
  ) {
    return imageUrl;
  }

  const normalizedPath =
    imageUrl.startsWith("/")
      ? imageUrl
      : `/${imageUrl}`;

  return `${API_BASE_URL}${normalizedPath}`;
}


// =========================================================
// Enrolled Person Face URL
//
// URL only.
// Will be handled as authenticated image separately.
// =========================================================

export function getEnrolledPersonFaceUrl(
  personId
) {
  if (!personId) {
    return "";
  }

  return `${API_BASE_URL}/api/face-enrollment/persons/${personId}/face`;
}


// =========================================================
// Face Enrollment Recent Logs APIs
// =========================================================

export async function getRecentEnrollmentLogs(
  limit = 50
) {
  const res = await authenticatedFetch(
    `${API_BASE_URL}/api/face-enrollment/logs?limit=${limit}`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  const result = await res.json();

  if (!res.ok || result?.ok === false) {
    return {
      ok: false,
      data: [],
      message:
        result?.message ||
        "Could not load recent enrollment logs",
    };
  }

  const logs = Array.isArray(
    result?.data
  )
    ? result.data
    : [];

  return {
    ...result,

    data: logs.map((row) => ({
      ...row,

      enrolledFace:
        getFaceEnrollmentImageUrl(
          row.enrolledFace ||
            row.enrolled_face ||
            row.primaryFace ||
            row.primary_face ||
            row.imageUrl ||
            row.image_url ||
            ""
        ),
    })),
  };
}


// =========================================================
// Face Enrollment Dashboard Stats API
// =========================================================

export async function getFaceEnrollmentStats() {
  try {
    const res = await authenticatedFetch(
      `${API_BASE_URL}/api/face-enrollment/stats`,
      {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
        cache: "no-store",
      }
    );

    const result = await res.json();

    if (
      !res.ok ||
      result?.ok === false
    ) {
      return {
        ok: false,

        data: {
          totalEnrolled: 0,
          activePersonnel: 0,
          todayEnrollments: 0,
          inactivePersonnel: 0,
          archivedPersonnel: 0,
          faceQualityAverage: 0,
        },

        message:
          result?.message ||
          "Could not load face enrollment stats",
      };
    }

    return {
      ok: true,

      data: {
        totalEnrolled:
          result?.data?.totalEnrolled ??
          0,

        activePersonnel:
          result?.data?.activePersonnel ??
          0,

        todayEnrollments:
          result?.data?.todayEnrollments ??
          0,

        inactivePersonnel:
          result?.data?.inactivePersonnel ??
          0,

        archivedPersonnel:
          result?.data?.archivedPersonnel ??
          0,

        faceQualityAverage:
          result?.data?.faceQualityAverage ??
          0,
      },
    };
  } catch (error) {
    console.error(
      "getFaceEnrollmentStats error:",
      error
    );

    return {
      ok: false,

      data: {
        totalEnrolled: 0,
        activePersonnel: 0,
        todayEnrollments: 0,
        inactivePersonnel: 0,
        archivedPersonnel: 0,
        faceQualityAverage: 0,
      },

      message:
        error?.message ||
        "Network error while loading enrollment stats",
    };
  }
}


// =========================================================
// Face Enrollment - Recognition Performance
// =========================================================

export async function getRecognitionPerformance() {
  try {
    const res = await authenticatedFetch(
      `${API_BASE_URL}/api/face-enrollment/recognition-performance`,
      {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
        cache: "no-store",
      }
    );

    const result = await res.json();

    if (
      !res.ok ||
      result?.ok === false
    ) {
      return {
        ok: false,

        data: {
          recognitionRate: 0,
          recognizedFaces: 0,
          unknownDetections: 0,
          failedMatches: 0,
        },

        message:
          result?.message ||
          "Could not load recognition performance",
      };
    }

    return {
      ok: true,
      data: result?.data || {},
    };
  } catch (error) {
    console.error(
      "getRecognitionPerformance error:",
      error
    );

    return {
      ok: false,

      data: {
        recognitionRate: 0,
        recognizedFaces: 0,
        unknownDetections: 0,
        failedMatches: 0,
      },

      message:
        error?.message ||
        "Network error",
    };
  }
}


// =========================================================
// Face Enrollment - Alerts & Notifications
// =========================================================

export async function getFaceEnrollmentAlerts(
  limit = 20
) {
  try {
    const res = await authenticatedFetch(
      `${API_BASE_URL}/api/face-enrollment/alerts?limit=${limit}`,
      {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
        cache: "no-store",
      }
    );

    const result = await res.json();

    if (
      !res.ok ||
      result?.ok === false
    ) {
      return {
        ok: false,
        data: [],
        message:
          result?.message ||
          "Could not load face enrollment alerts",
      };
    }

    return {
      ok: true,

      data: Array.isArray(
        result?.data
      )
        ? result.data
        : [],

      count: result?.count || 0,
    };
  } catch (error) {
    console.error(
      "getFaceEnrollmentAlerts error:",
      error
    );

    return {
      ok: false,
      data: [],
      message:
        error?.message ||
        "Network error",
    };
  }
}


// =========================================================
// USER MANAGEMENT APIs
//
// Backend additionally checks role == super_admin.
// A normal authenticated user gets HTTP 403.
// =========================================================

export async function getUsers() {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/users`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  return handleResponse(response);
}


export async function getUserStats() {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/users/stats`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  return handleResponse(response);
}


export async function createUser(payload) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/users`,
    {
      method: "POST",
      headers: {
        "Content-Type":
          "application/json",
      },
      body: JSON.stringify(payload),
    }
  );

  return handleResponse(response);
}


export async function updateUser(
  email,
  payload
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/users/${encodeURIComponent(
      email
    )}`,
    {
      method: "PUT",
      headers: {
        "Content-Type":
          "application/json",
      },
      body: JSON.stringify(payload),
    }
  );

  return handleResponse(response);
}


export async function updateUserStatus(
  email,
  isActive
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/users/${encodeURIComponent(
      email
    )}/status`,
    {
      method: "PATCH",
      headers: {
        "Content-Type":
          "application/json",
      },

      body: JSON.stringify({
        is_active: isActive,
      }),
    }
  );

  return handleResponse(response);
}


export async function deleteUser(email) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/users/${encodeURIComponent(
      email
    )}`,
    {
      method: "DELETE",
    }
  );

  return handleResponse(response);
}


// =========================================================
// LOGIN AUTH APIs
//
// IMPORTANT:
// These MUST use normal fetch().
//
// JWT does not exist before successful login + OTP.
// =========================================================

export async function loginUser(payload) {
  const response = await fetch(
    `${API_BASE_URL}/api/auth/login`,
    {
      method: "POST",

      headers: {
        "Content-Type":
          "application/json",
        Accept: "application/json",
      },

      body: JSON.stringify(payload),
    }
  );

  return handleResponse(response);
}


export async function verifyLoginOtp(
  payload
) {
  const response = await fetch(
    `${API_BASE_URL}/api/auth/verify-otp`,
    {
      method: "POST",

      headers: {
        "Content-Type":
          "application/json",
        Accept: "application/json",
      },

      body: JSON.stringify(payload),
    }
  );

  return handleResponse(response);
}


// =========================================================
// FORGOT PASSWORD AUTH APIs
//
// These also remain public and therefore use fetch().
// =========================================================

export async function sendForgotPasswordOtp(
  payload
) {
  const response = await fetch(
    `${API_BASE_URL}/api/auth/forgot-password/send-otp`,
    {
      method: "POST",

      headers: {
        "Content-Type":
          "application/json",
        Accept: "application/json",
      },

      body: JSON.stringify(payload),
    }
  );

  return handleResponse(response);
}


export async function verifyForgotPasswordOtp(
  payload
) {
  const response = await fetch(
    `${API_BASE_URL}/api/auth/forgot-password/verify-otp`,
    {
      method: "POST",

      headers: {
        "Content-Type":
          "application/json",
        Accept: "application/json",
      },

      body: JSON.stringify(payload),
    }
  );

  return handleResponse(response);
}


export async function resetForgotPassword(
  payload
) {
  const response = await fetch(
    `${API_BASE_URL}/api/auth/forgot-password/reset`,
    {
      method: "POST",

      headers: {
        "Content-Type":
          "application/json",
        Accept: "application/json",
      },

      body: JSON.stringify(payload),
    }
  );

  return handleResponse(response);
}

// =========================================================
// Authenticated Image Fetch
// =========================================================

export async function getAuthenticatedImageUrl(
  imageUrl
) {
  if (!imageUrl) {
    return "";
  }

  // Already local/browser-ready image
  if (
    imageUrl.startsWith("data:") ||
    imageUrl.startsWith("blob:")
  ) {
    return imageUrl;
  }

  const response = await authenticatedFetch(
    imageUrl,
    {
      method: "GET",
      headers: {
        Accept: "image/*",
      },
      cache: "no-store",
    }
  );

  if (!response.ok) {
    let message =
      "Could not load protected image";

    try {
      const data = await response.json();

      message =
        data?.message ||
        data?.detail ||
        message;
    } catch {
      // Response may not be JSON
    }

    throw new Error(message);
  }

  const blob = await response.blob();

  return URL.createObjectURL(blob);
}

// =========================================================
// Enrolled Persons APIs
// =========================================================

export async function getEnrolledPersons({
  search = "",
  status = "",
  department = "",
  role = "",
} = {}) {
  const params = new URLSearchParams();

  if (search?.trim()) {
    params.set("search", search.trim());
  }

  if (status?.trim()) {
    params.set("status", status.trim());
  }

  if (department?.trim()) {
    params.set("department", department.trim());
  }

  if (role?.trim()) {
    params.set("role", role.trim());
  }

  const query = params.toString();

  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/face-enrollment/persons${
      query ? `?${query}` : ""
    }`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  return handleResponse(response);
}


// =========================================================
// Enrolled Person Details
// =========================================================

export async function getEnrolledPerson(
  personId
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/face-enrollment/persons/${personId}`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  return handleResponse(response);
}


// =========================================================
// Update Enrolled Person Details
// =========================================================

export async function updateEnrolledPerson(
  personId,
  payload
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/face-enrollment/persons/${personId}`,
    {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(payload),
    }
  );

  return handleResponse(response);
}


// =========================================================
// Activate / Deactivate Enrolled Person
// =========================================================

export async function updateEnrolledPersonStatus(
  personId,
  isActive
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/face-enrollment/persons/${personId}/status`,
    {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        isActive: Boolean(isActive),
      }),
    }
  );

  return handleResponse(response);
}


// =========================================================
// Delete Enrolled Person Permanently
// =========================================================

export async function deleteEnrolledPerson(
  personId
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/face-enrollment/persons/${personId}`,
    {
      method: "DELETE",
      headers: {
        Accept: "application/json",
      },
    }
  );

  return handleResponse(response);
}


// =========================================================
// Enrolled Person Protected Face Image
// =========================================================

export async function getEnrolledPersonImageUrl(
  personId
) {
  if (!personId) {
    return "";
  }

  const imageUrl =
    `${API_BASE_URL}/api/face-enrollment/persons/${personId}/face`;

  return getAuthenticatedImageUrl(imageUrl);
}

// =========================================================
// Counting Lines
// =========================================================

export async function getCountingLines(cameraId = null) {
  const params = new URLSearchParams();

  if (
    cameraId !== null &&
    cameraId !== undefined &&
    cameraId !== ""
  ) {
    params.set("camera_id", String(cameraId));
  }

  const query = params.toString();

  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/counting-lines${
      query ? `?${query}` : ""
    }`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  return handleResponse(response);
}


export async function createCountingLine(payload) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/counting-lines`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(payload),
    }
  );

  return handleResponse(response);
}


export async function updateCountingLine(
  lineId,
  payload
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/counting-lines/${encodeURIComponent(
      String(lineId)
    )}`,
    {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(payload),
    }
  );

  return handleResponse(response);
}


export async function deleteCountingLine(lineId) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/counting-lines/${encodeURIComponent(
      String(lineId)
    )}`,
    {
      method: "DELETE",
      headers: {
        Accept: "application/json",
      },
    }
  );

  return handleResponse(response);
}


// =========================================================
// Counting Management - Settings
// =========================================================

export async function getCountingSettings() {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/counting/settings`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  return handleResponse(response);
}


export async function updateCountingSettings(
  intervalMinutes
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/counting/settings`,
    {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        interval_minutes: Number(intervalMinutes),
      }),
    }
  );

  return handleResponse(response);
}


// =========================================================
// Counting Management - Live Counts
// =========================================================

export async function getCountingLiveCounts() {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/counting/live`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  return handleResponse(response);
}


export async function getCameraCountingLiveCount(
  cameraId
) {
  if (
    cameraId === null ||
    cameraId === undefined ||
    cameraId === ""
  ) {
    throw new Error(
      "Camera ID is required for live counting"
    );
  }

  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/counting/live/${encodeURIComponent(
      String(cameraId)
    )}`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  return handleResponse(response);
}


// =========================================================
// Counting Management - History / Labor Carry Events
// =========================================================

export async function getCountingSummaries({
  cameraId = null,
  limit = 100,
} = {}) {
  const params = new URLSearchParams();

  if (
    cameraId !== null &&
    cameraId !== undefined &&
    cameraId !== ""
  ) {
    params.set(
      "camera_id",
      String(cameraId)
    );
  }

  params.set(
    "limit",
    String(limit)
  );

  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/counting/summaries?${params.toString()}`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  return handleResponse(response);
}


// =========================================================
// Counting Management - Test Email
// =========================================================

export async function sendCountingTestEmail() {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/counting/email/test`,
    {
      method: "POST",
      headers: {
        Accept: "application/json",
      },
    }
  );

  return handleResponse(response);
}


// =========================================================
// Counting Management - Start Monitoring
// =========================================================

export async function startCountingMonitoring(
  cameraIds = []
) {
  const normalizedCameraIds = [
    ...new Set(
      (Array.isArray(cameraIds)
        ? cameraIds
        : []
      )
        .map((cameraId) =>
          Number(cameraId)
        )
        .filter(
          (cameraId) =>
            Number.isInteger(cameraId) &&
            cameraId > 0
        )
    ),
  ];

  if (normalizedCameraIds.length === 0) {
    throw new Error(
      "Select at least one camera for counting"
    );
  }

  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/counting/monitoring/start`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        camera_ids: normalizedCameraIds,
      }),
    }
  );

  return handleResponse(response);
}


// =========================================================
// Counting Management - Stop Monitoring
// =========================================================

export async function stopCountingMonitoring(
  cameraIds = []
) {
  const normalizedCameraIds = [
    ...new Set(
      (Array.isArray(cameraIds)
        ? cameraIds
        : []
      )
        .map((cameraId) =>
          Number(cameraId)
        )
        .filter(
          (cameraId) =>
            Number.isInteger(cameraId) &&
            cameraId > 0
        )
    ),
  ];

  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/counting/monitoring/stop`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        camera_ids: normalizedCameraIds,
      }),
    }
  );

  return handleResponse(response);
}


// =========================================================
// Counting Management - Monitoring Status
// =========================================================

export async function getCountingMonitoringStatus() {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/counting/monitoring/status`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  return handleResponse(response);
}


// =========================================================
// Counting Management - Annotated Stream URL
//
// <img> cannot attach Authorization Bearer header,
// therefore JWT token is passed through query string.
// =========================================================

export function getCountingStreamUrl(cameraId) {
  if (
    cameraId === null ||
    cameraId === undefined ||
    cameraId === ""
  ) {
    return "";
  }

  const token = getAccessToken();

  if (!token) {
    return "";
  }

  const safeCameraId = encodeURIComponent(
    String(cameraId)
  );

  const safeToken = encodeURIComponent(
    token
  );

  return (
    `${API_BASE_URL}/api/cameras/` +
    `${safeCameraId}/counting-stream` +
    `?token=${safeToken}`
  );
}


// =========================================================
// Counting Management - Evidence Image URL
//
// Backend:
// GET /api/counting/evidence/{summary_id}?token=...
//
// IMPORTANT:
// Pass CountingSummary.id here.
// Do NOT pass record_id such as:
// CNT-20260929100000-1-ABC123
// =========================================================

export function getCountingEvidenceUrl(
  summaryId
) {
  if (
    summaryId === null ||
    summaryId === undefined ||
    String(summaryId).trim() === ""
  ) {
    return "";
  }

  const token = getAccessToken();

  if (!token) {
    return "";
  }

  const safeSummaryId = encodeURIComponent(
    String(summaryId).trim()
  );

  const safeToken = encodeURIComponent(
    token
  );

  return (
    `${API_BASE_URL}/api/counting/evidence/` +
    `${safeSummaryId}?token=${safeToken}`
  );
}

// =========================================================
// Continuous Monitoring APIs
// =========================================================

export async function getMonitoringStatus() {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/monitoring/status`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  return handleResponse(response);
}


export async function startMonitoring() {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/monitoring/start`,
    {
      method: "POST",
      headers: {
        Accept: "application/json",
      },
    }
  );

  return handleResponse(response);
}


export async function stopMonitoring() {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/monitoring/stop`,
    {
      method: "POST",
      headers: {
        Accept: "application/json",
      },
    }
  );

  return handleResponse(response);
}


export async function setCameraMonitoring(
  cameraId,
  enabled
) {
  if (
    cameraId === null ||
    cameraId === undefined ||
    cameraId === ""
  ) {
    throw new Error("Camera ID is required");
  }

  const action = enabled
    ? "enable"
    : "disable";

  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/monitoring/cameras/${encodeURIComponent(
      String(cameraId)
    )}/${action}`,
    {
      method: "POST",
      headers: {
        Accept: "application/json",
      },
    }
  );

  return handleResponse(response);
}

export function getCameraSnapshotUrl(
  cameraId,
  stamp = Date.now()
) {
  if (
    cameraId === null ||
    cameraId === undefined ||
    cameraId === ""
  ) {
    return "";
  }

  const token = getAccessToken();

  if (!token) {
    return "";
  }

  const safeCameraId = encodeURIComponent(
    String(cameraId)
  );

  const safeToken = encodeURIComponent(token);

  return (
    `${API_BASE_URL}/api/cameras/` +
    `${safeCameraId}/snapshot.jpg` +
    `?token=${safeToken}` +
    `&t=${encodeURIComponent(String(stamp))}`
  );
}

// =========================================================
// Camera Zones APIs
// =========================================================

export async function getZones(cameraId = null) {
  const suffix =
    cameraId !== null &&
    cameraId !== undefined &&
    cameraId !== ""
      ? `?camera_id=${encodeURIComponent(
          String(cameraId)
        )}`
      : "";

  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/zones${suffix}`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  return handleResponse(response);
}


export async function createZone(payload) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/zones`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(payload),
    }
  );

  return handleResponse(response);
}


export async function updateZone(
  zoneId,
  payload
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/zones/${encodeURIComponent(
      String(zoneId)
    )}`,
    {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(payload),
    }
  );

  return handleResponse(response);
}


export async function deleteZone(zoneId) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/zones/${encodeURIComponent(
      String(zoneId)
    )}`,
    {
      method: "DELETE",
      headers: {
        Accept: "application/json",
      },
    }
  );

  return handleResponse(response);
}

// =========================================================
// Episodes APIs
// =========================================================

export const API_BASE = API_BASE_URL;


export async function getLiveEpisodes() {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/episodes/live`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  return handleResponse(response);
}


export async function listEpisodes(
  params = {}
) {
  const query = new URLSearchParams();

  Object.entries(params).forEach(
    ([key, value]) => {
      if (
        value !== undefined &&
        value !== null &&
        value !== ""
      ) {
        query.set(
          key,
          String(value)
        );
      }
    }
  );

  const suffix =
    query.toString()
      ? `?${query.toString()}`
      : "";

  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/episodes${suffix}`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  return handleResponse(response);
}


export async function acknowledgeEpisode(
  episodeId
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/episodes/${encodeURIComponent(
      String(episodeId)
    )}/acknowledge`,
    {
      method: "POST",
      headers: {
        Accept: "application/json",
      },
    }
  );

  return handleResponse(response);
}


export async function resolveEpisode(
  episodeId,
  note
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/episodes/${encodeURIComponent(
      String(episodeId)
    )}/resolve`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        note,
      }),
    }
  );

  return handleResponse(response);
}


export async function markEpisodeFalsePositive(
  episodeId
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/episodes/${encodeURIComponent(
      String(episodeId)
    )}/false-positive`,
    {
      method: "POST",
      headers: {
        Accept: "application/json",
      },
    }
  );

  return handleResponse(response);
}


// =========================================================
// Expected Vehicles (Arrivals)
// =========================================================

export async function listArrivals(date) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/arrivals?date=${encodeURIComponent(date)}`
  );

  return handleResponse(response);
}


export async function saveArrival(body, id = null) {
  const response = await authenticatedFetch(
    id == null
      ? `${API_BASE_URL}/api/arrivals`
      : `${API_BASE_URL}/api/arrivals/${id}`,
    {
      method: id == null ? "POST" : "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    }
  );

  return handleResponse(response);
}


export async function deleteArrival(id) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/arrivals/${id}`,
    {
      method: "DELETE",
    }
  );

  return handleResponse(response);
}


// action: arrived | departed | link
// episodeId is required only for "link"
export async function arrivalAction(
  id,
  action,
  episodeId = null
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/arrivals/${id}/${action}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: episodeId
        ? JSON.stringify({
            episode_id: episodeId,
          })
        : undefined,
    }
  );

  return handleResponse(response);
}


// =========================================================
// Episode Keep / Unkeep
// =========================================================

// Kept episodes' pictures are never auto-deleted.
export async function setEpisodeKeep(
  episodeId,
  keep
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/episodes/${encodeURIComponent(
      String(episodeId)
    )}/keep`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        keep,
      }),
    }
  );

  return handleResponse(response);
}


// =========================================================
// Bulk Episode Action
// =========================================================

// action:
// acknowledge
// resolve
// false_positive
export async function bulkEpisodeAction(
  episodeIds,
  action,
  note = ""
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/episodes/bulk`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        ids: episodeIds,
        action,
        note,
      }),
    }
  );

  return handleResponse(response);
}


// =========================================================
// Delete Episodes
// Super Admin Only
// =========================================================

export async function deleteEpisodes(
  episodeIds
) {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/episodes/delete`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        ids: episodeIds,
      }),
    }
  );

  return handleResponse(response);
}

// EventSource cannot send Authorization header.
// JWT token goes in query string.
export function getEpisodeStreamUrl() {
  const token = getAccessToken();

  if (!token) {
    return "";
  }

  return (
    `${API_BASE_URL}/api/episodes/stream` +
    `?token=${encodeURIComponent(token)}`
  );
}

// =========================================================
// Ops Board - Evidence URL Helper
// =========================================================

export function getEvidenceUrl(evidenceUrl) {
  if (!evidenceUrl) {
    return "";
  }

  // Already browser-ready
  if (
    evidenceUrl.startsWith("data:") ||
    evidenceUrl.startsWith("blob:")
  ) {
    return evidenceUrl;
  }

  // Already complete URL
  if (
    evidenceUrl.startsWith("http://") ||
    evidenceUrl.startsWith("https://")
  ) {
    return evidenceUrl;
  }

  const normalizedPath = evidenceUrl.startsWith("/")
    ? evidenceUrl
    : `/${evidenceUrl}`;

  const token = getAccessToken();

  const url = `${API_BASE_URL}${normalizedPath}`;

  // Evidence is normally displayed directly inside <img>,
  // so Authorization header cannot be attached.
  if (!token) {
    return url;
  }

  const separator = url.includes("?") ? "&" : "?";

  return `${url}${separator}token=${encodeURIComponent(token)}`;
}


// =========================================================
// Ops Board - Zone Summary
// =========================================================

export async function getZoneSummary() {
  const response = await authenticatedFetch(
    `${API_BASE_URL}/api/zones/summary`,
    {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    }
  );

  return handleResponse(response);
}
