import { useEffect, useMemo, useState } from "react";

import "./ops.css";
import { useEpisodes, useNow } from "./useEpisodes";
import { formatDuration, formatTime } from "./format";
import { arrivalAction, deleteArrival, listArrivals, saveArrival } from "../data/api";

const DAY = 86400;

function isoDay(epoch) {
  return new Date((epoch + 5.5 * 3600) * 1000).toISOString().slice(0, 10);
}

function minutesIST(epoch) {
  return Math.floor(((epoch + 5.5 * 3600) % DAY) / 60);
}

function hhmmToMinutes(hhmm) {
  if (!hhmm) return null;
  const [h, m] = hhmm.split(":").map(Number);
  return Number.isFinite(h) && Number.isFinite(m) ? h * 60 + m : null;
}

const EMPTY = { plate: "", transporter: "", material: "", purpose: "unloading", expected_time: "", notes: "" };

function StatusChip({ row, now, today }) {
  const expected = hhmmToMinutes(row.expected_time);
  const late = row.status === "expected" && today && expected != null && minutesIST(now) > expected + 15;
  if (row.status === "departed") return <span className="chip">departed {formatTime(row.departed_epoch)}</span>;
  if (row.status === "on_site") return <span className="chip ok">on site · {row.location.zone_name}</span>;
  if (row.status === "arrived") return <span className="chip ok">arrived {formatTime(row.arrived_epoch)}</span>;
  if (late) return <span className="chip bad">late · due {row.expected_time}</span>;
  return <span className="chip">expected{row.expected_time ? ` ${row.expected_time}` : ""}</span>;
}

export default function ArrivalsPage() {
  const now = useNow(1000);
  const [today] = useState(() => isoDay(Date.now() / 1000));
  const [date, setDate] = useState(today);
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState(EMPTY);
  const [editing, setEditing] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [linking, setLinking] = useState(null);       // arrival id whose "link" picker is open
  const { episodes } = useEpisodes();                  // live: which vehicles are on camera right now

  async function refresh(d = date) {
    try {
      const r = await listArrivals(d);
      setRows(r.data || []);
      setErr("");
    } catch (e) {
      setErr(e.message || "Could not load arrivals");
    }
  }

  useEffect(() => {
    const t = setTimeout(() => refresh(date), 0);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date]);

  // A linked vehicle's zone changes as the truck moves - keep the list fresh.
  useEffect(() => {
    const id = setInterval(() => refresh(date), 15000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date]);

  const openVehicles = useMemo(
    () => episodes.filter((e) => e.subject_type === "vehicle" && !e.ended_epoch),
    [episodes]
  );
  const linkedIds = useMemo(() => new Set(rows.flatMap((r) => r.visits.map((v) => v.episode_id))), [rows]);
  const unlinkedVehicles = openVehicles.filter((e) => !linkedIds.has(e.episode_id));

  const counts = useMemo(() => ({
    expected: rows.filter((r) => r.status === "expected").length,
    onSite: rows.filter((r) => r.status === "on_site" || r.status === "arrived").length,
    departed: rows.filter((r) => r.status === "departed").length,
  }), [rows]);

  async function run(fn) {
    setBusy(true);
    setErr("");
    try {
      await fn();
      await refresh(date);
    } catch (e) {
      setErr(e.message || "That did not go through");
    } finally {
      setBusy(false);
    }
  }

  function submit(e) {
    e.preventDefault();
    run(async () => {
      await saveArrival({ ...form, date }, editing);
      setForm(EMPTY);
      setEditing(null);
    });
  }

  function startEdit(row) {
    setEditing(row.id);
    setForm({ plate: row.plate, transporter: row.transporter || "", material: row.material || "", purpose: row.purpose, expected_time: row.expected_time || "", notes: row.notes || "" });
  }

  const field = (k) => ({ value: form[k], onChange: (e) => setForm((f) => ({ ...f, [k]: e.target.value })) });

  return (
    <div className="ops arrivals">
      <div className="topbar">
        <div>
          <h1 style={{ margin: 0, fontSize: 20 }}>Arrivals</h1>
          <span className="hint">Trucks due today, and where each one is right now</span>
        </div>
        <div className="tools">
          <label className="hint">Day <input className="btn" type="date" value={date} onChange={(e) => setDate(e.target.value)} /></label>
          <span className="chip">{counts.expected} expected</span>
          <span className="chip ok">{counts.onSite} on site</span>
          <span className="chip">{counts.departed} departed</span>
          {unlinkedVehicles.length ? <span className="chip warn">{unlinkedVehicles.length} on camera, not in the list</span> : null}
        </div>
      </div>

      {err ? <div className="error-banner">{err}</div> : null}

      <section aria-labelledby="h-add">
        <div className="sec-head"><h2 id="h-add">{editing ? "Edit vehicle" : "Add a vehicle"}</h2><span className="hint">plate is enough; the rest helps the bay</span></div>
        <form className="bulkbar" onSubmit={submit} style={{ position: "static" }}>
          <input className="btn mono" style={{ width: 150 }} placeholder="Plate  HR55AB1234" required {...field("plate")} aria-label="Number plate" />
          <input className="btn" style={{ width: 160 }} placeholder="Transporter" {...field("transporter")} aria-label="Transporter" />
          <input className="btn" style={{ width: 140 }} placeholder="Material" {...field("material")} aria-label="Material" />
          <select className="btn" {...field("purpose")} aria-label="Purpose">
            <option value="unloading">Unloading</option><option value="loading">Loading</option><option value="other">Other</option>
          </select>
          <input className="btn" type="time" {...field("expected_time")} aria-label="Expected time" />
          <input className="btn" style={{ flex: "1 1 160px" }} placeholder="Notes" {...field("notes")} aria-label="Notes" />
          <button className="btn primary" type="submit" disabled={busy}>{editing ? "Save" : "Add"}</button>
          {editing ? <button className="btn ghost" type="button" onClick={() => { setEditing(null); setForm(EMPTY); }}>Cancel</button> : null}
        </form>
      </section>

      <section aria-labelledby="h-list">
        <div className="sec-head"><h2 id="h-list">{date === today ? "Today" : date}</h2><span className="hint">on site = a camera sees it in a zone · link = tell the system which truck on camera this is</span></div>
        <div className="ledger">
          <div className="ledger-scroll">
            <table>
              <thead><tr><th>Plate</th><th>Transporter · material</th><th>Due</th><th>Status</th><th>Where</th><th>On site for</th><th>Actions</th></tr></thead>
              <tbody>
                {rows.length ? rows.map((row) => {
                  const loc = row.location;
                  const since = row.arrived_epoch ? (row.departed_epoch || now) - row.arrived_epoch : null;
                  return (
                    <tr key={row.id}>
                      <td className="mono"><b>{row.plate}</b>{row.notes ? <div className="hint">{row.notes}</div> : null}</td>
                      <td>{row.transporter || "—"}{row.material ? <div className="hint">{row.material} · {row.purpose}</div> : <div className="hint">{row.purpose}</div>}</td>
                      <td className="mono">{row.expected_time || "—"}</td>
                      <td><StatusChip row={row} now={now} today={date === today} /></td>
                      <td>
                        {loc ? (
                          <>
                            <b>{loc.zone_name}</b>{loc.over_limit ? <span className="chip bad" style={{ marginLeft: 6 }}>over limit</span> : null}
                            <div className="hint">{loc.ended_epoch ? `left ${formatTime(loc.ended_epoch)}` : `since ${formatTime(loc.started_epoch)}`}{row.visits.length > 1 ? ` · ${row.visits.length} stops` : ""}</div>
                          </>
                        ) : <span className="hint">not seen on camera</span>}
                      </td>
                      <td className="mono">{since != null ? formatDuration(since) : "—"}</td>
                      <td>
                        <div className="actions" style={{ marginTop: 0 }}>
                          {row.status === "expected" ? <button className="btn" type="button" disabled={busy} onClick={() => run(() => arrivalAction(row.id, "arrived"))}>Arrived</button> : null}
                          {row.status !== "departed" ? (
                            linking === row.id ? (
                              <select
                                className="btn"
                                autoFocus
                                defaultValue=""
                                onBlur={() => setLinking(null)}
                                onChange={(e) => { const v = e.target.value; setLinking(null); if (v) run(() => arrivalAction(row.id, "link", v)); }}
                                aria-label="Vehicle on camera"
                              >
                                <option value="">Which vehicle on camera?</option>
                                {openVehicles.map((e) => (
                                  <option key={e.episode_id} value={e.episode_id}>
                                    {e.subject_label} in {e.zone_name || e.camera_name} since {formatTime(e.started_epoch)}{e.attributes && e.attributes.plate ? ` (${e.attributes.plate})` : ""}
                                  </option>
                                ))}
                              </select>
                            ) : (
                              <button className="btn" type="button" disabled={busy || !openVehicles.length} title={openVehicles.length ? "" : "No vehicle is on camera right now"} onClick={() => setLinking(row.id)}>Link to camera</button>
                            )
                          ) : null}
                          {row.status !== "departed" ? <button className="btn ghost" type="button" disabled={busy} onClick={() => run(() => arrivalAction(row.id, "departed"))}>Departed</button> : null}
                          <button className="btn ghost" type="button" disabled={busy} onClick={() => startEdit(row)}>Edit</button>
                          <button className="btn ghost" type="button" disabled={busy} onClick={() => { if (window.confirm(`Remove ${row.plate} from the list?`)) run(() => deleteArrival(row.id)); }}>Remove</button>
                        </div>
                      </td>
                    </tr>
                  );
                }) : (
                  <tr><td colSpan={7} className="hint">No vehicles listed for this day yet.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );
}
