import { useEffect, useMemo, useState } from "react";

import "./ops.css";
import { buildInsights } from "./insights";
import { useNow } from "./useEpisodes";
import { formatDuration, formatSince, severityLabel, subjectText } from "./format";
import { getCameras, getEvidenceUrl, listEpisodes } from "../data/api";

const DAY = 86400;
const KINDS = [
  ["", "Everything"],
  ["ppe_violation", "PPE"],
  ["person_in_zone", "Restricted area"],
  ["vehicle_in_zone", "Vehicles"],
  ["system", "Camera health"],
];
const STATUSES = [["", "Any status"], ["open", "Open"], ["acknowledged", "Acknowledged"], ["resolved", "Resolved"], ["false_positive", "Not a real issue"]];

function isoDay(epoch) {
  // yyyy-mm-dd in India, for <input type="date">.
  return new Date((epoch + 5.5 * 3600) * 1000).toISOString().slice(0, 10);
}

function dayStartEpoch(iso) {
  // Midnight IST of that calendar day, as a UTC epoch.
  return Date.parse(`${iso}T00:00:00+05:30`) / 1000;
}

function csvCell(v) {
  let s = v == null ? "" : String(v);
  // Excel runs a cell that opens with these. A close-out note is free text
  // somebody typed, so it must never come back as a formula.
  if (typeof v !== "number" && /^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/** A cell Excel shows as a clickable link - a plain URL it leaves as text. */
function csvLink(url, label) {
  return url ? `"=HYPERLINK(""${url.replace(/"/g, '""')}"",""${label}"")"` : "";
}

/** "2026-09-25 14:03:11" IST - what Excel reads back as a date and time. */
function csvTime(localIso) {
  return localIso ? localIso.slice(0, 19).replace("T", " ") : "";
}

/** "0:02:05" - readable, and Excel sorts and sums it as a duration. */
function csvDuration(seconds) {
  const s = Math.max(0, Math.round(seconds || 0));
  return `${Math.floor(s / 3600)}:${String(Math.floor((s % 3600) / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}

function Lightbox({ item, onClose }) {
  useEffect(() => {
    if (!item) return undefined;
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [item, onClose]);
  if (!item) return null;
  return (
    <div className="lightbox" role="dialog" aria-modal="true" aria-label="Evidence picture" onClick={onClose}>
      <div className="lb-body" onClick={(e) => e.stopPropagation()}>
        <img src={item.src} alt={item.title} />
        <div className="lb-caption">
          <b>{item.title}</b>
          <span>{item.meta}</span>
          <a className="btn" href={item.src} target="_blank" rel="noreferrer">Open original</a>
          <button type="button" className="btn ghost" onClick={onClose}>Close (Esc)</button>
        </div>
      </div>
    </div>
  );
}

export default function HistoryPage() {
  const now = useNow(60000);
  const [today] = useState(() => isoDay(Date.now() / 1000));
  const [from, setFrom] = useState(() => isoDay(Date.now() / 1000 - 6 * DAY));
  const [to, setTo] = useState(today);
  const [cameraId, setCameraId] = useState("");
  const [kind, setKind] = useState("");
  const [status, setStatus] = useState("");
  const [cameras, setCameras] = useState([]);
  const [rows, setRows] = useState([]);
  const [prevRows, setPrevRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [viewing, setViewing] = useState(null);

  useEffect(() => {
    getCameras().then((r) => setCameras(r.data || [])).catch(() => {});
  }, []);

  const fromEpoch = dayStartEpoch(from);
  const toEpoch = dayStartEpoch(to) + DAY;
  const span = Math.max(DAY, toEpoch - fromEpoch);

  useEffect(() => {
    if (!from || !to || fromEpoch >= toEpoch) return undefined;
    let cancelled = false;
    const params = (since, until) => ({
      since: new Date(since * 1000).toISOString(),
      until: new Date(until * 1000).toISOString(),
      camera_id: cameraId || undefined,
      kind: kind || undefined,
      status: status || undefined,
      limit: 1000,
    });
    // The period itself, and the same length before it (for the comparisons).
    const timer = setTimeout(() => {
      setLoading(true);
      setError("");
      Promise.all([listEpisodes(params(fromEpoch, toEpoch)), listEpisodes(params(fromEpoch - span, fromEpoch))])
        .then(([cur, prev]) => {
          if (cancelled) return;
          setRows(cur.data || []);
          setPrevRows(prev.data || []);
        })
        .catch((e) => { if (!cancelled) setError(e.message || "Could not load history"); })
        .finally(() => { if (!cancelled) setLoading(false); });
    }, 0);
    return () => { cancelled = true; clearTimeout(timer); };
  }, [from, to, cameraId, kind, status, fromEpoch, toEpoch, span]);

  const stats = useMemo(() => {
    const violations = rows.filter((e) => e.kind !== "system");
    const prevViolations = prevRows.filter((e) => e.kind !== "system");
    const critical = violations.filter((e) => e.severity === "critical").length;
    const openNow = rows.filter((e) => e.status === "open" || e.status === "acknowledged").length;
    const vehicles = rows.filter((e) => e.kind === "vehicle_in_zone" && e.ended_epoch);
    const over = vehicles.filter((e) => e.attributes && e.attributes.over_limit).length;
    const noted = rows.filter((e) => e.status === "resolved" && e.resolve_note).length;
    const delta = violations.length - prevViolations.length;
    return { total: violations.length, delta, critical, openNow, vehicles: vehicles.length, over, noted };
  }, [rows, prevRows]);

  const insights = useMemo(
    () => buildInsights([...rows, ...prevRows], toEpoch, { from: fromEpoch, to: toEpoch, label: "this period", prevLabel: "the period before" }),
    [rows, prevRows, fromEpoch, toEpoch]
  );

  function exportCsv() {
    const head = ["Started (IST)", "Ended (IST)", "Duration (h:mm:ss)", "Camera", "Zone", "Kind", "What", "Who", "Severity", "Status", "Acknowledged by", "Resolved by", "Note", "Picture", "Picture URL"];
    const lines = rows.map((e) => {
      const picture = getEvidenceUrl(e.evidence_last || e.evidence_first);
      return [
        ...[
          csvTime(e.started_at), csvTime(e.ended_at), csvDuration(e.duration_sec),
          e.camera_name, e.zone_name || "", e.kind, e.title, subjectText(e),
          e.severity, e.status, e.acknowledged_by || "", e.resolved_by || "", e.resolve_note || "",
        ].map(csvCell),
        // Excel only makes a cell clickable through HYPERLINK; the plain URL
        // beside it is what Sheets and LibreOffice link, and what you paste.
        csvLink(picture, "Open picture"),
        csvCell(picture),
      ].join(",");
    });
    // The BOM is what tells Excel the file is UTF-8; CRLF is what it expects.
    const blob = new Blob(["﻿", [head.map(csvCell).join(","), ...lines, ""].join("\r\n")], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `vision-ai_${from}_to_${to}.csv`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }

  const inputCls = "btn";

  return (
    <div className="ops history">
      <div className="topbar">
        <div>
          <h1 style={{ margin: 0, fontSize: 20 }}>History &amp; reports</h1>
          <span className="hint">Every episode the cameras confirmed, with what people did about it</span>
        </div>
        <div className="tools">
          <button className="btn" type="button" onClick={exportCsv} disabled={!rows.length}>Export CSV</button>
          <button className="btn" type="button" onClick={() => window.print()} disabled={!rows.length}>Print / PDF</button>
        </div>
      </div>

      <div className="filters">
        <label>From <input className={inputCls} type="date" value={from} max={to} onChange={(e) => setFrom(e.target.value)} /></label>
        <label>To <input className={inputCls} type="date" value={to} min={from} max={today} onChange={(e) => setTo(e.target.value)} /></label>
        <select className={inputCls} value={cameraId} onChange={(e) => setCameraId(e.target.value)} aria-label="Camera">
          <option value="">All cameras</option>
          {cameras.map((c) => <option key={c.id} value={c.id}>{c.camera_name}</option>)}
        </select>
        <select className={inputCls} value={kind} onChange={(e) => setKind(e.target.value)} aria-label="Kind">
          {KINDS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
        <select className={inputCls} value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status">
          {STATUSES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
        <span className="hint">{loading ? "Loading…" : `${rows.length} episodes${rows.length >= 1000 ? " (first 1000 — narrow the dates)" : ""}`}</span>
      </div>

      {error ? <div className="error-banner">{error}</div> : null}

      <section aria-labelledby="h-sum">
        <div className="sec-head"><h2 id="h-sum">Summary</h2><span className="hint">compared with the same number of days before</span></div>
        <div className="stats">
          <div><span className="k">Violations</span><span className="v">{stats.total}{prevRows.length || rows.length ? <small className={stats.delta > 0 ? "down" : ""}>{stats.delta > 0 ? "▲" : stats.delta < 0 ? "▼" : "="} {Math.abs(stats.delta)}</small> : null}</span></div>
          <div><span className="k">Critical</span><span className="v">{stats.critical}</span></div>
          <div><span className="k">Still open</span><span className="v">{stats.openNow}</span></div>
          <div><span className="k">Vehicle visits</span><span className="v">{stats.vehicles}<small className={stats.over ? "down" : ""}>{stats.over} over limit</small></span></div>
          <div><span className="k">Closed with a note</span><span className="v">{stats.noted}</span></div>
        </div>
      </section>

      <section aria-labelledby="h-ai">
        <div className="sec-head"><h2 id="h-ai">AI noticed</h2><span className="hint">Findings from this period's own data · a suggestion with each</span></div>
        {insights.learning ? (
          <div className="allclear">Not enough episodes in this period to say anything honest ({insights.count} of 5). Widen the dates.</div>
        ) : (
          <div className="ai">
            {insights.cards.map((card) => (
              <article className="insight" key={card.kind}>
                <div className="kind"><span>{card.kind}</span><span className="conf">{card.conf}</span></div>
                <p>{card.text.map((part, i) => (typeof part === "string" ? <span key={i}>{part}</span> : <b key={i}>{part.b}</b>))}</p>
                <div className="sug"><span>Suggestion</span> · {card.suggestion}</div>
              </article>
            ))}
          </div>
        )}
      </section>

      <section aria-labelledby="h-list">
        <div className="sec-head"><h2 id="h-list">Episodes</h2><span className="hint">newest first · click a picture to view it</span></div>
        <div className="ledger">
          <div className="ledger-scroll">
            <table>
              <thead>
                <tr><th>When</th><th>Where</th><th>What</th><th>Who</th><th>Duration</th><th>Status</th><th>Note</th><th>Picture</th></tr>
              </thead>
              <tbody>
                {rows.length ? rows.map((e) => {
                  const picture = getEvidenceUrl(e.evidence_last || e.evidence_first);
                  return (
                    <tr key={e.episode_id} className={e.needs_action ? `attn ${e.severity}` : ""}>
                      <td className="mono">{formatSince(e.started_epoch, now)}</td>
                      <td><b>{e.zone_name || e.camera_name}</b>{e.zone_name ? <div className="hint">{e.camera_name}</div> : null}</td>
                      <td><span className={`chip ${e.severity === "critical" ? "bad" : e.severity === "warning" ? "warn" : ""}`}>{severityLabel(e.severity)}</span> {e.title}</td>
                      <td>{subjectText(e)}</td>
                      <td className="mono">{formatDuration((e.ended_epoch || now) - e.started_epoch)}{e.ended_epoch ? "" : " · ongoing"}</td>
                      <td>
                        {e.status === "resolved" ? <span className="chip ok">resolved · {e.resolved_by}</span>
                          : e.status === "false_positive" ? <span className="chip">not a real issue · {e.resolved_by}</span>
                          : e.status === "acknowledged" ? <span className="chip warn">acknowledged · {e.acknowledged_by}</span>
                          : <span className="chip bad">open</span>}
                      </td>
                      <td>{e.resolve_note && e.status === "resolved" ? e.resolve_note : ""}</td>
                      <td>
                        {picture ? (
                          <button type="button" className="thumb" onClick={() => setViewing({ src: picture, title: e.title, meta: `${e.camera_name} · ${e.zone_name || e.camera_location || ""} · ${e.started_at}` })}>
                            <img src={picture} alt="" loading="lazy" />
                          </button>
                        ) : <span className="hint">—</span>}
                      </td>
                    </tr>
                  );
                }) : (
                  <tr><td colSpan={8} className="hint">{loading ? "Loading…" : "Nothing in this period with these filters."}</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <Lightbox item={viewing} onClose={() => setViewing(null)} />
    </div>
  );
}
