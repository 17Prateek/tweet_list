import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";

import "./ops.css";
import { useEpisodes, useNow } from "./useEpisodes";
import { buildInsights, buildProgress } from "./insights";
import {
  SEVERITY_ORDER,
  cameraShort,
  formatAge,
  formatClock,
  formatDuration,
  formatSince,
  formatTime,
  pluralise,
  severityLabel,
  severityLine,
  subjectText,
} from "./format";
import {
  getCameraSnapshotUrl,
  getCameras,
  getEvidenceUrl,
  getMonitoringStatus,
  getZoneSummary,
  listEpisodes,
} from "../data/api";
import { ZONE_ORDER, zoneTypeLabel } from "../setup/zoneTypes";

const LIVE_MONITORING_PATH = "/live-monitoring";
const SNAPSHOT_EVERY_MS = 3000;

/* ---------------------------------------------------------------- glyphs */

function Glyph({ type }) {
  if (type === "vehicle") {
    return (
      <span className="glyph" aria-hidden="true">
        <svg viewBox="0 0 24 24"><path d="M3 13l2-5h9l3 5h4v5h-2M3 13v5h2M3 13h15" /><circle cx="7" cy="18" r="2" /><circle cx="17" cy="18" r="2" /></svg>
      </span>
    );
  }
  if (type === "camera") {
    return (
      <span className="glyph" aria-hidden="true">
        <svg viewBox="0 0 24 24"><rect x="3" y="7" width="13" height="10" rx="2" /><path d="M16 10l5-3v10l-5-3z" /></svg>
      </span>
    );
  }
  return (
    <span className="glyph" aria-hidden="true">
      <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4 4-6 8-6s8 2 8 6" /></svg>
    </span>
  );
}

/* ------------------------------------------------------------ lightbox */

function Lightbox({ item, onClose, onKeep }) {
  useEffect(() => {
    if (!item) return undefined;
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [item, onClose]);

  if (!item) return null;
  return (
    <div className="lightbox" role="dialog" aria-modal="true" aria-label="Evidence picture" onClick={onClose}>
      <div className="lb-body" onClick={(e) => e.stopPropagation()}>
        <img src={item.src} alt={item.title} />
        <div className="lb-caption">
          <b>{item.title}</b>
          <span>{item.meta}</span>
          {item.episode ? (
            <button type="button" className="btn" onClick={() => onKeep(item.episode.episode_id, !item.episode.attributes?.keep)}>
              {item.episode.attributes?.keep ? "★ Kept - will not be auto-deleted" : "Keep this picture"}
            </button>
          ) : null}
          <a className="btn" href={item.src} target="_blank" rel="noreferrer">Open original</a>
          <button type="button" className="btn ghost" onClick={onClose}>Close (Esc)</button>
        </div>
      </div>
    </div>
  );
}

/* ----------------------------------------------------------- alert card */

function AlertCard({ episode, now, onAck, onResolve, onFalse, onView, selecting, selected, onToggle }) {
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const acked = episode.status === "acknowledged";
  const picture = getEvidenceUrl(episode.evidence_last || episode.evidence_first);
  const age = now - (episode.started_epoch || now);

  async function run(fn) {
    setBusy(true);
    setErr("");
    try {
      await fn();
    } catch (e) {
      setErr(e.message || "That did not go through");
    } finally {
      setBusy(false);
    }
  }

  return (
    <article
      className={`alert ${episode.severity}${selecting ? " selectable" : ""}${selected ? " selected" : ""}`}
      id={`ep-${episode.episode_id}`}
      onClick={selecting ? () => onToggle(episode.episode_id) : undefined}
    >
      <button
        type="button"
        className="pic"
        disabled={!picture}
        title={picture ? "View picture full screen" : "No picture for this episode"}
        onClick={(ev) => { ev.stopPropagation(); if (picture) onView({ src: picture, episode, title: episode.title, meta: `${cameraShort(episode)} · ${episode.zone_name || episode.camera_location || ""} · ${formatTime(episode.started_epoch)}` }); }}
      >
        {picture ? <img src={picture} alt="" loading="lazy" /> : null}
        <span className="cam mono">{cameraShort(episode)} · {formatTime(episode.started_epoch)}</span>
      </button>
      <div className="body">
        <div className="row1">
          {selecting ? (
            <input type="checkbox" className="pick" checked={selected} onChange={() => onToggle(episode.episode_id)} onClick={(ev) => ev.stopPropagation()} aria-label={`Select: ${episode.title}`} />
          ) : null}
          <span className="sev">{severityLabel(episode.severity)}</span>
          <span className="age mono">{formatAge(age)}</span>
        </div>
        <h3>{episode.title}</h3>
        <div className="meta">
          <span><b>{episode.zone_name || episode.camera_name}</b>{episode.camera_location ? ` · ${episode.camera_location}` : ""}</span>
          <span>{episode.subject_type === "camera" ? "Camera" : <b className={episode.subject_type === "unknown" ? "" : "name"}>{subjectText(episode)}</b>}</span>
          {episode.people_count > 1 ? <span>{episode.people_count} people</span> : null}
          {episode.ended_epoch ? <span>Ended {formatTime(episode.ended_epoch)} · lasted {formatDuration(episode.ended_epoch - episode.started_epoch)}</span> : <span>Still on camera</span>}
        </div>

        {selecting ? (
          <div className="state">{selected ? "✓ Selected" : "Tap to select"}{acked ? ` · acknowledged by ${episode.acknowledged_by}` : ""}</div>
        ) : !acked ? (
          <div className="actions">
            <button className="btn primary" disabled={busy} onClick={() => run(() => onAck(episode.episode_id))}>Acknowledge</button>
            <Link className="btn" to={`${LIVE_MONITORING_PATH}?camera=${episode.camera_id}`}>Open camera</Link>
            <button className="btn ghost" disabled={busy} onClick={() => run(() => onFalse(episode.episode_id))}>Not a real issue</button>
          </div>
        ) : (
          <>
            <div className="state acked">● Acknowledged by {episode.acknowledged_by} · close it out below when handled</div>
            <form
              className="closeout"
              onSubmit={(e) => {
                e.preventDefault();
                run(() => onResolve(episode.episode_id, note));
              }}
            >
              <input type="text" value={note} onChange={(e) => setNote(e.target.value)} placeholder="What was done? e.g. helmet issued, contractor briefed" aria-label="Resolution note" />
              <button className="btn primary" type="submit" disabled={busy || !note.trim()}>Mark resolved</button>
              <button className="btn ghost" type="button" disabled={busy} onClick={() => run(() => onFalse(episode.episode_id))}>Not a real issue</button>
            </form>
          </>
        )}
        {err ? <div className="err">{err}</div> : null}
      </div>
    </article>
  );
}

/* ------------------------------------------------------------ map tile */

function tileClass(cam, eps) {
  if (String(cam.status).toLowerCase() !== "online") return "off";
  if (eps.some((e) => e.severity === "critical" && e.needs_action)) return "crit";
  if (eps.some((e) => (e.severity === "warning" || e.severity === "notice") && e.needs_action)) return "warn";
  if (eps.length) return "busy";
  return "empty";
}

function MapTile({ cam, eps, now, selected, onSelect }) {
  const cls = tileClass(cam, eps);
  const lead = eps[0];
  const offline = cls === "off";

  return (
    <button type="button" className={`z ${cls}${selected ? " selected" : ""}`} onClick={onSelect}>
      <div className="zn">
        <span>{cam.camera_name}</span>
        <span className="cnt">{offline ? "off" : eps.length ? eps.length : "—"}</span>
      </div>
      <div className="zv">
        {offline ? (
          <>Offline<small>{cam.last_seen ? `last seen ${cam.last_seen}` : "never connected"} · <span className="cams">CAM-{cam.id}</span></small></>
        ) : lead ? (
          <>
            {lead.title}
            <small>{formatDuration((lead.ended_epoch || now) - lead.started_epoch)}{lead.ended_epoch ? " · ended" : " and counting"}{eps.length > 1 ? ` · +${eps.length - 1} more` : ""} · <span className="cams">CAM-{cam.id}</span></small>
          </>
        ) : (
          <>Nothing in progress<small>{cam.location || "watching"} · <span className="cams">CAM-{cam.id}</span></small></>
        )}
      </div>
    </button>
  );
}

/* ------------------------------------------------------------ zone tile */

function zoneTileClass(row) {
  const eps = row.eps;
  if (eps.some((e) => e.severity === "critical" && e.needs_action)) return "crit";
  if (eps.some((e) => (e.severity === "warning" || e.severity === "notice") && e.needs_action)) return "warn";
  if (eps.length) return "busy";
  return "empty";
}

function ZoneTile({ row, now, selected, onSelect }) {
  const { zone, eps } = row;
  const cls = zoneTileClass(row);
  const lead = eps[0];
  const wide = zone.zone_type === "yard" || zone.zone_type === "restricted";
  const limit = zone.limit_sec ? ` · limit ${formatDuration(zone.limit_sec)}` : "";
  const vehicles = eps.filter((e) => e.subject_type === "vehicle").length;
  const people = eps.filter((e) => e.subject_type === "person" || e.subject_type === "unknown").length;
  const count = vehicles && people ? `${vehicles} + ${people}` : vehicles || people || "—";

  return (
    <button type="button" className={`z ${cls}${wide ? " wide" : ""}${selected ? " selected" : ""}`} onClick={onSelect}>
      <div className="zn">
        <span>{zone.zone_type === "restricted" ? "⛔ " : ""}{zone.name}</span>
        <span className="cnt">{count}</span>
      </div>
      <div className="zv">
        {lead ? (
          <>
            {lead.title}
            <small>{formatDuration((lead.ended_epoch || now) - lead.started_epoch)}{lead.ended_epoch ? " · ended" : " and counting"}{eps.length > 1 ? ` · +${eps.length - 1} more` : ""}{limit}</small>
          </>
        ) : (
          <>{zone.zone_type === "restricted" ? "Nobody inside ✓" : "Empty"}<small>{zoneTypeLabel(zone.zone_type)}{limit} · <span className="cams">CAM-{zone.camera_id}</span></small></>
        )}
      </div>
    </button>
  );
}

/* --------------------------------------------------------- camera tile */

function CameraTile({ cam, index, enabled }) {
  const openHref = `${LIVE_MONITORING_PATH}?camera=${cam.id}`;
  const online = String(cam.status).toLowerCase() === "online";
  const [stamp, setStamp] = useState(() => Date.now());
  const [broken, setBroken] = useState(false);

  useEffect(() => {
    if (!online || !enabled) return undefined;
    // Stagger tiles so they do not all hit the server in the same instant.
    const offset = (index % 6) * 400;
    const start = setTimeout(() => setStamp(Date.now()), offset);
    const id = setInterval(() => setStamp(Date.now()), SNAPSHOT_EVERY_MS);
    // A camera that had no picture (reconnecting, backend restart) gets
    // another try every 30 s instead of staying blank until a reload.
    const retry = setInterval(() => setBroken(false), 30000);
    return () => {
      clearTimeout(start);
      clearInterval(id);
      clearInterval(retry);
    };
  }, [online, enabled, index]);

  const cls = !online ? "off" : broken ? "idle" : "live";

  return (
    <Link className={`cam ${cls}`} to={openHref} title={`${cam.camera_name} — open live view`}>
      {online && enabled && !broken ? (
        <img src={getCameraSnapshotUrl(cam.id, stamp)} alt="" onError={() => setBroken(true)} />
      ) : null}
      <span className="tag">{!online ? "OFFLINE" : broken ? "NO PICTURE" : "LIVE"}</span>
      <span className="lbl">
        <span>{cam.camera_name}</span>
        <span className="mode">CAM-{cam.id}</span>
      </span>
    </Link>
  );
}

/* --------------------------------------------------------------- board */

export default function OpsBoard() {
  const { episodes, connected, error, lastSync, acknowledge, resolve, falsePositive, keep, bulk } = useEpisodes();
  const now = useNow(1000);
  const [cameras, setCameras] = useState([]);
  const [monitoring, setMonitoring] = useState(null);
  const [history, setHistory] = useState([]);
  const [seg, setSeg] = useState("all");
  const [cameraFilter, setCameraFilter] = useState(null);
  const [zoneFilter, setZoneFilter] = useState(null);
  const [zoneRows, setZoneRows] = useState([]);
  const [pill, setPill] = useState(false);
  const [viewing, setViewing] = useState(null);
  const [selecting, setSelecting] = useState(false);
  const [selected, setSelected] = useState(() => new Set());
  const [bulkNote, setBulkNote] = useState("");
  const [bulkBusy, setBulkBusy] = useState(false);
  const [bulkErr, setBulkErr] = useState("");
  const [bulkMsg, setBulkMsg] = useState("");
  const needsRef = useRef(null);

  // Cameras + monitoring status, refreshed every 30 s.
  useEffect(() => {
    let alive = true;
    async function load() {
      try {
        const res = await getCameras();
        if (alive) setCameras(Array.isArray(res?.data) ? res.data : []);
      } catch { /* keep the last list */ }
      try {
        const res = await getMonitoringStatus();
        if (alive) setMonitoring(res?.data || null);
      } catch { /* ignore */ }
    }
    load();
    const id = setInterval(load, 30000);
    return () => {
      alive = false;
      clearInterval(id);
    };
  }, []);

  // Zones (with what is live in them), refreshed every 30 s. Empty until drawn.
  useEffect(() => {
    let alive = true;
    async function load() {
      try {
        const res = await getZoneSummary();
        if (alive) setZoneRows(res.data || []);
      } catch { /* the map falls back to camera tiles */ }
    }
    load();
    const id = setInterval(load, 30000);
    return () => {
      alive = false;
      clearInterval(id);
    };
  }, []);

  // History for "AI noticed" and "Progress", refreshed every 2 min.
  useEffect(() => {
    let alive = true;
    async function load() {
      try {
        const res = await listEpisodes({ limit: 1000 });
        if (alive) setHistory(res.data || []);
      } catch { /* ignore */ }
    }
    load();
    const id = setInterval(load, 120000);
    return () => {
      alive = false;
      clearInterval(id);
    };
  }, [episodes.length]);

  const needsAction = useMemo(
    () =>
      episodes
        .filter((e) => e.needs_action)
        // Loudest first, then the newest - what just happened is what the
        // person at the screen is looking for.
        .sort((a, b) => (SEVERITY_ORDER[a.severity] ?? 9) - (SEVERITY_ORDER[b.severity] ?? 9) || b.started_epoch - a.started_epoch),
    [episodes]
  );

  // Sticky pill once the cards have scrolled off.
  useEffect(() => {
    const el = needsRef.current;
    if (!el) return undefined;
    const obs = new IntersectionObserver(([entry]) => setPill(!entry.isIntersecting), { threshold: 0.05 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  // The plant map answers "what is happening now", so an episode that has
  // ended keeps its card in Needs action for close-out but must let the tile
  // go back to normal (acceptance 2.2).
  const liveEpisodes = useMemo(() => episodes.filter((e) => !e.ended_epoch), [episodes]);

  const byCamera = useMemo(() => {
    const map = new Map();
    liveEpisodes.forEach((e) => {
      if (!map.has(e.camera_id)) map.set(e.camera_id, []);
      map.get(e.camera_id).push(e);
    });
    map.forEach((list) => list.sort((a, b) => (SEVERITY_ORDER[a.severity] ?? 9) - (SEVERITY_ORDER[b.severity] ?? 9) || a.started_epoch - b.started_epoch));
    return map;
  }, [liveEpisodes]);

  const zoneTiles = useMemo(() => {
    const byZone = new Map();
    liveEpisodes.forEach((e) => {
      if (e.zone_id == null) return;
      if (!byZone.has(e.zone_id)) byZone.set(e.zone_id, []);
      byZone.get(e.zone_id).push(e);
    });
    const rows = zoneRows.map((r) => {
      const eps = (byZone.get(r.zone.id) || []).slice().sort((a, b) => (SEVERITY_ORDER[a.severity] ?? 9) - (SEVERITY_ORDER[b.severity] ?? 9) || a.started_epoch - b.started_epoch);
      return { zone: r.zone, eps };
    });
    rows.sort((a, b) => ZONE_ORDER.indexOf(a.zone.zone_type) - ZONE_ORDER.indexOf(b.zone.zone_type) || a.zone.name.localeCompare(b.zone.name));
    return rows;
  }, [zoneRows, liveEpisodes]);

  const yard = useMemo(() => {
    const inside = new Set();
    let waiting = 0, overLimit = 0, restrictedPeople = 0, baysBusy = 0, bays = 0;
    zoneTiles.forEach(({ zone, eps }) => {
      const vehicles = eps.filter((e) => e.subject_type === "vehicle" && !e.ended_epoch);
      vehicles.forEach((e) => inside.add(e.episode_id));
      if (zone.zone_type === "yard" || zone.zone_type === "gate") waiting += vehicles.length;
      overLimit += vehicles.filter((e) => e.attributes && e.attributes.over_limit).length;
      if (zone.zone_type === "bay" || zone.zone_type === "unloading_bay") { bays += 1; if (vehicles.length) baysBusy += 1; }
      if (zone.zone_type === "restricted") restrictedPeople += eps.filter((e) => (e.subject_type === "person" || e.subject_type === "unknown") && !e.ended_epoch).length;
    });
    return { inside: inside.size, waiting, overLimit, bays, baysBusy, restrictedPeople };
  }, [zoneTiles]);

  const camerasWithoutZones = useMemo(() => {
    const zoned = new Set(zoneRows.map((r) => r.zone.camera_id));
    return cameras.filter((c) => !zoned.has(c.id));
  }, [cameras, zoneRows]);

  const ledger = useMemo(() => {
    return episodes.filter((e) => {
      if (cameraFilter != null && e.camera_id !== cameraFilter) return false;
      if (zoneFilter != null && e.zone_id !== zoneFilter) return false;
      if (seg === "vehicle") return e.subject_type === "vehicle";
      if (seg === "person") return e.subject_type === "person" || e.subject_type === "unknown";
      if (seg === "attn") return e.needs_action;
      return true;
    });
  }, [episodes, seg, cameraFilter, zoneFilter]);

  // Insights only need to move once a minute, not on every second tick.
  const minute = Math.floor(now / 60);
  const insights = useMemo(() => buildInsights(history, minute * 60), [history, minute]);
  const progress = useMemo(() => buildProgress(history, minute * 60, cameras), [history, cameras, minute]);

  const onlineCams = cameras.filter((c) => String(c.status).toLowerCase() === "online").length;
  const monitoringOn = monitoring ? Boolean(monitoring.enabled) : null;
  const syncAge = lastSync ? Math.max(0, Math.round(now - lastSync / 1000)) : null;
  const selectedCam = cameraFilter != null ? cameras.find((c) => c.id === cameraFilter) : null;
  const selectedZone = zoneFilter != null ? zoneRows.find((r) => r.zone.id === zoneFilter)?.zone : null;
  const sevLine = severityLine(needsAction);

  // Cards can leave the board (resolved elsewhere, closed) while selected.
  const chosen = needsAction.filter((e) => selected.has(e.episode_id));

  function toggleSelected(id) {
    setSelected((cur) => {
      const next = new Set(cur);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  function stopSelecting() {
    setSelecting(false);
    setSelected(new Set());
    setBulkNote("");
    setBulkErr("");
  }

  async function runBulk(action) {
    const ids = chosen.map((e) => e.episode_id);
    if (!ids.length) return;
    setBulkBusy(true);
    setBulkErr("");
    setBulkMsg("");
    try {
      const res = await bulk(ids, action, bulkNote);
      const n = (res.updated || []).length;
      const verb = action === "acknowledge" ? "acknowledged" : action === "resolve" ? "resolved" : "marked not a real issue";
      setBulkMsg(`${pluralise(n, "alert")} ${verb}`);
      if (action === "acknowledge") {
        // Keep the selection - the usual next step is resolving the same set.
        setBulkNote("");
      } else {
        stopSelecting();
      }
    } catch (e) {
      setBulkErr(e.message || "That did not go through");
    } finally {
      setBulkBusy(false);
    }
  }

  function pickCamera(id) {
    const next = cameraFilter === id ? null : id;
    setZoneFilter(null);
    setCameraFilter(next);
    if (next != null) document.getElementById("h-now")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function pickZone(id) {
    const next = zoneFilter === id ? null : id;
    setCameraFilter(null);
    setZoneFilter(next);
    if (next != null) document.getElementById("h-now")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  return (
    <div className="ops">
      <div className="topbar">
        <div className="site">
          <h1>Ops Board</h1>
          <div className="sub">
            {cameras.length ? `${cameras.length} cameras · ${onlineCams} online` : "Loading cameras…"}
            {monitoringOn == null ? "" : monitoringOn ? ` · monitoring on (${monitoring.monitored_count})` : " · monitoring OFF"}
          </div>
        </div>
        <div className="clock">
          <span>
            <span className={`status-dot${connected ? "" : " warn"}`} />
            {connected ? "Live" : "Reconnecting · polling"}
            {syncAge != null ? ` · synced ${syncAge < 2 ? "just now" : `${syncAge} s ago`}` : ""}
          </span>
          <span className="time mono">{formatClock(now * 1000)}</span>
          <span>IST</span>
        </div>
      </div>

      {error ? <div className="error-banner">{error}</div> : null}

      {/* ------------------------------------------------ needs action */}
      <section aria-labelledby="h-needs" ref={needsRef}>
        <div className="sec-head">
          <h2 id="h-needs">Needs action{sevLine ? <> · <span className="sevline">{sevLine}</span></> : null}</h2>
          <div className="tools">
            {!selecting ? (
              <>
                <span className="hint">Loudest first, newest first · acknowledge = someone's on it · resolving needs a note (that's the audit trail)</span>
                {needsAction.length > 1 ? <button className="btn" type="button" onClick={() => { setSelecting(true); setBulkMsg(""); }}>Select several</button> : null}
              </>
            ) : (
              <>
                <button className="btn" type="button" onClick={() => setSelected(new Set(needsAction.map((e) => e.episode_id)))}>Select all {needsAction.length}</button>
                <button className="btn ghost" type="button" onClick={() => setSelected(new Set())} disabled={!chosen.length}>Clear</button>
                <button className="btn ghost" type="button" onClick={stopSelecting}>Done</button>
              </>
            )}
            {bulkMsg && !selecting ? <span className="hint"><b>{bulkMsg}</b></span> : null}
          </div>
        </div>
        {selecting ? (
          <div className="bulkbar" role="region" aria-label="Actions on selected alerts">
            <span className="count"><b>{chosen.length}</b> of {needsAction.length} selected</span>
            <button className="btn primary" type="button" disabled={bulkBusy || !chosen.length} onClick={() => runBulk("acknowledge")}>Acknowledge {chosen.length || ""}</button>
            <form className="closeout" onSubmit={(e) => { e.preventDefault(); runBulk("resolve"); }}>
              <input type="text" value={bulkNote} onChange={(e) => setBulkNote(e.target.value)} placeholder="One note for all, e.g. night shift briefed" aria-label="Resolution note for selected alerts" />
              <button className="btn primary" type="submit" disabled={bulkBusy || !chosen.length || !bulkNote.trim()}>Resolve {chosen.length || ""}</button>
            </form>
            <button className="btn ghost" type="button" disabled={bulkBusy || !chosen.length} onClick={() => runBulk("false_positive")}>Not a real issue</button>
            {bulkMsg ? <span className="hint"><b>{bulkMsg}</b></span> : null}
            {bulkErr ? <span className="err">{bulkErr}</span> : null}
          </div>
        ) : null}
        {needsAction.length ? (
          <div className="alerts">
            {needsAction.map((e) => (
              <AlertCard
                key={e.episode_id}
                episode={e}
                now={now}
                onAck={acknowledge}
                onResolve={resolve}
                onFalse={falsePositive}
                onView={setViewing}
                selecting={selecting}
                selected={selected.has(e.episode_id)}
                onToggle={toggleSelected}
              />
            ))}
          </div>
        ) : (
          <div className="allclear"><b>All clear.</b> Nothing needs a person right now — new alerts appear here the moment a camera confirms one.</div>
        )}
      </section>

      {/* --------------------------------------------------- plant map */}
      <section aria-labelledby="h-map">
        <div className="sec-head">
          <h2 id="h-map">Plant map</h2>
          <span className="hint">
            {zoneTiles.length ? (
              <b>
                {pluralise(yard.inside, "vehicle")} inside · {yard.waiting} waiting{yard.overLimit ? ` (${yard.overLimit} over limit)` : ""}
                {yard.bays ? ` · ${yard.baysBusy} of ${yard.bays} bays occupied` : ""} · {yard.restrictedPeople} in restricted zones
              </b>
            ) : (
              <b>{pluralise(liveEpisodes.length, "thing")} in progress across {pluralise(byCamera.size, "camera")} · {needsAction.length} need action</b>
            )}
            {" "}· click a {zoneTiles.length ? "zone" : "camera"} to filter Happening now
          </span>
        </div>
        {zoneTiles.length || cameras.length ? (
          <div className="map">
            {zoneTiles.map((row) => (
              <ZoneTile key={`z${row.zone.id}`} row={row} now={now} selected={zoneFilter === row.zone.id} onSelect={() => pickZone(row.zone.id)} />
            ))}
            {(zoneTiles.length ? camerasWithoutZones : cameras).map((cam) => (
              <MapTile key={cam.id} cam={cam} eps={byCamera.get(cam.id) || []} now={now} selected={cameraFilter === cam.id} onSelect={() => pickCamera(cam.id)} />
            ))}
          </div>
        ) : (
          <div className="allclear">No cameras configured yet.</div>
        )}
        <div className="legend">
          <span className="c"><i />needs action now</span>
          <span className="w"><i />warning / notice open</span>
          <span className="b"><i />something in progress</span>
          <span><i />quiet</span>
          <span className="o"><i />offline</span>
          <span style={{ marginLeft: "auto" }}>
            {zoneTiles.length
              ? <>{pluralise(zoneTiles.length, "zone")} drawn · cameras without zones show as plain tiles · <Link to="/setup/zones">edit zones</Link></>
              : <>No zones drawn yet — <Link to="/setup/zones">draw gate, weighbridge, yard and bays on the cameras</Link> and this map turns into the plant.</>}
          </span>
        </div>
      </section>

      {/* ----------------------------------------------- happening now */}
      <section aria-labelledby="h-now">
        <div className="sec-head">
          <h2 id="h-now">Happening now</h2>
          <div className="tools">
            {selectedCam ? (
              <span className="zonechip">Showing <b>{selectedCam.camera_name}</b><button type="button" aria-label="Clear camera filter" onClick={() => setCameraFilter(null)}>×</button></span>
            ) : null}
            {selectedZone ? (
              <span className="zonechip">Showing <b>{selectedZone.name}</b><button type="button" aria-label="Clear zone filter" onClick={() => setZoneFilter(null)}>×</button></span>
            ) : null}
            <div className="seg" role="tablist" aria-label="Show">
              {[["all", "All"], ["vehicle", "Vehicles"], ["person", "People"], ["attn", "Needs action"]].map(([key, label]) => (
                <button key={key} type="button" className={`${seg === key ? "on" : ""}${key === "attn" ? " attn" : ""}`} onClick={() => setSeg(key)}>{label}</button>
              ))}
            </div>
            <span className="hint">{ledger.length} in progress · timers counting</span>
          </div>
        </div>
        <div className="ledger">
          <div className="ledger-scroll">
            <table>
              <thead>
                <tr><th>Who / what</th><th>Where</th><th>Since</th><th>Duration</th><th>Checks &amp; status</th><th>Camera</th></tr>
              </thead>
              <tbody>
                {ledger.length ? ledger.map((e) => {
                  const attrs = e.attributes || {};
                  const duration = (e.ended_epoch || now) - e.started_epoch;
                  const limitSec = attrs.limit_sec ? Number(attrs.limit_sec) : null;
                  const pastLimit = limitSec != null && duration >= limitSec && !e.ended_epoch;
                  const durCls = e.needs_action ? (e.severity === "critical" ? " hot" : " over") : pastLimit ? " over" : "";
                  return (
                    <tr key={e.episode_id} className={e.needs_action ? `attn ${e.severity}` : ""}>
                      <td>
                        <div className="who">
                          <Glyph type={e.subject_type} />
                          <div>
                            <div className={`${e.subject_type === "vehicle" ? "plate" : "name"}${e.subject_type === "unknown" ? " unknown" : ""}`}>{subjectText(e)}{e.people_count > 1 ? ` +${e.people_count - 1}` : ""}</div>
                            {e.needs_action ? <a className="uplink" href={`#ep-${e.episode_id}`}><b>{e.title}</b> ↑</a> : <span className="uplink">{e.title}{attrs.vehicle_class ? ` · ${attrs.vehicle_class}` : ""}</span>}
                          </div>
                        </div>
                      </td>
                      <td className="zone">{e.zone_name || e.camera_name}<small>{e.camera_location || ""}</small></td>
                      <td className="since">{formatSince(e.started_epoch, now)}</td>
                      <td>
                        <span className={`dur${durCls}`}>{formatDuration(duration)}<span className={`tick${e.ended_epoch ? "" : " live"}`}>{e.ended_epoch ? "ended" : "●"}</span></span>
                        {limitSec != null ? <span className="uplink">of {formatDuration(limitSec)}{pastLimit ? " — over" : ""}</span> : null}
                      </td>
                      <td>
                        <div className="checks">
                          {"helmet" in attrs ? <span className={`chip ${attrs.helmet ? "ok" : "bad"}`}>helmet {attrs.helmet ? "✓" : "✗"}</span> : null}
                          {"vest" in attrs ? <span className={`chip ${attrs.vest ? "ok" : "bad"}`}>vest {attrs.vest ? "✓" : "✗"}</span> : null}
                          {attrs.over_limit ? <span className="chip warn">over time limit</span> : null}
                          {e.status === "acknowledged" ? <span className="chip warn">acknowledged · {e.acknowledged_by}</span> : e.needs_action ? <span className="chip bad">open</span> : <span className="chip">info</span>}
                          {e.ended_epoch && e.needs_action ? <span className="chip">gone from camera</span> : null}
                        </div>
                      </td>
                      <td className="camref">CAM-{e.camera_id}</td>
                    </tr>
                  );
                }) : (
                  <tr className="empty-row"><td colSpan={6}>Nothing in progress{selectedCam ? ` on ${selectedCam.camera_name}` : ""}{seg !== "all" ? " for this filter" : ""}.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* -------------------------------------------------- AI noticed */}
      <section aria-labelledby="h-ai">
        <div className="sec-head">
          <h2 id="h-ai">AI noticed</h2>
          <span className="hint">Findings from this plant's own data · a suggestion with each</span>
        </div>
        <div className="ai">
          {insights.learning ? (
            [
              ["Hotspot", "Which camera and which hour produce most violations, and what to do about it."],
              ["Response", "How fast alerts get acknowledged, and whether that is improving week on week."],
              ["People", "Whether violations come from enrolled staff or unknown visitors, and who repeats."],
            ].map(([kind, text]) => (
              <article className="insight learning" key={kind}>
                <div className="kind"><span>{kind}</span><span className="conf">learning · {insights.count} of 5 episodes</span></div>
                <p>{text}</p>
                <div className="sug"><span>Appears</span> after five episodes in a week — the board only says what the data supports.</div>
              </article>
            ))
          ) : (
            insights.cards.map((card) => (
              <article className="insight" key={card.kind}>
                <div className="kind"><span>{card.kind}</span><span className="conf">{card.conf}</span></div>
                <p>{card.text.map((part, i) => (typeof part === "string" ? <span key={i}>{part}</span> : <b key={i}>{part.b}</b>))}</p>
                <div className="sug"><span>Suggestion</span> · {card.suggestion}</div>
              </article>
            ))
          )}
        </div>
      </section>

      {/* ----------------------------------------------------- cameras */}
      <section aria-labelledby="h-cams">
        <div className="sec-head">
          <h2 id="h-cams">Cameras</h2>
          <span className="hint">A fresh picture every 3 s · click for full video</span>
        </div>
        {cameras.length ? (
          <div className="camgrid">
            {cameras.map((cam, i) => <CameraTile key={cam.id} cam={cam} index={i} enabled />)}
          </div>
        ) : (
          <div className="allclear">No cameras configured yet.</div>
        )}
      </section>

      {/* ---------------------------------------------------- progress */}
      <section aria-labelledby="h-prog">
        <div className="sec-head">
          <h2 id="h-prog">Progress</h2>
          <span className="hint">Last 30 days vs the 30 before · the numbers a plant head takes to a review</span>
        </div>
        <div className="progress">
          {progress.items.map((it) => (
            <div key={it.k}>
              <span className="k">{it.k}</span>
              <span className="v">{it.v}{it.d ? <small className={it.d.good ? "" : "down"}>{it.d.text}</small> : null}</span>
            </div>
          ))}
          <div className="why"><b>{progress.why}</b> {progress.next}</div>
        </div>
      </section>

      <Lightbox
        item={viewing}
        onClose={() => setViewing(null)}
        onKeep={async (id, value) => {
          const updated = await keep(id, value);
          setViewing((v) => (v ? { ...v, episode: updated } : v));
        }}
      />

      {pill && needsAction.length ? (
        <button type="button" className="pill" onClick={() => needsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" })}>
          <span className="n">{needsAction.length}</span> need action ↑
        </button>
      ) : null}
    </div>
  );
}
