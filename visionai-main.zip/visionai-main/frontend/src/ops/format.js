// Small display helpers shared by the Ops Board.

export function formatDuration(seconds) {
  const s = Math.max(0, Math.floor(seconds || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;

  if (h) return `${h} h ${String(m).padStart(2, "0")} m`;
  if (m) return `${m} m ${String(sec).padStart(2, "0")} s`;
  return `${sec} s`;
}

export function formatAge(seconds) {
  const s = Math.max(0, Math.floor(seconds || 0));

  if (s < 60) return `${s} s ago`;
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ${Math.floor((s % 3600) / 60)} m ago`;
  return `${Math.floor(s / 86400)} d ago`;
}

const timeFmt = new Intl.DateTimeFormat("en-IN", { hour: "2-digit", minute: "2-digit", hour12: false, timeZone: "Asia/Kolkata" });
const clockFmt = new Intl.DateTimeFormat("en-IN", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false, timeZone: "Asia/Kolkata" });
const dayFmt = new Intl.DateTimeFormat("en-IN", { day: "numeric", month: "short", timeZone: "Asia/Kolkata" });

export function formatTime(epoch) {
  if (!epoch) return "—";
  return timeFmt.format(new Date(epoch * 1000));
}

export function formatClock(ms) {
  return clockFmt.format(new Date(ms));
}

/** "14:52" today, "13 Sep 14:52" otherwise. */
export function formatSince(epoch, nowEpoch) {
  if (!epoch) return "—";
  const d = new Date(epoch * 1000);
  const sameDay = dayFmt.format(d) === dayFmt.format(new Date(nowEpoch * 1000));
  return sameDay ? timeFmt.format(d) : `${dayFmt.format(d)} ${timeFmt.format(d)}`;
}

export const SEVERITY_ORDER = { critical: 0, warning: 1, notice: 2, info: 3 };

export function severityLabel(sev) {
  return sev ? sev[0].toUpperCase() + sev.slice(1) : "";
}

export function pluralise(n, word, plural = `${word}s`) {
  return `${n} ${n === 1 ? word : plural}`;
}

/** "2 critical · 3 warnings · 1 notice" or "" when nothing is open. */
export function severityLine(episodes) {
  const c = episodes.filter((e) => e.severity === "critical").length;
  const w = episodes.filter((e) => e.severity === "warning").length;
  const n = episodes.filter((e) => e.severity === "notice").length;
  return [c && `${c} critical`, w && pluralise(w, "warning"), n && pluralise(n, "notice")].filter(Boolean).join(" · ");
}

/** Short subject text for a row: name, plate, camera, or "Unknown person". */
export function subjectText(episode) {
  if (episode.subject_type === "unknown") return "Unknown person";
  const plate = episode.attributes && episode.attributes.plate;
  if (plate) return `${plate} · ${episode.subject_label || "vehicle"}`;
  return episode.subject_label || "—";
}

export function cameraShort(episode) {
  return episode.camera_name || `CAM-${episode.camera_id}`;
}
