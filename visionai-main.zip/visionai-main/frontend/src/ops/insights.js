// "AI noticed" and "Progress" derived from this plant's own episode history.
// Everything here is a plain fact computed from real rows - no guesses - and
// each insight names the number of episodes it rests on.

const DAY = 86400;

function inWindow(e, fromEpoch, toEpoch) {
  return e.started_epoch >= fromEpoch && e.started_epoch < toEpoch;
}

function isViolation(e) {
  return e.kind !== "system";
}

function median(values) {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

function ackDelayMin(e) {
  if (!e.acknowledged_at || !e.started_epoch) return null;
  const ack = Date.parse(e.acknowledged_at) / 1000;
  if (!Number.isFinite(ack)) return null;
  return Math.max(0, (ack - e.started_epoch) / 60);
}

function countBy(items, keyFn) {
  const map = new Map();
  items.forEach((item) => {
    const k = keyFn(item);
    if (k == null) return;
    map.set(k, (map.get(k) || 0) + 1);
  });
  return [...map.entries()].sort((a, b) => b[1] - a[1]);
}

function hourIST(epoch) {
  // Hour of day in India, without pulling in a timezone library.
  return Math.floor(((epoch + 5.5 * 3600) % DAY) / 3600);
}

function fmtMin(m) {
  if (m == null) return "—";
  if (m < 1) return "under a minute";
  if (m < 60) return `${Math.round(m)} min`;
  return `${(m / 60).toFixed(1)} h`;
}

/**
 * Insight cards for a window (default: the last 7 days, compared with the 7
 * before). Returns {learning: true} while there is too little data to say
 * anything honest. opts: {from, to} epochs and a label such as "this week".
 */
export function buildInsights(history, nowEpoch, opts = {}) {
  const to = opts.to ?? nowEpoch + 60;
  const from = opts.from ?? nowEpoch - 7 * DAY;
  const span = Math.max(DAY, to - from);
  const label = opts.label ?? "this week";
  const prevLabel = opts.prevLabel ?? "last week";
  const week = history.filter((e) => isViolation(e) && inWindow(e, from, to));
  const prevWeek = history.filter((e) => isViolation(e) && inWindow(e, from - span, from));

  if (week.length < 5) {
    return { learning: true, count: week.length };
  }

  const cards = [];
  const days = Math.max(1, Math.round(span / DAY));

  // 1. Where and when it happens.
  const byCamera = countBy(week, (e) => e.camera_name || `CAM-${e.camera_id}`);
  const [topCam, topCamN] = byCamera[0];
  const byHour = countBy(week, (e) => hourIST(e.started_epoch));
  const [peakHour, peakN] = byHour[0];
  const share = Math.round((topCamN / week.length) * 100);
  cards.push({
    kind: "Hotspot",
    conf: `${week.length} episodes · ${days} ${days === 1 ? "day" : "days"}`,
    text: [
      { b: topCam },
      ` accounts for ${share}% of ${label}'s violations (${topCamN} of ${week.length})`,
      peakN >= 3 ? `, most between ${String(peakHour).padStart(2, "0")}:00 and ${String((peakHour + 1) % 24).padStart(2, "0")}:00.` : ".",
    ],
    suggestion: `Put a two-minute PPE check at ${topCam}${peakN >= 3 ? ` before ${String(peakHour).padStart(2, "0")}:00` : ""} and see if the next period's count drops.`,
  });

  // 2. How fast people respond.
  const delays = week.map(ackDelayMin).filter((v) => v != null);
  const prevDelays = prevWeek.map(ackDelayMin).filter((v) => v != null);
  const med = median(delays);
  const prevMed = median(prevDelays);
  const unacked = week.filter((e) => !e.acknowledged_at && e.status === "open").length;
  if (delays.length >= 3) {
    const trend = prevMed != null ? (med < prevMed ? ` — faster than ${prevLabel}'s ${fmtMin(prevMed)}` : med > prevMed ? ` — slower than ${prevLabel}'s ${fmtMin(prevMed)}` : "") : "";
    cards.push({
      kind: "Response",
      conf: `${delays.length} acknowledged`,
      text: [`Alerts are acknowledged in a median of `, { b: fmtMin(med) }, `${trend}.`, unacked ? ` ${unacked} from ${label} were never acknowledged.` : ""],
      suggestion: med > 10 ? "Add a second person to the alert list so someone always picks up within 10 minutes." : "Keep the current alert list — this is a good response time for a plant floor.",
    });
  } else {
    cards.push({
      kind: "Response",
      conf: `${delays.length} acknowledged`,
      text: [`Only ${delays.length} of ${label}'s ${week.length} alerts were acknowledged on the board`, unacked ? ` — ${unacked} are still open.` : "."],
      suggestion: "Ask the shift supervisor to acknowledge from the phone app; response time only becomes visible once they do.",
    });
  }

  // 3. Who it is.
  const unknown = week.filter((e) => e.subject_type === "unknown").length;
  const unknownShare = Math.round((unknown / week.length) * 100);
  if (unknownShare >= 50) {
    cards.push({
      kind: "People",
      conf: `${week.length} episodes`,
      text: [{ b: `${unknownShare}%` }, ` of ${label}'s violations were by people the system does not recognise (${unknown} of ${week.length}).`],
      suggestion: "Enrol the regular contractors' faces — alerts then name the person, and repeat offenders become visible.",
    });
  } else {
    const byPerson = countBy(week.filter((e) => e.subject_type === "person"), (e) => e.subject_label);
    const [who, n] = byPerson[0] || ["—", 0];
    cards.push({
      kind: "People",
      conf: `${week.length} episodes`,
      text: [{ b: who }, ` was involved in ${n} of ${label}'s ${week.length} violations — more than anyone else.`],
      suggestion: `A quiet word with ${who} and their supervisor is the cheapest fix on this board.`,
    });
  }

  // 4. Yard: how long vehicles wait, and where.
  const vehicles = week.filter((e) => e.kind === "vehicle_in_zone" && e.ended_epoch);
  if (vehicles.length >= 3) {
    const waits = vehicles.map((e) => (e.ended_epoch - e.started_epoch) / 60);
    const medWait = median(waits);
    const over = vehicles.filter((e) => e.attributes && e.attributes.over_limit);
    const byZone = countBy(over, (e) => e.zone_name || e.camera_name);
    const [worstZone, worstN] = byZone[0] || [null, 0];
    cards.push({
      kind: "Yard",
      conf: `${vehicles.length} vehicle visits`,
      text: [
        `Vehicles stayed a median of `, { b: fmtMin(medWait) }, ` per zone visit; `,
        { b: `${over.length}` }, ` of ${vehicles.length} went over the limit`,
        worstZone ? `, ${worstN} of them at ${worstZone}.` : ".",
      ],
      suggestion: over.length
        ? `Look at what holds vehicles at ${worstZone || "the yard"} — paperwork, weighbridge queue or bay readiness — before changing the limit.`
        : "Limits are being met. Consider tightening the yard limit by 10% and see whether it still holds.",
    });
  }

  // 5. Restricted areas.
  const restricted = week.filter((e) => e.kind === "person_in_zone");
  if (restricted.length >= 2) {
    const byZone = countBy(restricted, (e) => e.zone_name || e.camera_name);
    const [zone, n] = byZone[0];
    const known = restricted.filter((e) => e.subject_type === "person").length;
    cards.push({
      kind: "Restricted",
      conf: `${restricted.length} entries`,
      text: [
        { b: `${restricted.length}` }, ` restricted-area entries, ${n} of them at `, { b: zone },
        known ? `; ${known} by enrolled staff.` : "; none by anyone the system recognises.",
      ],
      suggestion: known
        ? "Enrolled staff entering a restricted zone usually means the zone needs an allowed list — ask the plant who is permitted there."
        : `Check the physical barrier and signage at ${zone}; unknown people getting in is a fencing problem before it is a camera problem.`,
    });
  }

  return { learning: false, cards };
}

/** The numbers a plant head takes to a review: last 30 days vs the 30 before. */
export function buildProgress(history, nowEpoch, cameras) {
  const cur = history.filter((e) => isViolation(e) && inWindow(e, nowEpoch - 30 * DAY, nowEpoch + 60));
  const prev = history.filter((e) => isViolation(e) && inWindow(e, nowEpoch - 60 * DAY, nowEpoch - 30 * DAY));

  const curMed = median(cur.map(ackDelayMin).filter((v) => v != null));
  const prevMed = median(prev.map(ackDelayMin).filter((v) => v != null));

  const ended = cur.filter((e) => e.ended_epoch);
  const noted = ended.filter((e) => e.status === "resolved" && e.resolve_note && e.resolved_by !== "system");
  const notedPct = ended.length ? Math.round((noted.length / ended.length) * 100) : null;
  const prevEnded = prev.filter((e) => e.ended_epoch);
  const prevNoted = prevEnded.filter((e) => e.status === "resolved" && e.resolve_note && e.resolved_by !== "system");
  const prevNotedPct = prevEnded.length ? Math.round((prevNoted.length / prevEnded.length) * 100) : null;

  const online = (cameras || []).filter((c) => String(c.status).toLowerCase() === "online").length;

  const delta = (a, b, lowerIsBetter) => {
    if (a == null || b == null) return null;
    const diff = Math.round(a - b);
    if (diff === 0) return { text: "same as last month", good: true };
    const good = lowerIsBetter ? diff < 0 : diff > 0;
    return { text: `${diff > 0 ? "▲" : "▼"} ${Math.abs(diff)} vs last month`, good };
  };

  const why = [];
  if (cur.length && prev.length) why.push(`${cur.length < prev.length ? "fewer" : "more"} violations than last month`);
  if (notedPct != null) why.push(`${notedPct}% of closed alerts carry a note`);
  if (cameras && cameras.length) why.push(`${online} of ${cameras.length} cameras online`);

  return {
    items: [
      { k: "Violations · 30 days", v: String(cur.length), d: delta(cur.length, prev.length, true) },
      { k: "Response to alerts", v: fmtMin(curMed), d: delta(curMed, prevMed, true) },
      { k: "Closed with a note", v: notedPct == null ? "—" : `${notedPct}%`, d: delta(notedPct, prevNotedPct, false) },
      { k: "Cameras online", v: cameras ? `${online} / ${cameras.length}` : "—", d: null },
    ],
    why: why.length ? `What moved it: ${why.join(", ")}.` : "Numbers appear after the first month of monitoring.",
    next: "Next: draw zones on the yard and bay cameras so vehicle waiting times join this board.",
  };
}
