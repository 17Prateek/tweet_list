import { useCallback, useEffect, useRef, useState } from "react";

import {
  acknowledgeEpisode,
  bulkEpisodeAction,
  getEpisodeStreamUrl,
  getLiveEpisodes,
  markEpisodeFalsePositive,
  resolveEpisode,
  setEpisodeKeep,
} from "../data/api";

// How often to resync with /live when the stream is not connected.
const POLL_MS_STREAMING = 30000;
const POLL_MS_FALLBACK = 5000;

/**
 * Live episodes from the backend: one full /live fetch, then the SSE stream
 * keeps the list current (opened / updated / closed / action). Falls back to
 * polling while the stream is down. Actions update the list optimistically
 * from the server's own reply.
 */
export function useEpisodes() {
  const [episodes, setEpisodes] = useState([]);
  const [counts, setCounts] = useState(null);
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState("");
  const [lastSync, setLastSync] = useState(0);
  const connectedRef = useRef(false);

  const refresh = useCallback(async () => {
    try {
      const res = await getLiveEpisodes();
      setEpisodes(res.data.open || []);
      setCounts(res.data.counts || null);
      setLastSync(Date.now());
      setError("");
    } catch (err) {
      setError(err.message || "Could not load live state");
    }
  }, []);

  // Merge one episode from a stream message into the list.
  const applyEpisode = useCallback((episode) => {
    if (!episode || !episode.episode_id) return;

    setEpisodes((current) => {
      const isLive = episode.status === "open" || episode.status === "acknowledged";
      const without = current.filter((e) => e.episode_id !== episode.episode_id);

      if (!isLive) return without;

      const next = [...without, episode];
      next.sort((a, b) => (a.started_epoch || 0) - (b.started_epoch || 0));
      return next;
    });
  }, []);

  // Initial load + stream.
  useEffect(() => {
    let source = null;
    let stopped = false;
    let retry = null;
    // First paint straight away; the stream's onopen resyncs again.
    const initial = setTimeout(refresh, 0);

    function connect() {
      if (stopped) return;

      try {
        source = new EventSource(getEpisodeStreamUrl());
      } catch {
        setConnected(false);
        return;
      }

      source.onopen = () => {
        connectedRef.current = true;
        setConnected(true);
        // Anything that happened while we were away.
        refresh();
      };

      source.addEventListener("episode", (event) => {
        try {
          const msg = JSON.parse(event.data);
          applyEpisode(msg.episode);
          setLastSync(Date.now());
        } catch {
          /* ignore malformed */
        }
      });

      source.onerror = () => {
        connectedRef.current = false;
        setConnected(false);
        if (source) {
          source.close();
          source = null;
        }
        // The browser would retry on its own for transient errors, but a
        // closed connection (nginx timeout, restart) needs an explicit reopen.
        retry = setTimeout(connect, 4000);
      };
    }

    connect();

    return () => {
      stopped = true;
      clearTimeout(initial);
      if (retry) clearTimeout(retry);
      if (source) source.close();
    };
  }, [refresh, applyEpisode]);

  // Resync loop: slow while streaming, fast as a fallback.
  useEffect(() => {
    const id = setInterval(
      () => refresh(),
      connected ? POLL_MS_STREAMING : POLL_MS_FALLBACK
    );
    return () => clearInterval(id);
  }, [connected, refresh]);

  const act = useCallback(
    async (fn, episodeId, ...args) => {
      const res = await fn(episodeId, ...args);
      applyEpisode(res.data);
      return res.data;
    },
    [applyEpisode]
  );

  const bulk = useCallback(
    async (ids, action, note = "") => {
      const res = await bulkEpisodeAction(ids, action, note);
      (res.data.updated || []).forEach(applyEpisode);
      // Ids the server no longer knows are gone from the board too.
      const missing = new Set(res.data.missing || []);
      if (missing.size) setEpisodes((current) => current.filter((e) => !missing.has(e.episode_id)));
      return res.data;
    },
    [applyEpisode]
  );

  return {
    episodes,
    counts,
    connected,
    error,
    lastSync,
    refresh,
    acknowledge: (id) => act(acknowledgeEpisode, id),
    resolve: (id, note) => act(resolveEpisode, id, note),
    falsePositive: (id) => act(markEpisodeFalsePositive, id),
    keep: (id, keep) => act(setEpisodeKeep, id, keep),
    bulk,
  };
}


/** Ticks once a second so counting timers re-render. */
export function useNow(intervalMs = 1000) {
  const [now, setNow] = useState(() => Date.now() / 1000);

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now() / 1000), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);

  return now;
}
