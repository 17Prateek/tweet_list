import { useEffect, useState } from "react";

import {
  ChevronDown,
  Edit,
  Plus,
  RefreshCcw,
  Search,
  Trash2,
  Video,
  CircleGauge,
  Power,
  CircleDot,
} from "lucide-react";

import {
  getCameraGroups,
  createCameraGroup,
  deleteCameraGroup,
  getCameras,
  createCamera,
  deleteCamera,
  updateCamera,
  getCameraIssues,
  getCameraIssue,
  getMonitoringStatus,
  setCameraMonitoring,
} from "../data/api";

import { stats } from "../data/deshboarddata.js";

function StatusBadge({ status }) {
  const normalizedStatus =
    status?.charAt(0)?.toUpperCase() + status?.slice(1)?.toLowerCase();

  const styles = {
    Online: "text-green-400",
    Offline: "text-red-400",
    Lagging: "text-orange-400",
    Connecting: "text-blue-400",
  };

  const finalStatus = normalizedStatus || "Offline";

  return (
    <span
      title={finalStatus}
      className={`whitespace-nowrap text-[8px] font-semibold ${
        styles[finalStatus] || "text-white"
      }`}
    >
      ● {finalStatus}
    </span>
  );
}

function RecordingBadge({ value }) {
  const isRecording = value === "REC" || value === true;

  return (
    <span
      title={String(value)}
      className={`whitespace-nowrap text-[8px] ${
        isRecording ? "text-green-400" : "text-white/45"
      }`}
    >
      ● {isRecording ? "REC" : "OFF"}
    </span>
  );
}

function MonitoringSwitch({ enabled, busy, onToggle }) {
  return (
    <button
      type="button"
      title={enabled ? "PPE monitoring ON - click to exclude this camera" : "PPE monitoring OFF - click to include this camera"}
      disabled={busy}
      onClick={onToggle}
      className={`relative inline-flex h-[14px] w-[26px] shrink-0 items-center rounded-full border transition-colors ${
        enabled
          ? "border-green-500/60 bg-green-600/80"
          : "border-white/25 bg-white/10"
      } ${busy ? "opacity-50" : ""}`}
    >
      <span
        className={`inline-block h-[10px] w-[10px] rounded-full bg-white transition-transform ${
          enabled ? "translate-x-[13px]" : "translate-x-[2px]"
        }`}
      />
    </button>
  );
}

function CameraThumb({ index }) {
  const gradients = [
    "from-slate-700 via-slate-900 to-black",
    "from-yellow-900 via-slate-800 to-black",
    "from-orange-900 via-slate-900 to-black",
    "from-slate-600 via-zinc-900 to-black",
  ];

  return (
    <div
      className={`h-6 w-7 shrink-0 overflow-hidden rounded bg-gradient-to-br ${
        gradients[index % gradients.length]
      }`}
    >
      <div className="h-full w-full bg-[linear-gradient(90deg,transparent_0,transparent_45%,rgba(255,255,255,.12)_46%,transparent_47%),linear-gradient(0deg,transparent_0,transparent_55%,rgba(255,180,0,.16)_56%,transparent_57%)]" />
    </div>
  );
}

function StatSparkline({ type }) {
  const isOffline = type === "Offline";

  return (
    <svg
      viewBox="0 0 90 28"
      className="absolute bottom-2 right-4 h-8 w-20"
      preserveAspectRatio="none"
    >
      <path
        d={
          isOffline
            ? "M0 24 L12 21 L24 19 L36 15 L48 17 L60 9 L72 14 L82 7 L90 11"
            : "M0 24 L12 23 L24 21 L36 22 L48 18 L60 20 L72 12 L82 15 L90 6"
        }
        fill="none"
        stroke={isOffline ? "#ef4444" : "#22c55e"}
        strokeWidth="2"
      />
    </svg>
  );
}

function StatSummaryCard({ item }) {
  const iconMap = {
    "Total Cameras": Video,
    Online: CircleGauge,
    Offline: Power,
    Recording: CircleDot,
  };

  const Icon = iconMap[item.title] || item.icon;
  const isTotalCamera = item.title === "Total Cameras";
  const showSparkline = item.title === "Online" || item.title === "Offline";

  return (
    <div className="glass-card relative flex h-[89px] min-w-0 items-center gap-2 overflow-hidden px-2.5">
      <div
        className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${item.color}`}
      >
        <Icon size={20} />
      </div>

      <div className="min-w-0 flex-1">
        <p
          title={item.title}
          className="max-w-[105px] truncate text-[12px] font-semibold text-white/80"
        >
          {item.title}
        </p>

        <h2 className="mt-1 text-[17px] font-bold leading-none">
          {item.value}
        </h2>

        <div className="mt-3 flex items-center justify-between gap-2">
          <p
            title={item.sub}
            className="min-w-0 truncate text-[9px] text-white/55"
          >
            {item.sub}
          </p>

          {isTotalCamera && (
            <button className="shrink-0 whitespace-nowrap text-[9px] text-blue-400 hover:text-blue-300">
              View all →
            </button>
          )}
        </div>
      </div>

      {showSparkline && <StatSparkline type={item.title} />}
    </div>
  );
}

export default function CameraManagementPage() {
  const [cameraGroupRows, setCameraGroupRows] = useState([]);
  const [cameraRows, setCameraRows] = useState([]);

  const [popupType, setPopupType] = useState(null);
  const [popupMessage, setPopupMessage] = useState("");

  const [newGroupName, setNewGroupName] = useState("");
  const [deleteGroupId, setDeleteGroupId] = useState(null);
  const [deleteGroupName, setDeleteGroupName] = useState("");
  const [deleteCameraId, setDeleteCameraId] = useState(null);
  const [deleteCameraName, setDeleteCameraName] = useState("");
  const [editCameraId, setEditCameraId] = useState(null);
  const [searchText, setSearchText] = useState("");
  const [groupFilter, setGroupFilter] = useState("All Groups");
  const [statusFilter, setStatusFilter] = useState("All Status");
  const [selectedCameraIds, setSelectedCameraIds] = useState([]);
  const [cameraIssueRows, setCameraIssueRows] = useState([]);
  const [selectedIssue, setSelectedIssue] = useState(null);

  const [cameraForm, setCameraForm] = useState({
    source_type: "RTSP",
    name: "",
    location: "",
    source: "",
    group_id: "",
  });

  const [editCameraForm, setEditCameraForm] = useState({
    source_type: "RTSP",
    name: "",
    location: "",
    source: "",
    group_id: "",
  });

  // Per-camera PPE monitoring (exclusion list held by the backend).
  const [excludedCameraIds, setExcludedCameraIds] = useState([]);
  const [monitoringBusyId, setMonitoringBusyId] = useState(null);

  const loadMonitoringExclusions = async () => {
    try {
      const res = await getMonitoringStatus();
      setExcludedCameraIds(
        Array.isArray(res?.data?.excluded_camera_ids)
          ? res.data.excluded_camera_ids.map(Number)
          : []
      );
    } catch (error) {
      console.error("Monitoring status error:", error);
    }
  };

  const handleToggleCameraMonitoring = async (cam) => {
    const cameraId = Number(cam.id);
    const currentlyEnabled = !excludedCameraIds.includes(cameraId);

    setMonitoringBusyId(cameraId);

    try {
      await setCameraMonitoring(cameraId, !currentlyEnabled);
    } catch (error) {
      console.error("Camera monitoring toggle error:", error);
      alert(error?.message || "Could not update camera monitoring");
    } finally {
      // Always re-read the real state rather than assuming.
      await loadMonitoringExclusions();
      setMonitoringBusyId(null);
    }
  };

  useEffect(() => {
    loadCameraGroups();
    loadCameras();
    loadCameraIssues();
    loadMonitoringExclusions();

    const issueTimer = setInterval(() => {
      loadCameraIssues();
    }, 5000);

    const monitoringTimer = setInterval(() => {
      loadMonitoringExclusions();
    }, 15000);

    return () => {
      clearInterval(issueTimer);
      clearInterval(monitoringTimer);
    };
  }, []);

  const loadCameraGroups = async () => {
    const res = await getCameraGroups();

    if (res.ok) {
      setCameraGroupRows(res.data || []);
    } else {
      setPopupMessage(res.message || "Failed to load camera groups");
      setPopupType("message");
    }
  };

  const loadCameras = async () => {
    const res = await getCameras();

    if (res.ok) {
      setCameraRows(res.data || []);
      setSelectedCameraIds([]);
    } else {
      setPopupMessage(res.message || "Failed to load cameras");
      setPopupType("message");
    }
  };

  const loadCameraIssues = async () => {
    const res = await getCameraIssues();

    if (res.ok) {
      setCameraIssueRows(res.data || []);
    }
  };

  const totalCameras = cameraRows.length;

  const onlineCameras = cameraRows.filter(
    (cam) => String(cam.status).toLowerCase() === "online"
  ).length;

  const offlineCameras = cameraRows.filter(
    (cam) => String(cam.status).toLowerCase() === "offline"
  ).length;

  const recordingCameras = cameraRows.filter(
    (cam) => cam.recording_status === "REC" || cam.is_recording === true
  ).length;

  const dynamicStats = stats.map((item) => {
    if (item.title === "Total Cameras") {
      return {
        ...item,
        value: totalCameras,
        sub: "Configured",
      };
    }

    if (item.title === "Online") {
      return {
        ...item,
        value: onlineCameras,
        sub: `${totalCameras ? Math.round((onlineCameras / totalCameras) * 100) : 0}% of total`,
      };
    }

    if (item.title === "Offline") {
      return {
        ...item,
        value: offlineCameras,
        sub: `${totalCameras ? Math.round((offlineCameras / totalCameras) * 100) : 0}% of total`,
      };
    }

    if (item.title === "Recording") {
      return {
        ...item,
        value: recordingCameras,
        sub: `${totalCameras ? Math.round((recordingCameras / totalCameras) * 100) : 0}% of total`,
      };
    }

    return item;
  });

  const handleAddGroup = async () => {
    if (!newGroupName.trim()) {
      setPopupMessage("Group name is required");
      setPopupType("message");
      return;
    }

    const res = await createCameraGroup({
      name: newGroupName.trim(),
      description: "",
    });

    if (res.ok) {
      const addedGroupName = newGroupName.trim();

      setNewGroupName("");
      setPopupMessage(`Camera group "${addedGroupName}" has been added successfully.`);
      setPopupType("success");
      loadCameraGroups();
    } else {
      setPopupMessage(res.message || "Failed to create camera group");
      setPopupType("message");
    }
  };

  const openDeleteGroupPopup = (group) => {
    setDeleteGroupId(group.id);
    setDeleteGroupName(group.name || "");
    setPopupMessage(
      `Are you sure you want to delete camera group "${group.name || "this group"}"?`
    );
    setPopupType("deleteGroup");
  };

  const handleDeleteGroup = async () => {
    const res = await deleteCameraGroup(deleteGroupId);

    if (res.ok) {
      const deletedGroupName = deleteGroupName || "Camera group";

      setDeleteGroupId(null);
      setDeleteGroupName("");
      setPopupMessage(`Camera group "${deletedGroupName}" has been deleted successfully.`);
      setPopupType("success");
      loadCameraGroups();
    } else {
      setPopupMessage(res.message || "Failed to delete camera group");
      setPopupType("message");
    }
  };

  const handleAddCamera = async () => {
    if (!cameraForm.name.trim()) {
      setPopupMessage("Camera name is required");
      setPopupType("message");
      return;
    }

    if (!cameraForm.location.trim()) {
      setPopupMessage("Camera location is required");
      setPopupType("message");
      return;
    }

    if (!cameraForm.source.trim()) {
      setPopupMessage(
        cameraForm.source_type === "RTSP"
          ? "RTSP URL is required"
          : cameraForm.source_type === "USB"
          ? "USB camera index is required"
          : "Webcam index is required"
      );
      setPopupType("message");
      return;
    }

    if (!cameraForm.group_id) {
      setPopupMessage("Camera group is required");
      setPopupType("message");
      return;
    }

    const payload = {
      camera_name: cameraForm.name.trim(),
      source_type: cameraForm.source_type.toLowerCase(),
      rtsp_url: cameraForm.source_type === "RTSP" ? cameraForm.source.trim() : null,
      webcam_index:
        cameraForm.source_type === "Webcam" ? Number(cameraForm.source) : null,
      usb_index: cameraForm.source_type === "USB" ? Number(cameraForm.source) : null,
      group_id: Number(cameraForm.group_id),
      location: cameraForm.location.trim(),
      is_recording: false,
    };
    console.log("Camera Payload:", payload);

    const res = await createCamera(payload);

    if (res.ok) {
      const addedCameraName = cameraForm.name.trim();

      setCameraForm({
        source_type: "RTSP",
        name: "",
        location: "",
        source: "",
        group_id: "",
      });

      setPopupMessage(`Camera "${addedCameraName}" has been added successfully.`);
      setPopupType("success");

      loadCameras();
    } else {
      setPopupMessage(res.message || "Failed to add camera");
      setPopupType("message");
    }
  };

  const openEditCameraPopup = (cam) => {
    const sourceType =
      cam.source_type === "webcam"
        ? "Webcam"
        : cam.source_type === "usb"
        ? "USB"
        : "RTSP";

    setEditCameraId(cam.id);

    setEditCameraForm({
      source_type: sourceType,
      name: cam.camera_name || cam.name || "",
      location: cam.location || "",
      source:
        cam.source_type === "webcam"
          ? String(cam.webcam_index ?? "")
          : cam.source_type === "usb"
          ? String(cam.usb_index ?? "")
          : cam.rtsp_url || "",
      group_id: cam.group_id ? String(cam.group_id) : "",
    });

    setPopupType("editCamera");
  };

  const handleUpdateCamera = async () => {
    if (!editCameraForm.name.trim()) {
      setPopupMessage("Camera name is required");
      setPopupType("message");
      return;
    }

    if (!editCameraForm.location.trim()) {
      setPopupMessage("Camera location is required");
      setPopupType("message");
      return;
    }

    if (!editCameraForm.source.trim()) {
      setPopupMessage(
        editCameraForm.source_type === "RTSP"
          ? "RTSP URL is required"
          : editCameraForm.source_type === "USB"
          ? "USB camera index is required"
          : "Webcam index is required"
      );
      setPopupType("message");
      return;
    }

    if (!editCameraForm.group_id) {
      setPopupMessage("Camera group is required");
      setPopupType("message");
      return;
    }

    const payload = {
      camera_name: editCameraForm.name.trim(),
      source_type: editCameraForm.source_type.toLowerCase(),
      rtsp_url: editCameraForm.source_type === "RTSP" ? editCameraForm.source.trim() : null,
      webcam_index:
        editCameraForm.source_type === "Webcam" ? Number(editCameraForm.source) : null,
      usb_index: editCameraForm.source_type === "USB" ? Number(editCameraForm.source) : null,
      group_id: Number(editCameraForm.group_id),
      location: editCameraForm.location.trim(),
      is_recording: false,
    };

    const res = await updateCamera(editCameraId, payload);

    if (res.ok) {
      const updatedCameraName = editCameraForm.name.trim();

      setEditCameraId(null);
      setEditCameraForm({
        source_type: "RTSP",
        name: "",
        location: "",
        source: "",
        group_id: "",
      });
      setPopupMessage(`Camera "${updatedCameraName}" details have been updated successfully.`);
      setPopupType("success");
      loadCameras();
    } else {
      setPopupMessage(res.message || "Failed to update camera");
      setPopupType("message");
    }
  };

  const openDeleteCameraPopup = (cam) => {
    const cameraName = cam.camera_name || cam.name || "this camera";

    setDeleteCameraId(cam.id);
    setDeleteCameraName(cameraName);
    setPopupMessage(`Are you sure you want to delete camera "${cameraName}"?`);
    setPopupType("deleteCamera");
  };

  const handleDeleteCamera = async () => {
    const res = await deleteCamera(deleteCameraId);

    if (res.ok) {
      const deletedCameraName = deleteCameraName || "Camera";

      setDeleteCameraId(null);
      setDeleteCameraName("");
      setSelectedCameraIds((prev) => prev.filter((id) => id !== deleteCameraId));
      setPopupMessage(`Camera "${deletedCameraName}" has been deleted successfully.`);
      setPopupType("success");
      loadCameras();
    } else {
      setPopupMessage(res.message || "Failed to delete camera");
      setPopupType("message");
    }
  };

  const openBulkDeletePopup = () => {
    if (selectedCameraIds.length === 0) {
      setPopupMessage("Please select at least one camera to delete");
      setPopupType("message");
      return;
    }

    setPopupMessage(
      `Are you sure you want to delete ${selectedCameraIds.length} selected camera${
        selectedCameraIds.length > 1 ? "s" : ""
      }?`
    );
    setPopupType("bulkDeleteCamera");
  };

  const handleBulkDeleteCameras = async () => {
    let failedCount = 0;

    for (const cameraId of selectedCameraIds) {
      const res = await deleteCamera(cameraId);

      if (!res.ok) {
        failedCount += 1;
      }
    }

    const deletedCount = selectedCameraIds.length - failedCount;

    setSelectedCameraIds([]);
    loadCameras();

    if (failedCount > 0) {
      setPopupMessage(`${failedCount} camera delete failed`);
      setPopupType("message");
    } else {
      setPopupMessage(
        `${deletedCount} selected camera${deletedCount > 1 ? "s have" : " has"} been deleted successfully.`
      );
      setPopupType("success");
    }
  };

  const closePopup = () => {
    setPopupType(null);
    setPopupMessage("");
    setDeleteGroupId(null);
    setDeleteGroupName("");
    setDeleteCameraId(null);
    setDeleteCameraName("");
    setSelectedIssue(null);
    setEditCameraId(null);
    setEditCameraForm({
      source_type: "RTSP",
      name: "",
      location: "",
      source: "",
      group_id: "",
    });
  };

  const getGroupName = (cam) => {
    return (
      cam.group ||
      cam.group_name ||
      cam.camera_group?.name ||
      cameraGroupRows.find((group) => Number(group.id) === Number(cam.group_id))
        ?.name ||
      "-"
    );
  };

  const filteredCameraRows = cameraRows.filter((cam) => {
    const cameraName = cam.camera_name || cam.name || "";
    const groupName = getGroupName(cam);
    const location = cam.location || "";
    const sourceType = cam.source_type || "";
    const source =
      sourceType === "webcam"
        ? `Webcam ${cam.webcam_index ?? ""}`
        : sourceType === "usb"
        ? `USB ${cam.usb_index ?? ""}`
        : cam.rtsp_url || "";
    const status = cam.status || "Offline";
    const searchValue = searchText.trim().toLowerCase();

    const matchesSearch =
      !searchValue ||
      cameraName.toLowerCase().includes(searchValue) ||
      groupName.toLowerCase().includes(searchValue) ||
      location.toLowerCase().includes(searchValue) ||
      sourceType.toLowerCase().includes(searchValue) ||
      source.toLowerCase().includes(searchValue);

    const matchesGroup = groupFilter === "All Groups" || groupName === groupFilter;
    const matchesStatus =
      statusFilter === "All Status" ||
      status.toLowerCase() === statusFilter.toLowerCase();

    return matchesSearch && matchesGroup && matchesStatus;
  });

  const filteredCameraIds = filteredCameraRows
    .map((cam) => cam.id)
    .filter((id) => id !== undefined && id !== null);

  const allFilteredSelected =
    filteredCameraIds.length > 0 &&
    filteredCameraIds.every((id) => selectedCameraIds.includes(id));

  const toggleSelectAllCameras = () => {
    if (allFilteredSelected) {
      setSelectedCameraIds((prev) =>
        prev.filter((id) => !filteredCameraIds.includes(id))
      );
      return;
    }

    setSelectedCameraIds((prev) => [
      ...prev,
      ...filteredCameraIds.filter((id) => !prev.includes(id)),
    ]);
  };

  const toggleSelectCamera = (cameraId) => {
    setSelectedCameraIds((prev) =>
      prev.includes(cameraId)
        ? prev.filter((id) => id !== cameraId)
        : [...prev, cameraId]
    );
  };

  const getIssueTypeStyle = (severity) => {
    const normalizedSeverity = String(severity || "info").toLowerCase();

    if (normalizedSeverity === "critical") {
      return "bg-red-500";
    }

    if (normalizedSeverity === "warning") {
      return "bg-orange-500";
    }

    return "bg-blue-600";
  };

  const openIssueDetailsPopup = async (issue) => {
    const res = await getCameraIssue(issue.camera_id);

    if (res.ok) {
      setSelectedIssue(res.data);
    } else {
      setSelectedIssue(issue);
    }

    setPopupType("issueDetails");
  };

  return (
    <div className="w-full min-w-0 overflow-x-hidden pb-1 text-white">
      <div className="grid w-full min-w-0 grid-cols-1 gap-2 lg:grid-cols-[minmax(0,1fr)_260px]">
        <main className="min-w-0 space-y-2 overflow-x-hidden">
          <div className="grid min-w-0 grid-cols-4 gap-2">
            {dynamicStats.map((item) => (
              <StatSummaryCard key={item.title} item={item} />
            ))}
          </div>

          <section className="glass-card p-2.5">
            <h3 className="mb-0.5 text-[12px] font-semibold">Add New Camera</h3>

            <div className="space-y-1">
              <div className="grid min-w-0 grid-cols-4 gap-1 xl:grid-cols-[240px_minmax(130px,1fr)_minmax(120px,1fr)_minmax(100px,0.55fr)]">
                <div className="min-w-0">
                  <label className="mb-1 block text-[11px] text-white/65">
                    Source Type
                  </label>

                  <div className="grid grid-cols-3 gap-1">
                    {["RTSP", "USB", "Webcam"].map((type) => (
                      <button
                        key={type}
                        type="button"
                        onClick={() =>
                          setCameraForm({
                            ...cameraForm,
                            source_type: type,
                            source: "",
                          })
                        }
                        className={`flex h-8 min-w-0 items-center justify-center gap-1 rounded-md border px-2 text-[8px] font-semibold ${
                          cameraForm.source_type === type
                            ? "border-blue-600 bg-[#09254a] text-white"
                            : "border-[#123250] bg-[#07182a] text-white/80"
                        }`}
                      >
                        <span className="grid h-3 w-3 shrink-0 place-items-center rounded-full border border-blue-400">
                          {cameraForm.source_type === type && (
                            <span className="h-1.5 w-1.5 rounded-full bg-blue-400" />
                          )}
                        </span>
                        <span>{type}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="min-w-0">
                  <label className="mb-1 block text-[11px] text-white/65">
                    Camera Name
                  </label>

                  <input
                    value={cameraForm.name}
                    onChange={(e) =>
                      setCameraForm({ ...cameraForm, name: e.target.value })
                    }
                    className="h-8 w-full min-w-0 rounded-md border border-[#123250] bg-[#020817] px-2 text-[10px] outline-none placeholder:text-white/35 focus:border-blue-500"
                    placeholder="Enter camera name"
                  />
                </div>

                <div className="min-w-0">
                  <label className="mb-1 block text-[11px] text-white/65">
                    Camera Location
                  </label>

                  <input
                    value={cameraForm.location}
                    onChange={(e) =>
                      setCameraForm({ ...cameraForm, location: e.target.value })
                    }
                    className="h-8 w-full min-w-0 rounded-md border border-[#123250] bg-[#020817] px-2 text-[10px] outline-none placeholder:text-white/35 focus:border-blue-500"
                    placeholder="Enter camera location"
                  />
                </div>

                <div className="min-w-0">
                  <label className="mb-1 block text-[11px] text-white/65">
                    Group
                  </label>

                  <select
                    value={cameraForm.group_id}
                    onChange={(e) =>
                      setCameraForm({
                        ...cameraForm,
                        group_id: e.target.value,
                      })
                    }
                    className="h-8 w-full min-w-0 rounded-md border border-[#123250] bg-[#020817] px-2 text-[10px] outline-none focus:border-blue-500"
                  >
                    <option value="">Select group</option>
                    {cameraGroupRows.map((group) => (
                      <option key={group.id} value={group.id}>
                        {group.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid min-w-0 grid-cols-[minmax(0,1fr)_126px] items-end gap-2">
                <div className="min-w-0">
                  <label className="mb-1 block text-[11px] text-white/65">
                    {cameraForm.source_type === "RTSP"
                      ? "RTSP Stream URL"
                      : cameraForm.source_type === "USB"
                      ? "USB Camera Index"
                      : "Webcam Index"}
                  </label>

                  <input
                    value={cameraForm.source}
                    onChange={(e) =>
                      setCameraForm({ ...cameraForm, source: e.target.value })
                    }
                    className="h-8 w-full min-w-0 rounded-md border border-[#123250] bg-[#020817] px-2 text-[10px] outline-none placeholder:text-white/35 focus:border-blue-500"
                    placeholder={
                      cameraForm.source_type === "RTSP"
                        ? "rtsp://user:pass@ip/stream"
                        : cameraForm.source_type === "USB"
                        ? "1"
                        : "0"
                    }
                  />
                </div>

                <button
                  onClick={handleAddCamera}
                  className="flex h-8 w-full items-center justify-center gap-1.5 whitespace-nowrap rounded-md bg-blue-600 px-4 text-[10px] font-semibold hover:bg-blue-700"
                >
                  <Plus size={13} />
                  Add Camera
                </button>
              </div>
              
            </div>
          </section>

          <section className="glass-card flex h-[332px] min-w-0 flex-col overflow-hidden p-0">
            <div className="shrink-0 border-b border-[#123250] p-2">
              <div className="flex min-w-0 items-center justify-between gap-2">
                <h3 className="shrink-0 text-[12px] font-semibold">
                  Camera List ({cameraRows.length})
                </h3>

                <div className="flex min-w-0 shrink items-center justify-end gap-1.5">
                  <div className="relative w-[145px] shrink">
                    <Search
                      size={12}
                      className="absolute left-2 top-1/2 -translate-y-1/2 text-white/45"
                    />

                    <input
                      value={searchText}
                      onChange={(e) => setSearchText(e.target.value)}
                      className="h-7 w-full rounded-md border border-[#123250] bg-[#020817] pl-7 pr-2 text-[10px] outline-none placeholder:text-white/35 focus:border-blue-500"
                      placeholder="Search cameras..."
                    />
                  </div>

                  <select
                    value={groupFilter}
                    onChange={(e) => setGroupFilter(e.target.value)}
                    className="h-7 w-[88px] shrink-0 rounded-md border border-[#123250] bg-[#020817] px-1.5 text-[9px] outline-none focus:border-blue-500"
                  >
                    <option>All Groups</option>
                    {cameraGroupRows.map((group) => (
                      <option key={group.id}>{group.name}</option>
                    ))}
                  </select>

                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="h-7 w-[82px] shrink-0 rounded-md border border-[#123250] bg-[#020817] px-1.5 text-[9px] outline-none focus:border-blue-500"
                  >
                    <option>All Status</option>
                    <option>Online</option>
                    <option>Offline</option>
                    <option>Connecting</option>
                  </select>

                  <button
                    onClick={loadCameras}
                    className="grid h-7 w-7 shrink-0 place-items-center rounded-md border border-[#123250] bg-[#07182a] hover:bg-[#0b2238]"
                  >
                    <RefreshCcw size={12} />
                  </button>

                  <button
                    onClick={openBulkDeletePopup}
                    className="flex h-7 w-[88px] shrink-0 items-center justify-center gap-1 rounded-md border border-blue-600 bg-[#09254a] px-1.5 text-[9px] text-blue-300 hover:bg-[#0b2f60]"
                  >
                    <span className="truncate">
                      {selectedCameraIds.length > 0
                        ? `Delete (${selectedCameraIds.length})`
                        : "Bulk Actions"}
                    </span>
                    <ChevronDown size={11} className="shrink-0" />
                  </button>
                </div>
              </div>
            </div>

            <div className="min-h-0 flex-1 overflow-y-auto overflow-x-hidden">
              <table className="w-full table-fixed border-collapse text-left text-[9px]">
                <thead className="sticky top-0 z-10 bg-[#082136] text-white/75">
                  <tr className="h-[25px]">
                    <th className="w-[4%] px-2 py-1">
                      <input
                        type="checkbox"
                        checked={allFilteredSelected}
                        onChange={toggleSelectAllCameras}
                        className="h-3 w-3 appearance-none rounded-[2px] border border-white/50 bg-transparent checked:border-blue-500 checked:bg-blue-600"
                      />
                    </th>

                    <th className="w-[18%] px-1.5 py-1">Camera Name</th>
                    <th className="w-[11%] px-1.5 py-1">Group</th>
                    <th className="w-[11%] px-1.5 py-1">Location</th>
                    <th className="w-[14%] px-1.5 py-1">Source</th>
                    <th className="w-[9%] px-1.5 py-1">Status</th>
                    <th className="w-[8%] px-1.5 py-1">Recording</th>
                    <th className="w-[9%] px-1.5 py-1">PPE Monitoring</th>
                    <th className="w-[9%] px-1.5 py-1">Last Seen</th>
                    <th className="w-[7%] px-1.5 py-1 text-center">
                      Actions
                    </th>
                  </tr>
                </thead>

                <tbody>
                  {filteredCameraRows.map((cam, index) => {
                    const cameraName = cam.camera_name || cam.name || "-";
                    const group = getGroupName(cam);
                    const location = cam.location || "-";
                    const sourceType = cam.source_type || "rtsp";
                    const source =
                      sourceType === "webcam"
                        ? `Webcam ${cam.webcam_index ?? "-"}`
                        : sourceType === "usb"
                        ? `USB ${cam.usb_index ?? "-"}`
                        : cam.rtsp_url || "-";
                    const status = cam.status || "Offline";
                    const recording =
                      cam.recording_status || cam.is_recording || false;
                    const lastSeen = cam.last_seen || "-";

                    return (
                      <tr
                        key={cam.id || `${cameraName}-${index}`}
                        className="h-[32px] border-t border-[#123250] bg-[#051828]/80 hover:bg-[#0b2238]"
                      >
                        <td className="px-2 py-0.5">
                          <input
                            type="checkbox"
                            checked={selectedCameraIds.includes(cam.id)}
                            onChange={() => toggleSelectCamera(cam.id)}
                            className="h-3 w-3 appearance-none rounded-[2px] border border-white/50 bg-transparent checked:border-blue-500 checked:bg-blue-600"
                          />
                        </td>

                        <td className="px-0.5 py-0.5">
                          <div className="flex min-w-0 items-center gap-1.5">
                            <CameraThumb index={index} />

                            <span
                              title={cameraName}
                              className="min-w-0 truncate text-[9px] font-semibold"
                            >
                              {cameraName}
                            </span>
                          </div>
                        </td>

                        <td className="px-1.5 py-0.5">
                          <span title={group} className="block truncate text-[10px]">
                            {group}
                          </span>
                        </td>

                        <td className="px-1.5 py-0.5">
                          <span title={location} className="block truncate text-[10px]">
                            {location}
                          </span>
                        </td>

                        <td className="px-1.5 py-0.5">
                          <div
                            title={sourceType}
                            className="truncate font-medium leading-tight"
                          >
                            {sourceType.toUpperCase()}
                          </div>

                          <div
                            title={source}
                            className="truncate text-[7px] leading-tight text-white/45"
                          >
                            {source}
                          </div>
                        </td>

                        <td className="px-1.5 py-0.5">
                          <StatusBadge status={status} />
                        </td>

                        <td className="px-1.5 py-0.5">
                          <RecordingBadge value={recording} />
                        </td>

                        <td className="px-1.5 py-0.5">
                          <div className="flex items-center gap-1">
                            <MonitoringSwitch
                              enabled={!excludedCameraIds.includes(Number(cam.id))}
                              busy={monitoringBusyId === Number(cam.id)}
                              onToggle={() => handleToggleCameraMonitoring(cam)}
                            />
                            <span className="text-[8px] text-white/60">
                              {excludedCameraIds.includes(Number(cam.id)) ? "OFF" : "ON"}
                            </span>
                          </div>
                        </td>

                        <td className="px-1.5 py-0.5">
                          <span title={lastSeen} className="block truncate">
                            {lastSeen}
                          </span>
                        </td>

                        <td className="px-1.5 py-0.5">
                          <div className="flex justify-center gap-1">
                            <button
                              title="Edit"
                              onClick={() => openEditCameraPopup(cam)}
                              className="grid h-[18px] w-[18px] place-items-center rounded border border-[#123250] bg-[#07182a] text-white/75 hover:bg-[#123a5a] hover:text-white"
                            >
                              <Edit size={10} />
                            </button>

                            <button
                              title="Delete"
                              onClick={() => openDeleteCameraPopup(cam)}
                              className="grid h-[18px] w-[18px] place-items-center rounded border border-[#123250] bg-[#07182a] text-white/75 hover:bg-red-900/40 hover:text-red-300"
                            >
                              <Trash2 size={10} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}

                  {filteredCameraRows.length === 0 && (
                    <tr>
                      <td
                        colSpan="10"
                        className="h-24 text-center text-[11px] text-white/50"
                      >
                        No cameras found
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="shrink-0 border-t border-[#123250] px-3 py-1.5 text-[10px] text-white/65">
              <div className="flex items-center justify-between gap-2">
                <span>
                  Showing 1 to {Math.min(filteredCameraRows.length, 8)} of{" "}
                  {filteredCameraRows.length} cameras
                </span>

                <div className="flex items-center gap-1.5">
                  <button className="rounded-md bg-[#07182a] px-2 py-1 text-white/50 hover:bg-[#0b2238]">
                    ‹
                  </button>

                  <button className="rounded-md bg-blue-600 px-2 py-1 text-white">
                    1
                  </button>

                  <button className="rounded-md bg-[#07182a] px-2 py-1 hover:bg-[#0b2238]">
                    ›
                  </button>

                  <select className="ml-2 h-7 rounded-md border border-[#123250] bg-[#020817] px-2 text-[10px] outline-none">
                    <option>10 / page</option>
                    <option>25 / page</option>
                    <option>50 / page</option>
                  </select>
                </div>
              </div>
            </div>
          </section>
        </main>

        <aside className="w-[260px] min-w-0 space-y-2">
          <section className="glass-card p-3">
            <h3 className="mb-2 text-[12px] font-semibold">
              Monitoring Guidance
            </h3>

            {[
              "Use RTSP for IP camera, Webcam for laptop camera, or USB for external USB camera.",
              "Start Recognition opens PPE detection on the current source.",
              "Stop safely ends the running stream or enrollment session.",
              "Email alerts are managed from the Email Settings page.",
            ].map((text) => (
              <p
                key={text}
                className="mb-1.5 flex gap-2 text-[9px] leading-4 text-white/70 last:mb-0"
              >
                <span className="mt-1 text-blue-400">●</span>
                <span>{text}</span>
              </p>
            ))}
          </section>

          <section className="glass-card h-[188px] p-3">
            <div className="mb-2 flex items-center justify-between gap-2">
              <h3 className="text-[12px] font-semibold">Camera Issues</h3>

              <button
                onClick={loadCameraIssues}
                className="shrink-0 text-[10px] text-blue-400 hover:text-blue-300"
              >
                View All →
              </button>
            </div>

            <div className="max-h-[144px] overflow-y-auto pr-1">
              {cameraIssueRows.map((issue) => (
                <button
                  key={issue.id || issue.camera_id}
                  type="button"
                  onClick={() => openIssueDetailsPopup(issue)}
                  className="flex h-[36px] w-full items-center gap-2 border-b border-[#123250] text-left last:border-0 hover:bg-[#0b2238]"
                >
                  <div
                    className={`grid h-6 w-6 shrink-0 place-items-center rounded-full ${getIssueTypeStyle(
                      issue.severity
                    )}`}
                  >
                    <Power size={12} />
                  </div>

                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[10px] font-semibold">
                      {issue.camera_name || "Camera"}
                    </p>

                    <p className="truncate text-[8px] text-white/55">
                      {issue.title || issue.description || "Camera issue detected"}
                    </p>
                  </div>

                  <span className="shrink-0 text-[8px] text-white/45">
                    {issue.updated_at || "Now"}
                  </span>
                </button>
              ))}

              {cameraIssueRows.length === 0 && (
                <div className="flex h-[52px] items-center justify-center text-[10px] text-white/50">
                  No active camera issues
                </div>
              )}
            </div>
          </section>

          <section className="glass-card p-3">
            <div className="mb-2 flex items-center justify-between gap-2">
              <h3 className="text-[12px] font-semibold">Camera Groups</h3>

              <button
                onClick={() => setPopupType("add")}
                className="shrink-0 rounded-md border border-blue-600 px-2 py-1 text-[10px] text-blue-400 hover:bg-[#09254a]"
              >
                + Add Group
              </button>
            </div>

            <div className="h-[169px] overflow-y-auto pr-1">
              <table className="w-full table-fixed border-collapse text-left text-[8.5px]">
                <thead className="sticky top-0 z-10 bg-[#082136] text-white/75">
                  <tr className="h-[24px]">
                    <th className="w-[78%] px-2 py-1">Group Name</th>
                    <th className="w-[22%] px-2 py-1 text-center">Action</th>
                  </tr>
                </thead>

                <tbody>
                  {cameraGroupRows.map((group) => (
                    <tr
                      key={group.id}
                      className="h-[30px] border-t border-[#123250] bg-[#051828]/80 hover:bg-[#0b2238]"
                    >
                      <td className="px-2 py-1">
                        <span title={group.name} className="block truncate font-semibold">
                          {group.name}
                        </span>
                      </td>

                      <td className="px-2 py-1">
                        <div className="flex justify-center">
                          <button
                            title="Delete"
                            onClick={() => openDeleteGroupPopup(group)}
                            className="grid h-[18px] w-[18px] place-items-center rounded border border-[#123250] bg-[#07182a] text-white/75 hover:bg-red-900/40 hover:text-red-300"
                          >
                            <Trash2 size={9} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}

                  {cameraGroupRows.length === 0 && (
                    <tr>
                      <td colSpan="2" className="h-16 text-center text-[10px] text-white/50">
                        No groups found
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </section>
        </aside>
      </div>

      {popupType && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/45">
          <div className="w-[470px] overflow-hidden rounded-2xl bg-[#3b82f6] shadow-2xl">
            <div className="bg-[#14336d] px-6 py-5 text-center">
              <h2 className="text-[17px] font-bold text-white">
                Paperless Management System States
              </h2>
            </div>

            <div className="px-10 py-8 text-center">
              {popupType === "add" && (
                <>
                  <p className="mb-5 text-[13px] font-semibold text-white">
                    Enter new camera group name
                  </p>

                  <input
                    value={newGroupName}
                    onChange={(e) => setNewGroupName(e.target.value)}
                    className="mb-5 h-10 w-full rounded-md border border-white/20 bg-[#0f2d64] px-3 text-[13px] text-white outline-none placeholder:text-white/45 focus:border-white"
                    placeholder="Enter group name"
                  />

                  <div className="flex gap-3">
                    <button
                      onClick={handleAddGroup}
                      className="h-11 flex-1 rounded-lg bg-[#14336d] text-[14px] font-bold text-white hover:bg-[#102b5c]"
                    >
                      Add
                    </button>

                    <button
                      onClick={closePopup}
                      className="h-11 flex-1 rounded-lg bg-[#14336d] text-[14px] font-bold text-white hover:bg-[#102b5c]"
                    >
                      Cancel
                    </button>
                  </div>
                </>
              )}

              {popupType === "deleteGroup" && (
                <>
                  <p className="mb-8 text-[13px] font-semibold text-white">
                    {popupMessage}
                  </p>

                  <div className="flex gap-3">
                    <button
                      onClick={handleDeleteGroup}
                      className="h-11 flex-1 rounded-lg bg-[#14336d] text-[14px] font-bold text-white hover:bg-[#102b5c]"
                    >
                      Confirm Delete
                    </button>

                    <button
                      onClick={closePopup}
                      className="h-11 flex-1 rounded-lg bg-[#14336d] text-[14px] font-bold text-white hover:bg-[#102b5c]"
                    >
                      Cancel
                    </button>
                  </div>
                </>
              )}

              {popupType === "editCamera" && (
                <>
                  <p className="mb-5 text-[13px] font-semibold text-white">
                    Edit camera details
                  </p>

                  <select
                    value={editCameraForm.source_type}
                    onChange={(e) =>
                      setEditCameraForm({
                        ...editCameraForm,
                        source_type: e.target.value,
                        source: "",
                      })
                    }
                    className="mb-3 h-10 w-full rounded-md border border-white/20 bg-[#0f2d64] px-3 text-[13px] text-white outline-none focus:border-white"
                  >
                    <option value="RTSP">RTSP</option>
                    <option value="USB">USB</option>
                    <option value="Webcam">Webcam</option>
                  </select>

                  <input
                    value={editCameraForm.name}
                    onChange={(e) =>
                      setEditCameraForm({ ...editCameraForm, name: e.target.value })
                    }
                    className="mb-3 h-10 w-full rounded-md border border-white/20 bg-[#0f2d64] px-3 text-[13px] text-white outline-none placeholder:text-white/45 focus:border-white"
                    placeholder="Camera name"
                  />

                  <input
                    value={editCameraForm.location}
                    onChange={(e) =>
                      setEditCameraForm({
                        ...editCameraForm,
                        location: e.target.value,
                      })
                    }
                    className="mb-3 h-10 w-full rounded-md border border-white/20 bg-[#0f2d64] px-3 text-[13px] text-white outline-none placeholder:text-white/45 focus:border-white"
                    placeholder="Camera location"
                  />

                  <select
                    value={editCameraForm.group_id}
                    onChange={(e) =>
                      setEditCameraForm({
                        ...editCameraForm,
                        group_id: e.target.value,
                      })
                    }
                    className="mb-3 h-10 w-full rounded-md border border-white/20 bg-[#0f2d64] px-3 text-[13px] text-white outline-none focus:border-white"
                  >
                    <option value="">Select group</option>
                    {cameraGroupRows.map((group) => (
                      <option key={group.id} value={group.id}>
                        {group.name}
                      </option>
                    ))}
                  </select>

                  <input
                    value={editCameraForm.source}
                    onChange={(e) =>
                      setEditCameraForm({ ...editCameraForm, source: e.target.value })
                    }
                    className="mb-5 h-10 w-full rounded-md border border-white/20 bg-[#0f2d64] px-3 text-[13px] text-white outline-none placeholder:text-white/45 focus:border-white"
                    placeholder={
                      editCameraForm.source_type === "RTSP"
                        ? "rtsp://user:pass@ip/stream"
                        : editCameraForm.source_type === "USB"
                        ? "USB camera index"
                        : "Webcam index"
                    }
                  />

                  <div className="flex gap-3">
                    <button
                      onClick={handleUpdateCamera}
                      className="h-11 flex-1 rounded-lg bg-[#14336d] text-[14px] font-bold text-white hover:bg-[#102b5c]"
                    >
                      Update
                    </button>

                    <button
                      onClick={closePopup}
                      className="h-11 flex-1 rounded-lg bg-[#14336d] text-[14px] font-bold text-white hover:bg-[#102b5c]"
                    >
                      Cancel
                    </button>
                  </div>
                </>
              )}

              {popupType === "deleteCamera" && (
                <>
                  <p className="mb-8 text-[13px] font-semibold text-white">
                    {popupMessage}
                  </p>

                  <div className="flex gap-3">
                    <button
                      onClick={handleDeleteCamera}
                      className="h-11 flex-1 rounded-lg bg-[#14336d] text-[14px] font-bold text-white hover:bg-[#102b5c]"
                    >
                      Confirm Delete
                    </button>

                    <button
                      onClick={closePopup}
                      className="h-11 flex-1 rounded-lg bg-[#14336d] text-[14px] font-bold text-white hover:bg-[#102b5c]"
                    >
                      Cancel
                    </button>
                  </div>
                </>
              )}

              {popupType === "bulkDeleteCamera" && (
                <>
                  <p className="mb-8 text-[13px] font-semibold text-white">
                    {popupMessage}
                  </p>

                  <div className="flex gap-3">
                    <button
                      onClick={handleBulkDeleteCameras}
                      className="h-11 flex-1 rounded-lg bg-[#14336d] text-[14px] font-bold text-white hover:bg-[#102b5c]"
                    >
                      Confirm Delete
                    </button>

                    <button
                      onClick={closePopup}
                      className="h-11 flex-1 rounded-lg bg-[#14336d] text-[14px] font-bold text-white hover:bg-[#102b5c]"
                    >
                      Cancel
                    </button>
                  </div>
                </>
              )}

              {popupType === "issueDetails" && selectedIssue && (
                <>
                  <p className="mb-4 text-[13px] font-semibold text-white">
                    Camera Issue Details
                  </p>

                  <div className="mb-5 max-h-[330px] overflow-y-auto rounded-lg bg-[#0f2d64] p-4 text-left text-[11px] text-white">
                    <div className="mb-3 flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="truncate text-[13px] font-bold">
                          {selectedIssue.camera_name || "Camera"}
                        </p>
                        <p className="truncate text-[10px] text-white/60">
                          {selectedIssue.group || "-"} • {selectedIssue.location || "-"}
                        </p>
                      </div>

                      <span
                        className={`shrink-0 rounded-full px-2 py-1 text-[9px] font-bold uppercase ${
                          String(selectedIssue.severity).toLowerCase() === "critical"
                            ? "bg-red-500"
                            : String(selectedIssue.severity).toLowerCase() === "warning"
                            ? "bg-orange-500"
                            : "bg-blue-600"
                        }`}
                      >
                        {selectedIssue.severity || "info"}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                      <div>
                        <p className="text-white/45">Issue</p>
                        <p className="font-semibold">{selectedIssue.title || "-"}</p>
                      </div>

                      <div>
                        <p className="text-white/45">Status</p>
                        <p className="font-semibold">{selectedIssue.status || "-"}</p>
                      </div>

                      <div>
                        <p className="text-white/45">Source</p>
                        <p className="font-semibold uppercase">
                          {selectedIssue.source_type || "-"}
                        </p>
                      </div>

                      <div>
                        <p className="text-white/45">Recording</p>
                        <p className="font-semibold">
                          {selectedIssue.recording_status || "-"}
                        </p>
                      </div>

                      <div>
                        <p className="text-white/45">Last Seen</p>
                        <p className="font-semibold">{selectedIssue.last_seen || "-"}</p>
                      </div>

                      <div>
                        <p className="text-white/45">Updated</p>
                        <p className="font-semibold">{selectedIssue.updated_at || "-"}</p>
                      </div>
                    </div>

                    <div className="mt-4">
                      <p className="text-white/45">Description</p>
                      <p className="mt-1 leading-4 text-white/85">
                        {selectedIssue.description || "No description available."}
                      </p>
                    </div>

                    <div className="mt-4">
                      <p className="text-white/45">Recommended Action</p>
                      <p className="mt-1 leading-4 text-white/85">
                        {selectedIssue.recommendation || "Check camera and backend logs."}
                      </p>
                    </div>

                    {selectedIssue.details && Object.keys(selectedIssue.details).length > 0 && (
                      <div className="mt-4">
                        <p className="text-white/45">Extra Details</p>
                        <div className="mt-1 space-y-1">
                          {Object.entries(selectedIssue.details).map(([key, value]) => (
                            <p key={key} className="break-words text-white/85">
                              <span className="font-semibold">{key}: </span>
                              {String(value)}
                            </p>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <button
                    onClick={closePopup}
                    className="h-11 w-full rounded-lg bg-[#14336d] text-[14px] font-bold text-white hover:bg-[#102b5c]"
                  >
                    Close
                  </button>
                </>
              )}

              {(popupType === "success" || popupType === "message") && (
                <>
                  <p className="mb-8 text-[13px] font-semibold text-white">
                    {popupMessage}
                  </p>

                  <button
                    onClick={closePopup}
                    className="h-11 w-full rounded-lg bg-[#14336d] text-[14px] font-bold text-white hover:bg-[#102b5c]"
                  >
                    OK
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}