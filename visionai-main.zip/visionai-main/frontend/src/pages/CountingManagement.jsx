import { useEffect, useMemo, useRef, useState } from "react";
import { useOutletContext } from "react-router-dom";
import * as XLSX from "xlsx";

import {
  AlertTriangle,
  Box,
  Boxes,
  Camera,
  CheckCircle2,
  Expand,
  FileSpreadsheet,
  Loader2,
  Mail,
  Package,
  Square,
  Video,
} from "lucide-react";

import {
  getCameras,
  getCameraStreamUrl,
  getCountingStreamUrl,
  getCountingSettings,
  updateCountingSettings,
  getCameraCountingLiveCount,
  getCountingSummaries,
  startCountingMonitoring,
  stopCountingMonitoring,
  getCountingMonitoringStatus,
  getCountingEvidenceUrl,
  sendCountingTestEmail,
} from "../data/api";

/*
|--------------------------------------------------------------------------
| CountingManagement.jsx
|--------------------------------------------------------------------------
|
| Purpose:
|   Count how many bags and boxes are physically carried by labor/workers
|   from one location/zone to another location/zone.
|
| IMPORTANT:
|   Sidebar and Header are NOT rendered here.
|   Dashboard.jsx already renders them and this component is shown in <Outlet />.
|
| Header layout buttons:
|   1 / 2 / 4 / 8
| are controlled by countingLayout / setCountingLayout from Dashboard.jsx via useOutletContext().
|
| Current camera stream:
|   Monitoring OFF: getCameraStreamUrl(cameraId)
|   Monitoring ON:  getCountingStreamUrl(cameraId)
|
| Counting Management backend integration:
|   1. Camera video switches to the annotated counting stream while monitoring.
|   2. Live bag/box counts come from /api/counting/live/{camera_id}.
|   3. Completed interval events come from /api/counting/summaries.
|   4. Save interval comes from /api/counting/settings.
|
*/


/* -------------------------------------------------------------------------- */
/*                                CONSTANTS                                   */
/* -------------------------------------------------------------------------- */

const MAX_SLOTS = 8;
const COUNTING_SELECTED_SLOTS_KEY = "visionai.counting.selectedSlots.v1";

function loadSavedCountingSlots() {
  try {
    const raw = window.localStorage.getItem(COUNTING_SELECTED_SLOTS_KEY);
    if (!raw) return Array(MAX_SLOTS).fill("");

    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return Array(MAX_SLOTS).fill("");

    return Array.from({ length: MAX_SLOTS }, (_, index) => {
      const value = parsed[index];
      if (value === null || value === undefined || value === "") return "";
      return String(value);
    });
  } catch (error) {
    console.warn("Could not restore Counting Management camera selection:", error);
    return Array(MAX_SLOTS).fill("");
  }
}

function saveCountingSlots(slots) {
  try {
    window.localStorage.setItem(
      COUNTING_SELECTED_SLOTS_KEY,
      JSON.stringify(slots),
    );
  } catch (error) {
    console.warn("Could not save Counting Management camera selection:", error);
  }
}

const EMPTY_IMAGE_SRC =
  "data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=";

const defaultSlots = Array.from({ length: MAX_SLOTS }, (_, index) => ({
  id: index + 1,
  name: `Camera Slot ${index + 1}`,
}));


/* -------------------------------------------------------------------------- */
/*                               DEMO ALERTS                                  */
/* -------------------------------------------------------------------------- */

const carryAlerts = [
  {
    type: "critical",
    title: "Count Mismatch Detected",
    camera: "Camera 2 - Loading Bay 1",
    date: "16 Sep 2026",
    time: "05:10:21 PM",
  },
  {
    type: "critical",
    title: "Bag Drop Detected",
    camera: "Camera 4 - Storage Area",
    date: "16 Sep 2026",
    time: "05:09:45 PM",
  },
  {
    type: "warning",
    title: "Unknown Object Carried",
    camera: "Camera 1 - Warehouse Gate",
    date: "16 Sep 2026",
    time: "05:08:33 PM",
  },
  {
    type: "warning",
    title: "Transfer Route Changed",
    camera: "Camera 3 - Truck Area",
    date: "16 Sep 2026",
    time: "05:07:18 PM",
  },
  {
    type: "info",
    title: "Worker Carry Started",
    camera: "Camera 2 - Loading Bay 1",
    date: "16 Sep 2026",
    time: "05:06:10 PM",
  },
];


/* -------------------------------------------------------------------------- */
/*                              TABLE COLUMNS                                 */
/* -------------------------------------------------------------------------- */

const transferColumns = [
  { label: "Event ID", width: "w-[13%]" },
  { label: "Start Time", width: "w-[13%]" },
  { label: "End Time", width: "w-[13%]" },
  { label: "Camera", width: "w-[12%]" },
  { label: "Location", width: "w-[11%]" },
  { label: "Bags", width: "w-[7%]" },
  { label: "Boxes", width: "w-[7%]" },
  { label: "Total", width: "w-[7%]" },
  { label: "Interval", width: "w-[7%]" },
  { label: "Direction", width: "w-[8%]" },
  { label: "Status", width: "w-[9%]" },
  { label: "Evidence", width: "w-[8%]" },
];


/* -------------------------------------------------------------------------- */
/*                               HELPERS                                      */
/* -------------------------------------------------------------------------- */

function CellText({ children }) {
  const value =
    children === null || children === undefined || children === ""
      ? "—"
      : children;

  return (
    <span title={String(value)} className="block truncate">
      {value}
    </span>
  );
}

function formatCountingTime(value) {
  if (!value) return "—";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return String(value);
  }

  return date.toLocaleString([], {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function CarryStatusBadge({ value }) {
  const status = value || "Completed";
  const normalized = String(status).toLowerCase();

  let className = "bg-emerald-600";

  if (normalized.includes("transit")) {
    className = "bg-blue-600";
  } else if (
    normalized.includes("mismatch") ||
    normalized.includes("failed") ||
    normalized.includes("alert")
  ) {
    className = "bg-red-600";
  } else if (normalized.includes("pending")) {
    className = "bg-yellow-600";
  }

  return (
    <span
      title={status}
      className={`inline-flex max-w-full rounded px-1.5 py-0.5 text-[8px] font-semibold text-white ${className}`}
    >
      <span className="truncate">{status}</span>
    </span>
  );
}

function alertStyle(type) {
  if (type === "critical") {
    return {
      iconBg: "bg-red-600",
      iconText: "!",
    };
  }

  if (type === "warning") {
    return {
      iconBg: "bg-yellow-500",
      iconText: "!",
    };
  }

  return {
    iconBg: "bg-blue-600",
    iconText: "i",
  };
}


/* -------------------------------------------------------------------------- */
/*                        CONTROLLED CAMERA IMAGE                             */
/* -------------------------------------------------------------------------- */

function ManagedCountingCameraImage({
  src,
  title,
  className,
  onLoad,
  onError,
}) {
  const imageRef = useRef(null);

  useEffect(() => {
    const image = imageRef.current;

    if (!image || !src) {
      return undefined;
    }

    image.src = src;

    return () => {
      image.onload = null;
      image.onerror = null;
      image.removeAttribute("src");
      image.src = EMPTY_IMAGE_SRC;
    };
  }, [src]);

  return (
    <img
      ref={imageRef}
      alt={title}
      crossOrigin="anonymous"
      draggable={false}
      data-counting-camera-feed="true"
      onLoad={onLoad}
      onError={onError}
      className={className}
    />
  );
}


/* -------------------------------------------------------------------------- */
/*                                  FEED                                      */
/* -------------------------------------------------------------------------- */

function FeedView({
  src,
  title,
  fullscreen = false,
  layout = 4,
  onLoad,
  onError,
}) {
  // Match LiveMonitoring.jsx camera viewport sizing for every normal layout.
  // Layout 1/2/4/8 changes the grid/card width, while each camera feed keeps
  // the same responsive 16:9 aspect ratio used by Live Monitoring.
  let heightClass = "aspect-video";

  if (fullscreen) {
    heightClass = "h-[calc(100vh-155px)] min-h-[520px]";
  }

  return (
    <div
      data-counting-feed-container="true"
      className={`relative w-full overflow-hidden bg-black ${heightClass}`}
    >
      {src ? (
        <ManagedCountingCameraImage
          src={src}
          title={title}
          onLoad={onLoad}
          onError={onError}
          className="block h-full w-full select-none object-fill"
        />
      ) : (
        <div className="flex h-full w-full items-center justify-center bg-[#050f19] text-[10px] text-white/35">
          Select camera to connect
        </div>
      )}
    </div>
  );
}


/* -------------------------------------------------------------------------- */
/*                             CAMERA CARRY STATS                             */
/* -------------------------------------------------------------------------- */

function getCameraCarryStats(liveCounts, selectedCameraId) {
  if (!selectedCameraId) {
    return {
      bags: 0,
      boxes: 0,
      total: 0,
    };
  }

  const stats =
    liveCounts[String(selectedCameraId)] ||
    liveCounts[selectedCameraId] ||
    {};

  return {
    bags: Number(stats.bag_count || 0),
    boxes: Number(stats.box_count || 0),
    total: Number(stats.total_count || 0),
  };
}

/* -------------------------------------------------------------------------- */
/*                              CAMERA CARD                                   */
/* -------------------------------------------------------------------------- */

function CountingCameraCard({
  slotIndex,
  camera,
  cameraList,
  selectedCameraId,
  selectedSlots,
  onCameraChange,
  layout,
  fullscreenSlot,
  onToggleFullscreen,
  liveCounts,
  monitoringEnabled,
}) {
  const cardRef = useRef(null);
  const recordingCanvasRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const recordingChunksRef = useRef([]);
  const recordingAnimationRef = useRef(null);
  const recordingStreamRef = useRef(null);

  const [snapshotLoading, setSnapshotLoading] = useState(false);
  const [recording, setRecording] = useState(false);
  const [recordingLoading, setRecordingLoading] = useState(false);
  const [streamStatus, setStreamStatus] = useState("off");

  const selectedCamera = cameraList.find(
    (item) => String(item.id) === String(selectedCameraId),
  );

  const displayName =
    selectedCamera?.camera_name ||
    selectedCamera?.cameraName ||
    selectedCamera?.name ||
    camera.name;

  // Monitoring OFF -> normal low-latency shared camera stream.
  // Monitoring ON  -> annotated counting stream produced by counting_service.py.
  // The backend counting worker keeps running even if this React page unmounts.
  const streamUrl = selectedCameraId
    ? monitoringEnabled
      ? getCountingStreamUrl(selectedCameraId)
      : getCameraStreamUrl(selectedCameraId)
    : "";

  const isFullscreen = fullscreenSlot === slotIndex;
  const compact = layout === 8 && !isFullscreen;

  const carryStats = useMemo(
    () => getCameraCarryStats(liveCounts, selectedCameraId),
    [liveCounts, selectedCameraId],
  );

  useEffect(() => {
    setStreamStatus(streamUrl ? "loading" : "off");
  }, [streamUrl]);

  const createTimestamp = () => {
    const now = new Date();
    const pad = (value) => String(value).padStart(2, "0");

    return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(
      now.getDate(),
    )}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(
      now.getSeconds(),
    )}`;
  };

  const handleSnapshot = async () => {
    if (!selectedCameraId || !cardRef.current || snapshotLoading) {
      return;
    }

    setSnapshotLoading(true);

    try {
      const image = cardRef.current.querySelector(
        '[data-counting-camera-feed="true"]',
      );

      if (!image) {
        throw new Error("Camera frame is not available.");
      }

      if (!image.complete || !image.naturalWidth) {
        await new Promise((resolve, reject) => {
          let timeoutId;

          const cleanup = () => {
            window.clearTimeout(timeoutId);
            image.removeEventListener("load", handleLoad);
            image.removeEventListener("error", handleError);
          };

          const handleLoad = () => {
            cleanup();
            resolve();
          };

          const handleError = () => {
            cleanup();
            reject(new Error("Camera frame could not be loaded."));
          };

          timeoutId = window.setTimeout(() => {
            cleanup();
            reject(new Error("Camera frame is taking too long to load."));
          }, 7000);

          image.addEventListener("load", handleLoad, { once: true });
          image.addEventListener("error", handleError, { once: true });
        });
      }

      await new Promise((resolve) => {
        window.requestAnimationFrame(() => {
          window.requestAnimationFrame(resolve);
        });
      });

      if (!image.naturalWidth || !image.naturalHeight) {
        throw new Error("Camera frame does not have a valid resolution.");
      }

      const canvas = document.createElement("canvas");
      canvas.width = 1920;
      canvas.height = 1080;

      const context = canvas.getContext("2d", { alpha: false });

      if (!context) {
        throw new Error("Could not create snapshot canvas.");
      }

      context.fillStyle = "#000000";
      context.fillRect(0, 0, 1920, 1080);
      context.imageSmoothingEnabled = true;
      context.imageSmoothingQuality = "high";

      context.drawImage(
        image,
        0,
        0,
        image.naturalWidth,
        image.naturalHeight,
        0,
        0,
        1920,
        1080,
      );

      const blob = await new Promise((resolve, reject) => {
        canvas.toBlob(
          (value) => {
            if (value) {
              resolve(value);
            } else {
              reject(new Error("Could not create snapshot."));
            }
          },
          "image/png",
          1,
        );
      });

      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");

      link.href = url;
      link.download =
        `counting-camera-${selectedCameraId}-snapshot-` +
        `${createTimestamp()}-1920x1080.png`;
      link.style.display = "none";

      document.body.appendChild(link);
      link.click();
      link.remove();

      window.setTimeout(() => {
        URL.revokeObjectURL(url);
      }, 1500);
    } catch (error) {
      console.error("Counting camera snapshot error:", error);

      let message =
        error?.message || "Could not capture camera snapshot.";

      if (
        error?.name === "SecurityError" ||
        String(error?.message || "").toLowerCase().includes("tainted")
      ) {
        message =
          "Browser blocked this snapshot. Add the required CORS headers to the camera stream response.";
      }

      alert(message);
    } finally {
      setSnapshotLoading(false);
    }
  };

  const getCameraRecordingMimeType = () => {
    if (typeof MediaRecorder === "undefined") return "";

    const supportedTypes = [
      "video/webm;codecs=vp9",
      "video/webm;codecs=vp8",
      "video/webm",
    ];

    return (
      supportedTypes.find((type) => MediaRecorder.isTypeSupported(type)) || ""
    );
  };

  const stopRecordingAnimation = () => {
    if (recordingAnimationRef.current) {
      window.cancelAnimationFrame(recordingAnimationRef.current);
      recordingAnimationRef.current = null;
    }
  };

  const stopRecordingStream = () => {
    const stream = recordingStreamRef.current;

    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
    }

    recordingStreamRef.current = null;
  };

  const downloadCameraRecording = (blob) => {
    if (!blob || blob.size === 0) {
      throw new Error("No camera recording data was captured.");
    }

    const objectUrl = URL.createObjectURL(blob);
    const downloadLink = document.createElement("a");

    downloadLink.href = objectUrl;
    downloadLink.download =
      `counting-camera-${selectedCameraId}-recording-` +
      `${createTimestamp()}-1920x1080.webm`;
    downloadLink.style.display = "none";

    document.body.appendChild(downloadLink);
    downloadLink.click();
    downloadLink.remove();

    window.setTimeout(() => URL.revokeObjectURL(objectUrl), 2000);
  };

  const startCameraRecording = async () => {
    if (
      !selectedCameraId ||
      !cardRef.current ||
      recording ||
      recordingLoading
    ) {
      return;
    }

    try {
      setRecordingLoading(true);

      if (typeof MediaRecorder === "undefined") {
        throw new Error("MediaRecorder is not supported in this browser.");
      }

      const cameraImage = cardRef.current.querySelector(
        '[data-counting-camera-feed="true"]',
      );

      if (!cameraImage) {
        throw new Error("Camera frame is not available.");
      }

      if (!cameraImage.complete || !cameraImage.naturalWidth) {
        throw new Error("Camera stream is still loading.");
      }

      const outputWidth = 1920;
      const outputHeight = 1080;
      const recordingFps = 15;

      const canvas = document.createElement("canvas");
      canvas.width = outputWidth;
      canvas.height = outputHeight;

      const context = canvas.getContext("2d", { alpha: false });

      if (!context) {
        throw new Error("Could not create recording canvas.");
      }

      recordingCanvasRef.current = canvas;

      const canvasStream = canvas.captureStream(recordingFps);
      recordingStreamRef.current = canvasStream;

      const mimeType = getCameraRecordingMimeType();
      const recorder = new MediaRecorder(canvasStream, {
        videoBitsPerSecond: 4_000_000,
        ...(mimeType ? { mimeType } : {}),
      });

      mediaRecorderRef.current = recorder;
      recordingChunksRef.current = [];

      recorder.addEventListener("dataavailable", (event) => {
        if (event.data?.size > 0) {
          recordingChunksRef.current.push(event.data);
        }
      });

      recorder.addEventListener("stop", () => {
        try {
          const finalMimeType = recorder.mimeType || mimeType || "video/webm";
          const recordingBlob = new Blob(recordingChunksRef.current, {
            type: finalMimeType,
          });

          downloadCameraRecording(recordingBlob);
        } catch (error) {
          console.error("Camera recording download error:", error);
          alert(error?.message || "Could not download camera recording.");
        } finally {
          stopRecordingAnimation();
          stopRecordingStream();
          mediaRecorderRef.current = null;
          recordingCanvasRef.current = null;
          recordingChunksRef.current = [];
          setRecording(false);
          setRecordingLoading(false);
        }
      });

      recorder.addEventListener("error", (event) => {
        console.error("Camera recording error:", event.error);
        stopRecordingAnimation();
        stopRecordingStream();
        mediaRecorderRef.current = null;
        recordingCanvasRef.current = null;
        recordingChunksRef.current = [];
        setRecording(false);
        setRecordingLoading(false);
        alert(event.error?.message || "Camera recording failed.");
      });

      const drawRecordingFrame = () => {
        const activeRecorder = mediaRecorderRef.current;

        if (!activeRecorder || activeRecorder.state === "inactive") {
          return;
        }

        try {
          context.fillStyle = "#000000";
          context.fillRect(0, 0, outputWidth, outputHeight);

          if (
            cameraImage.complete &&
            cameraImage.naturalWidth > 0 &&
            cameraImage.naturalHeight > 0
          ) {
            context.imageSmoothingEnabled = true;
            context.imageSmoothingQuality = "high";
            context.drawImage(
              cameraImage,
              0,
              0,
              cameraImage.naturalWidth,
              cameraImage.naturalHeight,
              0,
              0,
              outputWidth,
              outputHeight,
            );
          }
        } catch (error) {
          console.error("Recording frame draw error:", error);
        }

        recordingAnimationRef.current = window.requestAnimationFrame(
          drawRecordingFrame,
        );
      };

      recorder.start(1000);
      setRecording(true);
      setRecordingLoading(false);
      drawRecordingFrame();
    } catch (error) {
      console.error("Start camera recording error:", error);
      stopRecordingAnimation();
      stopRecordingStream();
      mediaRecorderRef.current = null;
      recordingCanvasRef.current = null;
      recordingChunksRef.current = [];
      setRecording(false);
      setRecordingLoading(false);

      let message = error?.message || "Could not start camera recording.";

      if (
        error?.name === "SecurityError" ||
        String(error?.message || "").toLowerCase().includes("tainted")
      ) {
        message =
          "Browser blocked camera recording. Verify CORS headers on camera stream responses.";
      }

      alert(message);
    }
  };

  const stopCameraRecording = () => {
    stopRecordingAnimation();

    const recorder = mediaRecorderRef.current;

    if (recorder && recorder.state !== "inactive") {
      recorder.stop();
      return;
    }

    stopRecordingStream();
    mediaRecorderRef.current = null;
    recordingCanvasRef.current = null;
    recordingChunksRef.current = [];
    setRecording(false);
    setRecordingLoading(false);
  };

  const handleRecording = () => {
    if (recording) {
      stopCameraRecording();
    } else {
      startCameraRecording();
    }
  };

  useEffect(() => {
    return () => {
      stopRecordingAnimation();

      const recorder = mediaRecorderRef.current;

      if (recorder && recorder.state !== "inactive") {
        recorder.stop();
      } else {
        stopRecordingStream();
      }
    };
  }, []);

  return (
    <section
      ref={cardRef}
      className="min-w-0 overflow-hidden rounded-md border border-[#1b344d] bg-[#061421]"
    >
      {/* CAMERA HEADER */}

      <div className="flex min-h-[32px] items-center justify-between gap-1 px-2 py-1">
        <div className="flex min-w-0 flex-1 items-center gap-1">
          <span className="grid h-5 w-5 shrink-0 place-items-center rounded bg-blue-600 text-[10px] font-bold text-white">
            {slotIndex + 1}
          </span>

          <select
            value={selectedCameraId || ""}
            onChange={(event) =>
              onCameraChange(slotIndex, event.target.value)
            }
            className={`h-6 w-full rounded border border-[#1b344d] bg-[#03101d] text-white outline-none focus:border-blue-500 ${
              compact
                ? "min-w-[70px] max-w-[110px] px-1 text-[8px]"
                : "min-w-[95px] max-w-[190px] px-2 text-[9px]"
            }`}
          >
            <option value="">Select Camera</option>

            {cameraList
              .filter((item) => {
                const optionId = String(item.id);
                const currentId = String(selectedCameraId || "");

                return (
                  optionId === currentId ||
                  !selectedSlots
                    .filter((_, index) => index !== slotIndex)
                    .map(String)
                    .includes(optionId)
                );
              })
              .map((item) => (
                <option key={item.id} value={item.id}>
                  {item.camera_name ||
                    item.cameraName ||
                    item.name}
                </option>
              ))}
          </select>
        </div>

        <div className="flex shrink-0 items-center gap-1">
          {!compact && (
            <span className="flex items-center gap-1 text-[8px] font-semibold text-white/70">
              <span
                className={`h-1.5 w-1.5 rounded-full ${
                  streamStatus === "live"
                    ? "bg-emerald-500"
                    : streamStatus === "loading"
                      ? "bg-yellow-500"
                      : "bg-red-500"
                }`}
              />

              {streamStatus === "live"
                ? "LIVE"
                : streamStatus === "loading"
                  ? "WAIT"
                  : "OFF"}
            </span>
          )}

          <button
            type="button"
            title={isFullscreen ? "Exit fullscreen" : "Fullscreen"}
            onClick={() => onToggleFullscreen(slotIndex)}
            className="grid h-6 w-6 place-items-center rounded-md border border-[#1b344d] bg-[#03101d] text-white/85 transition hover:bg-[#0b2238]"
          >
            <Expand size={12} />
          </button>
        </div>
      </div>

      {/* CAMERA VIDEO */}

      <FeedView
        src={streamUrl}
        title={displayName}
        fullscreen={isFullscreen}
        layout={layout}
        onLoad={() => setStreamStatus("live")}
        onError={() => setStreamStatus("off")}
      />

      {/* CAMERA COUNTS */}

      <div
        className={`grid min-w-0 items-center border-t border-[#123250] bg-[#061421]/95 ${
          compact
            ? "h-[31px] grid-cols-[1fr_1fr_auto_auto] gap-1 px-1"
            : "h-[36px] grid-cols-[1fr_1fr_auto_auto] gap-2 px-2"
        }`}
      >
        <div className="flex min-w-0 items-center gap-1">
          <Package
            size={compact ? 11 : 13}
            className="shrink-0 text-emerald-400"
          />

          <div className="min-w-0 leading-none">
            <p className="truncate text-[9px] font-bold text-white">
              {carryStats.bags}
            </p>

            {!compact && (
              <p className="mt-0.5 truncate text-[7px] text-white/55">
                Bags
              </p>
            )}
          </div>
        </div>

        <div className="flex min-w-0 items-center gap-1">
          <Box
            size={compact ? 11 : 13}
            className="shrink-0 text-blue-400"
          />

          <div className="min-w-0 leading-none">
            <p className="truncate text-[9px] font-bold text-white">
              {carryStats.boxes}
            </p>

            {!compact && (
              <p className="mt-0.5 truncate text-[7px] text-white/55">
                Boxes
              </p>
            )}
          </div>
        </div>

        <button
          type="button"
          title="Download camera snapshot"
          disabled={!selectedCameraId || snapshotLoading}
          onClick={handleSnapshot}
          className={`grid shrink-0 place-items-center rounded-md border border-sky-700 bg-sky-700 text-white hover:bg-sky-600 disabled:cursor-not-allowed disabled:border-gray-700 disabled:bg-gray-700 ${
            compact ? "h-5 w-6" : "h-6 w-8"
          }`}
        >
          {snapshotLoading ? (
            <Loader2
              size={compact ? 10 : 12}
              className="animate-spin"
            />
          ) : (
            <Camera size={compact ? 11 : 13} />
          )}
        </button>

        <button
          type="button"
          title={recording ? "Stop recording" : "Start recording"}
          disabled={!selectedCameraId || recordingLoading}
          onClick={handleRecording}
          className={`flex shrink-0 items-center justify-center rounded-md border font-bold text-white disabled:cursor-not-allowed disabled:border-gray-700 disabled:bg-gray-700 ${
            compact
              ? "h-5 min-w-[38px] gap-1 px-1 text-[7px]"
              : "h-6 min-w-[56px] gap-1 px-1.5 text-[8px]"
          } ${
            recording
              ? "border-red-700 bg-red-700 hover:bg-red-600"
              : "border-gray-700 bg-gray-700 hover:bg-gray-600"
          }`}
        >
          {recordingLoading && !recording ? (
            <Loader2 size={compact ? 8 : 10} className="animate-spin" />
          ) : recording ? (
            <Square size={compact ? 8 : 10} fill="currentColor" />
          ) : (
            <span className="h-2 w-2 rounded-full bg-white/50" />
          )}

          <span>
            {recordingLoading && !recording
              ? "WAIT"
              : recording
                ? "STOP"
                : "REC"}
          </span>
        </button>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/*                              CAMERA GRID                                   */
/* -------------------------------------------------------------------------- */

function CountingCameraGrid({
  layout,
  cameraList,
  selectedSlots,
  setSelectedSlots,
  liveCounts,
  monitoringEnabled,
}) {
  const [fullscreenSlot, setFullscreenSlot] = useState(null);

  const visibleSlots =
    fullscreenSlot !== null
      ? [fullscreenSlot]
      : Array.from({ length: layout }, (_, index) => index);

  // Keep the exact same normal card width behavior as LiveMonitoring.jsx.
  // Layout 1 and 2 do NOT stretch cards to fill the row. Each card keeps the
  // same width it has in the 4-camera layout and the group is centered.
  const cameraGridClass =
    layout === 1
      ? "grid-cols-1"
      : layout === 2
        ? "grid-cols-1 md:grid-cols-2"
        : layout === 4
          ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-4"
          : "grid-cols-1 sm:grid-cols-2 lg:grid-cols-4";

  const handleCameraChange = (slotIndex, cameraId) => {
    setSelectedSlots((previous) => {
      const next = [...previous];

      next[slotIndex] =
        cameraId === "" ? "" : String(cameraId);

      return next;
    });
  };

  const handleToggleFullscreen = (slotIndex) => {
    setFullscreenSlot((previous) =>
      previous === slotIndex ? null : slotIndex,
    );
  };

  return (
    <div
      className={
        fullscreenSlot !== null
          ? "grid grid-cols-1 gap-2"
          : layout === 1 || layout === 2
            ? "flex flex-wrap justify-center gap-2"
            : `grid min-w-0 gap-2 ${cameraGridClass}`
      }
    >
      {visibleSlots.map((slotIndex) => (
        <div
          key={`counting-slot-${slotIndex}`}
          className={
            fullscreenSlot !== null
              ? "min-w-0 w-full"
              : layout === 1 || layout === 2
                ? "min-w-0 w-full sm:w-[calc(50%-4px)] lg:w-[calc(25%-6px)]"
                : "min-w-0"
          }
        >
          <CountingCameraCard
            slotIndex={slotIndex}
            camera={defaultSlots[slotIndex]}
            cameraList={cameraList}
            selectedCameraId={selectedSlots[slotIndex]}
            selectedSlots={selectedSlots}
            onCameraChange={handleCameraChange}
            layout={layout}
            fullscreenSlot={fullscreenSlot}
            onToggleFullscreen={handleToggleFullscreen}
            liveCounts={liveCounts}
            monitoringEnabled={monitoringEnabled}
          />
        </div>
      ))}
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                           REAL-TIME COUNT CARDS                            */
/* -------------------------------------------------------------------------- */

function RealtimeCard({
  title,
  value,
  subtitle,
  Icon,
  cardClass,
  iconClass,
  valueClass,
  glowClass,
}) {
  return (
    <section
      className={`
        group
        relative
        min-w-0
        overflow-hidden
        rounded-lg
        border
        px-3
        py-3
        shadow-[0_10px_25px_rgba(0,0,0,0.18)]
        transition-all
        duration-300
        hover:-translate-y-[2px]
        hover:shadow-[0_14px_32px_rgba(0,0,0,0.28)]
        ${cardClass}
      `}
    >
      {/* Decorative glow */}

      <div
        className={`
          pointer-events-none
          absolute
          -right-6
          -top-6
          h-24
          w-24
          rounded-full
          blur-3xl
          opacity-25
          transition
          duration-300
          group-hover:opacity-40
          ${glowClass}
        `}
      />

      {/* Top accent line */}

      <div
        className={`
          absolute
          left-0
          top-0
          h-[2px]
          w-full
          opacity-90
          ${glowClass}
        `}
      />

      <div className="relative z-10 flex min-w-0 items-center gap-3">

        {/* ICON */}

        <span
          className={`
            grid
            h-10
            w-10
            shrink-0
            place-items-center
            rounded-lg
            shadow-lg
            transition
            duration-300
            group-hover:scale-105
            ${iconClass}
          `}
        >
          <Icon
            size={19}
            strokeWidth={2}
            className="text-white"
          />
        </span>

        {/* DATA */}

        <div className="min-w-0 flex-1">

          <p className="truncate text-[9px] font-semibold uppercase tracking-[0.04em] text-white/60">
            {title}
          </p>

          <p
            className={`
              mt-1
              truncate
              text-[23px]
              font-bold
              leading-none
              ${valueClass}
            `}
          >
            {value}
          </p>

          <p className="mt-1.5 truncate text-[8px] text-white/50">
            {subtitle}
          </p>

        </div>

      </div>
    </section>
  );
}


/* -------------------------------------------------------------------------- */
/*                         REAL-TIME CARRY SUMMARY                            */
/* -------------------------------------------------------------------------- */

function RealtimeCarrySummary({
  liveCounts,
  monitoredCount,
}) {
  const summary = useMemo(() => {
    return Object.values(liveCounts || {}).reduce(
      (accumulator, item) => {
        accumulator.bags += Number(item?.bag_count || 0);
        accumulator.boxes += Number(item?.box_count || 0);
        accumulator.total += Number(item?.total_count || 0);
        return accumulator;
      },
      {
        total: 0,
        bags: 0,
        boxes: 0,
      },
    );
  }, [liveCounts]);

  return (
    <div className="mt-2 grid min-w-0 grid-cols-4 gap-2">
      <RealtimeCard
        title="Total Items Carried"
        value={summary.total}
        subtitle={`${monitoredCount} camera${
          monitoredCount === 1 ? "" : "s"
        } selected`}
        Icon={Boxes}
        cardClass="
          border-purple-500/40
          bg-gradient-to-br
          from-purple-950/90
          via-[#10152c]
          to-[#07182a]
          hover:border-purple-400/70
        "
        iconClass="
          bg-gradient-to-br
          from-purple-500
          to-violet-700
          shadow-purple-900/50
        "
        valueClass="text-purple-300"
        glowClass="bg-purple-500"
      />

      <RealtimeCard
        title="Bags Carried"
        value={summary.bags}
        subtitle="Live monitoring session"
        Icon={Package}
        cardClass="
          border-emerald-500/40
          bg-gradient-to-br
          from-emerald-950/90
          via-[#08251f]
          to-[#07182a]
          hover:border-emerald-400/70
        "
        iconClass="
          bg-gradient-to-br
          from-emerald-400
          to-green-700
          shadow-emerald-900/50
        "
        valueClass="text-emerald-300"
        glowClass="bg-emerald-500"
      />

      <RealtimeCard
        title="Boxes Carried"
        value={summary.boxes}
        subtitle="Live monitoring session"
        Icon={Box}
        cardClass="
          border-blue-500/40
          bg-gradient-to-br
          from-blue-950/90
          via-[#082038]
          to-[#07182a]
          hover:border-blue-400/70
        "
        iconClass="
          bg-gradient-to-br
          from-blue-400
          to-blue-700
          shadow-blue-900/50
        "
        valueClass="text-blue-300"
        glowClass="bg-blue-500"
      />

      <RealtimeCard
        title="Selected Cameras"
        value={monitoredCount}
        subtitle="Cameras used for counting"
        Icon={Camera}
        cardClass="
          border-orange-500/40
          bg-gradient-to-br
          from-orange-950/90
          via-[#2c190b]
          to-[#07182a]
          hover:border-orange-400/70
        "
        iconClass="
          bg-gradient-to-br
          from-orange-400
          to-red-600
          shadow-orange-900/50
        "
        valueClass="text-orange-300"
        glowClass="bg-orange-500"
      />
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                            QUICK ACTION TOGGLE                             */
/* -------------------------------------------------------------------------- */

function ActionToggle({
  Icon,
  label,
  enabled,
  onClick,
  activeClassName,
  disabled = false,
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={enabled}
      onClick={onClick}
      disabled={disabled}
      className={`grid h-[46px] min-w-0 grid-cols-[minmax(0,1fr)_auto] items-center gap-2 rounded-md border px-3 text-left text-[10px] font-bold text-white transition disabled:cursor-not-allowed disabled:opacity-60 ${
        enabled
          ? activeClassName
          : "border-slate-600 bg-slate-700 hover:bg-slate-600"
      }`}
    >
      <span className="flex min-w-0 items-center gap-2">
        <Icon size={15} className="shrink-0" />
        <span className="min-w-0 truncate">{label}</span>
      </span>

      <span className="flex shrink-0 items-center gap-1">
        <span
          className={`relative h-[17px] w-[31px] rounded-full ${
            enabled ? "bg-emerald-500" : "bg-slate-500"
          }`}
        >
          <span
            className={`absolute top-1/2 h-[11px] w-[11px] -translate-y-1/2 rounded-full bg-white transition ${
              enabled ? "right-[3px]" : "left-[3px]"
            }`}
          />
        </span>

        <span className="text-[8px]">
          {enabled ? "ON" : "OFF"}
        </span>
      </span>
    </button>
  );
}


/* -------------------------------------------------------------------------- */
/*                              QUICK ACTIONS                                 */
/* -------------------------------------------------------------------------- */

function CountingQuickActions({
  events,
  monitoredCount,
  monitoringEnabled,
  monitoringLoading,
  onToggleMonitoring,
}) {
  const [emailSending, setEmailSending] = useState(false);
  const [screenRecording, setScreenRecording] = useState(false);
  const [screenCaptureLoading, setScreenCaptureLoading] = useState(false);

  const screenRecorderRef = useRef(null);
  const screenStreamRef = useRef(null);
  const screenChunksRef = useRef([]);

  const handleSendCountingEmail = async () => {
    if (emailSending) {
      return;
    }

    try {
      setEmailSending(true);

      const response = await sendCountingTestEmail();

      alert(
        response?.message ||
          "Counting test email sent successfully.",
      );
    } catch (error) {
      console.error(
        "Counting test email error:",
        error,
      );

      alert(
        error?.message ||
          "Could not send counting test email.",
      );
    } finally {
      setEmailSending(false);
    }
  };


  const createCaptureTimestamp = () => {
    const now = new Date();
    const pad = (value) => String(value).padStart(2, "0");

    return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(
      now.getDate(),
    )}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(
      now.getSeconds(),
    )}`;
  };

  const downloadBlob = (blob, filename) => {
    if (!blob || blob.size === 0) {
      throw new Error("No recording data was captured.");
    }

    const objectUrl = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = objectUrl;
    link.download = filename;
    link.style.display = "none";

    document.body.appendChild(link);
    link.click();
    link.remove();

    window.setTimeout(() => URL.revokeObjectURL(objectUrl), 2000);
  };

  const exportToExcel = () => {
    if (!events.length) {
      alert("No counting history available to export.");
      return;
    }

    const rows = events.map((event) => ({
      "Event ID": event.record_id,
      "Start Time": formatCountingTime(event.start_time),
      "End Time": formatCountingTime(event.end_time),
      Camera: event.camera_name,
      Location: event.camera_location,
      Bags: Number(event.bag_count || 0),
      Boxes: Number(event.box_count || 0),
      Total: Number(event.total_count || 0),
      "Interval (Minutes)": Number(event.interval_minutes || 0),
      Direction: event.direction || "",
      Status: event.status || "Completed",
      Evidence: event.evidence_image || "",
    }));

    const worksheet = XLSX.utils.json_to_sheet(rows);

    worksheet["!cols"] = [
      { wch: 28 },
      { wch: 22 },
      { wch: 22 },
      { wch: 22 },
      { wch: 22 },
      { wch: 10 },
      { wch: 10 },
      { wch: 10 },
      { wch: 18 },
      { wch: 14 },
      { wch: 14 },
      { wch: 45 },
    ];

    if (worksheet["!ref"]) {
      worksheet["!autofilter"] = { ref: worksheet["!ref"] };
    }

    events.forEach((event, index) => {
      if (!event.evidence_image) return;

      worksheet[`L${index + 2}`] = {
        t: "s",
        v: "Open Evidence",
        l: {
          Target: getCountingEvidenceUrl(event.id),
          Tooltip: "Open evidence image",
        },
      };
    });

    const workbook = XLSX.utils.book_new();

    XLSX.utils.book_append_sheet(
      workbook,
      worksheet,
      "Labor Carry Events",
    );

    XLSX.writeFile(
      workbook,
      `labor-carry-events_${createCaptureTimestamp()}.xlsx`,
      {
        compression: true,
      },
    );
  };

  const getSupportedRecordingMimeType = () => {
    if (typeof MediaRecorder === "undefined") return "";

    const supportedTypes = [
      "video/webm;codecs=vp9",
      "video/webm;codecs=vp8",
      "video/webm",
    ];

    return (
      supportedTypes.find((type) => MediaRecorder.isTypeSupported(type)) || ""
    );
  };

  const stopScreenStream = () => {
    const stream = screenStreamRef.current;

    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
    }

    screenStreamRef.current = null;
  };

  const stopFullScreenRecording = () => {
    const recorder = screenRecorderRef.current;

    if (recorder && recorder.state !== "inactive") {
      recorder.stop();
      return;
    }

    stopScreenStream();
    screenRecorderRef.current = null;
    screenChunksRef.current = [];
    setScreenRecording(false);
    setScreenCaptureLoading(false);
  };

  const startFullScreenRecording = async () => {
    if (screenRecording || screenCaptureLoading) return;

    try {
      if (!navigator.mediaDevices?.getDisplayMedia) {
        throw new Error("Screen recording is not supported in this browser.");
      }

      if (typeof MediaRecorder === "undefined") {
        throw new Error("MediaRecorder is not supported in this browser.");
      }

      setScreenCaptureLoading(true);
      screenChunksRef.current = [];

      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          frameRate: { ideal: 15, max: 20 },
        },
        audio: false,
        preferCurrentTab: true,
        selfBrowserSurface: "include",
        surfaceSwitching: "exclude",
      });

      screenStreamRef.current = displayStream;

      const mimeType = getSupportedRecordingMimeType();
      const recorder = new MediaRecorder(displayStream, {
        videoBitsPerSecond: 3_000_000,
        ...(mimeType ? { mimeType } : {}),
      });

      screenRecorderRef.current = recorder;

      recorder.addEventListener("dataavailable", (event) => {
        if (event.data?.size > 0) {
          screenChunksRef.current.push(event.data);
        }
      });

      recorder.addEventListener("stop", () => {
        try {
          const finalMimeType = recorder.mimeType || mimeType || "video/webm";
          const recordingBlob = new Blob(screenChunksRef.current, {
            type: finalMimeType,
          });

          if (recordingBlob.size > 0) {
            downloadBlob(
              recordingBlob,
              `counting-management-recording-${createCaptureTimestamp()}.webm`,
            );
          } else {
            alert("No recording data was captured.");
          }
        } catch (error) {
          console.error("Recording download error:", error);
          alert(error?.message || "Could not save recording.");
        } finally {
          stopScreenStream();
          screenRecorderRef.current = null;
          screenChunksRef.current = [];
          setScreenRecording(false);
          setScreenCaptureLoading(false);
        }
      });

      recorder.addEventListener("error", (event) => {
        console.error("Counting Management recorder error:", event.error);
        alert(event.error?.message || "Recording failed.");
        stopScreenStream();
        screenRecorderRef.current = null;
        screenChunksRef.current = [];
        setScreenRecording(false);
        setScreenCaptureLoading(false);
      });

      const videoTrack = displayStream.getVideoTracks()[0];

      videoTrack?.addEventListener("ended", () => {
        if (screenRecorderRef.current?.state !== "inactive") {
          screenRecorderRef.current.stop();
        }
      });

      recorder.start(1000);
      setScreenRecording(true);
      setScreenCaptureLoading(false);
    } catch (error) {
      console.error("Start Counting Management recording error:", error);
      stopScreenStream();
      screenRecorderRef.current = null;
      screenChunksRef.current = [];
      setScreenRecording(false);
      setScreenCaptureLoading(false);

      if (error?.name !== "NotAllowedError") {
        alert(error?.message || "Could not start recording.");
      }
    }
  };

  const handleFullScreenRecording = () => {
    if (screenRecording) {
      stopFullScreenRecording();
    } else {
      startFullScreenRecording();
    }
  };

  useEffect(() => {
    return () => {
      const recorder = screenRecorderRef.current;

      if (recorder && recorder.state !== "inactive") {
        recorder.stop();
      }

      const stream = screenStreamRef.current;

      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }

      screenRecorderRef.current = null;
      screenStreamRef.current = null;
      screenChunksRef.current = [];
    };
  }, []);

  return (
    <section className="mt-2 rounded-md border border-[#16304a] bg-[#061421] p-1.5">
      <div className="grid min-w-0 grid-cols-[1.25fr_1.35fr_1.2fr_1fr] gap-2">
        <ActionToggle
          Icon={Video}
          label={`Monitoring (${monitoredCount})`}
          enabled={monitoringEnabled}
          onClick={onToggleMonitoring}
          disabled={monitoringLoading}
          activeClassName="border-emerald-600 bg-emerald-600 hover:bg-emerald-500"
        />

        <button
          type="button"
          onClick={exportToExcel}
          className="flex h-[46px] min-w-0 items-center justify-center gap-2 rounded-md border border-emerald-600 bg-emerald-600 px-3 text-[10px] font-bold text-white transition hover:bg-emerald-500"
        >
          <FileSpreadsheet
            size={15}
            className="shrink-0"
          />

          <span className="truncate">Export to Excel</span>
        </button>

        <button
          type="button"
          onClick={handleFullScreenRecording}
          disabled={screenCaptureLoading && !screenRecording}
          aria-pressed={screenRecording}
          className={`flex h-[46px] min-w-0 items-center justify-center gap-2 rounded-md border px-3 text-[10px] font-bold text-white transition disabled:cursor-not-allowed disabled:opacity-60 ${
            screenRecording
              ? "border-red-600 bg-red-600 hover:bg-red-500"
              : "border-purple-600 bg-purple-600 hover:bg-purple-500"
          }`}
        >
          {screenCaptureLoading && !screenRecording ? (
            <Loader2 size={15} className="animate-spin" />
          ) : screenRecording ? (
            <Square size={14} fill="currentColor" />
          ) : (
            <Video size={15} />
          )}

          <span className="truncate">
            {screenCaptureLoading && !screenRecording
              ? "Starting..."
              : screenRecording
                ? "Stop Recording"
                : "Record Clip"}
          </span>
        </button>

        <button
          type="button"
          onClick={handleSendCountingEmail}
          disabled={emailSending}
          className="flex h-[46px] min-w-0 items-center justify-center gap-2 rounded-md border border-red-600 bg-red-600 px-3 text-[10px] font-bold text-white transition hover:bg-red-500 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {emailSending ? (
            <Loader2
              size={15}
              className="animate-spin"
            />
          ) : (
            <Mail size={15} />
          )}

          <span className="truncate">
            {emailSending
              ? "Sending..."
              : "Email Alert"}
          </span>
        </button>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/*                               EVENTS TABLE                                 */
/* -------------------------------------------------------------------------- */

function CarryEventsTable({
  events,
  intervalMinutes,
  intervalSaving,
  onIntervalChange,
}) {
  return (
    <section className="flex h-[270px] min-h-0 flex-col rounded-lg border border-[#16304a] bg-[#061421] shadow-[0_0_30px_rgba(0,0,0,0.18)]">
      <div className="flex h-[36px] shrink-0 items-center justify-between gap-3 border-b border-[#123250] px-3">
        <div className="min-w-0">
          <h3 className="truncate text-[13px] font-semibold text-white">
            Labor Carry Events
          </h3>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <span className="text-[14px] text-white/80">
            Add Event Interval
          </span>

          <div className="relative">
            <select
              value={String(intervalMinutes)}
              disabled={intervalSaving}
              onChange={(event) =>
                onIntervalChange(Number(event.target.value))
              }
              title="Choose how often counting summary events are saved"
              className="h-7 min-w-[100px] rounded-md border border-[#23445f] bg-[#03101d] px-2 pr-7 text-[11px] font-semibold text-white outline-none transition focus:border-blue-500 disabled:cursor-not-allowed disabled:opacity-60"
            >
              <option value="5">5 min</option>
              <option value="10">10 min</option>
              <option value="15">15 min</option>
              <option value="30">30 min</option>
              <option value="60">1 hour</option>
            </select>

            {intervalSaving && (
              <Loader2
                size={10}
                className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 animate-spin text-white/60"
              />
            )}
          </div>
        </div>
      </div>

      <div className="min-h-0 flex-1 overflow-auto">
        <table className="w-full min-w-[1320px] table-fixed border-collapse text-left text-[9px]">
          <thead className="sticky top-0 z-10 bg-[#082136] text-white/70">
            <tr className="h-[30px]">
              {transferColumns.map((column) => (
                <th
                  key={column.label}
                  className={`${column.width} truncate border-r border-[#123250] px-2 py-1 font-semibold last:border-r-0`}
                >
                  {column.label}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {events.length ? (
              events.map((row, index) => {
                const evidenceUrl = row.evidence_image
                  ? getCountingEvidenceUrl(row.id)
                  : "";

                return (
                  <tr
                    key={`${row.record_id || row.id || "count"}-${index}`}
                    className="h-[31px] border-t border-[#123250] bg-[#051828]/80 text-white/85 transition hover:bg-[#0b2238]"
                  >
                    <td className="px-2 py-1">
                      <CellText>{row.record_id}</CellText>
                    </td>

                    <td className="px-2 py-1">
                      <CellText>{formatCountingTime(row.start_time)}</CellText>
                    </td>

                    <td className="px-2 py-1">
                      <CellText>{formatCountingTime(row.end_time)}</CellText>
                    </td>

                    <td className="px-2 py-1">
                      <CellText>{row.camera_name}</CellText>
                    </td>

                    <td className="px-2 py-1">
                      <CellText>{row.camera_location}</CellText>
                    </td>

                    <td className="px-2 py-1">
                      <span className="font-bold text-emerald-300">
                        {Number(row.bag_count || 0)}
                      </span>
                    </td>

                    <td className="px-2 py-1">
                      <span className="font-bold text-blue-300">
                        {Number(row.box_count || 0)}
                      </span>
                    </td>

                    <td className="px-2 py-1">
                      <span className="font-bold text-cyan-300">
                        {Number(row.total_count || 0)}
                      </span>
                    </td>

                    <td className="px-2 py-1">
                      <CellText>
                        {Number(row.interval_minutes || 0) === 60
                          ? "1 hour"
                          : `${Number(row.interval_minutes || 0)} min`}
                      </CellText>
                    </td>

                    <td className="px-2 py-1">
                      <CellText>{row.direction}</CellText>
                    </td>

                    <td className="px-2 py-1">
                      <CarryStatusBadge value={row.status} />
                    </td>

                    <td className="px-2 py-1 text-center">
                      <button
                        type="button"
                        title={evidenceUrl ? "View evidence" : "No evidence"}
                        disabled={!evidenceUrl}
                        onClick={() => {
                          if (evidenceUrl) {
                            window.open(
                              evidenceUrl,
                              "_blank",
                              "noopener,noreferrer",
                            );
                          }
                        }}
                        className="inline-flex h-6 w-10 items-center justify-center overflow-hidden rounded border border-white/10 bg-white/10 text-[8px] text-white/60 transition hover:bg-white/20 disabled:cursor-not-allowed disabled:opacity-40"
                      >
                        {evidenceUrl ? (
                          <img
                            src={evidenceUrl}
                            alt="Evidence"
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          "—"
                        )}
                      </button>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td
                  colSpan={transferColumns.length}
                  className="h-[150px] text-center text-[10px] text-white/45"
                >
                  No completed counting events found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="flex h-[22px] shrink-0 items-center justify-between border-t border-[#123250] px-3 text-[8px] text-white/40">
        <span>
          Showing {events.length} counting event
          {events.length === 1 ? "" : "s"}
        </span>

        <span>
          New event every{" "}
          {Number(intervalMinutes) === 60
            ? "1 hour"
            : `${intervalMinutes} min`}
        </span>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/*                              ALERT PANEL                                   */
/* -------------------------------------------------------------------------- */

function CarryAlertsPanel() {
  return (
    <section className="flex h-[270px] min-h-0 flex-col overflow-hidden rounded-lg border border-[#16304a] bg-[#061421]">
      <div className="flex h-[32px] shrink-0 items-center justify-between border-b border-[#123250] px-3">
        <h3 className="text-[13px] font-semibold text-white">
          Carry Alerts
        </h3>

        <button
          type="button"
          className="text-[9px] text-white/55 transition hover:text-white"
        >
          View All ›
        </button>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto">
        {carryAlerts.map((alert, index) => {
          const style = alertStyle(alert.type);

          return (
            <button
              key={`${alert.title}-${index}`}
              type="button"
              className="flex w-full items-center gap-2 border-b border-[#123250] px-2.5 py-2 text-left transition last:border-b-0 hover:bg-[#0b2238]"
            >
              <span
                className={`grid h-5 w-5 shrink-0 place-items-center rounded-full text-[10px] font-bold text-white ${style.iconBg}`}
              >
                {style.iconText}
              </span>

              <span className="min-w-0 flex-1">
                <span className="block truncate text-[9px] font-bold text-white">
                  {alert.title}
                </span>

                <span className="mt-0.5 block truncate text-[8px] text-white/55">
                  {alert.camera}
                </span>
              </span>

              <span className="shrink-0 text-right text-[7px] leading-3 text-white/55">
                <span className="block">{alert.date}</span>
                <span className="block">{alert.time}</span>
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
}


/* -------------------------------------------------------------------------- */
/*                         MAIN COUNTING MANAGEMENT                             */
/* -------------------------------------------------------------------------- */

export default function CountingManagement() {
  const outletContext =
    useOutletContext() || {};

  const {
    countingLayout = 4,
    setCountingLayout,
  } = outletContext;

  const safeLayout =
    [1, 2, 4, 8].includes(Number(countingLayout))
      ? Number(countingLayout)
      : 4;

  const [cameraList, setCameraList] =
    useState([]);

  const [cameraLoading, setCameraLoading] =
    useState(true);

  // Camera selections survive route/page navigation and browser refresh.
  const [selectedSlots, setSelectedSlots] =
    useState(() => loadSavedCountingSlots());

  const [monitoringEnabled, setMonitoringEnabled] =
    useState(false);

  const [monitoringLoading, setMonitoringLoading] =
    useState(false);

  const monitoringSyncRef = useRef(0);

  // Persist camera slot selection. Monitoring state itself is intentionally
  // NOT stored in localStorage: the backend worker is the source of truth.
  useEffect(() => {
    saveCountingSlots(selectedSlots);
  }, [selectedSlots]);

  const [events, setEvents] = useState([]);
  const [liveCounts, setLiveCounts] = useState({});
  const [intervalMinutes, setIntervalMinutes] = useState(5);
  const [intervalSaving, setIntervalSaving] = useState(false);


  /* ---------------------------------------------------------------------- */
  /* LOAD COUNTING SETTINGS + HISTORY                                       */
  /* ---------------------------------------------------------------------- */

  useEffect(() => {
    let mounted = true;

    const loadCountingData = async () => {
      try {
        const [settingsResponse, summariesResponse] = await Promise.all([
          getCountingSettings(),
          getCountingSummaries({ limit: 100 }),
        ]);

        if (!mounted) return;

        const savedInterval = Number(
          settingsResponse?.data?.interval_minutes || 5,
        );

        if ([5, 10, 15, 30, 60].includes(savedInterval)) {
          setIntervalMinutes(savedInterval);
        }

        setEvents(
          Array.isArray(summariesResponse?.data)
            ? summariesResponse.data
            : [],
        );
      } catch (error) {
        console.error(
          "Counting Management initial data error:",
          error,
        );
      }
    };

    loadCountingData();

    const historyTimer = window.setInterval(async () => {
      try {
        const response = await getCountingSummaries({
          limit: 100,
        });

        if (mounted) {
          setEvents(
            Array.isArray(response?.data)
              ? response.data
              : [],
          );
        }
      } catch (error) {
        console.error(
          "Counting history refresh error:",
          error,
        );
      }
    }, 15000);

    return () => {
      mounted = false;
      window.clearInterval(historyTimer);
    };
  }, []);


  /* ---------------------------------------------------------------------- */
  /* LOAD CAMERAS                                                           */
  /* ---------------------------------------------------------------------- */

  useEffect(() => {
    let mounted = true;

    const loadCameras = async () => {
      setCameraLoading(true);

      try {
        const response =
          await getCameras();

        if (
          mounted &&
          response?.ok
        ) {
          const cameras =
            Array.isArray(response.data)
              ? response.data
              : [];

          setCameraList(cameras);
        }
      } catch (error) {
        console.error(
          "Counting Management camera list error:",
          error,
        );
      } finally {
        if (mounted) {
          setCameraLoading(false);
        }
      }
    };

    loadCameras();

    return () => {
      mounted = false;
    };
  }, []);


  /* ---------------------------------------------------------------------- */
  /* COUNTING MONITORING CONTROL                                            */
  /* ---------------------------------------------------------------------- */

  const selectedCameraIds = useMemo(
    () =>
      [
        ...new Set(
          selectedSlots
            .filter(Boolean)
            .map((cameraId) => Number(cameraId))
            .filter(
              (cameraId) =>
                Number.isInteger(cameraId) && cameraId > 0,
            ),
        ),
      ],
    [selectedSlots],
  );

  useEffect(() => {
    let mounted = true;

    const loadMonitoringStatus = async () => {
      try {
        const response = await getCountingMonitoringStatus();
        if (!mounted) return;

        const data = response?.data || {};
        const runningIds =
          data.running_camera_ids ||
          data.active_camera_ids ||
          data.camera_ids ||
          [];

        const normalizedRunningIds = (Array.isArray(runningIds) ? runningIds : [])
          .map((value) => Number(value))
          .filter((value) => Number.isInteger(value) && value > 0);

        setMonitoringEnabled(
          Boolean(data.enabled ?? data.running ?? normalizedRunningIds.length > 0),
        );

        // If monitoring is still running on the backend but local storage was
        // cleared/empty, restore those active cameras into visible slots.
        if (normalizedRunningIds.length > 0) {
          setSelectedSlots((previous) => {
            if (previous.some(Boolean)) return previous;

            const restored = Array(MAX_SLOTS).fill("");
            normalizedRunningIds.slice(0, MAX_SLOTS).forEach((cameraId, index) => {
              restored[index] = String(cameraId);
            });
            return restored;
          });
        }
      } catch (error) {
        console.error("Counting monitoring status error:", error);
      }
    };

    loadMonitoringStatus();

    return () => {
      mounted = false;
    };
  }, []);

  const handleToggleMonitoring = async () => {
    if (monitoringLoading) return;

    if (!monitoringEnabled && selectedCameraIds.length === 0) {
      alert("Select at least one camera before starting monitoring.");
      return;
    }

    try {
      setMonitoringLoading(true);

      if (monitoringEnabled) {
        await stopCountingMonitoring(selectedCameraIds);
        setMonitoringEnabled(false);
      } else {
        await startCountingMonitoring(selectedCameraIds);
        setMonitoringEnabled(true);
      }
    } catch (error) {
      console.error("Counting monitoring toggle error:", error);
      alert(
        error?.message ||
          `Could not ${monitoringEnabled ? "stop" : "start"} counting monitoring.`,
      );
    } finally {
      setMonitoringLoading(false);
    }
  };

  // While Monitoring is ON, camera selection changes are synchronized with
  // counting_service.py. startCountingMonitoring() starts newly selected
  // cameras and the backend stops workers that are no longer selected.
  useEffect(() => {
    if (!monitoringEnabled || monitoringLoading) return undefined;

    if (selectedCameraIds.length === 0) {
      const stopAll = async () => {
        try {
          setMonitoringLoading(true);
          await stopCountingMonitoring([]);
          setMonitoringEnabled(false);
        } catch (error) {
          console.error("Stop empty counting selection error:", error);
        } finally {
          setMonitoringLoading(false);
        }
      };

      stopAll();
      return undefined;
    }

    const syncId = ++monitoringSyncRef.current;
    const timer = window.setTimeout(async () => {
      try {
        await startCountingMonitoring(selectedCameraIds);
      } catch (error) {
        if (syncId === monitoringSyncRef.current) {
          console.error("Counting camera sync error:", error);
        }
      }
    }, 250);

    return () => window.clearTimeout(timer);
  }, [monitoringEnabled, selectedCameraIds]);


  /* ---------------------------------------------------------------------- */
  /* LIVE COUNTS FOR SELECTED CAMERAS                                       */
  /* ---------------------------------------------------------------------- */

  useEffect(() => {
    let mounted = true;

    const liveCameraIds = selectedCameraIds.map((cameraId) =>
      String(cameraId),
    );

    if (!monitoringEnabled || !liveCameraIds.length) {
      // Realtime cards belong to the current Monitoring ON session only.
      // Monitoring OFF always shows 0, and the next ON session starts at 0.
      setLiveCounts({});
      return undefined;
    }

    const loadLiveCounts = async () => {
      const results = await Promise.allSettled(
        liveCameraIds.map((cameraId) =>
          getCameraCountingLiveCount(cameraId),
        ),
      );

      if (!mounted) return;

      const next = {};

      results.forEach((result, index) => {
        if (
          result.status === "fulfilled" &&
          result.value?.ok !== false &&
          result.value?.data
        ) {
          next[liveCameraIds[index]] =
            result.value.data;
        }
      });

      setLiveCounts(next);
    };

    loadLiveCounts();

    const timer = window.setInterval(
      loadLiveCounts,
      1000,
    );

    return () => {
      mounted = false;
      window.clearInterval(timer);
    };
  }, [monitoringEnabled, selectedCameraIds]);


  const handleIntervalChange = async (nextInterval) => {
    if (
      intervalSaving ||
      ![5, 10, 15, 30, 60].includes(Number(nextInterval))
    ) {
      return;
    }

    const previousInterval = intervalMinutes;

    try {
      setIntervalSaving(true);
      setIntervalMinutes(Number(nextInterval));

      const response = await updateCountingSettings(
        Number(nextInterval),
      );

      const savedInterval = Number(
        response?.data?.interval_minutes || nextInterval,
      );

      setIntervalMinutes(savedInterval);
    } catch (error) {
      console.error(
        "Counting interval update error:",
        error,
      );

      setIntervalMinutes(previousInterval);

      alert(
        error?.message ||
          "Could not update counting interval.",
      );
    } finally {
      setIntervalSaving(false);
    }
  };


  /* ---------------------------------------------------------------------- */
  /* PROTECT LAYOUT VALUE                                                   */
  /* ---------------------------------------------------------------------- */

  useEffect(() => {
    if (!setCountingLayout) {
      return;
    }

    if (
      ![1, 2, 4, 8].includes(
        Number(countingLayout),
      )
    ) {
      setCountingLayout(4);
    }
  }, [
    countingLayout,
    setCountingLayout,
  ]);


  /* ---------------------------------------------------------------------- */
  /* SELECTED CAMERA COUNT                                                  */
  /* ---------------------------------------------------------------------- */

  const monitoredCount =
    useMemo(
      () =>
        selectedSlots.filter(Boolean).length,
      [selectedSlots],
    );


  /* ---------------------------------------------------------------------- */
  /* UI                                                                     */
  /* ---------------------------------------------------------------------- */

  return (
    <div className="w-full min-w-0 overflow-x-hidden pb-1 text-white">
      {/* 1 / 2 / 4 / 8 CAMERA GRID */}

      <CountingCameraGrid
        layout={safeLayout}
        cameraList={cameraList}
        selectedSlots={selectedSlots}
        setSelectedSlots={setSelectedSlots}
        liveCounts={liveCounts}
        monitoringEnabled={monitoringEnabled}
      />

      {/* REAL-TIME COUNT SUMMARY */}

      <RealtimeCarrySummary
        liveCounts={liveCounts}
        monitoredCount={monitoredCount}
      />

      {/* MONITORING / EXPORT / RECORD / EMAIL ACTIONS */}

      <CountingQuickActions
        events={events}
        monitoredCount={monitoredCount}
        monitoringEnabled={monitoringEnabled}
        monitoringLoading={monitoringLoading}
        onToggleMonitoring={handleToggleMonitoring}
      />

      {/* LABOR TRANSFER EVENTS + ALERTS */}

      <div className="mt-2 grid min-w-0 grid-cols-[minmax(0,1fr)_280px] gap-2 2xl:grid-cols-[minmax(0,1fr)_320px]">
        <CarryEventsTable
          events={events}
          intervalMinutes={intervalMinutes}
          intervalSaving={intervalSaving}
          onIntervalChange={handleIntervalChange}
        />

        <CarryAlertsPanel />
      </div>
    </div>
  );
}
