import { useState } from "react";
import { Outlet, useLocation } from "react-router-dom";

import Sidebar from "../components/Sidebar";
import Header from "../components/Header";

/* -------------------------------------------------------------------------- */
/*                         ACTIVE PAGE FOR HEADER                             */
/* -------------------------------------------------------------------------- */

function getActivePage(pathname) {
  /* Zones & Lines */
  if (pathname.includes("/setup/zones")) {
    return "zones";
  }

  /* Camera Management */
  if (pathname.includes("camera-management")) {
    return "camera-management";
  }

  /* Face Enrollment */
  if (pathname.includes("face-enrollment")) {
    return "face";
  }

  /* Enrolled Persons */
  if (pathname.includes("enrolled-persons")) {
    return "enrolled-persons";
  }

  /* Notifications & Alerts */
  if (pathname.includes("notifications-alerts")) {
    return "notifications";
  }

  /* Email Settings */
  if (pathname.includes("email-settings")) {
    return "email";
  }

  /* User Management */
  if (pathname.includes("user-management")) {
    return "user-management";
  }

  /* Live Monitoring */
  if (pathname.includes("live-monitoring")) {
    return "live";
  }

  /* Counting Management
     IMPORTANT:
     We only use "counting".
  */
  if (pathname.includes("counting-management")) {
    return "counting";
  }

  /*
   * Ops Board / Arrivals / History & Reports
   * do not use the common top Header.
   */
  return "common";
}

/* -------------------------------------------------------------------------- */
/*                         MAIN DASHBOARD LAYOUT                              */
/* -------------------------------------------------------------------------- */

export default function Dashboard() {
  const { pathname } = useLocation();

  const activePage =
    getActivePage(pathname);

  /* ------------------------------------------------------------------------ */
  /* HIDE COMMON HEADER ON PAGES WITH THEIR OWN HEADER                        */
  /* ------------------------------------------------------------------------ */

  const hideGlobalHeader = [
    "/ops",
    "/arrivals",
    "/history",
  ].includes(pathname);

  /* ------------------------------------------------------------------------ */
  /* CAMERA STATE                                                             */
  /* ------------------------------------------------------------------------ */

  const [
    selectedCamera,
    setSelectedCamera,
  ] = useState(null);

  /* ------------------------------------------------------------------------ */
  /* LIVE MONITORING STATE                                                    */
  /* ------------------------------------------------------------------------ */

  const [
    liveSelectedEvents,
    setLiveSelectedEvents,
  ] = useState([
    "All Events",
  ]);

  const [
    liveLayout,
    setLiveLayout,
  ] = useState(4);

  /* ------------------------------------------------------------------------ */
  /* COUNTING MANAGEMENT STATE                                                */
  /* ------------------------------------------------------------------------ */

  /*
   * Counting Management has its own layout.
   *
   * This means changing Counting layout does not change
   * Live Monitoring layout.
   */
  const [
    countingLayout,
    setCountingLayout,
  ] = useState(4);

  /* ------------------------------------------------------------------------ */
  /* MOBILE SIDEBAR                                                           */
  /* ------------------------------------------------------------------------ */

  /*
   * Code 2 responsive functionality.
   *
   * false = sidebar closed on mobile
   * true  = sidebar open on mobile
   */
  const [
    menuOpen,
    setMenuOpen,
  ] = useState(false);

  /* ------------------------------------------------------------------------ */
  /* UI                                                                       */
  /* ------------------------------------------------------------------------ */

  return (
    <div className="dashboard-shell min-h-screen w-full bg-[#020817] text-white">

      <div className="flex min-h-screen w-full flex-col lg:flex-row">

        {/* ---------------------------------------------------------------- */}
        {/* SIDEBAR                                                          */}
        {/* ---------------------------------------------------------------- */}

        <Sidebar
          open={menuOpen}
          onNavigate={() =>
            setMenuOpen(false)
          }
        />

        {/* ---------------------------------------------------------------- */}
        {/* MAIN CONTENT                                                     */}
        {/* ---------------------------------------------------------------- */}

        <main className="min-w-0 flex-1 overflow-x-hidden p-2 sm:p-3">

          {/* -------------------------------------------------------------- */}
          {/* TOP HEADER                                                     */}
          {/* Hidden on Ops Board, Arrivals and History & Reports           */}
          {/* -------------------------------------------------------------- */}

          {!hideGlobalHeader && (
            <Header
              activePage={
                activePage
              }

              selectedCamera={
                selectedCamera
              }
              setSelectedCamera={
                setSelectedCamera
              }

              liveSelectedEvents={
                liveSelectedEvents
              }
              setLiveSelectedEvents={
                setLiveSelectedEvents
              }

              liveLayout={
                liveLayout
              }
              setLiveLayout={
                setLiveLayout
              }

              countingLayout={
                countingLayout
              }
              setCountingLayout={
                setCountingLayout
              }

              menuOpen={
                menuOpen
              }
              onMenuClick={() =>
                setMenuOpen(
                  (previous) =>
                    !previous
                )
              }
            />
          )}

          {/* -------------------------------------------------------------- */}
          {/* CHILD ROUTES                                                   */}
          {/* -------------------------------------------------------------- */}

          <Outlet
            context={{
              selectedCamera,
              setSelectedCamera,

              liveSelectedEvents,
              setLiveSelectedEvents,

              liveLayout,
              setLiveLayout,

              countingLayout,
              setCountingLayout,
            }}
          />

        </main>
      </div>
    </div>
  );
}
