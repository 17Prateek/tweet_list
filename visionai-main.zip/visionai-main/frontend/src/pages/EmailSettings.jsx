import { useEffect, useState } from "react";
import {
  AlertTriangle,
  Bell,
  Briefcase,
  CalendarDays,
  FileText,
  Flame,
  Mail,
  Pencil,
  Send,
  Plus,
  Shield,
  Trash2,
  Truck,
  User,
  VideoOff,
  Zap,
} from "lucide-react";

import {
  getEmailRecipients,
  createEmailRecipient,
  updateEmailRecipient,
  deleteEmailRecipient,
  sendTestEmailRecipient,
} from "../data/api";

const ALERT_TYPES = [
  "All Alerts",
  "Helmet Missing",
  "Vest Missing",
  "Safety Shoes Missing",
  "Welding Suit Missing",
  "Arcflash Suit Missing",
  "Restricted Zone",
  "Vehicle Over Limit",
  "Camera Offline",
  "Daily Summary",
  "Weekly Report",
];

const ALERT_CONFIG = {
  "All Alerts": {
    description: "Notify recipients for every enabled alert",
    icon: Bell,
    color: "bg-blue-600",
    enabled: true,
  },
  "Helmet Missing": {
    description: "Alert when helmet is not detected",
    icon: AlertTriangle,
    color: "bg-yellow-500",
    enabled: true,
  },
  "Vest Missing": {
    description: "Alert when safety vest is not detected",
    icon: Shield,
    color: "bg-orange-500",
    enabled: true,
  },
  "Safety Shoes Missing": {
    description: "Alert when safety shoes are not detected",
    icon: Shield,
    color: "bg-cyan-500",
    enabled: true,
  },
  "Welding Suit Missing": {
    description: "Alert when welding suit is not detected",
    icon: Flame,
    color: "bg-red-500",
    enabled: true,
  },
  "Arcflash Suit Missing": {
    description: "Alert when arcflash suit is not detected",
    icon: Zap,
    color: "bg-purple-600",
    enabled: true,
  },
  "Restricted Zone": {
    description: "Alert when a person is confirmed inside a restricted zone",
    icon: Shield,
    color: "bg-rose-600",
    enabled: true,
  },
  "Vehicle Over Limit": {
    description: "Alert when a vehicle stays in a zone past its time limit",
    icon: Truck,
    color: "bg-amber-600",
    enabled: true,
  },
  "Camera Offline": {
    description: "Alert when a monitored camera stops sending video",
    icon: VideoOff,
    color: "bg-slate-500",
    enabled: true,
  },
  "Daily Summary": {
    description: "Daily summary of compliance statistics",
    icon: CalendarDays,
    color: "bg-teal-500",
    enabled: true,
  },
  "Weekly Report": {
    description: "Weekly compliance report",
    icon: FileText,
    color: "bg-violet-600",
    enabled: false,
  },
};

const BADGE_STYLE = {
  "All Alerts": "border-blue-400/30 bg-blue-500/20 text-blue-200",
  "Helmet Missing": "border-yellow-400/30 bg-yellow-500/20 text-yellow-200",
  "Vest Missing": "border-orange-400/30 bg-orange-500/20 text-orange-200",
  "Safety Shoes Missing": "border-cyan-400/30 bg-cyan-500/20 text-cyan-200",
  "Welding Suit Missing": "border-red-400/30 bg-red-500/20 text-red-200",
  "Arcflash Suit Missing": "border-purple-400/30 bg-purple-500/20 text-purple-200",
  "Restricted Zone": "border-rose-400/30 bg-rose-500/20 text-rose-200",
  "Vehicle Over Limit": "border-amber-400/30 bg-amber-500/20 text-amber-200",
  "Camera Offline": "border-slate-400/30 bg-slate-500/20 text-slate-200",
  "Daily Summary": "border-teal-400/30 bg-teal-500/20 text-teal-200",
  "Weekly Report": "border-violet-400/30 bg-violet-500/20 text-violet-200",
};

const initialAlerts = ALERT_TYPES.map((title, index) => ({
  id: index + 1,
  title,
  ...ALERT_CONFIG[title],
}));

const emptyForm = {
  email: "",
  name: "",
  position: "",
  alertType: "All Alerts",
  status: "Active",
};

const inputClass =
  "h-11 w-full rounded-lg border border-[#19405f] bg-[#061827] px-3 text-[12px] text-white outline-none transition placeholder:text-slate-500 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20";

const iconInputClass = `${inputClass} pl-10`;

function Card({ children, className = "" }) {
  return (
    <section
      className={`rounded-lg border border-[#17405f] bg-[#03111f] shadow-[0_14px_38px_rgba(0,0,0,0.22)] ${className}`}
    >
      {children}
    </section>
  );
}

function Toggle({ enabled, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={enabled}
      className={`relative h-5 w-9 shrink-0 rounded-full transition focus:outline-none focus:ring-2 focus:ring-blue-500/60 ${
        enabled ? "bg-emerald-500" : "bg-slate-700"
      }`}
    >
      <span
        className={`absolute top-1 h-3 w-3 rounded-full bg-white transition ${
          enabled ? "right-1" : "left-1"
        }`}
      />
    </button>
  );
}

function Field({ label, icon: Icon, children }) {
  return (
    <label className="block">
      <span className="mb-2 block text-[12px] font-semibold text-slate-200">
        {label}
      </span>
      <div className="relative">
        {Icon && (
          <Icon
            size={16}
            className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
          />
        )}
        {children}
      </div>
    </label>
  );
}

function AlertBadge({ type }) {
  return (
    <span
      className={`inline-flex w-fit rounded-md border px-2.5 py-1 text-[11px] font-bold ${
        BADGE_STYLE[type] || BADGE_STYLE["All Alerts"]
      }`}
    >
      {type}
    </span>
  );
}

function StatusBadge({ status }) {
  const active = status === "Active";

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-[11px] font-bold ${
        active
          ? "bg-emerald-500/15 text-emerald-300"
          : "bg-slate-500/15 text-slate-300"
      }`}
    >
      <span
        className={`h-1.5 w-1.5 rounded-full ${
          active ? "bg-emerald-400" : "bg-slate-400"
        }`}
      />
      {status}
    </span>
  );
}

export default function EmailSettings() {
  const [alerts, setAlerts] = useState(initialAlerts);
  const [recipients, setRecipients] = useState([]);

  const [form, setForm] = useState(emptyForm);
  const [editForm, setEditForm] = useState(emptyForm);
  const [editingRecipient, setEditingRecipient] = useState(null);

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [testingRecipientId, setTestingRecipientId] = useState(null);

  const [popupType, setPopupType] = useState(null);
  const [popupMessage, setPopupMessage] = useState("");
  const [deleteRecipientId, setDeleteRecipientId] = useState(null);
  const [deleteRecipientEmail, setDeleteRecipientEmail] = useState("");

  useEffect(() => {
    loadRecipients();
  }, []);

  const showMessage = (message) => {
    setPopupMessage(message);
    setPopupType("message");
  };

  const showSuccess = (message) => {
    setPopupMessage(message);
    setPopupType("success");
  };

  const closePopup = () => {
    setPopupType(null);
    setPopupMessage("");
    setDeleteRecipientId(null);
    setDeleteRecipientEmail("");
    setEditingRecipient(null);
    setEditForm(emptyForm);
  };

  const loadRecipients = async () => {
    setLoading(true);

    try {
      const res = await getEmailRecipients();

      if (res.ok) {
        setRecipients(res.data || []);
      } else {
        showMessage(res.message || "Failed to load email recipients");
      }
    } catch (error) {
      showMessage(error.message || "Failed to load email recipients");
    } finally {
      setLoading(false);
    }
  };

  const handleChange = ({ target }) => {
    setForm((prev) => ({ ...prev, [target.name]: target.value }));
  };

  const handleEditChange = ({ target }) => {
    setEditForm((prev) => ({ ...prev, [target.name]: target.value }));
  };

  const resetForm = () => {
    setForm(emptyForm);
  };

  const validateRecipientForm = (recipientForm, ignoredRecipientId = null) => {
    const email = recipientForm.email.trim();
    const name = recipientForm.name.trim();
    const position = recipientForm.position.trim();

    if (!email || !name || !position) {
      return "Email, full name, and position are required.";
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return "Please enter a valid email address.";
    }

    const alreadyExists = recipients.some(
      (recipient) =>
        recipient.email.toLowerCase() === email.toLowerCase() &&
        recipient.id !== ignoredRecipientId
    );

    if (alreadyExists) {
      return "This email already exists in the recipient list.";
    }

    return "";
  };

  const handleAddRecipient = async (event) => {
    event.preventDefault();

    const validationError = validateRecipientForm(form);

    if (validationError) {
      showMessage(validationError);
      return;
    }

    const recipientData = {
      email: form.email.trim(),
      name: form.name.trim(),
      position: form.position.trim(),
      alertType: form.alertType,
      status: form.status,
    };

    setSaving(true);

    try {
      const res = await createEmailRecipient(recipientData);

      if (res.ok) {
        setRecipients((prev) => [res.data, ...prev]);
        resetForm();
        showSuccess(`Recipient "${recipientData.email}" have been added successfully.`);
      } else {
        showMessage(res.message || "Failed to add email recipient");
      }
    } catch (error) {
      showMessage(error.message || "Failed to add email recipient");
    } finally {
      setSaving(false);
    }
  };

  const editRecipient = (recipient) => {
    setEditingRecipient(recipient);
    setEditForm({
      email: recipient.email || "",
      name: recipient.name || "",
      position: recipient.position || "",
      alertType: recipient.alertType || "All Alerts",
      status: recipient.status || "Active",
    });
    setPopupType("editRecipient");
  };

  const handleEditSubmit = async (event) => {
    event.preventDefault();

    const validationError = validateRecipientForm(editForm, editingRecipient?.id);

    if (validationError) {
      showMessage(validationError);
      return;
    }

    await handleUpdateRecipient();
  };

  const handleUpdateRecipient = async () => {
    if (!editingRecipient) {
      showMessage("No recipient selected for update.");
      return;
    }

    const recipientData = {
      email: editForm.email.trim(),
      name: editForm.name.trim(),
      position: editForm.position.trim(),
      alertType: editForm.alertType,
      status: editForm.status,
    };

    setSaving(true);

    try {
      const res = await updateEmailRecipient(editingRecipient.id, recipientData);

      if (res.ok) {
        setRecipients((prev) =>
          prev.map((recipient) =>
            recipient.id === editingRecipient.id ? res.data : recipient
          )
        );

        setEditingRecipient(null);
        setEditForm(emptyForm);
        showSuccess(`Recipient "${recipientData.email}" have been updated successfully.`);
      } else {
        showMessage(res.message || "Failed to update email recipient");
      }
    } catch (error) {
      showMessage(error.message || "Failed to update email recipient");
    } finally {
      setSaving(false);
    }
  };

  const openDeleteRecipientPopup = (recipient) => {
    setDeleteRecipientId(recipient.id);
    setDeleteRecipientEmail(recipient.email || "");
    setPopupMessage(
      `Are you sure you want to delete recipient "${recipient.email || "this recipient"}"?`
    );
    setPopupType("confirmDelete");
  };

  const handleDeleteRecipient = async () => {
    setSaving(true);

    try {
      const res = await deleteEmailRecipient(deleteRecipientId);

      if (res.ok) {
        setRecipients((prev) =>
          prev.filter((recipient) => recipient.id !== deleteRecipientId)
        );

        const deletedEmail = deleteRecipientEmail || "Recipient";
        setDeleteRecipientId(null);
        setDeleteRecipientEmail("");

        showSuccess(`Recipient "${deletedEmail}" have been deleted successfully.`);
      } else {
        showMessage(res.message || "Failed to delete email recipient");
      }
    } catch (error) {
      showMessage(error.message || "Failed to delete email recipient");
    } finally {
      setSaving(false);
    }
  };

  const handleTestEmail = async (recipient) => {
    if (!recipient?.id) {
      showMessage("No recipient selected for test email.");
      return;
    }

    setTestingRecipientId(recipient.id);

    try {
      const res = await sendTestEmailRecipient(recipient.id);

      if (res.ok) {
        showSuccess(
          res.message ||
            `Testing successful message have been sent to "${recipient.email}".`
        );
      } else {
        showMessage(res.message || "Failed to send test email.");
      }
    } catch (error) {
      showMessage(error.message || "Failed to send test email.");
    } finally {
      setTestingRecipientId(null);
    }
  };

  const toggleAlert = (id) => {
    setAlerts((prev) =>
      prev.map((alert) =>
        alert.id === id ? { ...alert, enabled: !alert.enabled } : alert
      )
    );
  };

  return (
    <main className="relative min-h-screen w-full overflow-x-hidden bg-[#020914] p-3 text-white sm:p-0.5 xl:p-0.5">
      <div className="mx-auto grid w-full max-w-[1600px] grid-cols-1 gap-2 lg:grid-cols-[minmax(320px,360px)_minmax(0,1fr)] xl:gap-2">
        <Card className="h-full min-w-0 p-4 sm:p-5">
          <div className="mb-2 flex items-start justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-white sm:text-lg">
                Add Email Recipient
              </h2>
              <p className="mt-1 text-[11px] leading-5 text-slate-400">
                Add receiver email details for alerts.
              </p>
            </div>
          </div>

          <form onSubmit={handleAddRecipient} className="space-y-4">
            <Field label="Email Address" icon={Mail}>
              <input
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                placeholder="receiver@company.com"
                className={iconInputClass}
              />
            </Field>

            <Field label="Full Name" icon={User}>
              <input
                name="name"
                value={form.name}
                onChange={handleChange}
                placeholder="Enter full name"
                className={iconInputClass}
              />
            </Field>

            <Field label="Position" icon={Briefcase}>
              <input
                name="position"
                value={form.position}
                onChange={handleChange}
                placeholder="Enter position"
                className={iconInputClass}
              />
            </Field>

            <Field label="Alert Type" icon={Bell}>
              <select
                name="alertType"
                value={form.alertType}
                onChange={handleChange}
                className={iconInputClass}
              >
                {ALERT_TYPES.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Status">
              <select
                name="status"
                value={form.status}
                onChange={handleChange}
                className={inputClass}
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </Field>

            <button
              type="submit"
              disabled={saving}
              className="flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-blue-600 text-[12px] font-bold text-white shadow-lg shadow-blue-950/40 transition hover:bg-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-400/70 disabled:cursor-not-allowed disabled:opacity-60"
            >
              <Plus size={18} />
              {saving ? "Saving..." : "Add Recipient"}
            </button>
          </form>
        </Card>

        <Card className="h-full min-w-0 overflow-hidden">
          <div className="border-b border-[#17405f] p-3 sm:p-3">
            <h2 className="text-base font-bold sm:text-lg">Alert Settings</h2>
            <p className="mt-1 text-[11px] text-slate-400">
              Only these alert types are available for email notifications.
            </p>
          </div>

          <div className="divide-y divide-[#17405f] p-2">
            {alerts.map(({ id, title, description, icon: Icon, color, enabled }) => (
              <div
                key={title}
                className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-md px-2 py-4 transition hover:bg-white/[0.03] sm:grid-cols-[auto_minmax(180px,0.45fr)_minmax(220px,1fr)_auto] sm:px-4"
              >
                <span className={`grid h-8 w-8 place-items-center rounded-lg ${color}`}>
                  <Icon size={17} />
                </span>

                <p className="min-w-0 font-bold text-white">{title}</p>

                <p className="col-start-2 text-[11px] text-slate-400 sm:col-start-auto">
                  {description}
                </p>

                <Toggle enabled={enabled} onClick={() => toggleAlert(id)} />
              </div>
            ))}
          </div>
        </Card>

        <Card className="min-w-0 overflow-hidden lg:col-span-2">
          <div className="flex flex-col gap-3 border-b border-[#17405f] p-2 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-base font-bold sm:text-lg">Email Recipient List</h2>
              <p className="mt-1 text-[11px] text-slate-400">
                Added receiver email data appears here.
              </p>
            </div>

            <span className="w-fit rounded-md bg-blue-500/15 px-3 py-1.5 text-[12px] font-bold text-blue-300">
              {recipients.length} {recipients.length === 1 ? "Recipient" : "Recipients"}
            </span>
          </div>

          <div className="hidden p-1 md:block">
            <div className="h-[232px] w-full overflow-auto rounded-md border border-[#17405f]">
              <table className="w-full min-w-[920px] border-collapse text-left text-[12px]">
                <thead>
                  <tr className="sticky top-0 z-10 border-b border-[#17405f] bg-[#08243a] text-slate-300">
                    <th className="px-4 py-3 font-semibold">Email</th>
                    <th className="px-4 py-3 font-semibold">Name</th>
                    <th className="px-4 py-3 font-semibold">Position</th>
                    <th className="px-4 py-3 font-semibold">Alert Type</th>
                    <th className="px-4 py-3 font-semibold">Status</th>
                    <th className="px-12 py-3 text-right font-semibold">Actions</th>
                  </tr>
                </thead>

                <tbody className="bg-[#031522]">
                  {loading ? (
                    <tr>
                      <td colSpan={6} className="px-4 py-10 text-center text-slate-400">
                        Loading recipients...
                      </td>
                    </tr>
                  ) : recipients.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-4 py-10 text-center text-slate-400">
                        No recipients added yet.
                      </td>
                    </tr>
                  ) : (
                    recipients.map((recipient) => (
                      <tr
                        key={recipient.id}
                        className="border-b border-[#17405f] transition last:border-b-0 hover:bg-[#08243a]/70"
                      >
                        <td
                          className="px-3 py-3 font-semibold text-white"
                          title={recipient.email}
                        >
                          <div className="flex min-w-0 items-center gap-2">
                            <Mail size={14} className="shrink-0 text-slate-300" />
                            <span className="break-all">{recipient.email}</span>
                          </div>
                        </td>

                        <td
                          className="px-4 py-3 font-semibold text-white"
                          title={recipient.name}
                        >
                          {recipient.name}
                        </td>

                        <td
                          className="px-4 py-3 text-slate-200"
                          title={recipient.position}
                        >
                          {recipient.position}
                        </td>

                        <td className="px-4 py-3" title={recipient.alertType}>
                          <AlertBadge type={recipient.alertType} />
                        </td>

                        <td className="px-4 py-3" title={recipient.status}>
                          <StatusBadge status={recipient.status} />
                        </td>

                        <td className="px-4 py-3">
                          <div className="flex justify-end gap-2">
                            <button
                              type="button"
                              onClick={() => handleTestEmail(recipient)}
                              disabled={testingRecipientId === recipient.id}
                              className="rounded-md border border-emerald-500/60 p-1.5 text-emerald-400 transition hover:bg-emerald-500/10 disabled:cursor-not-allowed disabled:opacity-50"
                              aria-label={`Send test email to ${recipient.email}`}
                              title={`Test email: ${recipient.email}`}
                            >
                              <Send size={15} />
                            </button>

                            <button
                              type="button"
                              onClick={() => editRecipient(recipient)}
                              className="rounded-md border border-blue-500/60 p-1.5 text-blue-400 transition hover:bg-blue-500/10"
                              aria-label={`Edit ${recipient.email}`}
                              title={`Edit: ${recipient.name || recipient.email}`}
                            >
                              <Pencil size={15} />
                            </button>

                            <button
                              type="button"
                              onClick={() => openDeleteRecipientPopup(recipient)}
                              className="rounded-md border border-red-500/60 p-1.5 text-red-400 transition hover:bg-red-500/10"
                              aria-label={`Delete ${recipient.email}`}
                              title={`Delete: ${recipient.name || recipient.email}`}
                            >
                              <Trash2 size={15} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="h-[420px] space-y-3 overflow-y-auto p-4 md:hidden">
            {loading ? (
              <div className="rounded-lg border border-[#17405f] bg-[#031522] p-6 text-center text-sm text-slate-400">
                Loading recipients...
              </div>
            ) : recipients.length === 0 ? (
              <div className="rounded-lg border border-[#17405f] bg-[#031522] p-6 text-center text-sm text-slate-400">
                No recipients added yet.
              </div>
            ) : (
              recipients.map((recipient) => (
                <article
                  key={recipient.id}
                  className="rounded-lg border border-[#17405f] bg-[#031522] p-4"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-bold text-white" title={recipient.name}>
                        {recipient.name}
                      </p>
                      <p
                        className="mt-1 break-all text-[12px] text-slate-300"
                        title={recipient.email}
                      >
                        {recipient.email}
                      </p>
                    </div>

                    <StatusBadge status={recipient.status} />
                  </div>

                  <div className="mt-4 flex flex-wrap items-center gap-2">
                    <span className="rounded-md border border-slate-500/20 bg-slate-500/15 px-2.5 py-1 text-[11px] font-bold text-slate-200">
                      {recipient.position}
                    </span>

                    <AlertBadge type={recipient.alertType} />
                  </div>

                  <div className="mt-4 flex gap-2">
                    <button
                      type="button"
                      onClick={() => handleTestEmail(recipient)}
                      disabled={testingRecipientId === recipient.id}
                      title={`Test email: ${recipient.email}`}
                      className="flex flex-1 items-center justify-center gap-2 rounded-lg border border-emerald-500/50 py-2 text-[12px] font-bold text-emerald-300 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <Send size={15} /> Test
                    </button>

                    <button
                      type="button"
                      onClick={() => editRecipient(recipient)}
                      className="flex flex-1 items-center justify-center gap-2 rounded-lg border border-blue-500/50 py-2 text-[12px] font-bold text-blue-300"
                      title={`Edit: ${recipient.name || recipient.email}`}
                    >
                      <Pencil size={15} /> Edit
                    </button>

                    <button
                      type="button"
                      onClick={() => openDeleteRecipientPopup(recipient)}
                      className="flex flex-1 items-center justify-center gap-2 rounded-lg border border-red-500/50 py-2 text-[12px] font-bold text-red-300"
                      title={`Delete: ${recipient.name || recipient.email}`}
                    >
                      <Trash2 size={15} /> Delete
                    </button>
                  </div>
                </article>
              ))
            )}
          </div>
        </Card>
      </div>

      {popupType && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/45">
          <div className="w-[min(470px,calc(100vw-24px))] overflow-hidden rounded-2xl bg-[#3b82f6] shadow-2xl">
            <div className="bg-[#14336d] px-6 py-5 text-center">
              <h2 className="text-[17px] font-bold text-white">
                Paperless Management System States
              </h2>
            </div>

            <div className="px-10 py-8 text-center">
              {popupType === "editRecipient" && (
                <form onSubmit={handleEditSubmit} className="space-y-4 text-left">
                  <Field label="Email Address" icon={Mail}>
                    <input
                      name="email"
                      type="email"
                      value={editForm.email}
                      onChange={handleEditChange}
                      placeholder="receiver@company.com"
                      className={iconInputClass}
                    />
                  </Field>

                  <Field label="Full Name" icon={User}>
                    <input
                      name="name"
                      value={editForm.name}
                      onChange={handleEditChange}
                      placeholder="Enter full name"
                      className={iconInputClass}
                    />
                  </Field>

                  <Field label="Position" icon={Briefcase}>
                    <input
                      name="position"
                      value={editForm.position}
                      onChange={handleEditChange}
                      placeholder="Enter position"
                      className={iconInputClass}
                    />
                  </Field>

                  <Field label="Alert Type" icon={Bell}>
                    <select
                      name="alertType"
                      value={editForm.alertType}
                      onChange={handleEditChange}
                      className={iconInputClass}
                    >
                      {ALERT_TYPES.map((type) => (
                        <option key={type} value={type}>
                          {type}
                        </option>
                      ))}
                    </select>
                  </Field>

                  <Field label="Status">
                    <select
                      name="status"
                      value={editForm.status}
                      onChange={handleEditChange}
                      className={inputClass}
                    >
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </Field>

                  <div className="flex gap-3 pt-3">
                    <button
                      type="submit"
                      disabled={saving}
                      className="h-11 flex-1 rounded-lg bg-[#14336d] text-[14px] font-bold text-white hover:bg-[#102b5c] disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      Update
                    </button>

                    <button
                      type="button"
                      onClick={closePopup}
                      disabled={saving}
                      className="h-11 flex-1 rounded-lg bg-[#14336d] text-[14px] font-bold text-white hover:bg-[#102b5c] disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              )}

              {popupType === "confirmDelete" && (
                <>
                  <p className="mb-8 text-[13px] font-semibold text-white">
                    {popupMessage}
                  </p>

                  <div className="flex gap-3">
                    <button
                      onClick={handleDeleteRecipient}
                      disabled={saving}
                      className="h-11 flex-1 rounded-lg bg-[#14336d] text-[14px] font-bold text-white hover:bg-[#102b5c] disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      {saving ? "Deleting..." : "Confirm Delete"}
                    </button>

                    <button
                      onClick={closePopup}
                      disabled={saving}
                      className="h-11 flex-1 rounded-lg bg-[#14336d] text-[14px] font-bold text-white hover:bg-[#102b5c] disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      Cancel
                    </button>
                  </div>
                </>
              )}

              {(popupType === "success" || popupType === "message") && (
                <>
                  <p className="mb-8 text-[13px] font-semibold text-white">
                    {popupMessage}
                  </p>

                  <button
                    onClick={closePopup}
                    className="h-11 w-full rounded-lg bg-[#14336d] text-[14px] font-bold text-white hover:bg-[#102b5c]"
                  >
                    OK
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </main>
  );
}