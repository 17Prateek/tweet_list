import { useEffect, useMemo, useRef, useState } from "react";
import {
  Archive,
  CheckCircle,
  Download,
  Edit,
  Images,
  PauseCircle,
  Power,
  Search,
  Trash2,
  UserRound,
  X,
} from "lucide-react";

import {
  deleteEnrolledPerson,
  getEnrolledPerson,
  getEnrolledPersonImageUrl,
  getEnrolledPersons,
  getFaceEnrollmentStats,
  updateEnrolledPerson,
  updateEnrolledPersonStatus,
} from "../data/api";

/* -------------------------------------------------------------------------- */
/*                                HELPERS                                     */
/* -------------------------------------------------------------------------- */

function formatDateTime(value) {
  if (!value) return "—";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return String(value);
  }

  return date.toLocaleString([], {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function formatDateTimeTwoLines(value) {
  if (!value) return "—";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return String(value);
  }

  const datePart = date.toLocaleDateString([], {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });

  const timePart = date.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });

  return `${datePart}\n${timePart}`;
}

function normalizePerson(row = {}) {
  return {
    id: row.id,
    name: row.name || row.fullName || "Unknown",
    employeeId: row.employeeId || row.employee_id || "",
    department: row.department || "—",
    role: row.role || "—",
    status:
      row.status ||
      (row.isActive === false || row.is_active === false
        ? "Inactive"
        : "Active"),
    isActive:
      row.isActive ??
      row.is_active ??
      String(row.status || "").toLowerCase() !== "inactive",
    faceQuality: Number(
      row.faceQuality ??
        row.primaryQualityScore ??
        row.primary_quality_score ??
        0,
    ),
    images: Number(
      row.images ??
        row.totalImages ??
        row.total_images ??
        0,
    ),
    enrolledOnRaw:
      row.enrolledOn ||
      row.createdAt ||
      row.created_at ||
      null,
    enrolledOn: formatDateTimeTwoLines(
      row.enrolledOn ||
        row.createdAt ||
        row.created_at ||
        null,
    ),
    lastSeenRaw:
      row.lastSeen ||
      row.lastSeenAt ||
      row.last_seen_at ||
      null,
    lastSeen: formatDateTimeTwoLines(
      row.lastSeen ||
        row.lastSeenAt ||
        row.last_seen_at ||
        null,
    ),
    mobile: row.mobile || "",
    email: row.email || "",
    camera:
      row.camera ||
      row.cameraName ||
      row.camera_name ||
      "Unknown Camera",
    cameraId:
      row.cameraId ??
      row.camera_id ??
      null,
    image: row.image || "",
  };
}

/* -------------------------------------------------------------------------- */
/*                               STAT CARD                                    */
/* -------------------------------------------------------------------------- */

function StatCard({ item }) {
  const Icon = item.icon;

  const colors = {
    blue: "from-blue-700 to-blue-500",
    green: "from-emerald-700 to-emerald-500",
    amber: "from-amber-600 to-orange-500",
    purple: "from-violet-700 to-purple-500",
  };

  return (
    <div className="h-[92px] min-w-0 overflow-hidden rounded-lg border border-[#123250] bg-[#061421]/90 p-2 shadow-lg">
      <div className="flex h-full min-w-0 items-center gap-1">
        <div
          className={`grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-gradient-to-br ${
            colors[item.color]
          } 2xl:h-10 2xl:w-10`}
        >
          <Icon size={20} className="text-white" />
        </div>

        <div className="min-w-0 flex-1">
          <p className="max-w-full whitespace-normal break-words text-[10px] font-semibold uppercase leading-[11px] tracking-wide text-white/70 2xl:text-[10px] 2xl:leading-[12px]">
            {item.label}
          </p>

          <h3 className="mt-1 text-[16px] font-bold leading-none text-white 2xl:text-[18px]">
            {item.value}
          </h3>

          <div className="mt-1 flex min-w-0 flex-wrap items-center gap-1">
            <span className="text-[9px] leading-none text-white/60 2xl:text-[9px]">
              {item.note}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                         FACE QUALITY CARD                                  */
/* -------------------------------------------------------------------------- */

function FaceQualityCard({ value = 0 }) {
  const score = Number(value) || 0;

  return (
    <div className="h-[92px] min-w-0 overflow-hidden rounded-lg border border-[#123250] bg-[#061421]/90 p-2 shadow-lg">
      <div className="flex h-full min-w-0 items-center gap-1">
        <div className="grid h-14 w-14 shrink-0 place-items-center rounded-full border-[4px] border-emerald-500 2xl:h-16 2xl:w-16">
          <span className="text-[15px] font-bold leading-none text-white 2xl:text-[18px]">
            {score}%
          </span>
        </div>

        <div className="min-w-0 flex-1">
          <p className="whitespace-normal break-words text-[10px] font-semibold uppercase leading-[11px] tracking-wide text-white/70 2xl:text-[10px] 2xl:leading-[12px]">
            Face Quality Average
          </p>

          <p className="mt-1 whitespace-normal break-words text-[9px] leading-[10px] text-white/65 2xl:text-[9px] 2xl:leading-[11px]">
            Average image quality across all enrolled faces
          </p>
        </div>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                           QUALITY TEXT                                     */
/* -------------------------------------------------------------------------- */

function QualityText({ value }) {
  const score = Number(value) || 0;

  const label =
    score >= 90
      ? "Excellent"
      : score >= 75
        ? "Good"
        : score >= 60
          ? "Fair"
          : "Poor";

  const color =
    score >= 90
      ? "text-emerald-400"
      : score >= 75
        ? "text-green-400"
        : score >= 60
          ? "text-amber-400"
          : "text-red-400";

  return (
    <div className="leading-none">
      <p className="text-[10px] font-semibold text-white">
        {score}%
      </p>

      <p className={`mt-1 text-[8px] font-medium ${color}`}>
        {label}
      </p>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                             STATUS BADGE                                   */
/* -------------------------------------------------------------------------- */

function StatusBadge({ status }) {
  const styles = {
    Active:
      "border-emerald-500/60 bg-emerald-500/10 text-emerald-400",
    Inactive:
      "border-amber-500/60 bg-amber-500/10 text-amber-400",
    Archived:
      "border-violet-500/60 bg-violet-500/10 text-violet-400",
  };

  return (
    <span
      className={`inline-flex rounded border px-1 py-0.5 text-[8px] font-semibold ${
        styles[status] ||
        "border-white/20 bg-white/5 text-white/70"
      }`}
    >
      {status || "Unknown"}
    </span>
  );
}

/* -------------------------------------------------------------------------- */
/*                         MOBILE PERSON CARD                                 */
/* -------------------------------------------------------------------------- */

function MobilePersonCard({ person, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="w-full rounded-lg border border-[#123250] bg-[#061421]/90 p-1 text-left transition hover:bg-[#0b2238]"
    >
      <div className="flex items-center gap-1">
        {person.image ? (
          <img
            src={person.image}
            alt={person.name}
            className="h-9 w-9 shrink-0 rounded object-cover ring-1 ring-[#123250]"
          />
        ) : (
          <div className="grid h-9 w-9 shrink-0 place-items-center rounded bg-[#0b2238] ring-1 ring-[#123250]">
            <UserRound size={18} className="text-white/45" />
          </div>
        )}

        <div className="min-w-0 flex-1">
          <p className="truncate text-xs font-semibold text-white">
            {person.name}
          </p>

          <p className="text-[10px] text-white/60">
            {person.employeeId}
          </p>
        </div>

        <StatusBadge status={person.status} />
      </div>

      <div className="mt-1 grid grid-cols-2 gap-1 text-[10px] text-white/70">
        <p className="truncate">
          Dept: {person.department}
        </p>

        <p className="truncate">
          Role: {person.role}
        </p>

        <p>Quality: {person.faceQuality}%</p>
        <p>Images: {person.images}</p>

        <p className="col-span-2 truncate">
          Last Seen: {person.lastSeen.replace("\n", ", ")}
        </p>
      </div>
    </button>
  );
}

/* -------------------------------------------------------------------------- */
/*                              EDIT MODAL                                    */
/* -------------------------------------------------------------------------- */

function EditPersonModal({
  person,
  form,
  setForm,
  saving,
  error,
  onClose,
  onSave,
}) {
  if (!person) return null;

  return (
    <div className="fixed inset-0 z-[100] grid place-items-center bg-black/70 p-4">
      <div className="w-full max-w-lg rounded-xl border border-[#1e4265] bg-[#061421] p-4 shadow-2xl">
        <div className="flex items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-semibold text-white">
              Edit Person Details
            </h2>
            <p className="mt-1 text-[11px] text-white/50">
              Employee ID: {person.employeeId}
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            disabled={saving}
            className="grid h-8 w-8 place-items-center rounded-md border border-[#123250] text-white/60 hover:bg-white/5 hover:text-white"
          >
            <X size={15} />
          </button>
        </div>

        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <label className="space-y-1">
            <span className="text-[10px] font-semibold uppercase text-white/50">
              Full Name
            </span>
            <input
              value={form.fullName}
              onChange={(event) =>
                setForm((prev) => ({
                  ...prev,
                  fullName: event.target.value,
                }))
              }
              className="h-10 w-full rounded-md border border-[#123250] bg-[#020817] px-3 text-xs text-white outline-none focus:border-blue-500"
            />
          </label>

          <label className="space-y-1">
            <span className="text-[10px] font-semibold uppercase text-white/50">
              Department
            </span>
            <input
              value={form.department}
              onChange={(event) =>
                setForm((prev) => ({
                  ...prev,
                  department: event.target.value,
                }))
              }
              className="h-10 w-full rounded-md border border-[#123250] bg-[#020817] px-3 text-xs text-white outline-none focus:border-blue-500"
            />
          </label>

          <label className="space-y-1">
            <span className="text-[10px] font-semibold uppercase text-white/50">
              Role / Access
            </span>
            <input
              value={form.role}
              onChange={(event) =>
                setForm((prev) => ({
                  ...prev,
                  role: event.target.value,
                }))
              }
              className="h-10 w-full rounded-md border border-[#123250] bg-[#020817] px-3 text-xs text-white outline-none focus:border-blue-500"
            />
          </label>

          <label className="space-y-1">
            <span className="text-[10px] font-semibold uppercase text-white/50">
              Mobile
            </span>
            <input
              value={form.mobile}
              onChange={(event) =>
                setForm((prev) => ({
                  ...prev,
                  mobile: event.target.value,
                }))
              }
              className="h-10 w-full rounded-md border border-[#123250] bg-[#020817] px-3 text-xs text-white outline-none focus:border-blue-500"
            />
          </label>

          <label className="space-y-1 sm:col-span-2">
            <span className="text-[10px] font-semibold uppercase text-white/50">
              Email
            </span>
            <input
              type="email"
              value={form.email}
              onChange={(event) =>
                setForm((prev) => ({
                  ...prev,
                  email: event.target.value,
                }))
              }
              className="h-10 w-full rounded-md border border-[#123250] bg-[#020817] px-3 text-xs text-white outline-none focus:border-blue-500"
            />
          </label>
        </div>

        {error && (
          <p className="mt-3 rounded-md border border-red-500/30 bg-red-500/10 px-3 py-2 text-[11px] text-red-300">
            {error}
          </p>
        )}

        <div className="mt-4 flex justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            disabled={saving}
            className="h-9 rounded-md border border-[#123250] px-4 text-xs font-semibold text-white/70 hover:bg-white/5"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={onSave}
            disabled={saving}
            className="h-9 rounded-md bg-blue-600 px-4 text-xs font-semibold text-white hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {saving ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*                       ENROLLED PERSONS PAGE                                */
/* -------------------------------------------------------------------------- */

export default function EnrolledPersons() {
  const [people, setPeople] = useState([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("");
  const [roleFilter, setRoleFilter] = useState("");

  const [selectedPerson, setSelectedPerson] = useState(null);

  const [statsData, setStatsData] = useState({
    totalEnrolled: 0,
    activePersonnel: 0,
    inactivePersonnel: 0,
    archivedPersonnel: 0,
    faceQualityAverage: 0,
  });

  const [loading, setLoading] = useState(true);
  const [detailsLoading, setDetailsLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [pageError, setPageError] = useState("");

  const [editOpen, setEditOpen] = useState(false);
  const [editSaving, setEditSaving] = useState(false);
  const [editError, setEditError] = useState("");
  const [editForm, setEditForm] = useState({
    fullName: "",
    department: "",
    role: "",
    mobile: "",
    email: "",
  });

  const imageUrlsRef = useRef(new Set());

  const rememberObjectUrl = (url) => {
    if (url?.startsWith("blob:")) {
      imageUrlsRef.current.add(url);
    }

    return url;
  };

  const revokeObjectUrls = () => {
    imageUrlsRef.current.forEach((url) => {
      URL.revokeObjectURL(url);
    });

    imageUrlsRef.current.clear();
  };

  useEffect(() => {
    return () => {
      revokeObjectUrls();
    };
  }, []);

  const loadPersonImage = async (personId) => {
    if (!personId) return "";

    try {
      const imageUrl = await getEnrolledPersonImageUrl(personId);
      return rememberObjectUrl(imageUrl);
    } catch (error) {
      console.error(
        `Could not load face image for person ${personId}:`,
        error,
      );
      return "";
    }
  };

  const loadStats = async () => {
    try {
      const response = await getFaceEnrollmentStats();

      if (!response?.ok) {
        throw new Error(
          response?.message ||
            "Could not load enrolled person stats",
        );
      }

      setStatsData({
        totalEnrolled: Number(
          response.data?.totalEnrolled || 0,
        ),
        activePersonnel: Number(
          response.data?.activePersonnel || 0,
        ),
        inactivePersonnel: Number(
          response.data?.inactivePersonnel || 0,
        ),
        archivedPersonnel: Number(
          response.data?.archivedPersonnel || 0,
        ),
        faceQualityAverage: Number(
          response.data?.faceQualityAverage || 0,
        ),
      });
    } catch (error) {
      console.error("Enrolled person stats failed:", error);
    }
  };

  const loadPeople = async ({
    preserveSelectedId = null,
  } = {}) => {
    setLoading(true);
    setPageError("");

    try {
      const response = await getEnrolledPersons({
        search,
        status: statusFilter,
        department: departmentFilter,
        role: roleFilter,
      });

      const rows = Array.isArray(response?.data)
        ? response.data
        : [];

      const normalized = rows.map(normalizePerson);

      const withImages = await Promise.all(
        normalized.map(async (person) => ({
          ...person,
          image: await loadPersonImage(person.id),
        })),
      );

      setPeople(withImages);

      setSelectedPerson((current) => {
        const wantedId =
          preserveSelectedId ??
          current?.id ??
          withImages[0]?.id ??
          null;

        return (
          withImages.find(
            (person) => person.id === wantedId,
          ) ||
          withImages[0] ||
          null
        );
      });
    } catch (error) {
      console.error("Enrolled persons load failed:", error);
      setPageError(
        error?.message ||
          "Could not load enrolled persons",
      );
      setPeople([]);
      setSelectedPerson(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStats();
  }, []);

  useEffect(() => {
    const timeout = window.setTimeout(() => {
      loadPeople();
    }, 300);

    return () => {
      window.clearTimeout(timeout);
    };
  }, [
    search,
    statusFilter,
    departmentFilter,
    roleFilter,
  ]);

  const departments = useMemo(
    () =>
      Array.from(
        new Set(
          people
            .map((person) => person.department)
            .filter(Boolean),
        ),
      ).sort(),
    [people],
  );

  const roles = useMemo(
    () =>
      Array.from(
        new Set(
          people
            .map((person) => person.role)
            .filter(Boolean),
        ),
      ).sort(),
    [people],
  );

  const summaryCards = useMemo(() => {
    const total = statsData.totalEnrolled || 0;

    const percent = (value) =>
      total > 0
        ? `${((Number(value || 0) / total) * 100).toFixed(1)}% of total`
        : "0% of total";

    return [
      {
        label: "Total Enrolled Persons",
        value: statsData.totalEnrolled.toLocaleString(),
        note: "All Time",
        color: "blue",
        icon: UserRound,
      },
      {
        label: "Active Personnel",
        value: statsData.activePersonnel.toLocaleString(),
        note: percent(statsData.activePersonnel),
        color: "green",
        icon: CheckCircle,
      },
      {
        label: "Inactive Personnel",
        value: statsData.inactivePersonnel.toLocaleString(),
        note: percent(statsData.inactivePersonnel),
        color: "amber",
        icon: PauseCircle,
      },
      {
        label: "Archived Personnel Records",
        value: statsData.archivedPersonnel.toLocaleString(),
        note: "Archive backend not enabled yet",
        color: "purple",
        icon: Archive,
      },
    ];
  }, [statsData]);

  const handleRowClick = async (person) => {
    if (!person?.id) return;

    setSelectedPerson(person);
    setDetailsLoading(true);

    try {
      const response = await getEnrolledPerson(person.id);
      const normalized = normalizePerson(
        response?.data || {},
      );

      const image =
        person.image ||
        (await loadPersonImage(person.id));

      setSelectedPerson({
        ...normalized,
        image,
      });
    } catch (error) {
      console.error("Person details load failed:", error);
    } finally {
      setDetailsLoading(false);
    }
  };

  const handleExport = () => {
    if (!people.length) return;

    const escapeXml = (value) =>
      String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&apos;");

    const exportRows = people.map((person) => ({
      person: person.name || "",
      employeeId: person.employeeId || "",
      department: person.department || "",
      role: person.role || "",
      status: person.status || "",
      faceQuality: `${Number(person.faceQuality || 0)}%`,
      images: Number(person.images || 0),
      enrolledOn: formatDateTime(person.enrolledOnRaw),
      lastSeen:
        person.lastSeenRaw
          ? formatDateTime(person.lastSeenRaw)
          : "",
      mobile: person.mobile || "",
      email: person.email || "",
      camera: person.camera || "",
    }));

    const rowXml = exportRows
      .map(
        (row, index) => `
          <Row ss:AutoFitHeight="0" ss:Height="24">
            <Cell ss:StyleID="${index % 2 === 0 ? "DataEven" : "DataOdd"}"><Data ss:Type="String">${escapeXml(row.person)}</Data></Cell>
            <Cell ss:StyleID="${index % 2 === 0 ? "DataEven" : "DataOdd"}"><Data ss:Type="String">${escapeXml(row.employeeId)}</Data></Cell>
            <Cell ss:StyleID="${index % 2 === 0 ? "DataEven" : "DataOdd"}"><Data ss:Type="String">${escapeXml(row.department)}</Data></Cell>
            <Cell ss:StyleID="${index % 2 === 0 ? "DataEven" : "DataOdd"}"><Data ss:Type="String">${escapeXml(row.role)}</Data></Cell>
            <Cell ss:StyleID="${String(row.status).toLowerCase() === "active" ? "StatusActive" : "StatusInactive"}"><Data ss:Type="String">${escapeXml(row.status)}</Data></Cell>
            <Cell ss:StyleID="${index % 2 === 0 ? "CenterEven" : "CenterOdd"}"><Data ss:Type="String">${escapeXml(row.faceQuality)}</Data></Cell>
            <Cell ss:StyleID="${index % 2 === 0 ? "CenterEven" : "CenterOdd"}"><Data ss:Type="Number">${row.images}</Data></Cell>
            <Cell ss:StyleID="${index % 2 === 0 ? "DataEven" : "DataOdd"}"><Data ss:Type="String">${escapeXml(row.enrolledOn)}</Data></Cell>
            <Cell ss:StyleID="${index % 2 === 0 ? "DataEven" : "DataOdd"}"><Data ss:Type="String">${escapeXml(row.lastSeen)}</Data></Cell>
            <Cell ss:StyleID="${index % 2 === 0 ? "TextEven" : "TextOdd"}"><Data ss:Type="String">${escapeXml(row.mobile)}</Data></Cell>
            <Cell ss:StyleID="${index % 2 === 0 ? "DataEven" : "DataOdd"}"><Data ss:Type="String">${escapeXml(row.email)}</Data></Cell>
            <Cell ss:StyleID="${index % 2 === 0 ? "DataEven" : "DataOdd"}"><Data ss:Type="String">${escapeXml(row.camera)}</Data></Cell>
          </Row>`,
      )
      .join("");

    const worksheetXml = `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook
  xmlns="urn:schemas-microsoft-com:office:spreadsheet"
  xmlns:o="urn:schemas-microsoft-com:office:office"
  xmlns:x="urn:schemas-microsoft-com:office:excel"
  xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
  xmlns:html="http://www.w3.org/TR/REC-html40">

  <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
    <Title>Enrolled Persons</Title>
    <Subject>Face enrollment person records</Subject>
    <Author>Paperless AI PPE Monitoring System</Author>
  </DocumentProperties>

  <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
    <ProtectStructure>False</ProtectStructure>
    <ProtectWindows>False</ProtectWindows>
  </ExcelWorkbook>

  <Styles>
    <Style ss:ID="Default" ss:Name="Normal">
      <Alignment ss:Vertical="Center"/>
      <Font ss:FontName="Calibri" ss:Size="11"/>
    </Style>

    <Style ss:ID="Title">
      <Alignment ss:Horizontal="Left" ss:Vertical="Center"/>
      <Font ss:FontName="Calibri" ss:Size="16" ss:Bold="1" ss:Color="#FFFFFF"/>
      <Interior ss:Color="#0B2238" ss:Pattern="Solid"/>
    </Style>

    <Style ss:ID="Header">
      <Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/>
      <Borders>
        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#9FB3C8"/>
        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#9FB3C8"/>
        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#9FB3C8"/>
        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#9FB3C8"/>
      </Borders>
      <Font ss:FontName="Calibri" ss:Size="11" ss:Bold="1" ss:Color="#FFFFFF"/>
      <Interior ss:Color="#1565C0" ss:Pattern="Solid"/>
    </Style>

    <Style ss:ID="DataEven">
      <Alignment ss:Vertical="Center" ss:WrapText="1"/>
      <Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#D7E0EA"/></Borders>
      <Interior ss:Color="#F7FAFD" ss:Pattern="Solid"/>
    </Style>

    <Style ss:ID="DataOdd">
      <Alignment ss:Vertical="Center" ss:WrapText="1"/>
      <Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#D7E0EA"/></Borders>
      <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
    </Style>

    <Style ss:ID="TextEven">
      <Alignment ss:Vertical="Center"/>
      <Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#D7E0EA"/></Borders>
      <Interior ss:Color="#F7FAFD" ss:Pattern="Solid"/>
      <NumberFormat ss:Format="@"/>
    </Style>

    <Style ss:ID="TextOdd">
      <Alignment ss:Vertical="Center"/>
      <Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#D7E0EA"/></Borders>
      <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
      <NumberFormat ss:Format="@"/>
    </Style>

    <Style ss:ID="CenterEven">
      <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
      <Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#D7E0EA"/></Borders>
      <Interior ss:Color="#F7FAFD" ss:Pattern="Solid"/>
    </Style>

    <Style ss:ID="CenterOdd">
      <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
      <Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#D7E0EA"/></Borders>
      <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
    </Style>

    <Style ss:ID="StatusActive">
      <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
      <Font ss:Bold="1" ss:Color="#047857"/>
      <Interior ss:Color="#D1FAE5" ss:Pattern="Solid"/>
    </Style>

    <Style ss:ID="StatusInactive">
      <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
      <Font ss:Bold="1" ss:Color="#B45309"/>
      <Interior ss:Color="#FEF3C7" ss:Pattern="Solid"/>
    </Style>
  </Styles>

  <Worksheet ss:Name="Enrolled Persons">
    <Table>
      <Column ss:Width="120"/>
      <Column ss:Width="95"/>
      <Column ss:Width="100"/>
      <Column ss:Width="95"/>
      <Column ss:Width="75"/>
      <Column ss:Width="85"/>
      <Column ss:Width="60"/>
      <Column ss:Width="135"/>
      <Column ss:Width="135"/>
      <Column ss:Width="110"/>
      <Column ss:Width="190"/>
      <Column ss:Width="125"/>

      <Row ss:Height="28">
        <Cell ss:MergeAcross="11" ss:StyleID="Title">
          <Data ss:Type="String">Enrolled Persons Export</Data>
        </Cell>
      </Row>

      <Row ss:Height="24">
        <Cell ss:StyleID="Header"><Data ss:Type="String">Person</Data></Cell>
        <Cell ss:StyleID="Header"><Data ss:Type="String">Employee ID</Data></Cell>
        <Cell ss:StyleID="Header"><Data ss:Type="String">Department</Data></Cell>
        <Cell ss:StyleID="Header"><Data ss:Type="String">Role</Data></Cell>
        <Cell ss:StyleID="Header"><Data ss:Type="String">Status</Data></Cell>
        <Cell ss:StyleID="Header"><Data ss:Type="String">Face Quality</Data></Cell>
        <Cell ss:StyleID="Header"><Data ss:Type="String">Images</Data></Cell>
        <Cell ss:StyleID="Header"><Data ss:Type="String">Enrolled On</Data></Cell>
        <Cell ss:StyleID="Header"><Data ss:Type="String">Last Seen</Data></Cell>
        <Cell ss:StyleID="Header"><Data ss:Type="String">Mobile</Data></Cell>
        <Cell ss:StyleID="Header"><Data ss:Type="String">Email</Data></Cell>
        <Cell ss:StyleID="Header"><Data ss:Type="String">Camera</Data></Cell>
      </Row>

      ${rowXml}
    </Table>

    <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
      <FreezePanes/>
      <FrozenNoSplit/>
      <SplitHorizontal>2</SplitHorizontal>
      <TopRowBottomPane>2</TopRowBottomPane>
      <Selected/>
      <ProtectObjects>False</ProtectObjects>
      <ProtectScenarios>False</ProtectScenarios>
    </WorksheetOptions>

    <AutoFilter
      x:Range="R2C1:R${exportRows.length + 2}C12"
      xmlns="urn:schemas-microsoft-com:office:excel"/>
  </Worksheet>
</Workbook>`;

    const blob = new Blob(
      ["\ufeff", worksheetXml],
      {
        type: "application/vnd.ms-excel;charset=utf-8;",
      },
    );

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = `enrolled-persons-${
      new Date().toISOString().split("T")[0]
    }.xls`;

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    URL.revokeObjectURL(url);
  };

  const openEdit = (person) => {
    if (!person) return;

    setEditError("");
    setEditForm({
      fullName: person.name || "",
      department: person.department || "",
      role: person.role || "",
      mobile: person.mobile || "",
      email: person.email || "",
    });

    setEditOpen(true);
  };

  const closeEdit = () => {
    if (editSaving) return;
    setEditOpen(false);
    setEditError("");
  };

  const saveEdit = async () => {
    if (!selectedPerson?.id) return;

    if (
      !editForm.fullName.trim() ||
      !editForm.department.trim() ||
      !editForm.role.trim()
    ) {
      setEditError(
        "Full name, department and role are required.",
      );
      return;
    }

    setEditSaving(true);
    setEditError("");

    try {
      const response = await updateEnrolledPerson(
        selectedPerson.id,
        {
          fullName: editForm.fullName.trim(),
          department: editForm.department.trim(),
          role: editForm.role.trim(),
          mobile: editForm.mobile.trim(),
          email: editForm.email.trim(),
        },
      );

      const updated = normalizePerson(
        response?.data || {},
      );

      setSelectedPerson((current) => ({
        ...updated,
        image: current?.image || "",
      }));

      setEditOpen(false);

      await Promise.all([
        loadPeople({
          preserveSelectedId: selectedPerson.id,
        }),
        loadStats(),
      ]);
    } catch (error) {
      console.error("Person update failed:", error);
      setEditError(
        error?.message ||
          "Could not update person details",
      );
    } finally {
      setEditSaving(false);
    }
  };

  const handleToggleActive = async (person) => {
    if (!person?.id || actionLoading) return;

    const nextActive =
      person.status !== "Active";

    const confirmed = window.confirm(
      nextActive
        ? `Activate face access for ${person.name}?`
        : `Deactivate face access for ${person.name}?`,
    );

    if (!confirmed) return;

    setActionLoading(true);
    setPageError("");

    try {
      const response =
        await updateEnrolledPersonStatus(
          person.id,
          nextActive,
        );

      const updated = normalizePerson(
        response?.data || {},
      );

      setSelectedPerson((current) => ({
        ...updated,
        image: current?.image || person.image || "",
      }));

      await Promise.all([
        loadPeople({
          preserveSelectedId: person.id,
        }),
        loadStats(),
      ]);
    } catch (error) {
      console.error(
        "Person status update failed:",
        error,
      );
      setPageError(
        error?.message ||
          "Could not update person status",
      );
    } finally {
      setActionLoading(false);
    }
  };

  const handleDelete = async (person) => {
    if (!person?.id || actionLoading) return;

    const confirmed = window.confirm(
      `Permanently delete ${person.name}?\n\nThis will delete the SQL person record, face_db.pkl entry, all stored embeddings and saved face image data.`,
    );

    if (!confirmed) return;

    setActionLoading(true);
    setPageError("");

    try {
      await deleteEnrolledPerson(person.id);

      setSelectedPerson(null);

      await Promise.all([
        loadPeople(),
        loadStats(),
      ]);
    } catch (error) {
      console.error("Person delete failed:", error);
      setPageError(
        error?.message ||
          "Could not permanently delete person",
      );
    } finally {
      setActionLoading(false);
    }
  };

  const handleArchive = () => {
    window.alert(
      "Archive backend is not enabled yet.",
    );
  };

  return (
    <>
      <main className="min-h-[calc(100vh-56px)] overflow-hidden bg-[#020817] p-0.2 text-white">
        {/* ================================================================== */}
        {/*                         SUMMARY CARDS                              */}
        {/* ================================================================== */}

        <section className="grid grid-cols-2 gap-2 md:grid-cols-3 lg:grid-cols-5">
          {summaryCards.map((item) => (
            <StatCard
              key={item.label}
              item={item}
            />
          ))}

          <FaceQualityCard
            value={statsData.faceQualityAverage}
          />
        </section>

        {/* ================================================================== */}
        {/*                     MAIN LEFT + RIGHT AREA                         */}
        {/* ================================================================== */}

        <section
          className="
            mt-2
            grid
            grid-cols-1
            gap-2
            lg:h-[calc(100vh-154px)]
            lg:min-h-[560px]
            lg:grid-cols-[minmax(0,1fr)_260px]
            2xl:grid-cols-[minmax(0,1fr)_280px]
          "
        >
          {/* ================================================================ */}
          {/*                         LEFT COLUMN                             */}
          {/* ================================================================ */}

          <div className="flex min-h-0 min-w-0 flex-col overflow-hidden">
            {/* -------------------------------------------------------------- */}
            {/*                  SEARCH + FILTERS + EXPORT                     */}
            {/* -------------------------------------------------------------- */}

            <div className="mb-2 flex shrink-0 flex-wrap items-center gap-2">
              <div className="relative min-w-[200px] flex-1">
                <Search
                  size={13}
                  className="absolute left-2 top-1/2 -translate-y-1/2 text-white/50"
                />

                <input
                  type="text"
                  value={search}
                  onChange={(event) =>
                    setSearch(event.target.value)
                  }
                  placeholder="Search person, employee ID, department, role..."
                  className="h-9 w-full rounded-md border border-[#123250] bg-[#020817] pl-7 pr-7 text-[9px] text-white outline-none placeholder:text-white/40 focus:border-blue-500 2xl:text-[10px]"
                />

                {search && (
                  <button
                    type="button"
                    onClick={() => setSearch("")}
                    title="Clear search"
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-white/40 hover:text-white"
                  >
                    <X size={12} />
                  </button>
                )}
              </div>

              <select
                value={statusFilter}
                onChange={(event) =>
                  setStatusFilter(event.target.value)
                }
                className="h-9 rounded-md border border-[#123250] bg-[#020817] px-2 text-[9px] text-white outline-none focus:border-blue-500"
              >
                <option value="">All Status</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>

              <select
                value={departmentFilter}
                onChange={(event) =>
                  setDepartmentFilter(event.target.value)
                }
                className="h-9 max-w-[150px] rounded-md border border-[#123250] bg-[#020817] px-2 text-[9px] text-white outline-none focus:border-blue-500"
              >
                <option value="">All Departments</option>
                {departments.map((department) => (
                  <option
                    key={department}
                    value={department}
                  >
                    {department}
                  </option>
                ))}
              </select>

              <select
                value={roleFilter}
                onChange={(event) =>
                  setRoleFilter(event.target.value)
                }
                className="h-9 max-w-[140px] rounded-md border border-[#123250] bg-[#020817] px-2 text-[9px] text-white outline-none focus:border-blue-500"
              >
                <option value="">All Roles</option>
                {roles.map((role) => (
                  <option key={role} value={role}>
                    {role}
                  </option>
                ))}
              </select>

              <button
                type="button"
                onClick={handleExport}
                disabled={!people.length}
                className="flex h-9 shrink-0 items-center justify-center gap-1 rounded-md bg-blue-700 px-2 text-[9px] font-semibold hover:bg-blue-600 disabled:cursor-not-allowed disabled:opacity-40 2xl:text-[10px]"
              >
                <Download size={12} />
                Export
              </button>
            </div>

            {pageError && (
              <div className="mb-2 shrink-0 rounded-md border border-red-500/30 bg-red-500/10 px-3 py-2 text-[10px] text-red-300">
                {pageError}
              </div>
            )}

            {/* -------------------------------------------------------------- */}
            {/*                         TABLE PANEL                            */}
            {/* -------------------------------------------------------------- */}

            <div className="hidden min-h-0 flex-1 flex-col overflow-hidden rounded-lg border border-[#123250] bg-[#061421]/90 lg:flex">
              <div className="min-h-0 flex-1 overflow-auto">
                <table className="w-full min-w-[900px] table-fixed border-collapse text-left text-[10px] 2xl:min-w-0">
                  <colgroup>
                    <col className="w-[18%]" />
                    <col className="w-[11%]" />
                    <col className="w-[11%]" />
                    <col className="w-[9%]" />
                    <col className="w-[9%]" />
                    <col className="w-[11%]" />
                    <col className="w-[7%]" />
                    <col className="w-[12%]" />
                    <col className="w-[12%]" />
                  </colgroup>

                  <thead className="sticky top-0 z-20 bg-[#082137] text-[10px] uppercase text-white/70 2xl:text-[10px]">
                    <tr>
                      <th className="border-b border-[#123250] p-2">
                        Person
                      </th>
                      <th className="border-b border-[#123250] p-1">
                        Employee ID
                      </th>
                      <th className="border-b border-[#123250] p-1">
                        Department
                      </th>
                      <th className="border-b border-[#123250] p-1">
                        Role
                      </th>
                      <th className="border-b border-[#123250] p-1">
                        Status
                      </th>
                      <th className="border-b border-[#123250] p-1">
                        Face Quality
                      </th>
                      <th className="border-b border-[#123250] p-1 text-center">
                        Images
                      </th>
                      <th className="border-b border-[#123250] p-1">
                        Enrolled On
                      </th>
                      <th className="border-b border-[#123250] p-1">
                        Last Seen
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {loading ? (
                      <tr>
                        <td
                          colSpan={9}
                          className="p-6 text-center text-[10px] text-white/45"
                        >
                          Loading enrolled persons...
                        </td>
                      </tr>
                    ) : people.length === 0 ? (
                      <tr>
                        <td
                          colSpan={9}
                          className="p-4 text-center text-[10px] text-white/40"
                        >
                          No enrolled persons match your filters.
                        </td>
                      </tr>
                    ) : (
                      people.map((person) => (
                        <tr
                          key={person.id}
                          onClick={() =>
                            handleRowClick(person)
                          }
                          className={`min-h-[54px] cursor-pointer border-b border-[#123250]/80 transition hover:bg-[#0b2238]/70 ${
                            selectedPerson?.id ===
                            person.id
                              ? "bg-[#0b2238]/60"
                              : ""
                          }`}
                        >
                          <td className="px-2 py-2">
                            <div className="flex min-w-0 items-center gap-2">
                              {person.image ? (
                                <img
                                  src={person.image}
                                  alt={person.name}
                                  className="h-9 w-9 shrink-0 rounded-md object-cover ring-1 ring-[#123250]"
                                />
                              ) : (
                                <div className="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-[#0b2238] ring-1 ring-[#123250]">
                                  <UserRound
                                    size={17}
                                    className="text-white/40"
                                  />
                                </div>
                              )}

                              <span
                                title={person.name}
                                className="min-w-0 truncate font-medium text-white"
                              >
                                {person.name}
                              </span>
                            </div>
                          </td>

                          <td
                            title={person.employeeId}
                            className="truncate px-2 py-2 text-white/80"
                          >
                            {person.employeeId}
                          </td>

                          <td
                            title={person.department}
                            className="truncate px-2 py-2 text-white/80"
                          >
                            {person.department}
                          </td>

                          <td
                            title={person.role}
                            className="truncate px-2 py-2 text-white/80"
                          >
                            {person.role}
                          </td>

                          <td className="px-2 py-2">
                            <StatusBadge
                              status={person.status}
                            />
                          </td>

                          <td className="px-2 py-2">
                            <QualityText
                              value={person.faceQuality}
                            />
                          </td>

                          <td className="px-2 py-2 text-center">
                            <div className="inline-flex items-center gap-1 text-white/80">
                              <Images
                                size={11}
                                className="text-blue-400"
                              />
                              <span className="font-semibold">
                                {person.images}
                              </span>
                            </div>
                          </td>

                          <td className="whitespace-pre-line px-2 py-2 text-[9px] leading-[12px] text-white/70">
                            {person.enrolledOn}
                          </td>

                          <td className="whitespace-pre-line px-2 py-2 text-[9px] leading-[12px] text-white/70">
                            {person.lastSeen || "—"}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>

              <div className="flex h-9 shrink-0 items-center justify-between gap-1 border-t border-[#123250] px-2 text-[10px] text-white/60">
                <span>
                  Showing {people.length} entries
                </span>

                {(search ||
                  statusFilter ||
                  departmentFilter ||
                  roleFilter) && (
                  <button
                    type="button"
                    onClick={() => {
                      setSearch("");
                      setStatusFilter("");
                      setDepartmentFilter("");
                      setRoleFilter("");
                    }}
                    className="text-blue-400 hover:text-blue-300"
                  >
                    Clear Filters
                  </button>
                )}
              </div>
            </div>

            {/* -------------------------------------------------------------- */}
            {/*                         MOBILE LIST                            */}
            {/* -------------------------------------------------------------- */}

            <div className="grid min-h-0 flex-1 gap-1 overflow-y-auto lg:hidden">
              {loading ? (
                <div className="rounded-lg border border-[#123250] bg-[#061421]/90 p-4 text-center text-[10px] text-white/40">
                  Loading enrolled persons...
                </div>
              ) : people.length === 0 ? (
                <div className="rounded-lg border border-[#123250] bg-[#061421]/90 p-4 text-center text-[10px] text-white/40">
                  No enrolled persons match your filters.
                </div>
              ) : (
                people.map((person) => (
                  <MobilePersonCard
                    key={person.id}
                    person={person}
                    onClick={() =>
                      handleRowClick(person)
                    }
                  />
                ))
              )}
            </div>
          </div>

          {/* ================================================================ */}
          {/*                     RIGHT DETAILS PANEL                         */}
          {/* ================================================================ */}

          <aside className="flex h-full min-h-0 flex-col overflow-hidden rounded-lg border border-[#123250] bg-[#061421]/90 p-1 shadow-lg">
            <div className="mb-1 flex h-6 shrink-0 items-center justify-between">
              <h2 className="text-[13px] font-semibold text-white">
                Person Details
              </h2>

              {detailsLoading && (
                <span className="text-[8px] text-blue-300">
                  Loading...
                </span>
              )}
            </div>

            <div className="min-h-0 flex-1 overflow-y-auto">
              <div className="overflow-hidden rounded-md border border-[#123250] bg-[#020817]">
                {selectedPerson?.image ? (
                  <img
                    src={selectedPerson.image}
                    alt={selectedPerson?.name || "Person"}
                    className="h-40 w-full bg-[#020817] object-contain p-1 2xl:h-44"
                  />
                ) : (
                  <div className="grid h-36 w-full place-items-center 2xl:h-40">
                    <div className="text-center">
                      <UserRound
                        size={48}
                        className="mx-auto text-white/25"
                      />
                      <p className="mt-2 text-[9px] text-white/35">
                        No person selected
                      </p>
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-1 flex items-center justify-between gap-1">
                <StatusBadge
                  status={selectedPerson?.status || "Unknown"}
                />

                <p className="text-[8px] text-white/60">
                  Face Quality:{" "}
                  <span className="font-bold text-emerald-400">
                    {selectedPerson?.faceQuality ?? 0}%
                  </span>
                </p>
              </div>

              <div className="mt-2 space-y-1.5 border-b border-[#123250] pb-2 text-[10px]">
                {[
                  [
                    "Full Name",
                    selectedPerson?.name || "—",
                  ],
                  [
                    "Employee ID",
                    selectedPerson?.employeeId || "—",
                  ],
                  [
                    "Department",
                    selectedPerson?.department || "—",
                  ],
                  [
                    "Role / Access",
                    selectedPerson?.role || "—",
                  ],
                  [
                    "Status",
                    selectedPerson?.status || "—",
                  ],
                  [
                    "Face Quality",
                    selectedPerson
                      ? `${selectedPerson.faceQuality ?? 0}%`
                      : "—",
                  ],
                  [
                    "Mobile",
                    selectedPerson?.mobile || "—",
                  ],
                  [
                    "Email",
                    selectedPerson?.email || "—",
                  ],
                  [
                    "Images",
                    selectedPerson
                      ? selectedPerson.images ?? 0
                      : "—",
                  ],
                  [
                    "Enrolled On",
                    selectedPerson
                      ? formatDateTime(
                          selectedPerson.enrolledOnRaw,
                        )
                      : "—",
                  ],
                  [
                    "Last Seen",
                    selectedPerson
                      ? formatDateTime(
                          selectedPerson.lastSeenRaw,
                        )
                      : "—",
                  ],
                  [
                    "Camera",
                    selectedPerson?.camera || "—",
                  ],
                ].map(([label, value]) => (
                  <div
                    key={label}
                    className="grid grid-cols-[86px_minmax(0,1fr)] gap-2"
                  >
                    <span className="text-white/50">
                      {label}
                    </span>

                    <span className="break-words text-white/80">
                      {value || "—"}
                    </span>
                  </div>
                ))}
              </div>

              <div className="mt-3">
                <h3 className="mb-2 text-[13px] font-semibold text-white">
                  Quick Actions
                </h3>

                <div className="space-y-2.5">
                  <button
                    type="button"
                    onClick={() =>
                      selectedPerson &&
                      openEdit(selectedPerson)
                    }
                    disabled={
                      !selectedPerson ||
                      actionLoading
                    }
                    className="flex h-11 w-full items-center justify-center gap-2 rounded-lg border border-blue-400/60 bg-gradient-to-r from-blue-700/80 to-cyan-600/70 px-2 text-[11px] font-semibold text-white shadow-md shadow-blue-950/30 transition hover:from-blue-600 hover:to-cyan-500 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    <Edit size={15} />
                    Edit Person Details
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      selectedPerson &&
                      handleToggleActive(
                        selectedPerson,
                      )
                    }
                    disabled={
                      !selectedPerson ||
                      actionLoading
                    }
                    className={`flex h-11 w-full items-center justify-center gap-2 rounded-lg border px-2 text-[11px] font-semibold shadow-md transition disabled:cursor-not-allowed disabled:opacity-40 ${
                      selectedPerson?.status ===
                      "Active"
                        ? "border-orange-400/70 bg-gradient-to-r from-orange-700/70 to-red-700/70 text-orange-50 shadow-red-950/30 hover:from-orange-600 hover:to-red-600"
                        : "border-emerald-400/70 bg-gradient-to-r from-emerald-700/70 to-teal-600/70 text-emerald-50 shadow-emerald-950/30 hover:from-emerald-600 hover:to-teal-500"
                    }`}
                  >
                    <Power size={15} />
                    {actionLoading
                      ? "Updating..."
                      : selectedPerson?.status ===
                          "Active"
                        ? "Deactivate Face Access"
                        : "Activate Face Access"}
                  </button>

                  <button
                    type="button"
                    onClick={handleArchive}
                    disabled
                    title="Archive backend is not enabled yet"
                    className="flex h-11 w-full cursor-not-allowed items-center justify-center gap-2 rounded-lg border border-violet-400/30 bg-gradient-to-r from-violet-800/30 to-fuchsia-800/20 px-2 text-[11px] font-semibold text-violet-200/50 opacity-60"
                  >
                    <Archive size={15} />
                    Archive Person
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      selectedPerson &&
                      handleDelete(selectedPerson)
                    }
                    disabled={
                      !selectedPerson ||
                      actionLoading
                    }
                    className="flex h-11 w-full items-center justify-center gap-2 rounded-lg border border-rose-400/70 bg-gradient-to-r from-rose-800/75 to-red-700/75 px-2 text-[11px] font-semibold text-rose-50 shadow-md shadow-red-950/30 transition hover:from-rose-700 hover:to-red-600 disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    <Trash2 size={15} />
                    {actionLoading
                      ? "Please wait..."
                      : "Delete Permanently"}
                  </button>
                </div>
              </div>

              <p className="mt-2 text-[10px] leading-[11px] text-white/50">
                Select a person from the table to enable person actions.
                Deactivated persons remain stored but are ignored by face
                recognition. Permanent delete removes the SQL record,
                pickle face data, embeddings and stored face images.
              </p>
            </div>
          </aside>
        </section>
      </main>

      {editOpen && (
        <EditPersonModal
          person={selectedPerson}
          form={editForm}
          setForm={setEditForm}
          saving={editSaving}
          error={editError}
          onClose={closeEdit}
          onSave={saveEdit}
        />
      )}
    </>
  );
}
