import { useEffect, useRef, useState } from "react";
import { useOutletContext } from "react-router-dom";
import { useLiveMonitoringContext } from "../context/LiveMonitoringContext";
import * as XLSX from "xlsx";

import {
  AlertTriangle,
  Bell,
  CalendarDays,
  Download,
  Loader2,
  Mail,
  Volume2,
  Camera,
  CheckCircle,
  CheckCircle2,
  Expand,
  FileSpreadsheet,
  Square,
  Trash2,
  Users,
  Video,
  X,
  XCircle,
} from "lucide-react";

const SOUND_ALERT_URL = "/sounds/alarm.mp3";



const LIVE_MONITORING_SYNC_EVENT = "live-monitoring-slots-updated";

import {
  getCameras,
  getCameraDetectionStreamUrl,
  getCameraDetectionStats,
  getLiveEvents,
  getLiveEventsByRange,
  deleteEpisodes,
  getEvidenceImageUrl,
  getEmailAlertStatus,
  updateEmailAlertStatus,
  getLatestEmailSentAlert,
  getMonitoringStatus,
  startMonitoring,
  stopMonitoring,
} from "../data/api";

const defaultSlotData = Array.from({ length: 8 }, (_, index) => ({
  id: index + 1,
  name: `Camera Slot ${index + 1}`,
}));

const alerts = [
  {
    type: "critical",
    title: "No PPE Detected",
    camera: "Camera 2 - Parking",
    date: "23 Apr 2026",
    time: "12:06:21 PM",
  },
  {
    type: "critical",
    title: "No PPE Detected",
    camera: "Camera 2 - Parking",
    date: "23 Apr 2026",
    time: "12:06:21 PM",
  },
  {
    type: "critical",
    title: "No PPE Detected",
    camera: "Camera 2 - Parking",
    date: "23 Apr 2026",
    time: "12:06:21 PM",
  },
  {
    type: "warning",
    title: "Helmet Missing",
    camera: "Camera 4 - Entrance",
    date: "23 Apr 2026",
    time: "12:06:09 PM",
  },
  {
    type: "info",
    title: "Unauthorized Access",
    camera: "Camera 3 - Warehouse",
    date: "23 Apr 2026",
    time: "12:05:45 PM",
  },
  {
    type: "critical",
    title: "No Helmet, No Vest",
    camera: "Camera 3 - Warehouse",
    date: "23 Apr 2026",
    time: "12:05:30 PM",
  },
];

const columns = [
  { label: "Event ID", width: "w-[10%]" },
  { label: "Time", width: "w-[13%]" },
  { label: "Frame ID", width: "w-[7%]" },
  { label: "Camera Name", width: "w-[12%]" },
  { label: "Camera Location", width: "w-[13%]" },
  { label: "Event Type", width: "w-[11%]" },
  { label: "Person Name", width: "w-[12%]" },
  { label: "Person ID", width: "w-[9%]" },
  { label: "Helmet", width: "w-[6%]" },
  { label: "Vest", width: "w-[6%]" },
  { label: "Face Match", width: "w-[8%]" },
  { label: "Evidence", width: "w-[9%]" },
];

function typeStyle(type) {
  if (type === "critical") return { iconBg: "bg-red-600" };
  if (type === "warning") return { iconBg: "bg-yellow-500" };
  return { iconBg: "bg-blue-600" };
}

function CellText({ children }) {
  const value = children || "—";
  return (
    <span title={String(value)} className="block truncate">
      {value}
    </span>
  );
}

function YesNo({ value }) {
  const yes = value === "Yes";
  const finalValue = value || "No";

  return (
    <span
      title={finalValue}
      className={`inline-flex max-w-full items-center gap-0.5 truncate whitespace-nowrap text-[8.5px] font-semibold sm:text-[9px] ${
        yes ? "text-green-400" : "text-red-400"
      }`}
    >
      {yes ? (
        <CheckCircle size={9} className="shrink-0" />
      ) : (
        <XCircle size={9} className="shrink-0" />
      )}
      <span className="truncate">{finalValue}</span>
    </span>
  );
}

function StatusBadge({ value }) {
  const finalValue = value || "Unresolved";

  return (
    <span
      title={finalValue}
      className="inline-block max-w-full truncate rounded bg-red-700/80 px-1 py-[2px] text-[7.5px] font-semibold text-white sm:text-[8px]"
    >
      {finalValue}
    </span>
  );
}

function isSuperAdmin() {
  try {
    const user = JSON.parse(sessionStorage.getItem("currentUser") || "null");
    return String(user?.role || "").trim().toLowerCase() === "super_admin";
  } catch {
    return false;
  }
}

// Super-admins can tick events and delete them (row + pictures) for good.
// "View All Events" shows the same table full-screen so long lists are workable.
function EventsTable({ events = [], onDeleted, expanded = false, onToggleExpand }) {
  const canDelete = isSuperAdmin();
  const [selected, setSelected] = useState(() => new Set());
  const [deleting, setDeleting] = useState(false);

  const ids = events.map((row) => row.event_id).filter(Boolean);
  const allSelected = ids.length > 0 && ids.every((id) => selected.has(id));

  const toggleOne = (id) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const toggleAll = () => setSelected(allSelected ? new Set() : new Set(ids));

  const handleDelete = async () => {
    const chosen = ids.filter((id) => selected.has(id));
    if (chosen.length === 0) return;
    if (!window.confirm(`Delete ${chosen.length} event(s) and their pictures permanently?`)) return;
    setDeleting(true);
    try {
      const res = await deleteEpisodes(chosen);
      if (!res.ok) throw new Error(res.message || "Delete failed");
      setSelected(new Set());
      onDeleted?.(res.data?.deleted || chosen);
    } catch (error) {
      window.alert(error.message || "Could not delete events");
    } finally {
      setDeleting(false);
    }
  };

  const selectedCount = ids.filter((id) => selected.has(id)).length;

  return (
    <section
      className={`flex min-h-0 flex-col rounded-lg border border-[#16304a] bg-[#061421] shadow-[0_0_30px_rgba(0,0,0,0.18)] ${
        expanded ? "h-full" : "h-[255px]"
      }`}
    >
      <div className="flex h-[32px] items-center justify-between gap-2 border-b border-[#123250] px-3">
        <h3 className="truncate text-[13px] font-semibold text-white">
          Live Events
        </h3>

        <div className="flex shrink-0 items-center gap-3">
          {canDelete && selectedCount > 0 && (
            <button
              type="button"
              onClick={handleDelete}
              disabled={deleting}
              className="inline-flex items-center gap-1 rounded border border-red-500 bg-red-600 px-2 py-[2px] text-[10px] font-semibold text-white hover:bg-red-500 disabled:opacity-60"
            >
              <Trash2 size={10} />
              {deleting ? "Deleting…" : `Delete (${selectedCount})`}
            </button>
          )}
          <button
            type="button"
            onClick={onToggleExpand}
            className="text-[10px] text-white/55 hover:text-white"
          >
            {expanded ? "Close ×" : "View All Events ›"}
          </button>
        </div>
      </div>

      <div className="min-h-0 flex-1 overflow-auto">
        <table className="w-full min-w-[1120px] table-fixed border-collapse text-left text-[8.5px] sm:text-[10px]">
          <thead className="sticky top-0 z-10 bg-[#082136] text-white/70">
            <tr className="h-[30px]">
              {canDelete && (
                <th className="w-[28px] border-r border-[#123250] px-2 py-1 text-center">
                  <input
                    type="checkbox"
                    aria-label="Select all events"
                    checked={allSelected}
                    onChange={toggleAll}
                    className="h-3 w-3 cursor-pointer accent-red-500"
                  />
                </th>
              )}
              {columns.map((column) => (
                <th
                  key={column.label}
                  className={`${column.width} truncate border-r border-[#123250] px-2 py-1 font-semibold last:border-r-0`}
                >
                  {column.label}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {events.length > 0 ? (
              events.map((row, index) => {
                const eventId = row.event_id || row.id || `EVT-${index + 1}`;
                const time = row.time || row.created_at || "—";
                const frameId = row.frame_id || "—";
                const cameraName = row.camera_name || row.camera || "—";
                const cameraLocation =
                  row.camera_location || row.location || "—";
                const eventType = row.event_type || row.event || "—";
                const personName = row.person_name || row.personName || row.name || "Unknown Person";
                const personId =
                  row.person_id ||
                  row.employee_id ||
                  row.employeeId ||
                  row.person_employee_id ||
                  "N/A";
                const helmet = row.helmet || "No";
                const vest = row.vest || "No";
                const faceMatch = row.face_match || "No";
                const evidence = row.evidence_image || "";
                const evidenceUrl = evidence ? getEvidenceImageUrl(evidence) : "";

                return (
                  <tr
                    key={`${eventId}-${index}`}
                    className={`h-[28px] border-t border-[#123250] text-white/85 hover:bg-[#0b2238] ${
                      selected.has(eventId) ? "bg-red-900/30" : "bg-[#051828]/80"
                    }`}
                  >
                    {canDelete && (
                      <td className="px-2 py-1 text-center">
                        <input
                          type="checkbox"
                          aria-label={`Select ${eventId}`}
                          checked={selected.has(eventId)}
                          onChange={() => toggleOne(eventId)}
                          className="h-3 w-3 cursor-pointer accent-red-500"
                        />
                      </td>
                    )}
                    <td className="px-2 py-1">
                      <CellText>{eventId}</CellText>
                    </td>
                    <td className="px-2 py-1">
                      <CellText>{time}</CellText>
                    </td>
                    <td className="px-2 py-1">
                      <CellText>{frameId}</CellText>
                    </td>
                    <td className="px-2 py-1">
                      <CellText>{cameraName}</CellText>
                    </td>
                    <td className="px-2 py-1">
                      <CellText>{cameraLocation}</CellText>
                    </td>
                    <td className="px-2 py-1">
                      <CellText>{eventType}</CellText>
                    </td>
                    <td className="px-2 py-1">
                      <CellText>{personName}</CellText>
                    </td>
                    <td className="px-2 py-1">
                      <CellText>{personId}</CellText>
                    </td>
                    <td className="px-2 py-1">
                      <YesNo value={helmet} />
                    </td>
                    <td className="px-2 py-1">
                      <YesNo value={vest} />
                    </td>
                    <td className="px-2 py-1">
                      <YesNo value={faceMatch} />
                    </td>
                    <td className="px-2 py-1 text-center">
                      <button
                        type="button"
                        title={evidence ? "View evidence" : "No evidence"}
                        disabled={!evidenceUrl}
                        onClick={() =>
                          evidenceUrl && window.open(evidenceUrl, "_blank")
                        }
                        className="inline-flex h-7 w-10 items-center justify-center overflow-hidden rounded border border-white/10 bg-white/10 hover:bg-white/20 disabled:cursor-not-allowed disabled:opacity-40"
                      >
                        {evidenceUrl ? (
                          <img
                            src={evidenceUrl}
                            alt="Evidence"
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <span className="text-[9px] text-white/45">—</span>
                        )}
                      </button>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td
                  colSpan={columns.length + (canDelete ? 1 : 0)}
                  className="h-[130px] text-center text-[11px] text-white/50"
                >
                  No live events found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="flex h-[22px] items-center justify-between border-t border-[#123250] px-3">
        
      </div>
    </section>
  );
}

function OnSwitch() {
  return (
    <span className="flex shrink-0 items-center gap-1 text-[9px] text-white">
      <span className="relative h-[15px] w-[28px] rounded-full bg-emerald-600">
        <span className="absolute right-[3px] top-1/2 h-[9px] w-[9px] -translate-y-1/2 rounded-full bg-white" />
      </span>
      ON
    </span>
  );
}

const EMPTY_IMAGE_SRC =
  "data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=";

/**
 * MJPEG requests remain open for the lifetime of an <img>.
 *
 * Assigning the URL through an effect allows us to explicitly replace the src
 * when this component unmounts or the camera URL changes. That closes the old
 * browser HTTP stream before another page creates new camera subscribers.
 */
function ManagedCameraStreamImage({
  src,
  title,
  className,
}) {
  const imageRef = useRef(null);

  useEffect(() => {
    const image = imageRef.current;

    if (!image || !src) {
      return undefined;
    }

    image.src = src;

    return () => {
      // Stop the old MJPEG request immediately on route change/unmount.
      image.removeAttribute("src");
      image.src = EMPTY_IMAGE_SRC;
    };
  }, [src]);

  return (
    <img
      ref={imageRef}
      alt={title}
      crossOrigin="anonymous"
      data-camera-feed="true"
      draggable={false}
      className={className}
    />
  );
}

function FeedView({
  src,
  title,
  fullscreenType = null,
  compactMode = false,
}) {
  const heightClass =
    fullscreenType === "single"
      ? "h-[calc(100vh-150px)]"
      : fullscreenType === "all"
      ? "h-[calc((100vh-190px)/2)]"
      : compactMode
      ? "aspect-video"
      : "h-[120px] xl:h-[132px] 2xl:h-[150px]";

  return (
    <div
      data-camera-feed-container="true"
      className={`relative w-full overflow-hidden bg-black ${heightClass}`}
    >
      {src ? (
        <ManagedCameraStreamImage
          src={src}
          title={title}
          className="block h-full w-full select-none object-fill"
        />
      ) : (
        <div className="flex h-full w-full items-center justify-center bg-[#050f19] text-[10px] text-white/35">
          Select camera to connect
        </div>
      )}
    </div>
  );
}

function CameraCard({
  slotIndex,
  camera,
  cameraList,
  selectedCameraId,
  selectedSlots,
  onCameraChange,
  cameraStats,
  fullscreenType = null,
  onToggleFullscreen,
  layout = 4,
}) {
  const cardRef = useRef(null);
  const recordingCanvasRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const recordingChunksRef = useRef([]);
  const recordingAnimationRef = useRef(null);
  const recordingStreamRef = useRef(null);

  const [snapshotLoading, setSnapshotLoading] = useState(false);
  const [browserRecording, setBrowserRecording] = useState(false);
  const [browserRecordingLoading, setBrowserRecordingLoading] = useState(false);

  const selectedCamera = cameraList.find(
    (item) => Number(item.id) === Number(selectedCameraId)
  );

  const displayName =
    selectedCamera?.camera_name || selectedCamera?.name || camera.name;

  const compactMode = !fullscreenType;

  // Selecting a camera opens the annotated stream directly.
  // Continuous AI monitoring is controlled separately by the single
  // master Monitoring toggle below the camera grid.
  const streamUrl = selectedCameraId
    ? getCameraDetectionStreamUrl(selectedCameraId, slotIndex + 1)
    : "";

  const stats = selectedCameraId ? cameraStats[selectedCameraId] || {} : {};
  const persons = streamUrl ? Number(stats.persons || 0) : 0;
  const violations = streamUrl ? Number(stats.violations || 0) : 0;

  const createSnapshotTimestamp = () => {
    const now = new Date();
    const pad = (value) => String(value).padStart(2, "0");

    return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(
      now.getDate()
    )}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(
      now.getSeconds()
    )}`;
  };

  const handleCameraSnapshot = async () => {
    if (!selectedCameraId || !cardRef.current || snapshotLoading) {
      return;
    }

    setSnapshotLoading(true);

    try {
      /*
      * Sirf live camera image select hogi.
      * Card ke header, buttons aur footer capture nahi honge.
      */
      const cameraImage = cardRef.current.querySelector(
        '[data-camera-feed="true"]'
      );

      if (!cameraImage) {
        throw new Error("Camera image abhi available nahi hai.");
      }

      /*
      * Camera stream ke properly load hone ka wait karega.
      */
      if (!cameraImage.complete || !cameraImage.naturalWidth) {
        await new Promise((resolve, reject) => {
          let timeoutId;

          const cleanup = () => {
            window.clearTimeout(timeoutId);

            cameraImage.removeEventListener("load", handleLoad);
            cameraImage.removeEventListener("error", handleError);
          };

          const handleLoad = () => {
            cleanup();
            resolve();
          };

          const handleError = () => {
            cleanup();
            reject(new Error("Camera frame load nahi ho saka."));
          };

          timeoutId = window.setTimeout(() => {
            cleanup();
            reject(
              new Error(
                "Camera frame load hone me zyada time lag raha hai."
              )
            );
          }, 7000);

          cameraImage.addEventListener("load", handleLoad, {
            once: true,
          });

          cameraImage.addEventListener("error", handleError, {
            once: true,
          });
        });
      }

      /*
      * Browser ko next frame render karne ka time dete hain,
      * jisse latest visible frame capture ho.
      */
      await new Promise((resolve) => {
        window.requestAnimationFrame(() => {
          window.requestAnimationFrame(resolve);
        });
      });

      if (!cameraImage.naturalWidth || !cameraImage.naturalHeight) {
        throw new Error("Camera image ki valid resolution nahi mili.");
      }

      /*
      * Har downloaded screenshot Full HD landscape rahega.
      */
      const outputWidth = 1920;
      const outputHeight = 1080;

      const canvas = document.createElement("canvas");

      canvas.width = outputWidth;
      canvas.height = outputHeight;

      const context = canvas.getContext("2d", {
        alpha: false,
      });

      if (!context) {
        throw new Error("Snapshot canvas create nahi ho saka.");
      }

      /*
      * Black background set kar rahe hain.
      */
      context.fillStyle = "#000000";
      context.fillRect(0, 0, outputWidth, outputHeight);

      /*
      * Better resizing quality.
      */
      context.imageSmoothingEnabled = true;
      context.imageSmoothingQuality = "high";

      /*
      * Source image ka complete area canvas me draw hoga.
      *
      * FeedView me object-fill use ho raha hai, isliye canvas par bhi
      * complete source image ko 1920x1080 me stretch kiya ja raha hai.
      *
      * Isse downloaded PNG wahi full-width style me dikhega jo browser
      * ke camera frame me dikh raha hai.
      */
      context.drawImage(
        cameraImage,

        // Source image
        0,
        0,
        cameraImage.naturalWidth,
        cameraImage.naturalHeight,

        // Full-HD destination
        0,
        0,
        outputWidth,
        outputHeight
      );

      /*
      * Canvas ko PNG Blob me convert karega.
      */
      const snapshotBlob = await new Promise((resolve, reject) => {
        canvas.toBlob(
          (blob) => {
            if (blob) {
              resolve(blob);
            } else {
              reject(
                new Error("Camera snapshot PNG create nahi ho saka.")
              );
            }
          },
          "image/png",
          1
        );
      });

      /*
      * Snapshot download.
      */
      const objectUrl = URL.createObjectURL(snapshotBlob);

      const downloadLink = document.createElement("a");

      downloadLink.href = objectUrl;
      downloadLink.download =
        `camera-${selectedCameraId}-snapshot-` +
        `${createSnapshotTimestamp()}-1920x1080.png`;

      downloadLink.style.display = "none";

      document.body.appendChild(downloadLink);

      downloadLink.click();

      downloadLink.remove();

      /*
      * Browser memory clean-up.
      */
      window.setTimeout(() => {
        URL.revokeObjectURL(objectUrl);
      }, 1500);
    } catch (error) {
      console.error("Camera snapshot error:", error);

      let errorMessage =
        error?.message || "Camera frame capture nahi ho saka.";

      /*
      * Agar backend camera stream CORS allow nahi karta,
      * canvas SecurityError throw karega.
      */
      if (
        error?.name === "SecurityError" ||
        String(error?.message || "")
          .toLowerCase()
          .includes("tainted")
      ) {
        errorMessage =
          "Browser ne camera screenshot block kar diya hai. " +
          "Camera stream API response me CORS headers add karein.";
      }

      alert(errorMessage);
    } finally {
      setSnapshotLoading(false);
    }
  };

  const getCameraRecordingMimeType = () => {
    if (typeof MediaRecorder === "undefined") return "";

    const supportedTypes = [
      "video/webm;codecs=vp9",
      "video/webm;codecs=vp8",
      "video/webm",
    ];

    return (
      supportedTypes.find((type) => MediaRecorder.isTypeSupported(type)) || ""
    );
  };

  const stopRecordingAnimation = () => {
    if (recordingAnimationRef.current) {
      window.cancelAnimationFrame(recordingAnimationRef.current);
      recordingAnimationRef.current = null;
    }
  };

  const stopRecordingStream = () => {
    const stream = recordingStreamRef.current;

    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
    }

    recordingStreamRef.current = null;
  };

  const downloadCameraRecording = (blob) => {
    if (!blob || blob.size === 0) {
      throw new Error("No camera recording data was captured.");
    }

    const objectUrl = URL.createObjectURL(blob);
    const downloadLink = document.createElement("a");

    downloadLink.href = objectUrl;
    downloadLink.download =
      `camera-${selectedCameraId}-recording-` +
      `${createSnapshotTimestamp()}-1920x1080.webm`;
    downloadLink.style.display = "none";

    document.body.appendChild(downloadLink);
    downloadLink.click();
    downloadLink.remove();

    window.setTimeout(() => URL.revokeObjectURL(objectUrl), 2000);
  };

  const startBrowserCameraRecording = async () => {
    if (
      !selectedCameraId ||
      !cardRef.current ||
      browserRecording ||
      browserRecordingLoading
    ) {
      return;
    }

    try {
      setBrowserRecordingLoading(true);

      if (typeof MediaRecorder === "undefined") {
        throw new Error("MediaRecorder is not supported in this browser.");
      }

      const cameraImage = cardRef.current.querySelector(
        '[data-camera-feed="true"]'
      );

      if (!cameraImage) {
        throw new Error("Camera frame is not available.");
      }

      if (!cameraImage.complete || !cameraImage.naturalWidth) {
        throw new Error("Camera stream is still loading.");
      }

      const outputWidth = 1920;
      const outputHeight = 1080;
      const recordingFps = 15;

      const canvas = document.createElement("canvas");
      canvas.width = outputWidth;
      canvas.height = outputHeight;

      const context = canvas.getContext("2d", { alpha: false });

      if (!context) {
        throw new Error("Could not create recording canvas.");
      }

      recordingCanvasRef.current = canvas;

      const canvasStream = canvas.captureStream(recordingFps);
      recordingStreamRef.current = canvasStream;

      const mimeType = getCameraRecordingMimeType();
      const recorder = new MediaRecorder(canvasStream, {
        videoBitsPerSecond: 4_000_000,
        ...(mimeType ? { mimeType } : {}),
      });

      mediaRecorderRef.current = recorder;
      recordingChunksRef.current = [];

      recorder.addEventListener("dataavailable", (event) => {
        if (event.data?.size > 0) {
          recordingChunksRef.current.push(event.data);
        }
      });

      recorder.addEventListener("stop", () => {
        try {
          const finalMimeType = recorder.mimeType || mimeType || "video/webm";
          const recordingBlob = new Blob(recordingChunksRef.current, {
            type: finalMimeType,
          });

          downloadCameraRecording(recordingBlob);
        } catch (error) {
          console.error("Camera recording download error:", error);
          alert(error?.message || "Could not download camera recording.");
        } finally {
          stopRecordingAnimation();
          stopRecordingStream();
          mediaRecorderRef.current = null;
          recordingCanvasRef.current = null;
          recordingChunksRef.current = [];
          setBrowserRecording(false);
          setBrowserRecordingLoading(false);
        }
      });

      recorder.addEventListener("error", (event) => {
        console.error("Camera recording error:", event.error);
        stopRecordingAnimation();
        stopRecordingStream();
        mediaRecorderRef.current = null;
        recordingCanvasRef.current = null;
        recordingChunksRef.current = [];
        setBrowserRecording(false);
        setBrowserRecordingLoading(false);
        alert(event.error?.message || "Camera recording failed.");
      });

      const drawRecordingFrame = () => {
        const activeRecorder = mediaRecorderRef.current;

        if (!activeRecorder || activeRecorder.state === "inactive") {
          return;
        }

        try {
          context.fillStyle = "#000000";
          context.fillRect(0, 0, outputWidth, outputHeight);

          if (
            cameraImage.complete &&
            cameraImage.naturalWidth > 0 &&
            cameraImage.naturalHeight > 0
          ) {
            context.imageSmoothingEnabled = true;
            context.imageSmoothingQuality = "high";
            context.drawImage(
              cameraImage,
              0,
              0,
              cameraImage.naturalWidth,
              cameraImage.naturalHeight,
              0,
              0,
              outputWidth,
              outputHeight
            );
          }
        } catch (error) {
          console.error("Recording frame draw error:", error);
        }

        recordingAnimationRef.current = window.requestAnimationFrame(
          drawRecordingFrame
        );
      };

      recorder.start(1000);
      setBrowserRecording(true);
      setBrowserRecordingLoading(false);
      drawRecordingFrame();
    } catch (error) {
      console.error("Start camera recording error:", error);
      stopRecordingAnimation();
      stopRecordingStream();
      mediaRecorderRef.current = null;
      recordingCanvasRef.current = null;
      recordingChunksRef.current = [];
      setBrowserRecording(false);
      setBrowserRecordingLoading(false);

      let errorMessage = error?.message || "Could not start camera recording.";

      if (
        error?.name === "SecurityError" ||
        String(error?.message || "").toLowerCase().includes("tainted")
      ) {
        errorMessage =
          "Browser blocked camera recording. Verify CORS headers on camera stream responses.";
      }

      alert(errorMessage);
    }
  };

  const stopBrowserCameraRecording = () => {
    stopRecordingAnimation();

    const recorder = mediaRecorderRef.current;

    if (recorder && recorder.state !== "inactive") {
      recorder.stop();
      return;
    }

    stopRecordingStream();
    mediaRecorderRef.current = null;
    recordingCanvasRef.current = null;
    recordingChunksRef.current = [];
    setBrowserRecording(false);
    setBrowserRecordingLoading(false);
  };

  const handleBrowserCameraRecording = () => {
    if (browserRecording) {
      stopBrowserCameraRecording();
    } else {
      startBrowserCameraRecording();
    }
  };

  useEffect(() => {
    return () => {
      stopRecordingAnimation();

      const recorder = mediaRecorderRef.current;

      if (recorder && recorder.state !== "inactive") {
        recorder.stop();
      } else {
        stopRecordingStream();
      }
    };
  }, []);

  return (
    <section
      ref={cardRef}
      className="min-w-0 overflow-hidden rounded-md border border-[#1b344d] bg-[#061421]"
    >
      <div
        className={`flex min-h-[32px] items-center justify-between px-2 py-1 ${
          compactMode ? "gap-0.5" : "gap-1"
        }`}
      >
        <div
          className={`flex min-w-0 flex-1 items-center ${
            compactMode ? "gap-1" : "gap-2"
          }`}
        >
          <span className="grid h-5 w-5 shrink-0 place-items-center rounded bg-blue-600 text-[10px] font-bold text-white">
            {slotIndex + 1}
          </span>

          <select
            value={selectedCameraId || ""}
            onChange={(e) => onCameraChange(slotIndex, e.target.value)}
            className={`h-6 w-full rounded border border-[#1b344d] bg-[#03101d] text-white outline-none focus:border-blue-500 ${
              compactMode
                ? "min-w-[70px] max-w-[105px] px-1 text-[8px]"
                : "min-w-[92px] max-w-[170px] px-2 text-[10px]"
            }`}
          >
            <option value="">Select Camera</option>
            {cameraList
              .filter((item) => {
                const optionCameraId = String(item.id);
                const currentCameraId = String(selectedCameraId || "");

                return (
                  optionCameraId === currentCameraId ||
                  !selectedSlots
                    .filter((_, index) => index !== slotIndex)
                    .map(String)
                    .includes(optionCameraId)
                );
              })
              .map((item) => (
                <option key={item.id} value={item.id}>
                  {item.camera_name || item.name}
                </option>
              ))}
          </select>
        </div>

        <div
          className={`flex shrink-0 items-center justify-end ${
            compactMode ? "gap-0.5" : "flex-wrap gap-1"
          }`}
        >
          <span
            className={`items-center font-medium text-white ${
              compactMode ? "hidden" : "flex gap-1 text-[9px]"
            }`}
          >
            <span
              className={`h-2 w-2 rounded-full ${
                selectedCameraId ? "bg-emerald-500" : "bg-red-500"
              }`}
            />
            {selectedCameraId ? "LIVE" : "OFF"}
          </span>

          <button
            type="button"
            onClick={() => onToggleFullscreen(slotIndex)}
            className="grid h-6 w-6 place-items-center rounded-md border border-[#1b344d] bg-[#03101d] text-white/85 hover:bg-[#0b2238]"
          >
            <Expand size={12} />
          </button>
        </div>
      </div>

      <FeedView
        src={streamUrl}
        title={displayName}
        fullscreenType={fullscreenType}
        compactMode={compactMode}
      />

      <div
        className={`grid min-w-0 items-center border-t border-[#123250] bg-[#061421]/95 ${
          compactMode
            ? "h-[34px] grid-cols-[1fr_1fr_auto_auto] gap-1 px-1"
            : "h-[38px] grid-cols-[1fr_1fr_auto_auto] gap-2 px-2"
        }`}
      >
        <div
          title={`${persons} Persons`}
          className={`flex min-w-0 items-center overflow-hidden ${
            compactMode ? "gap-1" : "gap-1.5"
          }`}
        >
          <Users size={compactMode ? 12 : 15} className="shrink-0 text-blue-500" />
          <div className="min-w-0 leading-none">
            <p
              className={`truncate font-semibold text-white ${
                compactMode ? "text-[9px]" : "text-[10px]"
              }`}
            >
              {persons}
            </p>
            {!compactMode && (
              <p className="truncate text-[9px] leading-tight text-white/65">
                Persons
              </p>
            )}
          </div>
        </div>

        <div
          title={`${violations} Violations`}
          className={`flex min-w-0 items-center overflow-hidden ${
            compactMode ? "gap-1" : "gap-1.5"
          }`}
        >
          {streamUrl && violations === 0 ? (
            <CheckCircle2
              size={compactMode ? 12 : 15}
              className="shrink-0 text-emerald-500"
            />
          ) : (
            <AlertTriangle
              size={compactMode ? 12 : 15}
              className="shrink-0 text-yellow-400"
            />
          )}
          <div className="min-w-0 leading-none">
            <p
              className={`truncate font-semibold text-white ${
                compactMode ? "text-[9px]" : "text-[10px]"
              }`}
            >
              {violations}
            </p>
            {!compactMode && (
              <p className="truncate text-[9px] leading-tight text-white/65">
                Violations
              </p>
            )}
          </div>
        </div>

        <button
          type="button"
          title="Download camera snapshot"
          aria-label="Download camera snapshot"
          disabled={!selectedCameraId || snapshotLoading}
          onClick={handleCameraSnapshot}
          className={`grid shrink-0 place-items-center rounded-md border border-sky-700 bg-sky-700 text-white hover:bg-sky-600 disabled:cursor-not-allowed disabled:border-gray-700 disabled:bg-gray-700 ${
            compactMode ? "h-5 w-6" : "h-6 w-8"
          }`}
        >
          {snapshotLoading ? (
            <Loader2 size={compactMode ? 10 : 12} className="animate-spin" />
          ) : (
            <Camera size={compactMode ? 11 : 13} />
          )}
        </button>

        <button
          type="button"
          title={
            browserRecording
              ? "Stop and download recording"
              : "Start camera recording"
          }
          aria-label={
            browserRecording
              ? "Stop and download camera recording"
              : "Start camera recording"
          }
          disabled={!selectedCameraId || browserRecordingLoading}
          onClick={handleBrowserCameraRecording}
          className={`flex shrink-0 items-center justify-center rounded-md border font-bold text-white disabled:cursor-not-allowed disabled:border-gray-700 disabled:bg-gray-700 ${
            compactMode
              ? "h-5 min-w-[38px] gap-1 px-1 text-[7px]"
              : "h-6 min-w-[64px] gap-1 px-1.5 text-[8px]"
          } ${
            browserRecording
              ? "border-red-700/70 bg-red-700 hover:bg-red-600"
              : "border-gray-700 bg-gray-700 hover:bg-gray-600"
          }`}
        >
          <span
            className={`shrink-0 rounded-full ${
              compactMode ? "h-1.5 w-1.5" : "h-2 w-2"
            } ${
              browserRecording
                ? "animate-pulse bg-red-400"
                : "bg-white/40"
            }`}
          />
          <span className="whitespace-nowrap">
            {browserRecordingLoading
              ? "..."
              : browserRecording
              ? compactMode
                ? "STOP"
                : "Stop REC"
              : "REC"}
          </span>
        </button>
      </div>
    </section>
  );
}

function toDateTimeLocalValue(date) {
  const pad = (value) => String(value).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(
    date.getDate()
  )}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function QuickActions({
  events = [],
  monitoringEnabled = false,
  monitoringLoading = false,
  monitoringChanging = false,
  monitoredCount = 0,
  onMonitoringToggle,
}) {
  const { soundAlertsEnabled, setSoundAlertsEnabled } =
    useLiveMonitoringContext();

  const [emailAlertsEnabled, setEmailAlertsEnabled] = useState(true);
  const [emailFrequency, setEmailFrequency] = useState(() => {
    return localStorage.getItem("liveMonitoringEmailFrequency") || "5";
  });
  const [emailAlertsLoading, setEmailAlertsLoading] = useState(true);
  const [popup, setPopup] = useState(null);
  const [showExportModal, setShowExportModal] = useState(false);
  const [exportLoading, setExportLoading] = useState(false);
  const [screenRecording, setScreenRecording] = useState(false);
  const [screenCaptureLoading, setScreenCaptureLoading] = useState(false);

  const screenRecorderRef = useRef(null);
  const screenStreamRef = useRef(null);
  const screenChunksRef = useRef([]);
  const recordingLoopRef = useRef(null);
  const recordingCanvasRef = useRef(null);

  // Sound alert refs. The backend creates a new notificationId only after
  // an alert email is sent successfully.
  const alertAudioRef = useRef(null);
  const latestEmailNotificationIdRef = useRef(null);
  const emailNotificationInitializedRef = useRef(false);
  const soundAlertsEnabledRef = useRef(soundAlertsEnabled);
  const [exportStartTime, setExportStartTime] = useState(() => {
    const date = new Date();
    date.setHours(date.getHours() - 1);
    return toDateTimeLocalValue(date);
  });
  const [exportEndTime, setExportEndTime] = useState(() =>
    toDateTimeLocalValue(new Date())
  );

  const showPopup = (message, type = "info") => {
    setPopup({ message, type });
  };


  const createCaptureTimestamp = () => {
    const now = new Date();
    const pad = (value) => String(value).padStart(2, "0");

    return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(
      now.getDate()
    )}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(
      now.getSeconds()
    )}`;
  };

  const downloadBlob = (blob, fileName) => {
    const objectUrl = URL.createObjectURL(blob);
    const downloadLink = document.createElement("a");

    downloadLink.href = objectUrl;
    downloadLink.download = fileName;
    downloadLink.style.display = "none";

    document.body.appendChild(downloadLink);
    downloadLink.click();
    downloadLink.remove();

    window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
  };

  const stopScreenStream = () => {
    const stream = screenStreamRef.current;

    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
    }

    screenStreamRef.current = null;
  };

  const getSupportedRecordingMimeType = () => {
    if (typeof MediaRecorder === "undefined") return "";

    const supportedTypes = [
      "video/webm;codecs=vp9",
      "video/webm;codecs=vp8",
      "video/webm",
    ];

    return (
      supportedTypes.find((type) => MediaRecorder.isTypeSupported(type)) || ""
    );
  };


  const stopFullScreenRecording = () => {
    const recorder = screenRecorderRef.current;

    if (recorder && recorder.state !== "inactive") {
      recorder.stop();
      return;
    }

    stopScreenStream();
    screenRecorderRef.current = null;
    screenChunksRef.current = [];
    setScreenRecording(false);
    setScreenCaptureLoading(false);
  };

  const startFullScreenRecording = async () => {
    if (screenRecording || screenCaptureLoading) return;

    try {
      if (!navigator.mediaDevices?.getDisplayMedia) {
        throw new Error("Screen recording is not supported in this browser.");
      }

      if (typeof MediaRecorder === "undefined") {
        throw new Error("MediaRecorder is not supported in this browser.");
      }

      setScreenCaptureLoading(true);
      screenChunksRef.current = [];

      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          frameRate: { ideal: 15, max: 20 },
        },
        audio: false,
        preferCurrentTab: true,
        selfBrowserSurface: "include",
        surfaceSwitching: "exclude",
      });

      screenStreamRef.current = displayStream;

      const mimeType = getSupportedRecordingMimeType();
      const recorder = new MediaRecorder(displayStream, {
        videoBitsPerSecond: 3_000_000,
        ...(mimeType ? { mimeType } : {}),
      });

      screenRecorderRef.current = recorder;

      recorder.addEventListener("dataavailable", (event) => {
        if (event.data?.size > 0) {
          screenChunksRef.current.push(event.data);
        }
      });

      recorder.addEventListener("stop", () => {
        try {
          const finalMimeType = recorder.mimeType || mimeType || "video/webm";
          const recordingBlob = new Blob(screenChunksRef.current, {
            type: finalMimeType,
          });

          if (recordingBlob.size > 0) {
            downloadBlob(
              recordingBlob,
              `live-monitoring-recording-${createCaptureTimestamp()}.webm`
            );
            showPopup("Live monitoring recording downloaded.", "success");
          } else {
            showPopup("No recording data was captured.", "warning");
          }
        } catch (error) {
          console.error("Recording download error:", error);
          showPopup(error.message || "Could not save recording.", "error");
        } finally {
          stopScreenStream();
          screenRecorderRef.current = null;
          screenChunksRef.current = [];
          setScreenRecording(false);
          setScreenCaptureLoading(false);
        }
      });

      recorder.addEventListener("error", (event) => {
        console.error("Monitoring recorder error:", event.error);
        showPopup(event.error?.message || "Recording failed.", "error");
        stopScreenStream();
        screenRecorderRef.current = null;
        screenChunksRef.current = [];
        setScreenRecording(false);
        setScreenCaptureLoading(false);
      });

      const videoTrack = displayStream.getVideoTracks()[0];
      videoTrack?.addEventListener("ended", () => {
        if (screenRecorderRef.current?.state !== "inactive") {
          screenRecorderRef.current.stop();
        }
      });

      recorder.start(1000);
      setScreenRecording(true);
      setScreenCaptureLoading(false);
      showPopup("Live monitoring recording started.", "success");
    } catch (error) {
      console.error("Start monitoring recording error:", error);
      stopScreenStream();
      screenRecorderRef.current = null;
      screenChunksRef.current = [];
      setScreenRecording(false);
      setScreenCaptureLoading(false);

      if (error?.name !== "NotAllowedError") {
        showPopup(error.message || "Could not start recording.", "error");
      }
    }
  };

  const handleFullScreenRecording = () => {
    if (screenRecording) {
      stopFullScreenRecording();
    } else {
      startFullScreenRecording();
    }
  };

  useEffect(() => {
    return () => {
      const recorder = screenRecorderRef.current;

      if (recorder && recorder.state !== "inactive") {
        recorder.stop();
      }

      const stream = screenStreamRef.current;

      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }

      screenRecorderRef.current = null;
      screenStreamRef.current = null;
      screenChunksRef.current = [];
    };
  }, []);

  useEffect(() => {
    soundAlertsEnabledRef.current = soundAlertsEnabled;
  }, [soundAlertsEnabled]);

  useEffect(() => {
    const audio = new Audio(SOUND_ALERT_URL);

    audio.preload = "auto";
    audio.volume = 1;
    alertAudioRef.current = audio;

    const handleAudioError = () => {
      console.error(
        `Sound file could not be loaded. Please check the file location: public/alarm.mp3 (${SOUND_ALERT_URL})`
      );
    };

    audio.addEventListener("error", handleAudioError);
    audio.load();

    return () => {
      audio.removeEventListener("error", handleAudioError);
      audio.pause();
      audio.currentTime = 0;
      alertAudioRef.current = null;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    let requestRunning = false;

    const checkLatestEmailAlert = async () => {
      if (cancelled || requestRunning) return;

      requestRunning = true;

      try {
        const response = await getLatestEmailSentAlert();

        if (cancelled) return;

        // Supports both common API response shapes:
        // { ok: true, data: notification }
        // { data: { ok: true, data: notification } }
        const notification =
          response?.data?.data ??
          response?.data ??
          null;

        const rawNotificationId =
          notification?.notificationId ??
          notification?.notification_id ??
          null;

        const notificationId =
          rawNotificationId === null || rawNotificationId === undefined
            ? null
            : String(rawNotificationId);

        // IMPORTANT:
        // First successful poll initializes the baseline even when data is null.
        // The old code returned before initialization when no email existed,
        // therefore the first real email was incorrectly treated as old and
        // the first sound never played.
        if (!emailNotificationInitializedRef.current) {
          emailNotificationInitializedRef.current = true;
          latestEmailNotificationIdRef.current = notificationId;
          return;
        }

        if (!notificationId) return;

        // Same email notification should never ring twice.
        if (notificationId === latestEmailNotificationIdRef.current) return;

        // Mark every new email as processed, including while Sound Alert is OFF.
        latestEmailNotificationIdRef.current = notificationId;

        if (!soundAlertsEnabledRef.current) {
          console.log(
            "Email sent, but Sound Alert is OFF. Sound skipped:",
            notification
          );
          return;
        }

        const audio = alertAudioRef.current;

        if (!audio) {
          console.error("Sound audio object is not ready.");
          return;
        }

        audio.pause();
        audio.currentTime = 0;
        audio.volume = 1;

        try {
          await audio.play();

          showPopup(
            `Email sent: ${
              notification?.eventType ||
              notification?.event_type ||
              "PPE alert"
            }`,
            "success"
          );
        } catch (audioError) {
          console.error("Alarm play failed:", audioError);

          showPopup(
            "Email sent successfully, but the browser blocked the alarm sound. Please turn the Sound Alert button OFF and then ON again.",
            "error"
          );
        }
      } catch (error) {
        console.error("Email sound notification check failed:", error);
      } finally {
        requestRunning = false;
      }
    };

    // Initialize immediately, then check every second.
    checkLatestEmailAlert();

    const intervalId = window.setInterval(
      checkLatestEmailAlert,
      1000
    );

    return () => {
      cancelled = true;
      window.clearInterval(intervalId);
    };
  }, []);

  useEffect(() => {
    if (!popup) return undefined;

    const timerId = window.setTimeout(() => {
      setPopup(null);
    }, 3500);

    return () => window.clearTimeout(timerId);
  }, [popup]);

  useEffect(() => {
    if (!showExportModal) return undefined;

    const handleKeyDown = (event) => {
      if (event.key === "Escape" && !exportLoading) {
        setShowExportModal(false);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [showExportModal, exportLoading]);

  useEffect(() => {
    let isMounted = true;

    const loadEmailAlertStatus = async () => {
      setEmailAlertsLoading(true);

      try {
        const response = await getEmailAlertStatus();

        if (isMounted) {
          setEmailAlertsEnabled(
            response?.enabled === undefined ? true : Boolean(response.enabled)
          );

          if (response?.frequency_minutes) {
            const serverFrequency = String(response.frequency_minutes);

            if (["5", "10", "15", "20"].includes(serverFrequency)) {
              setEmailFrequency(serverFrequency);
              localStorage.setItem(
                "liveMonitoringEmailFrequency",
                serverFrequency
              );
            }
          }
        }
      } catch (error) {
        console.error("Email alert status error:", error);

        if (isMounted) {
          setEmailAlertsEnabled(true);
          showPopup(
            error.message || "Could not load email alert status",
            "error"
          );
        }
      } finally {
        if (isMounted) {
          setEmailAlertsLoading(false);
        }
      }
    };

    loadEmailAlertStatus();

    return () => {
      isMounted = false;
    };
  }, []);

  const handleEmailAlertsToggle = async () => {
    if (emailAlertsLoading) return;

    const previousValue = emailAlertsEnabled;
    const nextValue = !previousValue;

    setEmailAlertsEnabled(nextValue);
    setEmailAlertsLoading(true);

    try {
      const response = await updateEmailAlertStatus(
        nextValue,
        Number(emailFrequency)
      );

      setEmailAlertsEnabled(
        response?.enabled === undefined
          ? nextValue
          : Boolean(response.enabled)
      );

      showPopup(
        `Email alerts turned ${nextValue ? "ON" : "OFF"}.`,
        "success"
      );
    } catch (error) {
      console.error("Email alert toggle error:", error);

      setEmailAlertsEnabled(previousValue);
      showPopup(
        error.message || "Could not update email alert status",
        "error"
      );
    } finally {
      setEmailAlertsLoading(false);
    }
  };

  const handleEmailFrequencyChange = async (event) => {
    const previousFrequency = emailFrequency;
    const nextFrequency = event.target.value;

    setEmailFrequency(nextFrequency);
    localStorage.setItem("liveMonitoringEmailFrequency", nextFrequency);

    if (emailAlertsLoading) return;

    setEmailAlertsLoading(true);

    try {
      const response = await updateEmailAlertStatus(
        emailAlertsEnabled,
        Number(nextFrequency)
      );

      if (response?.frequency_minutes) {
        const savedFrequency = String(response.frequency_minutes);
        setEmailFrequency(savedFrequency);
        localStorage.setItem(
          "liveMonitoringEmailFrequency",
          savedFrequency
        );
      }
      showPopup(`Email frequency set to ${nextFrequency} minutes.`, "success");
    } catch (error) {
      console.error("Email alert frequency error:", error);

      setEmailFrequency(previousFrequency);
      localStorage.setItem(
        "liveMonitoringEmailFrequency",
        previousFrequency
      );
      showPopup(
        error.message || "Could not update email alert frequency",
        "error"
      );
    } finally {
      setEmailAlertsLoading(false);
    }
  };

  const createExcelFile = (exportEvents, startDate, endDate) => {
    const rows = exportEvents.map((row, index) => {
      const evidencePath = row.evidence_image || "";
      const evidenceUrl = evidencePath
        ? getEvidenceImageUrl(evidencePath)
        : "";

      return {
        "Event ID": row.event_id || row.id || `EVT-${index + 1}`,
        Time: row.time || row.created_at || "",
        "Frame ID": row.frame_id || "",
        "Camera Name": row.camera_name || row.camera || "",
        "Camera Location": row.camera_location || row.location || "",
        "Event Type": row.event_type || row.event || "",
        "Person Name":
          row.person_name ||
          row.personName ||
          row.name ||
          "Unknown Person",
        "Person ID":
          row.person_id ||
          row.employee_id ||
          row.employeeId ||
          row.person_employee_id ||
          "N/A",
        Helmet: row.helmet || "No",
        Vest: row.vest || "No",
        "Face Match": row.face_match || "No",
        Evidence: evidenceUrl,
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(rows);

    worksheet["!cols"] = [
      { wch: 32 },
      { wch: 22 },
      { wch: 12 },
      { wch: 18 },
      { wch: 20 },
      { wch: 18 },
      { wch: 22 },
      { wch: 16 },
      { wch: 10 },
      { wch: 10 },
      { wch: 12 },
      { wch: 55 },
    ];

    if (worksheet["!ref"]) {
      worksheet["!autofilter"] = { ref: worksheet["!ref"] };
    }

    exportEvents.forEach((row, index) => {
      const evidencePath = row.evidence_image || "";
      const evidenceUrl = evidencePath
        ? getEvidenceImageUrl(evidencePath)
        : "";

      if (!evidenceUrl) return;

      worksheet[`L${index + 2}`] = {
        t: "s",
        v: "Open Image",
        l: {
          Target: evidenceUrl,
          Tooltip: "Open evidence image",
        },
      };
    });

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Live Events");

    const formatFileDate = (date) =>
      date.toISOString().replaceAll(":", "-").replace("T", "_").slice(0, 19);

    XLSX.writeFile(
      workbook,
      `live-events_${formatFileDate(startDate)}_to_${formatFileDate(endDate)}.xlsx`,
      { compression: true }
    );
  };

  const openExportModal = () => {
    const endDate = new Date();
    const startDate = new Date(endDate.getTime() - 60 * 60 * 1000);

    setExportStartTime(toDateTimeLocalValue(startDate));
    setExportEndTime(toDateTimeLocalValue(endDate));
    setShowExportModal(true);
  };

  const handleRangeExport = async () => {
    if (!exportStartTime || !exportEndTime) {
      showPopup("Please select both start and end time.", "warning");
      return;
    }

    const startDate = new Date(exportStartTime);
    const endDate = new Date(exportEndTime);

    if (Number.isNaN(startDate.getTime()) || Number.isNaN(endDate.getTime())) {
      showPopup("Please select a valid date and time.", "warning");
      return;
    }

    if (startDate >= endDate) {
      showPopup("End time must be later than start time.", "warning");
      return;
    }

    if (endDate > new Date()) {
      showPopup("End time cannot be in the future.", "warning");
      return;
    }

    setExportLoading(true);

    try {
      const response = await getLiveEventsByRange(
        startDate.toISOString(),
        endDate.toISOString()
      );

      if (!response?.ok) {
        throw new Error(response?.message || "Could not load export data");
      }

      const exportEvents = Array.isArray(response.data)
        ? response.data
        : response.data?.events || [];

      if (!exportEvents.length) {
        showPopup("No events found in the selected time range.", "warning");
        return;
      }

      createExcelFile(exportEvents, startDate, endDate);
      setShowExportModal(false);
      showPopup(
        `${exportEvents.length} event${exportEvents.length === 1 ? "" : "s"} exported successfully.`,
        "success"
      );
    } catch (error) {
      console.error("Range export error:", error);
      showPopup(error.message || "Could not export selected events.", "error");
    } finally {
      setExportLoading(false);
    }
  };

  function ToggleAction({
    Icon,
    label,
    enabled,
    onToggle,
    activeClassName,
    disabled = false,
    loading = false,
  }) {
    return (
      <button
        type="button"
        role="switch"
        aria-checked={enabled}
        aria-busy={loading}
        disabled={disabled}
        onClick={onToggle}
        className={`grid h-[46px] w-full min-w-0 grid-cols-[minmax(0,1fr)_auto] items-center gap-2 overflow-hidden rounded-md border px-3 text-left text-[11px] font-bold text-white transition-all duration-200 hover:shadow-lg active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-65 ${
          enabled
            ? activeClassName
            : "border-slate-600 bg-slate-700 hover:bg-slate-600"
        }`}
      >
        <span className="flex min-w-0 items-center gap-2 overflow-hidden">
          <Icon size={16} className="shrink-0" />
          <span className="block min-w-0 whitespace-normal leading-tight line-clamp-2">
            {loading ? `${label}...` : label}
          </span>
        </span>

        <span className="flex shrink-0 items-center gap-1.5">
          <span
            className={`relative h-[18px] w-[34px] shrink-0 rounded-full border transition-colors ${
              enabled
                ? "border-emerald-300/60 bg-emerald-500"
                : "border-slate-400/40 bg-slate-500"
            }`}
          >
            <span
              className={`absolute top-[2px] h-[12px] w-[12px] rounded-full bg-white shadow-md transition-transform ${
                enabled ? "translate-x-[18px]" : "translate-x-[2px]"
              }`}
            />
          </span>

          <span className="w-[24px] text-left text-[9px] font-extrabold tracking-wide text-white">
            {enabled ? "ON" : "OFF"}
          </span>
        </span>
      </button>
    );
  }

  const normalButtonClass =
    "flex h-[46px] w-full min-w-0 items-center justify-center gap-2 overflow-hidden rounded-md border px-2 text-[11px] font-bold text-white transition-all duration-200 hover:shadow-lg active:scale-[0.98]";

  const popupStyle = {
    success: "border-emerald-500/60 bg-emerald-950/95 text-emerald-200",
    warning: "border-yellow-500/60 bg-yellow-950/95 text-yellow-200",
    error: "border-red-500/60 bg-red-950/95 text-red-200",
    info: "border-blue-500/60 bg-blue-950/95 text-blue-200",
  };

  return (
    <>
      <section className="overflow-x-auto rounded-md border border-[#1b344d] bg-[#061421] p-2">
        <div className="grid min-w-[840px] grid-cols-[minmax(150px,1.1fr)_minmax(130px,1.15fr)_minmax(130px,1.15fr)_minmax(150px,1fr)_minmax(150px,1fr)_130px] gap-2">
          <ToggleAction
            Icon={Video}
            label={
              monitoringLoading
                ? "Loading Monitoring"
                : monitoringChanging
                ? monitoringEnabled
                  ? "Stopping Monitoring"
                  : "Starting Monitoring"
                : monitoredCount > 0 && monitoringEnabled
                ? `Monitoring (${monitoredCount})`
                : "Monitoring"
            }
            enabled={monitoringEnabled}
            onToggle={onMonitoringToggle}
            disabled={monitoringLoading || monitoringChanging}
            loading={monitoringLoading || monitoringChanging}
            activeClassName="border-emerald-500 bg-emerald-600 hover:bg-emerald-500"
          />

          <button
            type="button"
            onClick={openExportModal}
            className={`${normalButtonClass} border-emerald-500 bg-emerald-600 hover:bg-emerald-500`}
          >
            <FileSpreadsheet size={16} className="shrink-0" />
            <span className="min-w-0 truncate whitespace-nowrap">
              Export to Excel
            </span>
          </button>


          <button
            type="button"
            onClick={handleFullScreenRecording}
            disabled={screenCaptureLoading && !screenRecording}
            aria-pressed={screenRecording}
            className={`${normalButtonClass} ${
              screenRecording
                ? "border-red-500 bg-red-600 hover:bg-red-500"
                : "border-violet-500 bg-violet-600 hover:bg-violet-500"
            } disabled:cursor-not-allowed disabled:opacity-60`}
          >
            {screenCaptureLoading && !screenRecording ? (
              <Loader2 size={16} className="shrink-0 animate-spin" />
            ) : screenRecording ? (
              <Square size={14} className="shrink-0 fill-current" />
            ) : (
              <Video size={16} className="shrink-0" />
            )}
            <span className="min-w-0 truncate whitespace-nowrap">
              {screenCaptureLoading && !screenRecording
                ? "Starting..."
                : screenRecording
                ? "Stop Recording"
                : "Record Clip"}
            </span>
          </button>

          <ToggleAction
            Icon={Volume2}
            label="Sound Alert"
            enabled={soundAlertsEnabled}
            onToggle={async () => {
              const nextValue = !soundAlertsEnabled;

              setSoundAlertsEnabled(nextValue);
              soundAlertsEnabledRef.current = nextValue;
              if (nextValue && alertAudioRef.current) {
                try {
                  const audio = alertAudioRef.current;
                  const previousVolume = audio.volume;

                  // This user click unlocks browser audio autoplay permission.
                  audio.volume = 0;
                  audio.currentTime = 0;

                  await audio.play();

                  await new Promise((resolve) => {
                    window.setTimeout(resolve, 120);
                  });

                  audio.pause();
                  audio.currentTime = 0;
                  audio.volume = previousVolume || 1;
                } catch (error) {
                  console.warn("Browser blocked sound initialization:", error);
                }
              }

              showPopup(
                `Sound alert turned ${nextValue ? "ON" : "OFF"}.`,
                "success"
              );
            }}
            activeClassName="border-cyan-500 bg-cyan-600 hover:bg-cyan-500"
          />

          <ToggleAction
            Icon={Mail}
            label="Email Alert"
            enabled={emailAlertsEnabled}
            onToggle={handleEmailAlertsToggle}
            disabled={emailAlertsLoading}
            loading={emailAlertsLoading}
            activeClassName="border-red-500 bg-red-600 hover:bg-red-500"
          />

          <select
            value={emailFrequency}
            onChange={handleEmailFrequencyChange}
            disabled={emailAlertsLoading}
            aria-label="Email alert frequency"
            title="Email alert frequency"
            className="h-[46px] w-full min-w-0 rounded-md border border-[#27506f] bg-[#03101d] px-2 text-[12px] font-bold text-white outline-none transition hover:border-blue-400 focus:border-blue-500 disabled:cursor-not-allowed disabled:opacity-60"
          >
            <option value="" disabled>
              Alert Frequency
            </option>
            <option value="5">5 min</option>
            <option value="10">10 min</option>
            <option value="15">15 min</option>
            <option value="20">20 min</option>
          </select>
        </div>
      </section>

      {showExportModal && (
        <div
          className="fixed inset-0 z-[1100] flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget && !exportLoading) {
              setShowExportModal(false);
            }
          }}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="export-range-title"
            className="w-full max-w-[520px] overflow-hidden rounded-xl border border-[#244761] bg-[#061421] shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-[#16304a] px-5 py-4">
              <div className="flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-lg bg-emerald-600/20 text-emerald-400">
                  <CalendarDays size={20} />
                </span>
                <div>
                  <h2 id="export-range-title" className="text-[15px] font-bold text-white">
                    Export Events by Time Range
                  </h2>
                  <p className="mt-0.5 text-[10px] text-white/50">
                    Select the start and end date/time for the Excel report.
                  </p>
                </div>
              </div>

              <button
                type="button"
                disabled={exportLoading}
                onClick={() => setShowExportModal(false)}
                className="grid h-8 w-8 place-items-center rounded-md text-white/60 hover:bg-white/10 hover:text-white disabled:cursor-not-allowed disabled:opacity-50"
                aria-label="Close export dialog"
              >
                <X size={18} />
              </button>
            </div>

            <div className="space-y-4 px-5 py-5">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <label className="block">
                  <span className="mb-2 block text-[11px] font-semibold text-white/75">
                    Start date and time
                  </span>
                  <input
                    type="datetime-local"
                    value={exportStartTime}
                    max={exportEndTime || toDateTimeLocalValue(new Date())}
                    onChange={(event) => setExportStartTime(event.target.value)}
                    disabled={exportLoading}
                    className="h-11 w-full rounded-md border border-[#27506f] bg-[#03101d] px-3 text-[11px] text-white outline-none [color-scheme:dark] focus:border-emerald-500 disabled:opacity-60"
                  />
                </label>

                <label className="block">
                  <span className="mb-2 block text-[11px] font-semibold text-white/75">
                    End date and time
                  </span>
                  <input
                    type="datetime-local"
                    value={exportEndTime}
                    min={exportStartTime}
                    max={toDateTimeLocalValue(new Date())}
                    onChange={(event) => setExportEndTime(event.target.value)}
                    disabled={exportLoading}
                    className="h-11 w-full rounded-md border border-[#27506f] bg-[#03101d] px-3 text-[11px] text-white outline-none [color-scheme:dark] focus:border-emerald-500 disabled:opacity-60"
                  />
                </label>
              </div>

              <div className="rounded-md border border-blue-500/20 bg-blue-500/10 px-3 py-2.5 text-[10px] leading-5 text-blue-100/80">
                The export uses historical data from the server, so it is not limited to the latest 100 rows shown on this page.
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 border-t border-[#16304a] bg-[#04111d] px-5 py-4">
              <button
                type="button"
                disabled={exportLoading}
                onClick={() => setShowExportModal(false)}
                className="h-9 rounded-md border border-slate-600 bg-slate-700 px-4 text-[11px] font-bold text-white hover:bg-slate-600 disabled:cursor-not-allowed disabled:opacity-50"
              >
                Cancel
              </button>

              <button
                type="button"
                disabled={exportLoading}
                onClick={handleRangeExport}
                className="flex h-9 min-w-[145px] items-center justify-center gap-2 rounded-md border border-emerald-500 bg-emerald-600 px-4 text-[11px] font-bold text-white hover:bg-emerald-500 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {exportLoading ? (
                  <Loader2 size={15} className="animate-spin" />
                ) : (
                  <Download size={15} />
                )}
                {exportLoading ? "Preparing..." : "Download Excel"}
              </button>
            </div>
          </div>
        </div>
      )}

      {popup && (
        <div
          role="status"
          className={`fixed right-4 top-4 z-[1200] max-w-[340px] rounded-lg border px-4 py-3 text-[12px] font-semibold shadow-2xl backdrop-blur ${
            popupStyle[popup.type] || popupStyle.info
          }`}
        >
          <div className="flex items-start gap-2">
            <Bell size={16} className="mt-0.5 shrink-0" />
            <span>{popup.message}</span>
            <button
              type="button"
              onClick={() => setPopup(null)}
              className="ml-2 text-white/70 hover:text-white"
              aria-label="Close notification"
            >
              ×
            </button>
          </div>
        </div>
      )}
    </>
  );
}

function LiveAlerts() {
  return (
    <section className="flex h-[255px] min-h-0 flex-col rounded-lg border border-[#16304a] bg-[#061421] shadow-[0_0_30px_rgba(0,0,0,0.18)]">
      <div className="flex h-[32px] items-center justify-between border-b border-[#123250] px-3">
        <h3 className="text-[13px] font-semibold text-white">Live Alerts</h3>
        <button className="text-[10px] text-white/55 hover:text-white">
          View All ›
        </button>
      </div>

      <div className="min-h-0 flex-1 overflow-auto">
        {alerts.map((item) => {
          const style = typeStyle(item.type);

          return (
            <div
              key={item.title + item.time}
              className="grid grid-cols-[18px_minmax(0,1fr)_68px] gap-2 border-b border-[#123250] px-3 py-2.5 last:border-b-0 hover:bg-[#0b2238]"
            >
              <span
                className={`mt-0.5 grid h-[16px] w-[16px] place-items-center rounded-full text-[9px] font-bold text-white ${style.iconBg}`}
              >
                !
              </span>

              <div className="min-w-0">
                <p className="truncate text-[10px] font-semibold text-white">
                  {item.title}
                </p>
                <p className="mt-0.5 truncate text-[9px] text-white/55">
                  {item.camera}
                </p>
              </div>

              <div className="text-right text-[7.5px] leading-4 text-white/60">
                <p>{item.date}</p>
                <p>{item.time}</p>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

export default function LiveMonitoringPage() {
  const { liveSelectedEvents = ["All Events"], liveLayout = 4 } =
    useOutletContext() || {};

  const {
    selectedSlots,
    updateSelectedCamera,
  } = useLiveMonitoringContext();

  const [cameraList, setCameraList] = useState([]);
  const [cameraStats, setCameraStats] = useState({});
  const [fullscreenMode, setFullscreenMode] = useState(null);
  const [liveEvents, setLiveEvents] = useState([]);
  const [showAllEvents, setShowAllEvents] = useState(false);

  // Backend monitoring is the single source of truth.
  // These endpoints are public and are called through normal fetch()
  // inside api.js, not authenticatedFetch().
  const [monitoringEnabled, setMonitoringEnabled] = useState(false);
  const [monitoringLoading, setMonitoringLoading] = useState(true);
  const [monitoringChanging, setMonitoringChanging] = useState(false);
  const [monitoredCameraIds, setMonitoredCameraIds] = useState([]);
  const [excludedCameraIds, setExcludedCameraIds] = useState([]);

  // Latest selected camera state is kept in a ref for slot changes.
  const selectedSlotsRef = useRef(selectedSlots);

  const isAllCamerasFullscreen = fullscreenMode === "all";
  const fullscreenSlotIndex =
    typeof fullscreenMode === "number" ? fullscreenMode : null;

  const visibleSlots = defaultSlotData.slice(0, liveLayout);
  const cameraGridClass =
    liveLayout === 1
      ? "grid-cols-1"
      : liveLayout === 2
      ? "grid-cols-1 md:grid-cols-2"
      : liveLayout === 4
      ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-4"
      : "grid-cols-1 sm:grid-cols-2 lg:grid-cols-4";


  useEffect(() => {
    selectedSlotsRef.current = selectedSlots;
  }, [selectedSlots]);

  const applyMonitoringData = (data = {}) => {
    setMonitoringEnabled(Boolean(data?.enabled));
    setMonitoredCameraIds(
      Array.isArray(data?.monitored_camera_ids)
        ? data.monitored_camera_ids
        : []
    );
    setExcludedCameraIds(
      Array.isArray(data?.excluded_camera_ids)
        ? data.excluded_camera_ids
        : []
    );
  };

  const loadMonitoringStatus = async ({ silent = false } = {}) => {
    if (!silent) {
      setMonitoringLoading(true);
    }

    try {
      const response = await getMonitoringStatus();
      applyMonitoringData(response?.data || {});
      return response;
    } catch (error) {
      console.error("Monitoring status error:", error);
      throw error;
    } finally {
      if (!silent) {
        setMonitoringLoading(false);
      }
    }
  };

  const handleMonitoringToggle = async () => {
    if (monitoringLoading || monitoringChanging) {
      return;
    }

    setMonitoringChanging(true);

    try {
      const response = monitoringEnabled
        ? await stopMonitoring()
        : await startMonitoring();

      applyMonitoringData(response?.data || {});

      // Re-read status after every action. We never assume that the
      // requested state became the actual backend state.
      await loadMonitoringStatus({ silent: true });
    } catch (error) {
      console.error("Monitoring toggle error:", error);
      alert(error?.message || "Could not update monitoring");

      try {
        await loadMonitoringStatus({ silent: true });
      } catch {
        // Keep the last known state if status refresh also fails.
      }
    } finally {
      setMonitoringChanging(false);
    }
  };

  useEffect(() => {
    let cancelled = false;
    let requestRunning = false;

    const refreshMonitoringStatus = async (initial = false) => {
      if (requestRunning || cancelled) return;
      requestRunning = true;

      if (initial) {
        setMonitoringLoading(true);
      }

      try {
        const response = await getMonitoringStatus();

        if (!cancelled) {
          applyMonitoringData(response?.data || {});
        }
      } catch (error) {
        if (!cancelled) {
          console.error("Monitoring status poll error:", error);
        }
      } finally {
        requestRunning = false;

        if (initial && !cancelled) {
          setMonitoringLoading(false);
        }
      }
    };

    refreshMonitoringStatus(true);

    const intervalId = window.setInterval(() => {
      refreshMonitoringStatus(false);
    }, 10000);

    return () => {
      cancelled = true;
      window.clearInterval(intervalId);
    };
  }, []);

  useEffect(() => {
    loadCameras();
  }, []);

  useEffect(() => {
    loadLiveEvents();

    // Keep local-code behavior: refresh Live Events every 1 second.
    // This preserves the faster UI update while still keeping all GitHub additions.
    const intervalId = window.setInterval(loadLiveEvents, 1000);

    return () => window.clearInterval(intervalId);
  }, []);

  useEffect(() => {
    const activeCameraIds = [...new Set(selectedSlots.filter(Boolean))];
    if (activeCameraIds.length === 0) return undefined;

    let cancelled = false;
    let requestRunning = false;

    const loadStats = async () => {
      if (requestRunning || cancelled) return;
      requestRunning = true;

      try {
        const results = await Promise.all(
          activeCameraIds.map(async (cameraId) => {
            try {
              const res = await getCameraDetectionStats(cameraId);
              return res.ok ? [cameraId, res.data] : null;
            } catch (error) {
              if (!cancelled) console.error("Detection stats error:", error);
              return null;
            }
          })
        );

        if (!cancelled) {
          setCameraStats((prev) => {
            const updated = { ...prev };
            results.forEach((item) => {
              if (!item) return;
              const [cameraId, data] = item;
              updated[cameraId] = data;
            });
            return updated;
          });
        }
      } finally {
        requestRunning = false;
      }
    };

    loadStats();
    const intervalId = window.setInterval(loadStats, 3000);

    return () => {
      cancelled = true;
      window.clearInterval(intervalId);
    };
  }, [selectedSlots]);

  // Drop deleted rows straight away; the 5 s poll confirms from the server.
  const handleEventsDeleted = (deletedIds) => {
    const gone = new Set(deletedIds);
    setLiveEvents((prev) => prev.filter((row) => !gone.has(row.event_id)));
  };

  const loadLiveEvents = async () => {
    try {
      const res = await getLiveEvents();

      if (res.ok) {
        setLiveEvents(res.data || []);
      }
    } catch (error) {
      console.error("Live events error:", error);
    }
  };

  const loadCameras = async () => {
    try {
      const res = await getCameras();

      if (res?.ok) {
        setCameraList(res.data || []);
      }
    } catch (error) {
      console.error(
        "Camera list load error:",
        error
      );
    }
  };

  const handleSlotCameraChange = (slotIndex, cameraId) => {
    const previousCameraId = selectedSlotsRef.current?.[slotIndex];

    // Selecting the same camera does not need any work.
    if (
      previousCameraId &&
      cameraId &&
      Number(previousCameraId) === Number(cameraId)
    ) {
      return;
    }

    // Camera selection only controls which stream is visible in this tile.
    // It does NOT start/stop backend monitoring anymore.
    const result = updateSelectedCamera(slotIndex, cameraId);

    if (!result.ok) {
      alert(result.message || "Could not update camera frame.");
      return;
    }

    selectedSlotsRef.current = [
      ...(selectedSlotsRef.current || [])
    ];
    selectedSlotsRef.current[slotIndex] = cameraId || null;

    window.dispatchEvent(
      new Event(LIVE_MONITORING_SYNC_EVENT)
    );
  };

  // Arriving from the Ops Board with ?camera=ID: show that camera in the
  // first free tile (or leave it if it is already on screen).
  useEffect(() => {
    if (!cameraList.length) return;
    const wanted = Number(new URLSearchParams(window.location.search).get("camera"));
    if (!wanted || !cameraList.some((c) => Number(c.id) === wanted)) return;
    const slots = selectedSlotsRef.current || [];
    if (slots.some((id) => Number(id) === wanted)) return;
    const free = slots.findIndex((id) => !id);
    handleSlotCameraChange(free === -1 ? 0 : free, wanted);
  }, [cameraList]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div
      data-live-monitoring-root="true"
      data-monitoring-enabled={monitoringEnabled ? "true" : "false"}
      data-excluded-camera-count={excludedCameraIds.length}
      className="w-full min-w-0 overflow-x-hidden bg-[#020c16] text-white"
    >
      <main className="min-w-0 space-y-3 overflow-x-hidden">
        <div
          className={
            fullscreenSlotIndex !== null
              ? "grid grid-cols-1 gap-2"
              : isAllCamerasFullscreen
              ? "grid grid-cols-1 gap-2 xl:grid-cols-2"
              : liveLayout === 1 || liveLayout === 2
              ? "flex flex-wrap justify-center gap-2"
              : `grid gap-2 ${cameraGridClass}`
          }
        >
          {visibleSlots.map((camera, index) => {
            if (fullscreenSlotIndex !== null && fullscreenSlotIndex !== index) {
              return null;
            }

            return (
              <div
                key={camera.id}
                className={
                  fullscreenSlotIndex !== null || isAllCamerasFullscreen
                    ? "min-w-0 w-full"
                    : liveLayout === 1 || liveLayout === 2
                    ? "min-w-0 w-full sm:w-[calc(50%-4px)] lg:w-[calc(25%-6px)]"
                    : "min-w-0"
                }
              >
                <CameraCard
                slotIndex={index}
                camera={camera}
                cameraList={cameraList}
                selectedCameraId={selectedSlots[index]}
                selectedSlots={selectedSlots}
                onCameraChange={handleSlotCameraChange}
                cameraStats={cameraStats}
                fullscreenType={
                  fullscreenSlotIndex === index
                    ? "single"
                    : isAllCamerasFullscreen
                    ? "all"
                    : null
                }
                onToggleFullscreen={(slotIndex) =>
                  setFullscreenMode((current) =>
                    current === slotIndex ? null : slotIndex
                  )
                }
                layout={liveLayout}
              />
              </div>
            );
          })}
        </div>

        {fullscreenMode === null && (
          <div className="min-w-0 space-y-2">
            <QuickActions
              events={liveEvents}
              monitoringEnabled={monitoringEnabled}
              monitoringLoading={monitoringLoading}
              monitoringChanging={monitoringChanging}
              monitoredCount={monitoredCameraIds.length}
              onMonitoringToggle={handleMonitoringToggle}
            />

            <div className="grid min-w-0 grid-cols-1 gap-2 lg:grid-cols-[minmax(0,1fr)_240px] xl:grid-cols-[minmax(0,1fr)_280px] 2xl:grid-cols-[minmax(0,1fr)_340px]">
              <EventsTable
                events={liveEvents}
                onDeleted={handleEventsDeleted}
                onToggleExpand={() => setShowAllEvents(true)}
              />
              <LiveAlerts />
            </div>
          </div>
        )}

        {showAllEvents && (
          <div className="fixed inset-0 z-[1100] bg-black/75 p-4 backdrop-blur-sm">
            <EventsTable
              events={liveEvents}
              expanded
              onDeleted={handleEventsDeleted}
              onToggleExpand={() => setShowAllEvents(false)}
            />
          </div>
        )}
      </main>
    </div>
  );
}
