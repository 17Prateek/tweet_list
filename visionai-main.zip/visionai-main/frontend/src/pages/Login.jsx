import { useEffect, useRef, useState } from "react";
import {
  useLocation,
  useNavigate,
} from "react-router-dom";

import loginBackground from "../assets/vision-ai-login-background.png";
import visionLogo from "../assets/vision-ai-logo.png";
import paperlessLogo from "../assets/logo_1.png";

import {
  loginUser,
  verifyLoginOtp,
  sendForgotPasswordOtp,
  verifyForgotPasswordOtp,
  resetForgotPassword,
} from "../data/api";

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();

  /* ======================================================
     LOGIN STATES
  ====================================================== */

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");

  const [isSubmitting, setIsSubmitting] =
    useState(false);

  const [isVerifyingOtp, setIsVerifyingOtp] =
    useState(false);

  const [isResendingOtp, setIsResendingOtp] =
    useState(false);

  /* ======================================================
     MODAL FLOW
  ====================================================== */

  /*
    null
    loginOtp
    forgotEmail
    forgotOtp
    resetPassword
    resetSuccess
  */

  const [modalStep, setModalStep] =
    useState(null);

  /* ======================================================
     LOGIN OTP
  ====================================================== */

  const [loginOtp, setLoginOtp] =
    useState(["", "", "", "", "", ""]);

  const [loginOtpError, setLoginOtpError] =
    useState("");

  /* ======================================================
     FORGOT PASSWORD
  ====================================================== */

  const [forgotEmail, setForgotEmail] =
    useState("");

  const [forgotEmailError, setForgotEmailError] =
    useState("");

  const [forgotOtp, setForgotOtp] =
    useState(["", "", "", "", "", ""]);

  const [forgotOtpError, setForgotOtpError] =
    useState("");

  const [newPassword, setNewPassword] =
    useState("");

  const [confirmPassword, setConfirmPassword] =
    useState("");

  const [newPasswordError, setNewPasswordError] =
    useState("");

  const [
    confirmPasswordError,
    setConfirmPasswordError,
  ] = useState("");

  const [forgotResetToken, setForgotResetToken] =
    useState("");

  const [showNewPassword, setShowNewPassword] =
    useState(false);

  const [showConfirmPassword, setShowConfirmPassword] =
    useState(false);

  const [isSendingForgotOtp, setIsSendingForgotOtp] =
    useState(false);

  const [isVerifyingForgotOtp, setIsVerifyingForgotOtp] =
    useState(false);

  const [isResendingForgotOtp, setIsResendingForgotOtp] =
    useState(false);

  const [isResettingPassword, setIsResettingPassword] =
    useState(false);

  /* ======================================================
     OTP INPUT REFS
  ====================================================== */

  const loginOtpRefs = useRef([]);
  const forgotOtpRefs = useRef([]);

  /* ======================================================
     EMAIL VALIDATION
  ====================================================== */

  const validateEmail = (value) => {
    const cleanValue = value.trim();

    if (!cleanValue) {
      return "Email address is required.";
    }

    const emailRegex =
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(cleanValue)) {
      return "Please enter a valid email address.";
    }

    return "";
  };

  /* ======================================================
     PASSWORD VALIDATION
  ====================================================== */

  const validatePassword = (value) => {
    // Login page par password policy dobara validate nahi karni chahiye.
    // User ka existing password backend hash ke against verify hoga.
    if (!value) {
      return "Password is required.";
    }

    return "";
  };

  const validateNewPassword = (value) => {
    if (!value) {
      return "New password is required.";
    }

    if (value.length < 8) {
      return "Password must be at least 8 characters.";
    }

    if (!/[A-Z]/.test(value)) {
      return "Password must contain at least one uppercase letter.";
    }

    if (!/[a-z]/.test(value)) {
      return "Password must contain at least one lowercase letter.";
    }

    if (!/[0-9]/.test(value)) {
      return "Password must contain at least one number.";
    }

    if (!/[^A-Za-z0-9]/.test(value)) {
      return "Password must contain at least one special character.";
    }

    return "";
  };

  /* ======================================================
     LOGIN SUBMIT
  ====================================================== */

  const handleSubmit = async (e) => {
    e.preventDefault();

    setEmailError("");
    setPasswordError("");
    setLoginOtpError("");

    const currentEmailError =
      validateEmail(email);

    const currentPasswordError =
      validatePassword(password);

    if (
      currentEmailError ||
      currentPasswordError
    ) {
      setEmailError(currentEmailError);
      setPasswordError(currentPasswordError);
      return;
    }

    setIsSubmitting(true);

    try {
      await loginUser({
        email: email.trim().toLowerCase(),
        password,
      });

      setLoginOtp([
        "",
        "",
        "",
        "",
        "",
        "",
      ]);

      setLoginOtpError("");
      setModalStep("loginOtp");
    } catch (error) {
      const message =
        error?.message ||
        "Unable to sign in. Please try again.";

      if (
        message.toLowerCase().includes("email") ||
        message.toLowerCase().includes("password")
      ) {
        setPasswordError(message);
      } else {
        setPasswordError(message);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  /* ======================================================
     LOGIN OTP VERIFY
  ====================================================== */

  const handleLoginOtpVerify = async () => {
    const enteredOtp = loginOtp.join("");

    if (enteredOtp.length !== 6) {
      setLoginOtpError(
        "Please enter the complete 6-digit OTP."
      );
      return;
    }

    setLoginOtpError("");
    setIsVerifyingOtp(true);

    try {
      const result = await verifyLoginOtp({
        email: email.trim().toLowerCase(),
        otp: enteredOtp,
      });

      sessionStorage.setItem(
        "isLoggedIn",
        "true"
      );

      sessionStorage.setItem(
        "loggedInEmail",
        email.trim().toLowerCase()
      );

      if (result?.accessToken) {
        sessionStorage.setItem(
          "accessToken",
          result.accessToken
        );
      }

      if (result?.user) {
        sessionStorage.setItem(
          "currentUser",
          JSON.stringify(result.user)
        );
      }

      const requestedPage =
        location.state?.from ||
        "/ops";

      setModalStep(null);

      navigate(
        requestedPage,
        {
          replace: true,
        }
      );
    } catch (error) {
      setLoginOtpError(
        error?.message ||
        "OTP verification failed. Please try again."
      );
    } finally {
      setIsVerifyingOtp(false);
    }
  };

  const handleResendLoginOtp = async () => {
    if (isResendingOtp) return;

    setLoginOtpError("");
    setIsResendingOtp(true);

    try {
      await loginUser({
        email: email.trim().toLowerCase(),
        password,
      });

      setLoginOtp([
        "",
        "",
        "",
        "",
        "",
        "",
      ]);

      setTimeout(() => {
        loginOtpRefs.current[0]?.focus();
      }, 100);
    } catch (error) {
      setLoginOtpError(
        error?.message ||
        "Could not resend OTP. Please try again."
      );
    } finally {
      setIsResendingOtp(false);
    }
  };

  /* ======================================================
     FORGOT PASSWORD OPEN
  ====================================================== */

  const openForgotPassword = () => {
    setForgotEmail(email.trim());

    setForgotEmailError("");

    setForgotOtp([
      "",
      "",
      "",
      "",
      "",
      "",
    ]);

    setForgotOtpError("");

    setNewPassword("");
    setConfirmPassword("");
    setForgotResetToken("");

    setShowNewPassword(false);
    setShowConfirmPassword(false);

    setNewPasswordError("");
    setConfirmPasswordError("");

    setModalStep("forgotEmail");
  };

  /* ======================================================
     FORGOT PASSWORD SEND OTP
  ====================================================== */

  const handleForgotSendOtp = async () => {
    const error = validateEmail(forgotEmail);

    if (error) {
      setForgotEmailError(error);
      return;
    }

    setForgotEmailError("");
    setForgotOtpError("");
    setIsSendingForgotOtp(true);

    try {
      await sendForgotPasswordOtp({
        email: forgotEmail.trim().toLowerCase(),
      });

      setForgotOtp(["", "", "", "", "", ""]);
      setForgotResetToken("");
      setModalStep("forgotOtp");
    } catch (error) {
      setForgotEmailError(
        error?.message ||
          "Could not send password reset OTP. Please try again."
      );
    } finally {
      setIsSendingForgotOtp(false);
    }
  };

  /* ======================================================
     FORGOT OTP VERIFY
  ====================================================== */

  const handleForgotOtpVerify = async () => {
    const enteredOtp = forgotOtp.join("");

    if (enteredOtp.length !== 6) {
      setForgotOtpError(
        "Please enter the complete 6-digit OTP."
      );
      return;
    }

    setForgotOtpError("");
    setIsVerifyingForgotOtp(true);

    try {
      const result = await verifyForgotPasswordOtp({
        email: forgotEmail.trim().toLowerCase(),
        otp: enteredOtp,
      });

      if (!result?.resetToken) {
        throw new Error(
          "Password reset token was not received. Please request a new OTP."
        );
      }

      setForgotResetToken(result.resetToken);
      setNewPassword("");
      setConfirmPassword("");
      setShowNewPassword(false);
      setShowConfirmPassword(false);
      setNewPasswordError("");
      setConfirmPasswordError("");
      setModalStep("resetPassword");
    } catch (error) {
      setForgotOtpError(
        error?.message ||
          "OTP verification failed. Please try again."
      );
    } finally {
      setIsVerifyingForgotOtp(false);
    }
  };

  const handleResendForgotOtp = async () => {
    if (isResendingForgotOtp) return;

    const error = validateEmail(forgotEmail);

    if (error) {
      setForgotOtpError(error);
      return;
    }

    setForgotOtpError("");
    setIsResendingForgotOtp(true);

    try {
      await sendForgotPasswordOtp({
        email: forgotEmail.trim().toLowerCase(),
      });

      setForgotOtp(["", "", "", "", "", ""]);
      setForgotResetToken("");

      setTimeout(() => {
        forgotOtpRefs.current[0]?.focus();
      }, 100);
    } catch (error) {
      setForgotOtpError(
        error?.message ||
          "Could not resend OTP. Please try again."
      );
    } finally {
      setIsResendingForgotOtp(false);
    }
  };

  /* ======================================================
     RESET PASSWORD
  ====================================================== */

  const handleResetPassword = async () => {
    const passwordValidationError =
      validateNewPassword(newPassword);

    let confirmError = "";

    if (!confirmPassword) {
      confirmError = "Please confirm your new password.";
    } else if (newPassword !== confirmPassword) {
      confirmError = "Passwords do not match.";
    }

    setNewPasswordError(passwordValidationError);
    setConfirmPasswordError(confirmError);

    if (passwordValidationError || confirmError) {
      return;
    }

    if (!forgotResetToken) {
      setNewPasswordError(
        "Your password reset session is missing or expired. Please request a new OTP."
      );
      return;
    }

    setIsResettingPassword(true);

    try {
      await resetForgotPassword({
        resetToken: forgotResetToken,
        newPassword,
      });

      setForgotResetToken("");
      setModalStep("resetSuccess");
    } catch (error) {
      setNewPasswordError(
        error?.message ||
          "Could not update password. Please try again."
      );
    } finally {
      setIsResettingPassword(false);
    }
  };

  /* ======================================================
     RESET FINISHED
  ====================================================== */

  const finishPasswordReset = () => {
    setEmail(forgotEmail);

    setPassword("");

    setForgotEmail("");
    setNewPassword("");
    setConfirmPassword("");
    setForgotResetToken("");
    setShowNewPassword(false);
    setShowConfirmPassword(false);

    setForgotOtp([
      "",
      "",
      "",
      "",
      "",
      "",
    ]);

    setModalStep(null);
  };

  /* ======================================================
     OTP INPUT
  ====================================================== */

  const handleOtpChange = (
    index,
    value,
    otp,
    setOtp,
    refs,
    setError
  ) => {
    /*
      Only digit allowed
    */

    const digit =
      value.replace(/\D/g, "");

    if (!digit) {
      const updated = [...otp];

      updated[index] = "";

      setOtp(updated);

      return;
    }

    const updated =
      [...otp];

    updated[index] =
      digit.slice(-1);

    setOtp(updated);

    setError("");

    if (
      index < 5 &&
      refs.current[index + 1]
    ) {
      refs.current[index + 1].focus();
    }
  };

  const handleOtpKeyDown = (
    index,
    e,
    otp,
    refs
  ) => {
    if (
      e.key === "Backspace" &&
      !otp[index] &&
      index > 0
    ) {
      refs.current[index - 1]?.focus();
    }

    if (
      e.key === "ArrowLeft" &&
      index > 0
    ) {
      refs.current[index - 1]?.focus();
    }

    if (
      e.key === "ArrowRight" &&
      index < 5
    ) {
      refs.current[index + 1]?.focus();
    }
  };

  /* ======================================================
     OTP PASTE
  ====================================================== */

  const handleOtpPaste = (
    e,
    setOtp,
    refs,
    setError
  ) => {
    e.preventDefault();

    const pasted =
      e.clipboardData
        .getData("text")
        .replace(/\D/g, "")
        .slice(0, 6);

    if (!pasted) return;

    const values =
      pasted.split("");

    const updated =
      Array(6).fill("");

    values.forEach(
      (digit, index) => {
        updated[index] = digit;
      }
    );

    setOtp(updated);

    setError("");

    const targetIndex =
      Math.min(
        pasted.length,
        6
      ) - 1;

    refs.current[targetIndex]?.focus();
  };

  /* ======================================================
     AUTO FOCUS MODAL
  ====================================================== */

  useEffect(() => {
    if (
      modalStep === "loginOtp"
    ) {
      setTimeout(() => {
        loginOtpRefs.current[0]?.focus();
      }, 100);
    }

    if (
      modalStep === "forgotOtp"
    ) {
      setTimeout(() => {
        forgotOtpRefs.current[0]?.focus();
      }, 100);
    }
  }, [modalStep]);

  return (
    <div
      className="login-page"
      style={{
        backgroundImage:
          `url(${loginBackground})`,
      }}
    >
      {/* ================================================= */}
      {/* MAIN LOGIN CARD */}
      {/* ================================================= */}

      <div className="login-card">

        {/* LOGOS */}

        <div className="logo-row">
          <img
            src={paperlessLogo}
            alt="Paperless AI"
            className="paperless-logo-image"
          />

          <img
            src={visionLogo}
            alt="Vision AI"
            className="vision-logo-image"
          />
        </div>

        {/* TITLE */}

        <h1 className="login-title">
          Login
        </h1>

        {/* FORM */}

        <form
          onSubmit={handleSubmit}
          noValidate
        >
          {/* EMAIL */}

          <div className="input-group">
            <input
              type="email"
              placeholder="Email Address"
              value={email}
              onChange={(e) => {
                setEmail(
                  e.target.value
                );

                if (emailError) {
                  setEmailError("");
                }
              }}
              onBlur={() => {
                setEmailError(
                  validateEmail(email)
                );
              }}
              className={`login-input ${
                emailError
                  ? "input-error"
                  : ""
              }`}
              autoComplete="username"
            />

            {emailError && (
              <div className="validation-message">
                <ErrorIcon />

                <span>
                  {emailError}
                </span>
              </div>
            )}
          </div>

          {/* PASSWORD */}

          <div className="input-group">
            <div className="password-input-wrapper">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Password"
                value={password}
                onChange={(e) => {
                  setPassword(
                    e.target.value
                  );

                  if (passwordError) {
                    setPasswordError("");
                  }
                }}
                onBlur={() => {
                  setPasswordError(
                    validatePassword(
                      password
                    )
                  );
                }}
                className={`login-input ${
                  passwordError
                    ? "input-error"
                    : ""
                }`}
                autoComplete="current-password"
              />

              <button
                type="button"
                className="password-toggle-button"
                onClick={() =>
                  setShowPassword((current) => !current)
                }
                aria-label={
                  showPassword
                    ? "Hide password"
                    : "Show password"
                }
                title={
                  showPassword
                    ? "Hide password"
                    : "Show password"
                }
              >
                {showPassword ? (
                  <EyeOffIcon />
                ) : (
                  <EyeIcon />
                )}
              </button>
            </div>

            {passwordError && (
              <div className="validation-message">
                <ErrorIcon />

                <span>
                  {passwordError}
                </span>
              </div>
            )}
          </div>

          {/* BUTTONS */}

          <div className="button-row">
            <button
              type="submit"
              className="signin-button"
              disabled={isSubmitting}
            >
              <LoginIcon />

              <span>
                {isSubmitting
                  ? "Please wait..."
                  : "Sign in"}
              </span>
            </button>

            <button
              type="button"
              className="install-button"
            >
              <DownloadIcon />

              <span>
                Install App
              </span>
            </button>
          </div>
        </form>

        {/* FORGOT PASSWORD */}

        <button
          type="button"
          className="forgot-password"
          onClick={openForgotPassword}
        >
          Forgot Password?
        </button>

        {/* SOCIAL */}

        <div className="social-row">
          <button
            type="button"
            className="social-button"
            aria-label="Instagram"
          >
            <InstagramIcon />
          </button>

          <button
            type="button"
            className="social-button"
            aria-label="Facebook"
          >
            <FacebookIcon />
          </button>

          <button
            type="button"
            className="social-button"
            aria-label="LinkedIn"
          >
            <LinkedinIcon />
          </button>
        </div>

        {/* TERMS */}

        <div className="terms">
          By becoming our member and logging
          in your account you agree to our{" "}

          <a href="#">
            Terms of Use agreement
          </a>
          ,{" "}

          <a href="#">
            Terms and Conditions
          </a>

          {" "}and{" "}

          <a href="#">
            Privacy & Cookies policy.
          </a>
        </div>
      </div>

      {/* ================================================= */}
      {/* FOOTER */}
      {/* ================================================= */}

      <footer className="login-footer">
        <div className="ip-row">
          <span>
            IP Address
          </span>

          <strong>
            49.36.138.165, 208.109.1.13
          </strong>
        </div>

        <div>
          This site is best viewed in Google Chrome and Mozilla Firefox.
          Copyright © 2018-26. All Rights Reserved
        </div>

        <div>
          Designed, developed & maintained by{" "}

          <strong>
            QHSE Risk Consultants LLP
          </strong>
        </div>
      </footer>

      {/* ================================================= */}
      {/* LOGIN OTP MODAL */}
      {/* ================================================= */}

      {modalStep === "loginOtp" && (
        <div className="modal-overlay">

          <div className="auth-modal-card">

            <button
              type="button"
              className="modal-close"
              onClick={() =>
                setModalStep(null)
              }
            >
              ×
            </button>

            <div className="modal-logo-row">
              <img
                src={paperlessLogo}
                alt="Paperless AI"
                className="modal-paperless-logo"
              />

              <img
                src={visionLogo}
                alt="Vision AI"
                className="modal-vision-logo"
              />
            </div>

            <div className="otp-icon">
              <MailIcon />
            </div>

            <h2 className="modal-title">
              Email Verification
            </h2>

            <p className="modal-description">
              We have sent a 6-digit OTP to
            </p>

            <div className="modal-email">
              {email}
            </div>

            <OtpBoxes
              otp={loginOtp}
              setOtp={setLoginOtp}
              refs={loginOtpRefs}
              error={loginOtpError}
              setError={setLoginOtpError}
              onChange={handleOtpChange}
              onKeyDown={handleOtpKeyDown}
              onPaste={handleOtpPaste}
            />

            {loginOtpError && (
              <div className="modal-error">
                <ErrorIcon />

                <span>
                  {loginOtpError}
                </span>
              </div>
            )}

            <button
              type="button"
              className="modal-primary-button"
              onClick={
                handleLoginOtpVerify
              }
              disabled={isVerifyingOtp}
            >
              {isVerifyingOtp
                ? "Verifying..."
                : "Verify OTP"}
            </button>

            <div className="resend-row">
              Didn't receive OTP?

              <button
                type="button"
                onClick={handleResendLoginOtp}
                disabled={isResendingOtp}
              >
                {isResendingOtp
                  ? "Sending..."
                  : "Resend OTP"}
              </button>
            </div>

          </div>

        </div>
      )}

      {/* ================================================= */}
      {/* FORGOT PASSWORD - EMAIL */}
      {/* ================================================= */}

      {modalStep === "forgotEmail" && (
        <div className="modal-overlay">

          <div className="auth-modal-card">

            <button
              type="button"
              className="modal-close"
              onClick={() =>
                setModalStep(null)
              }
            >
              ×
            </button>

            <div className="modal-logo-row">
              <img
                src={paperlessLogo}
                alt="Paperless AI"
                className="modal-paperless-logo"
              />

              <img
                src={visionLogo}
                alt="Vision AI"
                className="modal-vision-logo"
              />
            </div>

            <div className="otp-icon">
              <LockIcon />
            </div>

            <h2 className="modal-title">
              Forgot Password
            </h2>

            <p className="modal-description forgot-description">
              Enter your registered email
              address. We will send an OTP
              for password verification.
            </p>

            <div className="modal-input-group">

              <input
                type="email"
                placeholder="Email Address"
                value={forgotEmail}
                onChange={(e) => {
                  setForgotEmail(
                    e.target.value
                  );

                  if (
                    forgotEmailError
                  ) {
                    setForgotEmailError(
                      ""
                    );
                  }
                }}
                className={`modal-input ${
                  forgotEmailError
                    ? "input-error"
                    : ""
                }`}
              />

              {forgotEmailError && (
                <div className="validation-message">
                  <ErrorIcon />

                  <span>
                    {forgotEmailError}
                  </span>
                </div>
              )}

            </div>

            <button
              type="button"
              className="modal-primary-button"
              onClick={
                handleForgotSendOtp
              }
              disabled={isSendingForgotOtp}
            >
              {isSendingForgotOtp
                ? "Sending..."
                : "Send OTP"}
            </button>

            <button
              type="button"
              className="back-login-button"
              onClick={() =>
                setModalStep(null)
              }
            >
              ← Back to Login
            </button>

          </div>

        </div>
      )}

      {/* ================================================= */}
      {/* FORGOT PASSWORD - OTP */}
      {/* ================================================= */}

      {modalStep === "forgotOtp" && (
        <div className="modal-overlay">

          <div className="auth-modal-card">

            <button
              type="button"
              className="modal-close"
              onClick={() =>
                setModalStep(null)
              }
            >
              ×
            </button>

            <div className="modal-logo-row">
              <img
                src={paperlessLogo}
                alt="Paperless AI"
                className="modal-paperless-logo"
              />

              <img
                src={visionLogo}
                alt="Vision AI"
                className="modal-vision-logo"
              />
            </div>

            <div className="otp-icon">
              <MailIcon />
            </div>

            <h2 className="modal-title">
              Verify OTP
            </h2>

            <p className="modal-description">
              Enter the OTP sent to
            </p>

            <div className="modal-email">
              {forgotEmail}
            </div>

            <OtpBoxes
              otp={forgotOtp}
              setOtp={setForgotOtp}
              refs={forgotOtpRefs}
              error={forgotOtpError}
              setError={setForgotOtpError}
              onChange={handleOtpChange}
              onKeyDown={handleOtpKeyDown}
              onPaste={handleOtpPaste}
            />

            {forgotOtpError && (
              <div className="modal-error">
                <ErrorIcon />

                <span>
                  {forgotOtpError}
                </span>
              </div>
            )}

            <button
              type="button"
              className="modal-primary-button"
              onClick={
                handleForgotOtpVerify
              }
              disabled={isVerifyingForgotOtp}
            >
              {isVerifyingForgotOtp
                ? "Verifying..."
                : "Verify OTP"}
            </button>

            <div className="resend-row">
              Didn't receive OTP?

              <button
                type="button"
                onClick={handleResendForgotOtp}
                disabled={isResendingForgotOtp}
              >
                {isResendingForgotOtp
                  ? "Sending..."
                  : "Resend OTP"}
              </button>
            </div>

            <button
              type="button"
              className="back-login-button"
              onClick={() =>
                setModalStep(
                  "forgotEmail"
                )
              }
            >
              ← Change Email
            </button>

          </div>

        </div>
      )}

      {/* ================================================= */}
      {/* RESET PASSWORD */}
      {/* ================================================= */}

      {modalStep === "resetPassword" && (
        <div className="modal-overlay">

          <div className="auth-modal-card reset-card">

            <button
              type="button"
              className="modal-close"
              onClick={() =>
                setModalStep(null)
              }
            >
              ×
            </button>

            <div className="modal-logo-row">
              <img
                src={paperlessLogo}
                alt="Paperless AI"
                className="modal-paperless-logo"
              />

              <img
                src={visionLogo}
                alt="Vision AI"
                className="modal-vision-logo"
              />
            </div>

            <div className="otp-icon">
              <PasswordIcon />
            </div>

            <h2 className="modal-title">
              Create New Password
            </h2>

            <p className="modal-description forgot-description">
              Enter and confirm your new
              password.
            </p>

            {/* NEW PASSWORD */}

            <div className="modal-input-group">

              <div className="modal-password-input-wrapper">
                <input
                  type={showNewPassword ? "text" : "password"}
                  placeholder="New Password"
                  value={newPassword}
                  onChange={(e) => {
                    setNewPassword(
                      e.target.value
                    );

                    if (newPasswordError) {
                      setNewPasswordError("");
                    }

                    if (confirmPasswordError) {
                      setConfirmPasswordError("");
                    }
                  }}
                  className={`modal-input ${
                    newPasswordError
                      ? "input-error"
                      : ""
                  }`}
                  autoComplete="new-password"
                />

                <button
                  type="button"
                  className="password-toggle-button modal-password-toggle"
                  onClick={() =>
                    setShowNewPassword((current) => !current)
                  }
                  aria-label={
                    showNewPassword
                      ? "Hide new password"
                      : "Show new password"
                  }
                  title={
                    showNewPassword
                      ? "Hide new password"
                      : "Show new password"
                  }
                >
                  {showNewPassword ? (
                    <EyeOffIcon />
                  ) : (
                    <EyeIcon />
                  )}
                </button>
              </div>

              {newPasswordError && (
                <div className="validation-message">
                  <ErrorIcon />

                  <span>
                    {newPasswordError}
                  </span>
                </div>
              )}

            </div>

            {/* CONFIRM PASSWORD */}

            <div className="modal-input-group">

              <div className="modal-password-input-wrapper">
                <input
                  type={showConfirmPassword ? "text" : "password"}
                  placeholder="Confirm Password"
                  value={confirmPassword}
                  onChange={(e) => {
                    setConfirmPassword(
                      e.target.value
                    );

                    if (confirmPasswordError) {
                      setConfirmPasswordError("");
                    }
                  }}
                  className={`modal-input ${
                    confirmPasswordError
                      ? "input-error"
                      : ""
                  }`}
                  autoComplete="new-password"
                />

                <button
                  type="button"
                  className="password-toggle-button modal-password-toggle"
                  onClick={() =>
                    setShowConfirmPassword((current) => !current)
                  }
                  aria-label={
                    showConfirmPassword
                      ? "Hide confirm password"
                      : "Show confirm password"
                  }
                  title={
                    showConfirmPassword
                      ? "Hide confirm password"
                      : "Show confirm password"
                  }
                >
                  {showConfirmPassword ? (
                    <EyeOffIcon />
                  ) : (
                    <EyeIcon />
                  )}
                </button>
              </div>

              {confirmPasswordError && (
                <div className="validation-message">
                  <ErrorIcon />

                  <span>
                    {confirmPasswordError}
                  </span>
                </div>
              )}

            </div>

            <div className="password-rules">
              Password must contain at least
              8 characters, uppercase,
              lowercase, number and special
              character.
            </div>

            <button
              type="button"
              className="modal-primary-button"
              onClick={
                handleResetPassword
              }
              disabled={isResettingPassword}
            >
              {isResettingPassword
                ? "Updating..."
                : "Create New Password"}
            </button>

          </div>

        </div>
      )}

      {/* ================================================= */}
      {/* RESET SUCCESS */}
      {/* ================================================= */}

      {modalStep === "resetSuccess" && (
        <div className="modal-overlay">

          <div className="auth-modal-card success-card">

            <div className="success-icon">
              <CheckIcon />
            </div>

            <h2 className="modal-title">
              Password Updated
            </h2>

            <p className="modal-description forgot-description">
              Your password has been reset
              successfully. You can now sign
              in using your new password.
            </p>

            <button
              type="button"
              className="modal-primary-button"
              onClick={
                finishPasswordReset
              }
            >
              Back to Login
            </button>

          </div>

        </div>
      )}

      {/* ================================================= */}
      {/* CSS */}
      {/* ================================================= */}

      <style>{`

        * {
          box-sizing: border-box;
        }

        html,
        body,
        #root {
          width: 100%;
          height: 100%;
          margin: 0;
          padding: 0;
        }

        body {
          overflow: hidden;
          background: #02072c;
        }

        button,
        input {
          font-family:
            Arial,
            Helvetica,
            sans-serif;
        }

        /* ==============================================
           PAGE
        ============================================== */

        .login-page {
          position: relative;

          width: 100vw;
          height: 100vh;

          overflow: hidden;

          background-color:
            #02072c;

          background-repeat:
            no-repeat;

          background-position:
            center center;

          background-size:
            cover;

          color:
            white;

          font-family:
            Arial,
            Helvetica,
            sans-serif;
        }

        /* ==============================================
           LOGIN CARD
        ============================================== */

        .login-card {
          position: absolute;

          top: 8.5vh;
          left: 50%;

          transform:
            translateX(-50%);

          width:
            40.6vw;

          max-width:
            560px;

          min-width:
            320px;

          padding:
            clamp(18px, 2vw, 28px)
            clamp(30px, 4vw, 52px)
            clamp(16px, 1.8vw, 25px);

          border-radius:
            clamp(18px, 2vw, 24px);

          border:
            1px solid #23384d;

          background:
            #07192b;

          box-shadow:
            0
            12px
            35px
            rgba(0, 0, 0, 0.35);
        }

        /* ==============================================
           LOGOS
        ============================================== */

        .logo-row {
          width: 100%;

          display: flex;

          align-items: center;

          justify-content:
            space-between;

          min-height:
            clamp(44px, 5vw, 62px);

          margin-bottom:
            clamp(4px, 0.4vw, 7px);
        }

        .paperless-logo-image {
          display: block;

          width:
            clamp(
              118px,
              11vw,
              154px
            );

          height: auto;

          object-fit:
            contain;

          flex-shrink: 0;
        }

        .vision-logo-image {
          display: block;

          width:
            clamp(
              118px,
              11vw,
              145px
            );

          height: auto;

          object-fit:
            contain;

          flex-shrink: 0;
        }

        /* ==============================================
           TITLE
        ============================================== */

        .login-title {
          margin:
            clamp(
              7px,
              0.7vw,
              10px
            )
            0
            clamp(
              12px,
              1.3vw,
              18px
            );

          text-align:
            center;

          font-size:
            clamp(
              16px,
              1.55vw,
              22px
            );

          line-height:
            1.2;

          font-weight:
            700;
        }

        /* ==============================================
           INPUT
        ============================================== */

        .input-group {
          width: 100%;

          margin-bottom:
            clamp(
              8px,
              0.9vw,
              12px
            );
        }

        .login-input {
          display: block;

          width: 100%;

          height:
            clamp(
              35px,
              4.3vw,
              48px
            );

          margin: 0;

          padding:
            0
            clamp(
              11px,
              1.2vw,
              16px
            );

          border:
            1px solid #d9dde4;

          border-radius:
            clamp(
              5px,
              0.5vw,
              7px
            );

          background:
            #f8f8f8;

          color:
            #242b35;

          font-size:
            clamp(
              10px,
              1vw,
              14px
            );

          outline: none;
        }

        .login-input::placeholder {
          color:
            #9299a6;
        }

        .login-input:focus {
          border-color:
            #4b9cff;

          box-shadow:
            0
            0
            0
            1px
            rgba(
              78,
              156,
              255,
              0.18
            );
        }

        .password-input-wrapper {
          position: relative;
          width: 100%;
        }

        .password-input-wrapper .login-input {
          padding-right: 44px;
        }

        .password-toggle-button {
          position: absolute;
          top: 50%;
          right: 10px;
          transform: translateY(-50%);
          width: 30px;
          height: 30px;
          padding: 0;
          border: 0;
          background: transparent;
          color: #667085;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          border-radius: 6px;
        }

        .password-toggle-button:hover {
          color: #2563eb;
          background: rgba(37, 99, 235, 0.08);
        }

        .password-toggle-button:focus-visible {
          outline: 2px solid #4b9cff;
          outline-offset: 1px;
        }

        .password-toggle-button svg {
          width: 18px;
          height: 18px;
        }

        .input-error {
          border-color:
            #ef4444 !important;

          box-shadow:
            0
            0
            0
            1px
            rgba(
              239,
              68,
              68,
              0.25
            ) !important;
        }

        .validation-message {
          display: flex;

          align-items:
            center;

          gap: 4px;

          margin-top:
            4px;

          color:
            #ff8080;

          font-size:
            clamp(
              8px,
              0.72vw,
              10px
            );

          line-height:
            1.3;
        }

        .validation-message svg {
          width: 11px;
          height: 11px;

          flex-shrink: 0;
        }

        /* ==============================================
           LOGIN BUTTONS
        ============================================== */

        .button-row {
          display: grid;

          grid-template-columns:
            1fr 1fr;

          gap:
            clamp(
              8px,
              1vw,
              14px
            );

          margin-top:
            clamp(
              8px,
              1vw,
              12px
            );
        }

        .signin-button,
        .install-button {
          height:
            clamp(
              29px,
              3.5vw,
              40px
            );

          padding: 0;

          border: 0;

          border-radius:
            clamp(
              4px,
              0.45vw,
              6px
            );

          display: flex;

          align-items:
            center;

          justify-content:
            center;

          gap:
            clamp(
              5px,
              0.5vw,
              7px
            );

          color:
            white;

          font-size:
            clamp(
              10px,
              1vw,
              14px
            );

          font-weight:
            600;

          cursor:
            pointer;
        }

        .signin-button {
          background:
            linear-gradient(
              180deg,
              #0878ff 0%,
              #0563e9 100%
            );
        }

        .install-button {
          background:
            linear-gradient(
              180deg,
              #09c84b 0%,
              #06963b 100%
            );
        }

        .signin-button:disabled {
          opacity: 0.65;

          cursor:
            not-allowed;
        }

        .signin-button svg,
        .install-button svg {
          width:
            clamp(
              11px,
              1vw,
              14px
            );

          height:
            clamp(
              11px,
              1vw,
              14px
            );
        }

        /* ==============================================
           FORGOT
        ============================================== */

        .forgot-password {
          display: block;

          margin:
            clamp(
              9px,
              1.2vw,
              14px
            )
            auto
            0;

          padding: 0;

          border: 0;

          background:
            transparent;

          color:
            #f1f3f6;

          font-size:
            clamp(
              9px,
              0.9vw,
              12px
            );

          cursor:
            pointer;
        }

        .forgot-password:hover {
          color:
            #4ddcff;
        }

        /* ==============================================
           SOCIAL
        ============================================== */

        .social-row {
          display: flex;

          justify-content:
            center;

          gap:
            clamp(
              10px,
              1.1vw,
              15px
            );

          margin-top:
            clamp(
              10px,
              1.2vw,
              15px
            );
        }

        .social-button {
          width:
            clamp(
              55px,
              6.8vw,
              72px
            );

          height:
            clamp(
              25px,
              3vw,
              34px
            );

          padding: 0;

          border: 0;

          border-radius:
            clamp(
              4px,
              0.45vw,
              6px
            );

          background:
            #f6f6f6;

          display: flex;

          align-items:
            center;

          justify-content:
            center;

          cursor:
            pointer;
        }

        .social-button svg {
          width:
            clamp(
              15px,
              1.4vw,
              19px
            );

          height:
            clamp(
              15px,
              1.4vw,
              19px
            );
        }

        /* ==============================================
           TERMS
        ============================================== */

        .terms {
          width: 100%;

          margin-top:
            clamp(
              10px,
              1.2vw,
              15px
            );

          color:
            #e7ebf1;

          text-align:
            center;

          font-size:
            clamp(
              7px,
              0.68vw,
              9px
            );

          line-height:
            1.45;
        }

        .terms a {
          color:
            white;

          text-decoration:
            underline;
        }

        /* ==============================================
           FOOTER
        ============================================== */

        .login-footer {
          position:
            absolute;

          left:
            50%;

          bottom:
            clamp(
              14px,
              3vh,
              30px
            );

          transform:
            translateX(-50%);

          width:
            min(
              90vw,
              760px
            );

          text-align:
            center;

          color:
            #e3e7ed;

          font-size:
            clamp(
              8px,
              0.72vw,
              10px
            );

          line-height:
            clamp(
              18px,
              2vh,
              22px
            );
        }

        .login-footer strong {
          color:
            #ffffff;
        }

        .ip-row {
          display: flex;

          align-items:
            center;

          justify-content:
            center;

          gap:
            clamp(
              6px,
              0.7vw,
              10px
            );
        }

        /* ==============================================
           MODAL OVERLAY
        ============================================== */

        .modal-overlay {
          position: fixed;

          inset: 0;

          z-index: 9999;

          display: flex;

          align-items:
            center;

          justify-content:
            center;

          padding:
            20px;

          background:
            rgba(
              0,
              7,
              24,
              0.74
            );

          backdrop-filter:
            blur(5px);

          animation:
            fadeIn
            0.18s
            ease;
        }

        /* ==============================================
           OTP / FORGOT CARD
        ============================================== */

        .auth-modal-card {
          position:
            relative;

          width:
            min(
              40.6vw,
              560px
            );

          min-width:
            320px;

          padding:
            24px
            clamp(
              30px,
              4vw,
              52px
            )
            26px;

          border:
            1px solid
            #29465f;

          border-radius:
            clamp(
              18px,
              2vw,
              24px
            );

          background:
            #07192b;

          color:
            white;

          box-shadow:
            0
            22px
            70px
            rgba(
              0,
              0,
              0,
              0.55
            );

          animation:
            modalIn
            0.2s
            ease;
        }

        .modal-close {
          position:
            absolute;

          top:
            11px;

          right:
            14px;

          width:
            30px;

          height:
            30px;

          padding: 0;

          border: 0;

          background:
            transparent;

          color:
            #aebdcb;

          font-size:
            27px;

          line-height:
            28px;

          cursor:
            pointer;
        }

        .modal-close:hover {
          color:
            white;
        }

        /* ==============================================
           MODAL LOGOS
        ============================================== */

        .modal-logo-row {
          width:
            100%;

          display:
            flex;

          align-items:
            center;

          justify-content:
            space-between;

          padding-right:
            18px;

          margin-bottom:
            12px;
        }

        .modal-paperless-logo {
          width:
            clamp(
              110px,
              10vw,
              145px
            );

          height:
            auto;
        }

        .modal-vision-logo {
          width:
            clamp(
              110px,
              10vw,
              145px
            );

          height:
            auto;
        }

        /* ==============================================
           MODAL ICON
        ============================================== */

        .otp-icon {
          width:
            48px;

          height:
            48px;

          margin:
            5px
            auto
            9px;

          display:
            flex;

          align-items:
            center;

          justify-content:
            center;

          border:
            1px solid
            rgba(
              50,
              164,
              255,
              0.35
            );

          border-radius:
            50%;

          background:
            rgba(
              16,
              108,
              196,
              0.15
            );

          color:
            #35b8ff;
        }

        .otp-icon svg {
          width:
            23px;

          height:
            23px;
        }

        /* ==============================================
           MODAL TEXT
        ============================================== */

        .modal-title {
          margin:
            0
            0
            8px;

          text-align:
            center;

          font-size:
            clamp(
              18px,
              1.6vw,
              22px
            );

          font-weight:
            700;
        }

        .modal-description {
          margin:
            0;

          text-align:
            center;

          color:
            #aebdcb;

          font-size:
            clamp(
              10px,
              0.9vw,
              12px
            );

          line-height:
            1.5;
        }

        .forgot-description {
          max-width:
            350px;

          margin:
            0
            auto
            16px;
        }

        .modal-email {
          margin-top:
            3px;

          text-align:
            center;

          color:
            #ffffff;

          font-size:
            clamp(
              11px,
              1vw,
              13px
            );

          font-weight:
            700;
        }

        /* ==============================================
           OTP BOX
        ============================================== */

        .otp-box-container {
          display:
            flex;

          align-items:
            center;

          justify-content:
            center;

          gap:
            clamp(
              6px,
              0.8vw,
              10px
            );

          margin:
            22px
            0
            12px;
        }

        .otp-box {
          width:
            clamp(
              35px,
              4vw,
              46px
            );

          height:
            clamp(
              40px,
              4.5vw,
              50px
            );

          padding: 0;

          border:
            1px solid
            #37536e;

          border-radius:
            7px;

          background:
            #0d263d;

          color:
            #ffffff;

          text-align:
            center;

          font-size:
            clamp(
              17px,
              1.5vw,
              21px
            );

          font-weight:
            700;

          outline:
            none;

          caret-color:
            #37b8ff;
        }

        .otp-box:focus {
          border-color:
            #1595ff;

          box-shadow:
            0
            0
            0
            2px
            rgba(
              21,
              149,
              255,
              0.12
            );
        }

        /* ==============================================
           MODAL ERRORS
        ============================================== */

        .modal-error {
          display:
            flex;

          align-items:
            center;

          justify-content:
            center;

          gap:
            5px;

          min-height:
            18px;

          margin-bottom:
            8px;

          color:
            #ff8080;

          text-align:
            center;

          font-size:
            10px;
        }

        .modal-error svg {
          width:
            12px;

          height:
            12px;
        }

        /* ==============================================
           MODAL INPUTS
        ============================================== */

        .modal-input-group {
          width:
            100%;

          margin-bottom:
            12px;
        }

        .modal-input {
          width:
            100%;

          height:
            43px;

          padding:
            0
            13px;

          border:
            1px solid
            #d9dde4;

          border-radius:
            6px;

          background:
            #f8f8f8;

          color:
            #242b35;

          font-size:
            12px;

          outline:
            none;
        }

        .modal-input:focus {
          border-color:
            #4b9cff;
        }

        .modal-password-input-wrapper {
          position: relative;
          width: 100%;
        }

        .modal-password-input-wrapper .modal-input {
          padding-right: 44px;
        }

        .modal-password-toggle {
          right: 9px;
        }

        .modal-primary-button:disabled,
        .resend-row button:disabled {
          opacity: 0.65;
          cursor: not-allowed;
        }

        /* ==============================================
           MODAL BUTTON
        ============================================== */

        .modal-primary-button {
          width:
            100%;

          height:
            40px;

          margin-top:
            5px;

          border: 0;

          border-radius:
            6px;

          background:
            linear-gradient(
              180deg,
              #0878ff 0%,
              #0563e9 100%
            );

          color:
            white;

          font-size:
            12px;

          font-weight:
            700;

          cursor:
            pointer;
        }

        .modal-primary-button:hover {
          filter:
            brightness(1.08);
        }

        /* ==============================================
           RESEND
        ============================================== */

        .resend-row {
          display:
            flex;

          align-items:
            center;

          justify-content:
            center;

          gap:
            5px;

          margin-top:
            12px;

          color:
            #aebdcb;

          font-size:
            10px;
        }

        .resend-row button {
          padding: 0;

          border: 0;

          background:
            transparent;

          color:
            #38bdf8;

          font-size:
            10px;

          font-weight:
            700;

          cursor:
            pointer;
        }

        .back-login-button {
          display:
            block;

          margin:
            13px
            auto
            0;

          padding: 0;

          border: 0;

          background:
            transparent;

          color:
            #aebdcb;

          font-size:
            10px;

          cursor:
            pointer;
        }

        .back-login-button:hover {
          color:
            #38bdf8;
        }

        /* ==============================================
           PASSWORD RULES
        ============================================== */

        .password-rules {
          margin:
            2px
            0
            12px;

          color:
            #8296a9;

          font-size:
            9px;

          line-height:
            1.45;
        }

        /* ==============================================
           DEMO OTP
        ============================================== */

        .demo-otp {
          margin-top:
            10px;

          text-align:
            center;

          color:
            #71889c;

          font-size:
            9px;
        }

        .demo-otp strong {
          color:
            #63d5ff;
        }

        /* ==============================================
           SUCCESS
        ============================================== */

        .success-card {
          padding-top:
            35px;
        }

        .success-icon {
          width:
            58px;

          height:
            58px;

          margin:
            0
            auto
            14px;

          display:
            flex;

          align-items:
            center;

          justify-content:
            center;

          border-radius:
            50%;

          background:
            rgba(
              16,
              185,
              88,
              0.15
            );

          border:
            1px solid
            rgba(
              16,
              185,
              88,
              0.45
            );

          color:
            #20d56b;
        }

        .success-icon svg {
          width:
            30px;

          height:
            30px;
        }

        /* ==============================================
           ANIMATION
        ============================================== */

        @keyframes fadeIn {
          from {
            opacity: 0;
          }

          to {
            opacity: 1;
          }
        }

        @keyframes modalIn {
          from {
            opacity: 0;

            transform:
              translateY(10px)
              scale(0.98);
          }

          to {
            opacity: 1;

            transform:
              translateY(0)
              scale(1);
          }
        }

        /* ==============================================
           LARGE
        ============================================== */

        @media (
          min-width: 1500px
        ) {

          .login-card {
            width:
              min(
                38vw,
                590px
              );
          }

          .auth-modal-card {
            width:
              min(
                38vw,
                590px
              );
          }

        }

        /* ==============================================
           LAPTOP
        ============================================== */

        @media (
          max-width: 1100px
        ) {

          .login-card {
            width:
              44vw;

            min-width:
              320px;
          }

          .auth-modal-card {
            width:
              44vw;
          }

        }

        /* ==============================================
           TABLET
        ============================================== */

        @media (
          max-width: 800px
        ) {

          .login-card {
            width:
              min(
                72vw,
                480px
              );

            top:
              6vh;
          }

          .auth-modal-card {
            width:
              min(
                72vw,
                480px
              );
          }

          .login-footer {
            width:
              94vw;
          }

        }

        /* ==============================================
           MOBILE
        ============================================== */

        @media (
          max-width: 600px
        ) {

          body {
            overflow-y:
              auto;
          }

          .login-page {
            min-height:
              100vh;

            height:
              auto;

            overflow-y:
              auto;
          }

          .login-card {
            position:
              relative;

            top:
              auto;

            left:
              auto;

            transform:
              none;

            width:
              calc(
                100% - 32px
              );

            min-width:
              auto;

            max-width:
              390px;

            margin:
              24px
              auto
              0;

            padding:
              20px
              30px
              18px;
          }

          .paperless-logo-image {
            width:
              115px;
          }

          .vision-logo-image {
            width:
              115px;
          }

          .login-footer {
            position:
              relative;

            left:
              auto;

            bottom:
              auto;

            transform:
              none;

            width:
              calc(
                100% - 24px
              );

            margin:
              28px
              auto
              18px;
          }

          .auth-modal-card {
            width:
              100%;

            min-width:
              0;

            max-width:
              390px;

            padding:
              22px
              24px
              24px;
          }

          .otp-box-container {
            gap:
              5px;
          }

          .otp-box {
            width:
              37px;

            height:
              43px;
          }

          .modal-paperless-logo {
            width:
              110px;
          }

          .modal-vision-logo {
            width:
              110px;
          }

          .ip-row {
            flex-wrap:
              wrap;
          }

        }

      `}</style>
    </div>
  );
}

/* =========================================================
   OTP BOX COMPONENT
========================================================= */

function OtpBoxes({
  otp,
  setOtp,
  refs,
  setError,
  onChange,
  onKeyDown,
  onPaste,
}) {
  return (
    <div className="otp-box-container">
      {otp.map(
        (value, index) => (
          <input
            key={index}
            ref={(element) => {
              refs.current[index] =
                element;
            }}
            type="text"
            inputMode="numeric"
            maxLength={1}
            value={value}
            className="otp-box"
            onChange={(e) =>
              onChange(
                index,
                e.target.value,
                otp,
                setOtp,
                refs,
                setError
              )
            }
            onKeyDown={(e) =>
              onKeyDown(
                index,
                e,
                otp,
                refs
              )
            }
            onPaste={(e) =>
              onPaste(
                e,
                setOtp,
                refs,
                setError
              )
            }
          />
        )
      )}
    </div>
  );
}

/* =========================================================
   ICONS
========================================================= */

function EyeIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  );
}

function EyeOffIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M3 3l18 18" />
      <path d="M10.6 10.6a2 2 0 0 0 2.8 2.8" />
      <path d="M9.9 4.2A10.8 10.8 0 0 1 12 4c6.5 0 10 8 10 8a18.5 18.5 0 0 1-3 4.2" />
      <path d="M6.6 6.6C3.7 8.5 2 12 2 12s3.5 8 10 8a10.6 10.6 0 0 0 4.1-.8" />
    </svg>
  );
}

function ErrorIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle
        cx="12"
        cy="12"
        r="9"
      />

      <path d="M12 7v6" />

      <path d="M12 17h.01" />
    </svg>
  );
}

function MailIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect
        x="3"
        y="5"
        width="18"
        height="14"
        rx="2"
      />

      <path d="m3 7 9 6 9-6" />
    </svg>
  );
}

function LockIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect
        x="5"
        y="10"
        width="14"
        height="11"
        rx="2"
      />

      <path d="M8 10V7a4 4 0 0 1 8 0v3" />
    </svg>
  );
}

function PasswordIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M7 14a4 4 0 1 1 3-6.65" />

      <path d="M10 11h11" />

      <path d="M18 11v3" />

      <path d="M15 11v2" />
    </svg>
  );
}

function CheckIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m5 12 4 4L19 6" />
    </svg>
  );
}

function LoginIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="white"
      strokeWidth="2.4"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M10 17l5-5-5-5" />

      <path d="M15 12H3" />

      <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4" />
    </svg>
  );
}

function DownloadIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="white"
      strokeWidth="2.4"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 3v12" />

      <path d="M7 10l5 5 5-5" />

      <path d="M5 21h14" />
    </svg>
  );
}

function InstagramIcon() {
  return (
    <svg viewBox="0 0 24 24">

      <defs>
        <linearGradient
          id="instaGradient"
          x1="0"
          y1="1"
          x2="1"
          y2="0"
        >
          <stop
            offset="0%"
            stopColor="#FFBA45"
          />

          <stop
            offset="45%"
            stopColor="#FF3478"
          />

          <stop
            offset="100%"
            stopColor="#9935D7"
          />
        </linearGradient>
      </defs>

      <rect
        x="4"
        y="4"
        width="16"
        height="16"
        rx="5"
        fill="none"
        stroke="url(#instaGradient)"
        strokeWidth="2.3"
      />

      <circle
        cx="12"
        cy="12"
        r="3.4"
        fill="none"
        stroke="#F14482"
        strokeWidth="2"
      />

      <circle
        cx="17.2"
        cy="6.9"
        r="1.1"
        fill="#AD3AC8"
      />

    </svg>
  );
}

function FacebookIcon() {
  return (
    <svg viewBox="0 0 24 24">

      <rect
        x="3"
        y="3"
        width="18"
        height="18"
        rx="3"
        fill="#266CC1"
      />

      <text
        x="12"
        y="18"
        textAnchor="middle"
        fontSize="16"
        fontWeight="700"
        fill="white"
      >
        f
      </text>

    </svg>
  );
}

function LinkedinIcon() {
  return (
    <svg viewBox="0 0 24 24">

      <rect
        x="3"
        y="3"
        width="18"
        height="18"
        rx="2"
        fill="#1769AA"
      />

      <text
        x="12"
        y="16.5"
        textAnchor="middle"
        fontSize="10"
        fontWeight="700"
        fill="white"
      >
        in
      </text>

    </svg>
  );
}