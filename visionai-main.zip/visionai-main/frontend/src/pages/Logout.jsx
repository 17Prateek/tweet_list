import {
  useEffect,
} from "react";

import {
  useNavigate,
} from "react-router-dom";

import {
  CheckCircle2,
  LogIn,
} from "lucide-react";

import loginBackground from "../assets/vision-ai-login-background.png";
import visionLogo from "../assets/vision-ai-logo.png";
import paperlessLogo from "../assets/logo_1.png";

/* =========================================================
   LOGOUT PAGE
========================================================= */

export default function Logout() {
  const navigate = useNavigate();

  /* =======================================================
     SAFETY SESSION CLEANUP
  ======================================================= */

  useEffect(() => {
    /*
     * Sidebar already clears these values before navigating
     * here.
     *
     * We clear them again intentionally so even if somebody
     * directly opens /logout, the browser session is ended.
     */

    sessionStorage.removeItem("isLoggedIn");
    sessionStorage.removeItem("loggedInEmail");
    sessionStorage.removeItem("accessToken");
    sessionStorage.removeItem("currentUser");
  }, []);

  /* =======================================================
     LOGIN AGAIN
  ======================================================= */

  const handleLoginAgain = () => {
    navigate("/login", {
      replace: true,
    });
  };

  return (
    <div
      className="logout-page"
      style={{
        backgroundImage:
          `url(${loginBackground})`,
      }}
    >

      {/* ===================================================
          LOGOUT CARD
      =================================================== */}

      <main className="logout-card">

        {/* LOGOS */}

        <div className="logout-logo-row">

          <img
            src={paperlessLogo}
            alt="Paperless AI"
            className="logout-paperless-logo"
          />

          <img
            src={visionLogo}
            alt="Vision AI"
            className="logout-vision-logo"
          />

        </div>

        {/* SUCCESS ICON */}

        <div className="logout-success-icon">
          <CheckCircle2 />
        </div>

        {/* TITLE */}

        <h1 className="logout-title">
          Logout Successful
        </h1>

        {/* MESSAGE */}

        <p className="logout-description">
          You have successfully logged out of the
          Vision AI Monitoring System.
        </p>

        <p className="logout-security-text">
          Please log in again to access your
          monitoring dashboard.
        </p>

        {/* LOGIN BUTTON */}

        <button
          type="button"
          className="login-again-button"
          onClick={handleLoginAgain}
        >
          <LogIn />

          <span>
            Login
          </span>
        </button>

      </main>

      {/* ===================================================
          FOOTER
      =================================================== */}

      <footer className="logout-footer">

        <div className="logout-ip-row">
          <span>
            IP Address
          </span>

          <strong>
            49.36.138.165, 208.109.1.13
          </strong>
        </div>

        <div>
          This site is best viewed in Google Chrome
          and Mozilla Firefox. Copyright © 2018-26.
          All Rights Reserved
        </div>

        <div>
          Designed, developed & maintained by{" "}
          <strong>
            QHSE Risk Consultants LLP
          </strong>
        </div>

      </footer>

      {/* ===================================================
          CSS
      =================================================== */}

      <style>{`

        * {
          box-sizing: border-box;
        }

        html,
        body,
        #root {
          width: 100%;
          height: 100%;
          margin: 0;
          padding: 0;
        }

        body {
          overflow: hidden;
          background: #02072c;
        }

        button {
          font-family:
            Arial,
            Helvetica,
            sans-serif;
        }

        /* ================================================
           PAGE
        ================================================ */

        .logout-page {
          position: relative;

          width: 100vw;
          height: 100vh;

          overflow: hidden;

          background-color: #02072c;
          background-repeat: no-repeat;
          background-position: center center;
          background-size: cover;

          color: white;

          font-family:
            Arial,
            Helvetica,
            sans-serif;
        }

        /* ================================================
           CARD
        ================================================ */

        .logout-card {
          position: absolute;

          top: 50%;
          left: 50%;

          transform:
            translate(-50%, -54%);

          width: 40.6vw;

          max-width: 560px;
          min-width: 320px;

          padding:
            clamp(22px, 2.4vw, 34px)
            clamp(30px, 4vw, 52px)
            clamp(24px, 2.6vw, 36px);

          border:
            1px solid #23384d;

          border-radius:
            clamp(18px, 2vw, 24px);

          background:
            #07192b;

          box-shadow:
            0 12px 35px
            rgba(0, 0, 0, 0.35);

          text-align: center;
        }

        /* ================================================
           LOGOS
        ================================================ */

        .logout-logo-row {
          width: 100%;

          display: flex;

          align-items: center;

          justify-content:
            space-between;

          min-height:
            clamp(44px, 5vw, 62px);

          margin-bottom:
            clamp(14px, 1.4vw, 20px);
        }

        .logout-paperless-logo {
          display: block;

          width:
            clamp(
              118px,
              11vw,
              154px
            );

          height: auto;

          object-fit: contain;

          flex-shrink: 0;
        }

        .logout-vision-logo {
          display: block;

          width:
            clamp(
              118px,
              11vw,
              145px
            );

          height: auto;

          object-fit: contain;

          flex-shrink: 0;
        }

        /* ================================================
           SUCCESS ICON
        ================================================ */

        .logout-success-icon {
          width:
            clamp(48px, 5vw, 62px);

          height:
            clamp(48px, 5vw, 62px);

          margin:
            3px auto
            clamp(10px, 1vw, 14px);

          display: flex;

          align-items: center;

          justify-content: center;

          border:
            1px solid
            rgba(34, 197, 94, 0.4);

          border-radius: 50%;

          background:
            rgba(34, 197, 94, 0.12);

          color:
            #32d875;
        }

        .logout-success-icon svg {
          width:
            clamp(27px, 2.8vw, 36px);

          height:
            clamp(27px, 2.8vw, 36px);
        }

        /* ================================================
           TITLE
        ================================================ */

        .logout-title {
          margin:
            0
            0
            clamp(10px, 1vw, 14px);

          color:
            #ffffff;

          text-align: center;

          font-size:
            clamp(
              19px,
              1.7vw,
              24px
            );

          line-height: 1.25;

          font-weight: 700;
        }

        /* ================================================
           DESCRIPTION
        ================================================ */

        .logout-description {
          max-width: 390px;

          margin:
            0 auto
            clamp(8px, 0.9vw, 12px);

          color:
            #e8edf3;

          text-align: center;

          font-size:
            clamp(
              11px,
              1vw,
              14px
            );

          line-height: 1.6;
        }

        .logout-security-text {
          max-width: 390px;

          margin:
            0 auto
            clamp(20px, 2vw, 28px);

          color:
            #aebdcb;

          text-align: center;

          font-size:
            clamp(
              10px,
              0.9vw,
              12px
            );

          line-height: 1.6;
        }

        /* ================================================
           LOGIN AGAIN
        ================================================ */

        .login-again-button {
          width: 100%;

          height:
            clamp(
              36px,
              4vw,
              44px
            );

          padding: 0 20px;

          border: 0;

          border-radius:
            clamp(
              5px,
              0.5vw,
              7px
            );

          display: flex;

          align-items: center;

          justify-content: center;

          gap: 8px;

          background:
            linear-gradient(
              180deg,
              #0878ff 0%,
              #0563e9 100%
            );

          color: white;

          font-size:
            clamp(
              11px,
              1vw,
              14px
            );

          font-weight: 600;

          cursor: pointer;

          transition:
            transform 0.15s ease,
            box-shadow 0.15s ease,
            filter 0.15s ease;
        }

        .login-again-button:hover {
          filter: brightness(1.08);

          box-shadow:
            0 7px 20px
            rgba(5, 99, 233, 0.28);
        }

        .login-again-button:active {
          transform:
            translateY(1px);
        }

        .login-again-button:focus-visible {
          outline:
            2px solid #65b7ff;

          outline-offset:
            3px;
        }

        .login-again-button svg {
          width: 17px;
          height: 17px;
        }

        /* ================================================
           FOOTER
        ================================================ */

        .logout-footer {
          position: absolute;

          left: 50%;

          bottom:
            clamp(
              14px,
              3vh,
              30px
            );

          transform:
            translateX(-50%);

          width:
            min(
              90vw,
              760px
            );

          text-align: center;

          color:
            #e3e7ed;

          font-size:
            clamp(
              8px,
              0.72vw,
              10px
            );

          line-height:
            clamp(
              18px,
              2vh,
              22px
            );
        }

        .logout-footer strong {
          color: #ffffff;
        }

        .logout-ip-row {
          display: flex;

          align-items: center;

          justify-content: center;

          gap:
            clamp(
              6px,
              0.7vw,
              10px
            );
        }

        /* ================================================
           SMALL SCREEN
        ================================================ */

        @media (max-width: 600px) {

          .logout-card {
            width: calc(100vw - 32px);
            min-width: 0;

            padding:
              22px
              22px
              26px;
          }

          .logout-logo-row {
            gap: 20px;
          }

          .logout-paperless-logo,
          .logout-vision-logo {
            width: 120px;
            max-width: 46%;
          }

          .logout-footer {
            width:
              calc(100vw - 24px);
          }

        }

      `}</style>

    </div>
  );
}