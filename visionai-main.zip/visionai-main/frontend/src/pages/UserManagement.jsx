import { useEffect, useMemo, useState } from "react";
import {
  CheckCircle2,
  Edit3,
  Eye,
  EyeOff,
  ShieldCheck,
  ToggleLeft,
  ToggleRight,
  Trash2,
  UserCheck,
  UserPlus,
  Users,
  UserX,
} from "lucide-react";

import {
  createUser,
  deleteUser,
  getUsers,
  getUserStats,
  updateUser,
  updateUserStatus,
} from "../data/api";

const emptyForm = {
  fullName: "",
  employeeId: "",
  email: "",
  mobile: "",
  department: "",
  password: "",
  confirmPassword: "",
};

const emptyErrors = {
  fullName: "",
  employeeId: "",
  email: "",
  mobile: "",
  department: "",
  password: "",
  confirmPassword: "",
};

const emptyStats = {
  totalUsers: 0,
  activeUsers: 0,
  inactiveUsers: 0,
  superAdmins: 0,
};

function StatCard({ title, value, subtitle, icon: Icon, type }) {
  const styles = {
    total: {
      wrap: "border-blue-500/25",
      glow: "bg-blue-500/10",
      icon: "bg-blue-500/15 text-blue-400 ring-blue-500/20",
      value: "text-blue-300",
      bar: "from-blue-500 to-cyan-400",
    },
    active: {
      wrap: "border-emerald-500/25",
      glow: "bg-emerald-500/10",
      icon: "bg-emerald-500/15 text-emerald-400 ring-emerald-500/20",
      value: "text-emerald-300",
      bar: "from-emerald-500 to-green-400",
    },
    inactive: {
      wrap: "border-orange-500/25",
      glow: "bg-orange-500/10",
      icon: "bg-orange-500/15 text-orange-400 ring-orange-500/20",
      value: "text-orange-300",
      bar: "from-orange-500 to-amber-400",
    },
    admin: {
      wrap: "border-purple-500/25",
      glow: "bg-purple-500/10",
      icon: "bg-purple-500/15 text-purple-400 ring-purple-500/20",
      value: "text-purple-300",
      bar: "from-purple-500 to-fuchsia-400",
    },
  };

  const style = styles[type];

  return (
    <div
      className={`group relative overflow-hidden rounded-xl border bg-[#07182a] p-3 transition duration-300 hover:-translate-y-0.5 hover:shadow-xl ${style.wrap}`}
    >
      <div
        className={`pointer-events-none absolute -right-12 -top-12 h-32 w-32 rounded-full blur-3xl ${style.glow}`}
      />

      <div className="relative flex items-center gap-3">
        <div
          className={`grid h-12 w-12 shrink-0 place-items-center rounded-xl ring-1 ${style.icon}`}
        >
          <Icon size={24} />
        </div>

        <div className="min-w-0">
          <p className="truncate text-[13px] font-medium text-white/90">
            {title}
          </p>

          <div className="mt-0.5 flex items-end gap-2">
            <h3 className={`text-2xl font-bold leading-none ${style.value}`}>
              {value}
            </h3>

            <span className="pb-0.5 text-[10px] text-white/75">Users</span>
          </div>

          <p className="mt-2 truncate text-[10px] text-white/85">
            {subtitle}
          </p>
        </div>
      </div>

      <div className="mt-4 h-1 overflow-hidden rounded-full bg-white/5">
        <div
          className={`h-full w-[78%] rounded-full bg-gradient-to-r ${style.bar}`}
        />
      </div>
    </div>
  );
}

function FormField({ label, error, required = true, children }) {
  return (
    <div className="min-w-0">
      <label className="mb-1.5 block text-[11px] font-semibold text-white/80">
        {label}
        {required && <span className="ml-1 text-red-400">*</span>}
      </label>

      {children}

      <div className="min-h-[18px] pt-1">
        {error && (
          <p className="text-[10px] font-medium leading-tight text-red-400">
            {error}
          </p>
        )}
      </div>
    </div>
  );
}

export default function UserManagement() {
  const [users, setUsers] = useState([]);
  const [stats, setStats] = useState(emptyStats);

  const [form, setForm] = useState(emptyForm);
  const [errors, setErrors] = useState(emptyErrors);
  const [editingEmail, setEditingEmail] = useState(null);

  const [successMessage, setSuccessMessage] = useState("");
  const [apiError, setApiError] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [search, setSearch] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const loadUsers = async () => {
    try {
      const result = await getUsers();
      setUsers(Array.isArray(result?.data) ? result.data : []);
    } catch (error) {
      setApiError(error.message || "Could not load users.");
    }
  };

  const loadStats = async () => {
    try {
      const result = await getUserStats();
      setStats(result?.data || emptyStats);
    } catch (error) {
      console.error("User stats error:", error);
    }
  };

  const refreshData = async () => {
    await Promise.all([loadUsers(), loadStats()]);
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      setApiError("");

      await refreshData();

      setLoading(false);
    };

    loadData();
  }, []);

  const departments = useMemo(
    () =>
      [...new Set(users.map((user) => user.department).filter(Boolean))].sort(),
    [users]
  );

  const filteredUsers = useMemo(() => {
    const query = search.trim().toLowerCase();

    return users.filter((user) => {
      const matchesSearch =
        !query ||
        user.name?.toLowerCase().includes(query) ||
        user.employeeId?.toLowerCase().includes(query) ||
        user.email?.toLowerCase().includes(query) ||
        user.mobile?.includes(query) ||
        user.department?.toLowerCase().includes(query);

      const matchesDepartment =
        departmentFilter === "All" ||
        user.department === departmentFilter;

      const matchesStatus =
        statusFilter === "All" ||
        user.status === statusFilter;

      return matchesSearch && matchesDepartment && matchesStatus;
    });
  }, [users, search, departmentFilter, statusFilter]);

  const inputClass = (error, disabled = false) =>
    `h-10 w-full rounded-md border bg-[#04111e] px-3 text-[11px] text-white outline-none transition placeholder:text-white/30 ${
      error
        ? "border-red-500/70 focus:border-red-400"
        : "border-[#173755] focus:border-blue-500"
    } ${disabled ? "cursor-not-allowed opacity-60" : ""}`;

  const updateForm = (field, value) => {
    let nextValue = value;

    if (field === "mobile") {
      nextValue = value.replace(/\D/g, "").slice(0, 10);
    }

    if (field === "employeeId") {
      nextValue = value.toUpperCase().replace(/\s/g, "");
    }

    setForm((prev) => ({
      ...prev,
      [field]: nextValue,
    }));

    if (errors[field]) {
      setErrors((prev) => ({
        ...prev,
        [field]: "",
      }));
    }

    setSuccessMessage("");
    setApiError("");
  };

  const validateField = (field, value) => {
    const clean =
      typeof value === "string"
        ? value.trim()
        : value;

    if (field === "fullName") {
      if (!clean) return "Full name is required.";
      if (clean.length < 3)
        return "Full name must contain at least 3 characters.";
      if (!/^[A-Za-z][A-Za-z\s.'-]*$/.test(clean))
        return "Please enter a valid full name.";
    }

    if (field === "employeeId") {
      if (!clean) return "Employee ID is required.";
      if (!/^[A-Za-z0-9_-]{3,20}$/.test(clean))
        return "Use 3-20 letters, numbers, _ or - only.";
    }

    if (field === "email") {
      if (!clean) return "Email address is required.";

      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean))
        return "Please enter a valid email address.";

      if (!editingEmail) {
        const exists = users.some(
          (user) =>
            user.email?.toLowerCase() === clean.toLowerCase()
        );

        if (exists)
          return "This email address is already registered.";
      }
    }

    if (field === "mobile") {
      if (!clean) return "Mobile number is required.";

      if (!/^[6-9]\d{9}$/.test(clean))
        return "Enter a valid 10-digit mobile number.";
    }

    if (field === "department") {
      if (!clean) return "Department is required.";

      if (clean.length < 2)
        return "Enter a valid department name.";
    }

    if (field === "password") {
      if (editingEmail && !value)
        return "";

      if (!value)
        return "Password is required.";

      if (value.length < 8)
        return "Password must be at least 8 characters.";

      if (!/[A-Z]/.test(value))
        return "Add at least one uppercase letter.";

      if (!/[a-z]/.test(value))
        return "Add at least one lowercase letter.";

      if (!/[0-9]/.test(value))
        return "Add at least one number.";

      if (!/[^A-Za-z0-9]/.test(value))
        return "Add at least one special character.";
    }

    if (field === "confirmPassword") {
      if (editingEmail && !form.password && !value)
        return "";

      if (!value)
        return "Confirm password is required.";

      if (value !== form.password)
        return "Passwords do not match.";
    }

    return "";
  };

  const handleBlur = (field) => {
    setErrors((prev) => ({
      ...prev,
      [field]: validateField(field, form[field]),
    }));
  };

  const validateForm = () => {
    const newErrors = {
      fullName: validateField("fullName", form.fullName),
      employeeId: validateField("employeeId", form.employeeId),
      email: validateField("email", form.email),
      mobile: validateField("mobile", form.mobile),
      department: validateField("department", form.department),
      password: validateField("password", form.password),
      confirmPassword: validateField(
        "confirmPassword",
        form.confirmPassword
      ),
    };

    setErrors(newErrors);

    return !Object.values(newErrors).some(Boolean);
  };

  const resetForm = () => {
    setEditingEmail(null);
    setForm(emptyForm);
    setErrors(emptyErrors);
    setShowPassword(false);
    setShowConfirmPassword(false);
  };

  const handleSave = async () => {
    setSuccessMessage("");
    setApiError("");

    if (!validateForm())
      return;

    setSaving(true);

    try {
      if (editingEmail) {
        const payload = {
          fullName: form.fullName.trim(),
          employeeId: form.employeeId.trim(),
          mobile: form.mobile,
          department: form.department.trim(),
          password: form.password || null,
        };

        const result = await updateUser(editingEmail, payload);

        setSuccessMessage(
          result?.message || "User updated successfully."
        );
      } else {
        const payload = {
          fullName: form.fullName.trim(),
          employeeId: form.employeeId.trim(),
          email: form.email.trim().toLowerCase(),
          mobile: form.mobile,
          department: form.department.trim(),
          password: form.password,
        };

        const result = await createUser(payload);

        setSuccessMessage(
          result?.message || "New user created successfully."
        );
      }

      resetForm();
      await refreshData();
    } catch (error) {
      setApiError(
        error.message || "Could not save user."
      );
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (user) => {
    setEditingEmail(user.email);
    setShowPassword(false);
    setShowConfirmPassword(false);

    setForm({
      fullName: user.name || "",
      employeeId: user.employeeId || "",
      email: user.email || "",
      mobile: user.mobile || "",
      department: user.department || "",
      password: "",
      confirmPassword: "",
    });

    setErrors(emptyErrors);
    setSuccessMessage("");
    setApiError("");

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  const handleCancel = () => {
    resetForm();
    setSuccessMessage("");
    setApiError("");
  };

  const handleToggleStatus = async (user) => {
    setSuccessMessage("");
    setApiError("");

    try {
      const isActive =
        user.status !== "Active";

      const result = await updateUserStatus(
        user.email,
        isActive
      );

      setSuccessMessage(
        result?.message ||
          (isActive
            ? "User activated successfully."
            : "User deactivated successfully.")
      );

      await refreshData();
    } catch (error) {
      setApiError(
        error.message ||
          "Could not update user status."
      );
    }
  };

  const handleDelete = async (user) => {
    const confirmed = window.confirm(
      `Are you sure you want to delete ${user.name}?`
    );

    if (!confirmed)
      return;

    setSuccessMessage("");
    setApiError("");

    try {
      const result = await deleteUser(user.email);

      if (editingEmail === user.email) {
        resetForm();
      }

      setSuccessMessage(
        result?.message ||
          "User deleted successfully."
      );

      await refreshData();
    } catch (error) {
      setApiError(
        error.message ||
          "Could not delete user."
      );
    }
  };

  const clearFilters = () => {
    setSearch("");
    setDepartmentFilter("All");
    setStatusFilter("All");
  };

  return (
    <div className="min-w-0 space-y-2 px-0.2 pb-1">
      {/* SUMMARY CARDS */}
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-4 xl:grid-cols-4">
        <StatCard
          title="Total Users"
          value={stats.totalUsers}
          subtitle="All registered system users"
          icon={Users}
          type="total"
        />

        <StatCard
          title="Active Users"
          value={stats.activeUsers}
          subtitle="Users currently allowed access"
          icon={UserCheck}
          type="active"
        />

        <StatCard
          title="Inactive Users"
          value={stats.inactiveUsers}
          subtitle="Users with disabled access"
          icon={UserX}
          type="inactive"
        />

        <StatCard
          title="Super Admins"
          value={stats.superAdmins}
          subtitle="System administrator accounts"
          icon={ShieldCheck}
          type="admin"
        />
      </div>

      {/* ADD / UPDATE USER */}
      <section className="overflow-hidden rounded-xl border border-[#123250] bg-[#07182a]">
        <div className="flex items-center justify-between border-b border-[#123250] px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="grid h-8 w-8 place-items-center rounded-lg bg-blue-500/10 text-blue-400">
              <UserPlus size={18} />
            </div>

            <div>
              <h2 className="text-sm font-bold text-white">
                {editingEmail
                  ? "Update User"
                  : "Add New User"}
              </h2>

              <p className="mt-0.5 text-[10px] text-white/70">
                {editingEmail
                  ? "Update the selected user's information"
                  : "Enter complete user information to create a new account"}
              </p>
            </div>
          </div>

          {editingEmail && (
            <span className="rounded-md border border-amber-500/25 bg-amber-500/10 px-2 py-1 text-[9px] font-semibold text-amber-400">
              Editing User
            </span>
          )}
        </div>

        <div className="p-4">
          <div className="grid grid-cols-1 gap-x-3 md:grid-cols-4 xl:grid-cols-4">
            <FormField
              label="Full Name"
              error={errors.fullName}
            >
              <input
                type="text"
                value={form.fullName}
                placeholder="Enter full name"
                onChange={(e) =>
                  updateForm(
                    "fullName",
                    e.target.value
                  )
                }
                onBlur={() =>
                  handleBlur("fullName")
                }
                className={inputClass(
                  errors.fullName
                )}
              />
            </FormField>

            <FormField
              label="Employee ID"
              error={errors.employeeId}
            >
              <input
                type="text"
                value={form.employeeId}
                placeholder="e.g. EMP009"
                onChange={(e) =>
                  updateForm(
                    "employeeId",
                    e.target.value
                  )
                }
                onBlur={() =>
                  handleBlur("employeeId")
                }
                className={inputClass(
                  errors.employeeId
                )}
              />
            </FormField>

            <FormField
              label="Email Address"
              error={errors.email}
            >
              <input
                type="email"
                value={form.email}
                disabled={Boolean(editingEmail)}
                placeholder="Enter email address"
                onChange={(e) =>
                  updateForm(
                    "email",
                    e.target.value
                  )
                }
                onBlur={() =>
                  handleBlur("email")
                }
                className={inputClass(
                  errors.email,
                  Boolean(editingEmail)
                )}
              />
            </FormField>

            <FormField
              label="Mobile Number"
              error={errors.mobile}
            >
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] text-white/45">
                  +91
                </span>

                <input
                  type="tel"
                  inputMode="numeric"
                  maxLength={10}
                  value={form.mobile}
                  placeholder="10-digit number"
                  onChange={(e) =>
                    updateForm(
                      "mobile",
                      e.target.value
                    )
                  }
                  onBlur={() =>
                    handleBlur("mobile")
                  }
                  className={`${inputClass(
                    errors.mobile
                  )} pl-10`}
                />
              </div>
            </FormField>

            <FormField
              label="Department"
              error={errors.department}
            >
              <input
                type="text"
                value={form.department}
                placeholder="e.g. Safety"
                onChange={(e) =>
                  updateForm(
                    "department",
                    e.target.value
                  )
                }
                onBlur={() =>
                  handleBlur("department")
                }
                className={inputClass(
                  errors.department
                )}
              />
            </FormField>

            <FormField
              label={editingEmail ? "New Password" : "Password"}
              error={errors.password}
              required={!editingEmail}
            >
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={form.password}
                  placeholder={editingEmail ? "Leave blank to keep existing" : "Enter password"}
                  onChange={(e) => updateForm("password", e.target.value)}
                  onBlur={() => handleBlur("password")}
                  className={`${inputClass(errors.password)} pr-10`}
                  autoComplete="new-password"
                />

                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 transition hover:text-white"
                  title={showPassword ? "Hide Password" : "Show Password"}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </FormField>

            <FormField
              label="Confirm Password"
              error={errors.confirmPassword}
              required={!editingEmail}
            >
              <div className="relative">
                <input
                  type={showConfirmPassword ? "text" : "password"}
                  value={form.confirmPassword}
                  placeholder={editingEmail ? "Confirm new password" : "Confirm password"}
                  onChange={(e) => updateForm("confirmPassword", e.target.value)}
                  onBlur={() => handleBlur("confirmPassword")}
                  className={`${inputClass(errors.confirmPassword)} pr-10`}
                  autoComplete="new-password"
                />

                <button
                  type="button"
                  onClick={() => setShowConfirmPassword((prev) => !prev)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 transition hover:text-white"
                  title={showConfirmPassword ? "Hide Confirm Password" : "Show Confirm Password"}
                >
                  {showConfirmPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </FormField>

            <div className="flex min-h-[69px] items-end justify-end gap-2 pb-[18px]">
              <button
                type="button"
                onClick={handleCancel}
                disabled={saving}
                className="h-10 rounded-md border border-[#173755] bg-[#0c2034] px-5 text-[10px] font-semibold text-white/80 transition hover:bg-[#12304d] disabled:cursor-not-allowed disabled:opacity-50"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleSave}
                disabled={saving}
                className="flex h-10 items-center gap-2 rounded-md bg-blue-600 px-5 text-[10px] font-semibold text-white shadow-lg shadow-blue-900/20 transition hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <UserPlus size={14} />

                {saving
                  ? "Saving..."
                  : editingEmail
                    ? "Update User"
                    : "Create User"}
              </button>
            </div>
          </div>

          <div className="mt-1 flex flex-col justify-between gap-2 border-t border-[#123250]/60 pt-3 sm:flex-row sm:items-center">
            <p className="text-[11px] leading-relaxed text-white/75">
              Password: minimum 8 characters
              with uppercase, lowercase, number
              and special character.
            </p>

            <div className="flex items-center gap-2">
              {apiError && (
                <div className="rounded-md border border-red-500/25 bg-red-500/10 px-3 py-1.5 text-[10px] font-medium text-red-400">
                  {apiError}
                </div>
              )}

              {successMessage && (
                <div className="flex items-center gap-1.5 rounded-md border border-emerald-500/25 bg-emerald-500/10 px-3 py-1.5 text-[10px] font-medium text-emerald-400">
                  <CheckCircle2 size={13} />
                  {successMessage}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* USER LIST */}
      <section className="overflow-hidden rounded-xl border border-[#123250] bg-[#07182a]">
        {/* FILTER BAR */}
        <div className="flex flex-nowrap items-center gap-2 border-b border-[#123250] p-3">
          <div className="relative min-w-0 flex-1">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/45"
            >
              <circle cx="11" cy="11" r="7" />
              <path d="m20 20-3.5-3.5" />
            </svg>

            <input
              type="text"
              value={search}
              placeholder="Search by name, employee ID, email, mobile or department..."
              onChange={(e) =>
                setSearch(e.target.value)
              }
              className="h-9 w-full rounded-md border border-[#173755] bg-[#04111e] pl-9 pr-3 text-[10px] text-white outline-none placeholder:text-white/50 focus:border-blue-500"
            />
          </div>

          <select
            value={departmentFilter}
            onChange={(e) =>
              setDepartmentFilter(
                e.target.value
              )
            }
            className="h-9 w-[170px] shrink-0 rounded-md border border-[#173755] bg-[#04111e] px-3 text-[10px] text-white outline-none focus:border-blue-500"
          >
            <option value="All">
              All Departments
            </option>

            {departments.map(
              (department) => (
                <option
                  key={department}
                  value={department}
                >
                  {department}
                </option>
              )
            )}
          </select>

          <select
            value={statusFilter}
            onChange={(e) =>
              setStatusFilter(
                e.target.value
              )
            }
            className="h-9 w-[145px] shrink-0 rounded-md border border-[#173755] bg-[#04111e] px-3 text-[10px] text-white outline-none focus:border-blue-500"
          >
            <option value="All">
              All Status
            </option>
            <option value="Active">
              Active
            </option>
            <option value="Inactive">
              Inactive
            </option>
          </select>

          <button
            type="button"
            onClick={clearFilters}
            className="h-9 shrink-0 whitespace-nowrap rounded-md border border-[#173755] bg-[#0c2034] px-4 text-[11px] font-medium text-white/80 transition hover:bg-[#12304d] hover:text-white"
          >
            Clear Filters
          </button>
        </div>

        {/* TABLE */}
        <div className="h-[350px] overflow-auto">
          <table className="w-full min-w-[1080px] border-collapse text-left">
            <thead className="sticky top-0 z-10">
              <tr className="bg-[#0a2035] text-[11px] font-semibold uppercase tracking-wide text-white/65">
                <th className="px-3 py-3">
                  Employee ID
                </th>
                <th className="px-3 py-3">
                  Full Name
                </th>
                <th className="px-3 py-3">
                  Email
                </th>
                <th className="px-3 py-3">
                  Mobile
                </th>
                <th className="px-3 py-3">
                  Department
                </th>
                <th className="px-3 py-3">
                  Status
                </th>
                <th className="px-3 py-3">
                  Last Login
                </th>
                <th className="px-3 py-3 text-center">
                  Actions
                </th>
              </tr>
            </thead>

            <tbody>
              {!loading &&
                filteredUsers.map(
                  (user) => (
                    <tr
                      key={user.email}
                      className="border-t border-[#123250] text-[11px] text-white/80 transition hover:bg-[#0b2238]/80"
                    >
                      <td className="px-3 py-3 font-semibold text-blue-300">
                        {user.employeeId}
                      </td>

                      <td className="px-3 py-3">
                        <div className="flex items-center gap-2">
                          <div className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-blue-500/15 text-[9px] font-bold text-blue-300">
                            {(user.name || "U")
                              .split(" ")
                              .map(
                                (part) =>
                                  part[0]
                              )
                              .join("")
                              .slice(0, 2)
                              .toUpperCase()}
                          </div>

                          <span className="font-semibold text-white">
                            {user.name}
                          </span>
                        </div>
                      </td>

                      <td className="px-3 py-3">
                        {user.email}
                      </td>

                      <td className="whitespace-nowrap px-3 py-3">
                        +91 {user.mobile}
                      </td>

                      <td className="px-3 py-3">
                        <span className="rounded-md border border-slate-500/20 bg-slate-500/10 px-2 py-1 text-[9px] text-slate-300">
                          {user.department}
                        </span>
                      </td>

                      <td className="px-3 py-3">
                        <span
                          className={`inline-flex items-center gap-1.5 rounded-md border px-2 py-1 text-[9px] font-semibold ${
                            user.status ===
                            "Active"
                              ? "border-emerald-500/25 bg-emerald-500/10 text-emerald-400"
                              : "border-orange-500/25 bg-orange-500/10 text-orange-400"
                          }`}
                        >
                          <span
                            className={`h-1.5 w-1.5 rounded-full ${
                              user.status ===
                              "Active"
                                ? "bg-emerald-400"
                                : "bg-orange-400"
                            }`}
                          />

                          {user.status}
                        </span>
                      </td>

                      <td className="whitespace-nowrap px-3 py-3 text-white/55">
                        {user.lastLogin ||
                          "Never"}
                      </td>

                      <td className="px-3 py-3">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            type="button"
                            title="Edit User"
                            onClick={() =>
                              handleEdit(
                                user
                              )
                            }
                            className="grid h-8 w-8 place-items-center rounded-md border border-amber-500/30 bg-amber-500/5 text-amber-400 transition hover:bg-amber-500/15"
                          >
                            <Edit3
                              size={14}
                            />
                          </button>

                          <button
                            type="button"
                            title={
                              user.status ===
                              "Active"
                                ? "Deactivate User"
                                : "Activate User"
                            }
                            onClick={() =>
                              handleToggleStatus(
                                user
                              )
                            }
                            className={`grid h-8 w-8 place-items-center rounded-md border transition ${
                              user.status ===
                              "Active"
                                ? "border-emerald-500/30 bg-emerald-500/5 text-emerald-400 hover:bg-emerald-500/15"
                                : "border-orange-500/30 bg-orange-500/5 text-orange-400 hover:bg-orange-500/15"
                            }`}
                          >
                            {user.status ===
                            "Active" ? (
                              <ToggleRight
                                size={17}
                              />
                            ) : (
                              <ToggleLeft
                                size={17}
                              />
                            )}
                          </button>

                          <button
                            type="button"
                            title="Delete User"
                            onClick={() =>
                              handleDelete(
                                user
                              )
                            }
                            className="grid h-8 w-8 place-items-center rounded-md border border-red-500/30 bg-red-500/5 text-red-400 transition hover:bg-red-500/15"
                          >
                            <Trash2
                              size={14}
                            />
                          </button>
                        </div>
                      </td>
                    </tr>
                  )
                )}

              {loading && (
                <tr>
                  <td
                    colSpan={8}
                    className="px-4 py-12 text-center text-[11px] text-white/45"
                  >
                    Loading users...
                  </td>
                </tr>
              )}

              {!loading &&
                filteredUsers.length ===
                  0 && (
                  <tr>
                    <td
                      colSpan={8}
                      className="px-4 py-12 text-center text-[11px] text-white/40"
                    >
                      No users found
                      matching your
                      search or filters.
                    </td>
                  </tr>
                )}
            </tbody>
          </table>
        </div>

        {/* FOOTER */}
        <div className="flex flex-col gap-3 border-t border-[#123250] px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-[10px] text-white/65">
            Showing{" "}
            <span className="font-semibold text-white">
              {filteredUsers.length}
            </span>{" "}
            of{" "}
            <span className="font-semibold text-white">
              {users.length}
            </span>{" "}
            users
          </p>
        </div>
      </section>
    </div>
  );
}