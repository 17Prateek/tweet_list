import { useEffect, useMemo, useState } from "react";
import {
  getEmailAlertHistory,
  getEvidenceImageUrl,
} from "../data/api";

import {
  Bell,
  CalendarDays,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Eye,
  Filter,
  Search,
  ShieldAlert,
  X,
} from "lucide-react";

const summaryCards = [
  {
    title: "TOTAL ALERTS",
    value: "0",
    subtitle: "All Time",
    trend: "Sent PPE Emails",
    icon: Bell,
    bg: "bg-red-600",
    trendColor: "text-red-400",
  },
];

function formatSentTime(value) {
  if (!value) return "-";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return String(value);
  }

  const datePart = date.toLocaleDateString([], {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });

  const timePart = date.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });

  return `${datePart}\n${timePart}`;
}

function getViolationMessage(alert) {
  if (!alert) return "-";

  if (!alert.helmet && !alert.vest) {
    return "No Helmet & No Vest";
  }

  if (!alert.helmet) {
    return "No Helmet detected";
  }

  if (!alert.vest) {
    return "No Vest detected";
  }

  return alert.eventType || "PPE Violation";
}

function getSource(alert) {
  if (!alert) return "-";

  const source = [alert.cameraName, alert.cameraLocation]
    .filter(Boolean)
    .join(" - ");

  return source || `Camera ${alert.cameraId ?? "-"}`;
}

function getEvidenceSource(alert) {
  if (!alert?.evidenceImage) {
    return "";
  }

  try {
    return getEvidenceImageUrl(alert.evidenceImage) || "";
  } catch {
    return "";
  }
}

export default function NotificationAlerts() {
  const [alerts, setAlerts] = useState([]);
  const [selectedAlert, setSelectedAlert] = useState(null);

  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const [pagination, setPagination] = useState({
    page: 1,
    pageSize: 10,
    total: 0,
    totalPages: 0,
  });

  const loadEmailAlerts = async () => {
    try {
      setLoading(true);
      setLoadError("");

      const result = await getEmailAlertHistory(page, pageSize);

      const rows = Array.isArray(result?.data) ? result.data : [];

      const nextPagination = {
        page: Number(result?.pagination?.page || page),
        pageSize: Number(result?.pagination?.pageSize || pageSize),
        total: Number(result?.pagination?.total || 0),
        totalPages: Number(result?.pagination?.totalPages || 0),
      };

      setAlerts(rows);
      setPagination(nextPagination);

      setSelectedAlert((currentAlert) => {
        if (!rows.length) {
          return null;
        }

        if (currentAlert) {
          const sameAlert = rows.find(
            (row) => row.id === currentAlert.id
          );

          if (sameAlert) {
            return sameAlert;
          }
        }

        return rows[0];
      });
    } catch (error) {
      console.error(
        "Could not load sent PPE email alert history:",
        error
      );

      setAlerts([]);
      setSelectedAlert(null);

      setPagination({
        page,
        pageSize,
        total: 0,
        totalPages: 0,
      });

      setLoadError(
        error?.message ||
          "Could not load sent PPE email alert history."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEmailAlerts();
  }, [page, pageSize]);

  const cards = useMemo(
    () =>
      summaryCards.map((card) =>
        card.title === "TOTAL ALERTS"
          ? {
              ...card,
              value: String(pagination.total),
            }
          : card
      ),
    [pagination.total]
  );

  const pageNumbers = useMemo(() => {
    const totalPages = pagination.totalPages;

    if (totalPages <= 0) {
      return [];
    }

    if (totalPages <= 5) {
      return Array.from(
        { length: totalPages },
        (_, index) => index + 1
      );
    }

    let start = Math.max(1, page - 1);
    let end = Math.min(totalPages, start + 2);

    if (end - start < 2) {
      start = Math.max(1, end - 2);
    }

    return Array.from(
      { length: end - start + 1 },
      (_, index) => start + index
    );
  }, [page, pagination.totalPages]);

  const firstVisibleAlert =
    pagination.total === 0
      ? 0
      : (page - 1) * pageSize + 1;

  const lastVisibleAlert =
    pagination.total === 0
      ? 0
      : Math.min(
          firstVisibleAlert + alerts.length - 1,
          pagination.total
        );

  return (
    <main className="w-full overflow-x-hidden bg-[#020817] p-2 text-white sm:p-0.5">
      <div className="mb-3 grid w-full grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
        {cards.map((card) => {
          const Icon = card.icon;

          return (
            <div
              key={card.title}
              className="flex h-[86px] min-w-0 items-center gap-3 rounded-md border border-[#123250] bg-[#061421] px-3 py-3"
            >
              <div
                className={`grid h-12 w-12 shrink-0 place-items-center rounded-lg ${card.bg}`}
              >
                <Icon size={21} />
              </div>

              <div className="min-w-0">
                <p className="truncate text-[11px] font-bold text-white/80 sm:text-[11px]">
                  {card.title}
                </p>

                <h3 className="text-[16px] font-bold leading-tight">
                  {card.value}
                </h3>

                <p className="truncate text-[9px] text-white/70 sm:text-[11px]">
                  {card.subtitle}
                </p>

                <p
                  className={`truncate text-[9px] font-semibold sm:text-[11px] ${card.trendColor}`}
                >
                  {card.trend}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      <section className="grid min-h-[calc(100vh-130px)] min-w-0 grid-cols-1 gap-2 lg:grid-cols-[minmax(0,1fr)_280px] xl:grid-cols-[minmax(0,1fr)_300px] 2xl:grid-cols-[minmax(0,1fr)_320px]">
        <div className="flex min-w-0 flex-col space-y-2">
          <div className="rounded-md border border-[#123250] bg-[#061421] p-3">
            <div className="grid grid-cols-1 gap-2 md:grid-cols-2 lg:grid-cols-[minmax(0,1fr)_88px_88px_88px_130px_70px] xl:grid-cols-[minmax(0,1.4fr)_105px_105px_105px_160px_82px]">
              <div className="relative min-w-0">
                <Search
                  size={15}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-white/60"
                />

                <input
                  className="h-10 w-full min-w-0 rounded-md border border-[#123250] bg-[#020817] pl-9 pr-3 text-[11px] outline-none placeholder:text-white/50 focus:border-blue-500"
                  placeholder="Search alerts by person, camera, or violation..."
                />
              </div>

              {["Severity: All", "Status: All", "Type: All"].map(
                (item) => (
                  <button
                    key={item}
                    className="flex h-10 min-w-0 items-center justify-between rounded-md border border-[#123250] bg-[#020817] px-2 text-[10px] hover:bg-[#0b2238]"
                  >
                    <span className="truncate">{item}</span>
                    <ChevronDown size={12} className="shrink-0" />
                  </button>
                )
              )}

              <button className="flex h-10 min-w-0 items-center justify-between rounded-md border border-[#123250] bg-[#020817] px-2 text-[10px] hover:bg-[#0b2238]">
                <span className="flex min-w-0 items-center gap-1 truncate">
                  <CalendarDays size={12} className="shrink-0" />
                  <span className="truncate">
                    Select Date Range
                  </span>
                </span>

                <ChevronDown size={12} className="shrink-0" />
              </button>

              <button className="flex h-10 items-center justify-center gap-1 rounded-md border border-[#123250] bg-[#020817] px-2 text-[10px] hover:bg-[#0b2238]">
                <Filter size={12} />
                Filters
              </button>
            </div>
          </div>

          <div className="flex h-[752px] min-w-0 flex-col overflow-hidden rounded-md border border-[#123250] bg-[#061421]">
            <div className="hidden flex-1 overflow-auto lg:block">
              <div className="min-w-[900px]">
                <table className="w-full table-fixed text-left text-[11px]">
                  <colgroup>
                    <col className="w-[15%]" />
                    <col className="w-[16%]" />
                    <col className="w-[13%]" />
                    <col className="w-[17%]" />
                    <col className="w-[15%]" />
                    <col className="w-[11%]" />
                    <col className="w-[9%]" />
                    <col className="w-[4%]" />
                  </colgroup>

                  <thead className="sticky top-0 z-10 bg-[#082033] text-white/80">
                    <tr>
                      {[
                        "Sent Time ↓",
                        "Violation",
                        "Person",
                        "Source",
                        "PPE Status",
                        "Email To",
                        "Email Status",
                        "Actions",
                      ].map((head) => (
                        <th
                          key={head}
                          className="border-b border-[#123250] px-2.5 py-3 font-medium"
                        >
                          {head}
                        </th>
                      ))}
                    </tr>
                  </thead>

                  <tbody>
                    {loading ? (
                      <tr>
                        <td
                          colSpan={8}
                          className="px-4 py-12 text-center text-white/60"
                        >
                          Loading sent PPE email alerts...
                        </td>
                      </tr>
                    ) : loadError ? (
                      <tr>
                        <td
                          colSpan={8}
                          className="px-4 py-12 text-center"
                        >
                          <p className="mb-3 text-red-400">
                            {loadError}
                          </p>

                          <button
                            onClick={loadEmailAlerts}
                            className="rounded border border-[#22425f] px-3 py-1.5 text-[11px] hover:bg-[#0b2238]"
                          >
                            Retry
                          </button>
                        </td>
                      </tr>
                    ) : alerts.length === 0 ? (
                      <tr>
                        <td
                          colSpan={8}
                          className="px-4 py-12 text-center text-white/60"
                        >
                          No sent PPE email alerts found.
                        </td>
                      </tr>
                    ) : (
                      alerts.map((alert) => (
                        <tr
                          key={alert.id}
                          className="h-[62px] border-b border-[#123250] hover:bg-[#0b2238]"
                        >
                          <td className="whitespace-pre-line px-2.5 py-3 text-white/80">
                            {formatSentTime(alert.emailSentAt)}
                          </td>

                          <td className="px-2.5 py-3">
                            <div className="flex min-w-0 items-center gap-1.5">
                              <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-red-600">
                                <ShieldAlert size={12} />
                              </span>

                              <span className="truncate font-semibold">
                                {alert.eventType || "PPE Violation"}
                              </span>
                            </div>
                          </td>

                          <td className="truncate px-2.5 py-3 font-semibold">
                            {alert.personName || "Unknown Person"}
                          </td>

                          <td className="truncate px-2.5 py-3 font-semibold">
                            {getSource(alert)}
                          </td>

                          <td className="px-2.5 py-3">
                            <div className="space-y-0.5 text-[10px]">
                              <p>
                                Helmet:{" "}
                                <span
                                  className={
                                    alert.helmet
                                      ? "text-emerald-400"
                                      : "text-red-400"
                                  }
                                >
                                  {alert.helmet
                                    ? "Detected"
                                    : "Missing"}
                                </span>
                              </p>

                              <p>
                                Vest:{" "}
                                <span
                                  className={
                                    alert.vest
                                      ? "text-emerald-400"
                                      : "text-red-400"
                                  }
                                >
                                  {alert.vest
                                    ? "Detected"
                                    : "Missing"}
                                </span>
                              </p>
                            </div>
                          </td>

                          <td className="px-2.5 py-3">
                            <span
                              title={(alert.recipients || []).join(
                                ", "
                              )}
                              className="font-semibold"
                            >
                              {alert.recipientCount ?? 0}{" "}
                              {(alert.recipientCount ?? 0) === 1
                                ? "Recipient"
                                : "Recipients"}
                            </span>
                          </td>

                          <td className="px-2.5 py-3">
                            <span className="flex items-center gap-1.5 font-semibold text-emerald-400">
                              <span className="h-2 w-2 shrink-0 rounded-full bg-emerald-500" />
                              {alert.emailStatus || "Sent"}
                            </span>
                          </td>

                          <td className="px-2.5 py-3">
                            <button
                              onClick={() =>
                                setSelectedAlert(alert)
                              }
                              className="grid h-6 w-6 place-items-center rounded border border-[#22425f] hover:bg-[#0b2238]"
                              title="View Details"
                            >
                              <Eye size={12} />
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="h-[560px] space-y-2 overflow-y-auto p-2 lg:hidden">
              {loading ? (
                <div className="py-10 text-center text-xs text-white/60">
                  Loading sent PPE email alerts...
                </div>
              ) : loadError ? (
                <div className="py-10 text-center text-xs text-red-400">
                  <p>{loadError}</p>

                  <button
                    onClick={loadEmailAlerts}
                    className="mt-3 rounded border border-[#22425f] px-3 py-1.5 text-white"
                  >
                    Retry
                  </button>
                </div>
              ) : alerts.length === 0 ? (
                <div className="py-10 text-center text-xs text-white/60">
                  No sent PPE email alerts found.
                </div>
              ) : (
                alerts.map((alert) => (
                  <div
                    key={alert.id}
                    className="rounded-md border border-[#123250] bg-[#020817] p-3"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex min-w-0 gap-3">
                        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-red-600">
                          <ShieldAlert size={16} />
                        </span>

                        <div className="min-w-0">
                          <h3 className="truncate text-sm font-semibold">
                            {getViolationMessage(alert)}
                          </h3>

                          <p className="truncate text-xs text-white/60">
                            {alert.eventType || "PPE Violation"}
                          </p>
                        </div>
                      </div>

                      <span className="rounded border border-emerald-500 px-2 py-1 text-[10px] text-emerald-400">
                        {alert.emailStatus || "Sent"}
                      </span>
                    </div>

                    <div className="mt-3 grid gap-1 text-xs text-white/70">
                      <p className="whitespace-pre-line">
                        {formatSentTime(alert.emailSentAt)}
                      </p>

                      <p>
                        Person:{" "}
                        {alert.personName || "Unknown Person"}
                      </p>

                      <p>{getSource(alert)}</p>

                      <p>
                        Helmet:{" "}
                        {alert.helmet ? "Detected" : "Missing"}
                      </p>

                      <p>
                        Vest:{" "}
                        {alert.vest ? "Detected" : "Missing"}
                      </p>

                      <p>
                        {alert.recipientCount ?? 0}{" "}
                        {(alert.recipientCount ?? 0) === 1
                          ? "Recipient"
                          : "Recipients"}
                      </p>
                    </div>

                    <button
                      onClick={() => setSelectedAlert(alert)}
                      className="mt-3 h-8 w-full rounded border border-[#22425f] text-xs hover:bg-[#0b2238]"
                    >
                      View Details
                    </button>
                  </div>
                ))
              )}
            </div>

            <div className="flex flex-col gap-2 border-t border-[#123250] px-3 py-2 text-[11px] text-white/70 md:flex-row md:items-center md:justify-between">
              <p>
                Showing {firstVisibleAlert} to {lastVisibleAlert} of{" "}
                {pagination.total} alerts
              </p>

              <div className="flex flex-wrap items-center gap-1.5">
                <button
                  onClick={() =>
                    setPage((current) =>
                      Math.max(1, current - 1)
                    )
                  }
                  disabled={page <= 1 || loading}
                  className="grid h-7 w-7 place-items-center rounded border border-[#22425f] disabled:cursor-not-allowed disabled:opacity-40"
                >
                  <ChevronLeft size={13} />
                </button>

                {pageNumbers.map((pageNumber) => (
                  <button
                    key={pageNumber}
                    onClick={() => setPage(pageNumber)}
                    disabled={loading}
                    className={`grid h-7 min-w-7 place-items-center rounded border border-[#22425f] px-1 ${
                      pageNumber === page
                        ? "bg-blue-700 text-white"
                        : ""
                    }`}
                  >
                    {pageNumber}
                  </button>
                ))}

                {pagination.totalPages > 5 &&
                  pageNumbers[pageNumbers.length - 1] <
                    pagination.totalPages && (
                    <>
                      <span>...</span>

                      <button
                        onClick={() =>
                          setPage(pagination.totalPages)
                        }
                        disabled={loading}
                        className={`grid h-7 min-w-7 place-items-center rounded border border-[#22425f] px-1 ${
                          page === pagination.totalPages
                            ? "bg-blue-700 text-white"
                            : ""
                        }`}
                      >
                        {pagination.totalPages}
                      </button>
                    </>
                  )}

                <button
                  onClick={() =>
                    setPage((current) =>
                      Math.min(
                        pagination.totalPages || 1,
                        current + 1
                      )
                    )
                  }
                  disabled={
                    loading ||
                    pagination.totalPages === 0 ||
                    page >= pagination.totalPages
                  }
                  className="grid h-7 w-7 place-items-center rounded border border-[#22425f] disabled:cursor-not-allowed disabled:opacity-40"
                >
                  <ChevronRight size={13} />
                </button>

                <select
                  value={pageSize}
                  onChange={(event) => {
                    setPageSize(Number(event.target.value));
                    setPage(1);
                  }}
                  disabled={loading}
                  className="h-7 rounded border border-[#22425f] bg-[#020817] px-2 text-[11px] text-white outline-none"
                >
                  <option value={10}>Rows: 10</option>
                  <option value={25}>Rows: 25</option>
                  <option value={50}>Rows: 50</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <aside className="min-w-0 space-y-2 lg:w-[280px] xl:w-[300px] 2xl:w-[320px]">
          <section className="min-h-[287px] rounded-md border border-[#123250] bg-[#061421] p-3">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-[12px] font-bold">
                Alert Details
              </h2>

              <button
                onClick={() => setSelectedAlert(null)}
                title="Close Details"
              >
                <X size={15} />
              </button>
            </div>

            {selectedAlert ? (
              <>
                <div className="mb-3 flex items-center justify-between gap-2">
                  <div className="flex min-w-0 items-center gap-2">
                    <span className="grid h-8 w-8 shrink-0 place-items-center rounded bg-red-600">
                      <ShieldAlert size={15} />
                    </span>

                    <p className="truncate text-[12px] font-semibold">
                      {selectedAlert.eventType || "PPE Violation"}
                    </p>
                  </div>

                  <span className="rounded border border-emerald-500 px-2 py-0.5 text-[10px] text-emerald-400">
                    {selectedAlert.emailStatus || "Sent"}
                  </span>
                </div>

                <div className="space-y-3 text-[11px]">
                  <div>
                    <p className="text-white/50">Violation</p>
                    <p className="font-semibold">
                      {getViolationMessage(selectedAlert)}
                    </p>
                  </div>

                  <div>
                    <p className="text-white/50">Person</p>
                    <p className="font-semibold">
                      {selectedAlert.personName ||
                        "Unknown Person"}
                    </p>

                    <p className="text-white/60">
                      Employee ID:{" "}
                      {selectedAlert.employeeId || "N/A"}
                    </p>
                  </div>

                  <div>
                    <p className="text-white/50">Source</p>
                    <p className="font-semibold">
                      {getSource(selectedAlert)}
                    </p>
                  </div>

                  <div>
                    <p className="text-white/50">PPE Status</p>

                    <p>
                      Helmet:{" "}
                      <span
                        className={
                          selectedAlert.helmet
                            ? "text-emerald-400"
                            : "text-red-400"
                        }
                      >
                        {selectedAlert.helmet
                          ? "Detected"
                          : "Missing"}
                      </span>
                    </p>

                    <p>
                      Vest:{" "}
                      <span
                        className={
                          selectedAlert.vest
                            ? "text-emerald-400"
                            : "text-red-400"
                        }
                      >
                        {selectedAlert.vest
                          ? "Detected"
                          : "Missing"}
                      </span>
                    </p>
                  </div>

                  <div>
                    <p className="text-white/50">Email Sent</p>
                    <p className="whitespace-pre-line font-medium text-white/90">
                      {formatSentTime(
                        selectedAlert.emailSentAt
                      )}
                    </p>
                  </div>

                  <div>
                    <p className="text-white/50">Sent To</p>

                    {(selectedAlert.recipients || []).length >
                    0 ? (
                      <div className="mt-1 space-y-1">
                        {selectedAlert.recipients.map(
                          (email) => (
                            <p
                              key={email}
                              className="break-all text-white/80"
                            >
                              {email}
                            </p>
                          )
                        )}
                      </div>
                    ) : (
                      <p className="text-white/60">
                        No recipient details
                      </p>
                    )}
                  </div>
                </div>
              </>
            ) : (
              <div className="grid min-h-[220px] place-items-center text-center text-[11px] text-white/50">
                Select an alert from the table to view details.
              </div>
            )}
          </section>

          <section className="rounded-md border border-[#123250] bg-[#061421] p-3">
            <h2 className="mb-2 text-[12px] font-bold">
              Alert Snapshot
            </h2>

            {getEvidenceSource(selectedAlert) ? (
              <div className="overflow-hidden rounded-md border border-[#123250]">
                <img
                  src={getEvidenceSource(selectedAlert)}
                  alt="Alert Snapshot"
                  className="h-36 w-full object-cover"
                />
              </div>
            ) : (
              <p className="text-[11px] text-white/50">No picture for this alert.</p>
            )}
          </section>

        </aside>
      </section>
    </main>
  );
}
