import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Pencil, Trash2 } from "lucide-react";
import {
  createZone,
  deleteZone,
  getCameraSnapshotUrl,
  getCameras,
  getZones,
  updateZone,

  getCountingLines,
  createCountingLine,
  updateCountingLine,
  deleteCountingLine,
} from "../data/api";

import {
  COUNTING_DIRECTIONS,
  countingDirectionLabel,
  normalizeCountingDirection,
} from "./zoneTypes";

/**
 * ZoneLinesEditor.jsx
 * React + Tailwind.
 *
 * Existing zone API and zone behavior are kept unchanged.
 *
 * Counting lines are persisted through the authenticated backend API:
 *   GET    /api/counting-lines?camera_id=...
 *   POST   /api/counting-lines
 *   PUT    /api/counting-lines/{line_id}
 *   DELETE /api/counting-lines/{line_id}
 *
 * Direction is part of the counting-line record:
 *   ltr = Left -> Right
 *   rtl = Right -> Left
 */

const ZONE_TYPES = [
  ["gate", "Gate", "#14b8a6"],
  ["weighbridge", "Weighbridge", "#14b8a6"],
  ["yard", "Yard / parking", "#14b8a6"],
  ["bay", "Loading bay", "#22c55e"],
  ["unloading_bay", "Unloading bay (tanker)", "#f59e0b"],
  ["restricted", "Restricted area", "#ef4444"],
  ["ppe", "PPE required here", "#3b82f6"],
  ["custom", "Other", "#94a3b8"],
];

const LINE_COLORS = [
  "#1683ff",
  "#22c55e",
  "#f59e0b",
  "#ef4444",
  "#a855f7",
  "#14b8a6",
  "#ec4899",
];

const CLOSE_RADIUS_PX = 14;
const EMPTY_ZONE_FORM = { name: "", zone_type: "bay", limit_min: "" };
const EMPTY_LINE_FORM = {
  name: "",
  color: "#1683ff",
  direction: "ltr",
  width: 4,
  showArrows: true,
  showLabel: true,
};

const zoneColour = (type) =>
  ZONE_TYPES.find(([key]) => key === type)?.[2] || "#94a3b8";

const zoneTypeLabel = (type) =>
  ZONE_TYPES.find(([key]) => key === type)?.[1] || type || "Other";

function zoneToForm(zone) {
  return {
    name: zone?.name || "",
    zone_type: zone?.zone_type || "custom",
    limit_min: zone?.limit_sec
      ? String(Math.round(zone.limit_sec / 60))
      : "",
  };
}

function centroid(points) {
  const n = points.length || 1;
  return points.reduce(
    ([sx, sy], [x, y]) => [sx + x / n, sy + y / n],
    [0, 0]
  );
}

function clamp01(n) {
  return Math.min(1, Math.max(0, n));
}

function normalizeLineFromApi(line) {
  return {
    id: line?.id,
    camera_id: line?.camera_id,
    name: line?.name || "Line",
    color: line?.color || "#1683ff",
    direction: normalizeCountingDirection(line?.direction),
    width: Number(line?.width || 4),
    showArrows: line?.show_arrows !== false,
    showLabel: line?.show_label !== false,
    is_active: line?.is_active !== false,
    points: Array.isArray(line?.points) ? line.points : [],
  };
}

function lineToApiPayload(cameraId, line) {
  return {
    camera_id: Number(cameraId),
    name: String(line?.name || "").trim(),
    points: Array.isArray(line?.points) ? line.points : [],
    direction: normalizeCountingDirection(line?.direction),
    color: line?.color || "#1683ff",
    width: Number(line?.width || 4),
    show_arrows: line?.showArrows !== false,
    show_label: line?.showLabel !== false,
    is_active: line?.is_active !== false,
  };
}

/* -------------------------------------------------------------------------- */

export default function ZoneLinesEditor() {
  const [cameras, setCameras] = useState([]);
  const [cameraId, setCameraId] = useState(null);

  const [zones, setZones] = useState([]);
  const [lines, setLines] = useState([]);

  const [activeTab, setActiveTab] = useState("lines"); // "zones" | "lines"
  const [filterTab, setFilterTab] = useState("all"); // all | zones | lines
  const [search, setSearch] = useState("");

  const [selectedZoneId, setSelectedZoneId] = useState(null);
  const [selectedLineId, setSelectedLineId] = useState(null);

  const [drawingZone, setDrawingZone] = useState(false);
  const [zoneDraft, setZoneDraft] = useState([]);

  const [drawingLine, setDrawingLine] = useState(false);
  const [lineDraft, setLineDraft] = useState([]);

  const [zoneForm, setZoneForm] = useState(EMPTY_ZONE_FORM);
  const [lineForm, setLineForm] = useState(EMPTY_LINE_FORM);

  const [stamp, setStamp] = useState(() => Date.now());
  const [picOk, setPicOk] = useState(true);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState({ kind: "", text: "" });
  const [confirmModal, setConfirmModal] = useState(null);
  const [confirmBusy, setConfirmBusy] = useState(false);

  const stageRef = useRef(null);
  const dragRef = useRef(null);
  const [size, setSize] = useState({ w: 0, h: 0 });

  const camera = cameras.find((c) => c.id === cameraId) || null;
  const selectedZone =
    zones.find((zone) => zone.id === selectedZoneId) || null;
  const selectedLine =
    lines.find((line) => line.id === selectedLineId) || null;

  /* ------------------------------- loading -------------------------------- */

  useEffect(() => {
    getCameras()
      .then((res) => {
        const list = Array.isArray(res?.data) ? res.data : [];
        setCameras(list);
        setCameraId((current) => current ?? list[0]?.id ?? null);
      })
      .catch((error) =>
        setMsg({ kind: "err", text: error?.message || "Could not load cameras." })
      );
  }, []);

  const loadCameraObjects = useCallback(async (id) => {
    if (id == null) return;

    try {
      const [zonesRes, linesRes] = await Promise.all([
        getZones(id),
        getCountingLines(id),
      ]);

      setZones(zonesRes?.data || []);

      const apiLines = Array.isArray(linesRes?.data)
        ? linesRes.data
        : [];

      setLines(apiLines.map(normalizeLineFromApi));
    } catch (error) {
      setMsg({
        kind: "err",
        text: error?.message || "Could not load zones and lines.",
      });
    }
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => loadCameraObjects(cameraId), 0);
    return () => clearTimeout(timer);
  }, [cameraId, loadCameraObjects]);

  useEffect(() => {
    const el = stageRef.current;
    if (!el) return undefined;

    const update = () =>
      setSize({ w: el.clientWidth, h: el.clientHeight });

    update();
    const observer = new ResizeObserver(update);
    observer.observe(el);

    return () => observer.disconnect();
  }, []);

  function selectCamera(id) {
    if (id === cameraId) return;

    setCameraId(id);
    setZones([]);
    setLines([]);
    clearSelection();
    cancelDrawing();
    setPicOk(true);
    setStamp(Date.now());
    setMsg({ kind: "", text: "" });
  }

  /* ------------------------------- helpers -------------------------------- */

  const toFraction = useCallback((event) => {
    const rect = stageRef.current?.getBoundingClientRect();
    if (!rect) return [0, 0];

    return [
      clamp01((event.clientX - rect.left) / rect.width),
      clamp01((event.clientY - rect.top) / rect.height),
    ];
  }, []);

  const px = useCallback(
    ([x, y]) => [x * size.w, y * size.h],
    [size.w, size.h]
  );

  function clearSelection() {
    setSelectedZoneId(null);
    setSelectedLineId(null);
    setZoneForm(EMPTY_ZONE_FORM);
    setLineForm(EMPTY_LINE_FORM);
  }

  function cancelDrawing() {
    setDrawingZone(false);
    setDrawingLine(false);
    setZoneDraft([]);
    setLineDraft([]);
  }

  function beginZone() {
    clearSelection();
    cancelDrawing();
    setActiveTab("zones");
    setDrawingZone(true);
    setMsg({
      kind: "",
      text: "Click at least 3 points. Click the first point again or press Enter to finish.",
    });
  }

  function beginLine() {
    clearSelection();
    cancelDrawing();
    setActiveTab("lines");

    setLineForm({ ...EMPTY_LINE_FORM });

    setDrawingLine(true);
    setMsg({
      kind: "",
      text: "Click the start point, then click the end point.",
    });
  }

  function closeZoneDraft() {
    if (zoneDraft.length < 3) {
      setMsg({ kind: "err", text: "A zone needs at least 3 corners." });
      return;
    }

    setDrawingZone(false);
    setMsg({
      kind: "",
      text: "Zone shape finished. Enter its details and save.",
    });
  }

  function selectZone(zone) {
    cancelDrawing();
    setActiveTab("zones");
    setSelectedLineId(null);
    setSelectedZoneId(zone.id);
    setZoneForm(zoneToForm(zone));
    setMsg({ kind: "", text: "" });
  }

  function selectLine(line) {
    cancelDrawing();
    setActiveTab("lines");
    setSelectedZoneId(null);
    setSelectedLineId(line.id);
    setLineForm({
      name: line.name || "Line",
      color: line.color || "#1683ff",
      direction: normalizeCountingDirection(line.direction),
      width: Number(line.width || 4),
      showArrows: line.showArrows !== false,
      showLabel: line.showLabel !== false,
    });
    setMsg({ kind: "", text: "" });
  }

  /* --------------------------- drawing + dragging -------------------------- */

  function onStageClick(event) {
    if (dragRef.current) return;

    const point = toFraction(event);

    if (drawingZone) {
      if (zoneDraft.length >= 3) {
        const [firstX, firstY] = px(zoneDraft[0]);
        const [clickX, clickY] = px(point);

        if (
          Math.hypot(firstX - clickX, firstY - clickY) <= CLOSE_RADIUS_PX
        ) {
          closeZoneDraft();
          return;
        }
      }

      setZoneDraft((draft) => [...draft, point]);
      return;
    }

    if (drawingLine) {
      setLineDraft((draft) => {
        if (draft.length === 0) return [point];

        const completed = [draft[0], point];
        setDrawingLine(false);
        setMsg({
          kind: "",
          text: "Line finished. Choose its direction and save.",
        });
        return completed;
      });
    }
  }

  function onVertexDown(event, objectType, objectId, index) {
    event.preventDefault();
    event.stopPropagation();

    dragRef.current = { objectType, objectId, index };
    event.currentTarget.setPointerCapture?.(event.pointerId);
  }

  function onStageMove(event) {
    const drag = dragRef.current;
    if (!drag) return;

    const point = toFraction(event);

    if (drag.objectType === "zone-draft") {
      setZoneDraft((draft) =>
        draft.map((p, index) => (index === drag.index ? point : p))
      );
      return;
    }

    if (drag.objectType === "line-draft") {
      setLineDraft((draft) =>
        draft.map((p, index) => (index === drag.index ? point : p))
      );
      return;
    }

    if (drag.objectType === "zone") {
      setZones((current) =>
        current.map((zone) =>
          zone.id === drag.objectId
            ? {
                ...zone,
                polygon: zone.polygon.map((p, index) =>
                  index === drag.index ? point : p
                ),
              }
            : zone
        )
      );
      return;
    }

    if (drag.objectType === "line") {
      setLines((current) =>
        current.map((line) =>
          line.id === drag.objectId
            ? {
                ...line,
                points: line.points.map((p, index) =>
                  index === drag.index ? point : p
                ),
              }
            : line
        )
      );
    }
  }

  async function onStageUp() {
    const drag = dragRef.current;
    dragRef.current = null;
    if (!drag) return;

    try {
      if (drag.objectType === "zone") {
        const zone = zones.find((item) => item.id === drag.objectId);
        if (!zone) return;

        await updateZone(zone.id, { polygon: zone.polygon });
        setMsg({ kind: "ok", text: `${zone.name} shape updated.` });
      }

      if (drag.objectType === "line") {
        const line = lines.find((item) => item.id === drag.objectId);
        if (!line) return;

        await updateCountingLine(
          line.id,
          lineToApiPayload(cameraId, line)
        );

        setMsg({ kind: "ok", text: `${line.name} position updated.` });
      }
    } catch (error) {
      setMsg({
        kind: "err",
        text: error?.message || "Could not save the new position.",
      });
      loadCameraObjects(cameraId);
    }
  }

  useEffect(() => {
    function onKey(event) {
      if (event.key === "Escape") {
        cancelDrawing();
        setMsg({ kind: "", text: "" });
        return;
      }

      if (drawingZone && event.key === "Enter") {
        event.preventDefault();
        closeZoneDraft();
      }

      if (drawingZone && event.key === "Backspace") {
        event.preventDefault();
        setZoneDraft((draft) => draft.slice(0, -1));
      }

      if (drawingLine && event.key === "Backspace") {
        event.preventDefault();
        setLineDraft((draft) => draft.slice(0, -1));
      }
    }

    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  function openConfirm({
    title = "Paperless Management System States",
    message,
    confirmText = "Confirm",
    action = "update",
    onConfirm,
  }) {
    setConfirmModal({
      title,
      message,
      confirmText,
      action,
      onConfirm,
    });
  }

  function closeConfirm() {
    if (confirmBusy) return;
    setConfirmModal(null);
  }

  async function runConfirm() {
    if (!confirmModal?.onConfirm || confirmBusy) return;

    setConfirmBusy(true);
    try {
      await confirmModal.onConfirm();
      setConfirmModal(null);
    } finally {
      setConfirmBusy(false);
    }
  }

  /* -------------------------------- zones --------------------------------- */

  async function persistZone(payload, zoneId = null) {
    setBusy(true);

    try {
      if (zoneId) {
        await updateZone(zoneId, payload);
        setMsg({ kind: "ok", text: `${payload.name} updated.` });
      } else {
        const res = await createZone({
          ...payload,
          camera_id: cameraId,
        });

        setZoneDraft([]);
        setSelectedZoneId(res?.data?.id ?? null);
        setMsg({ kind: "ok", text: `${payload.name} created.` });
      }

      await loadCameraObjects(cameraId);
    } catch (error) {
      setMsg({
        kind: "err",
        text: error?.message || "Could not save zone.",
      });
      throw error;
    } finally {
      setBusy(false);
    }
  }

  async function saveZone(event) {
    event.preventDefault();

    const polygon = selectedZone?.polygon || zoneDraft;

    if (!polygon || polygon.length < 3) {
      setMsg({
        kind: "err",
        text: "Draw the zone first using Add Zone.",
      });
      return;
    }

    if (!zoneForm.name.trim()) {
      setMsg({ kind: "err", text: "Enter a zone name." });
      return;
    }

    const limit =
      zoneForm.limit_min.trim() === ""
        ? null
        : Math.max(
            0,
            Math.round(Number(zoneForm.limit_min || 0) * 60)
          );

    const payload = {
      name: zoneForm.name.trim(),
      zone_type: zoneForm.zone_type,
      polygon,
      limit_sec: limit,
    };

    if (selectedZone) {
      openConfirm({
        message: `Are you sure you want to update zone "${payload.name}"?`,
        confirmText: "Confirm Update",
        action: "update",
        onConfirm: () => persistZone(payload, selectedZone.id),
      });
      return;
    }

    await persistZone(payload);
  }

  async function deleteZoneNow(zone) {
    setBusy(true);

    try {
      await deleteZone(zone.id);
      setSelectedZoneId(null);
      setZoneForm(EMPTY_ZONE_FORM);
      setMsg({ kind: "ok", text: `${zone.name} deleted.` });
      await loadCameraObjects(cameraId);
    } catch (error) {
      setMsg({
        kind: "err",
        text: error?.message || "Could not delete zone.",
      });
      throw error;
    } finally {
      setBusy(false);
    }
  }

  function requestDeleteZone(zone = selectedZone) {
    if (!zone) return;

    openConfirm({
      message: `Are you sure you want to delete zone "${zone.name}"?`,
      confirmText: "Confirm Delete",
      action: "delete",
      onConfirm: () => deleteZoneNow(zone),
    });
  }

  /* -------------------------------- lines --------------------------------- */

  async function persistLine(line) {
    setBusy(true);

    try {
      const payload = lineToApiPayload(
        cameraId,
        line
      );

      const response = line.id
        ? await updateCountingLine(
            line.id,
            payload
          )
        : await createCountingLine(
            payload
          );

      setLineDraft([]);

      setSelectedLineId(
        response?.data?.id ??
          line.id ??
          null
      );

      setMsg({
        kind: "ok",
        text: `${line.name} ${line.id ? "updated" : "saved"}.`,
      });

      await loadCameraObjects(cameraId);
    } catch (error) {
      setMsg({
        kind: "err",
        text: error?.message || "Could not save line.",
      });
      throw error;
    } finally {
      setBusy(false);
    }
  }

  async function saveLine(event) {
    event.preventDefault();

    const points = selectedLine?.points || lineDraft;

    if (!points || points.length !== 2) {
      setMsg({
        kind: "err",
        text: "Draw the counting line first using Add Line.",
      });
      return;
    }

    if (!lineForm.name.trim()) {
      setMsg({ kind: "err", text: "Enter a line name." });
      return;
    }

    const line = {
      id: selectedLine?.id || null,
      camera_id: cameraId,
      name: lineForm.name.trim(),
      color: lineForm.color,
      direction: normalizeCountingDirection(
        lineForm.direction
      ),
      width: Number(lineForm.width || 4),
      showArrows: !!lineForm.showArrows,
      showLabel: !!lineForm.showLabel,
      is_active: true,
      points,
    };

    if (selectedLine) {
      openConfirm({
        message: `Are you sure you want to update line "${line.name}"?`,
        confirmText: "Confirm Update",
        action: "update",
        onConfirm: () => persistLine(line),
      });
      return;
    }

    await persistLine(line);
  }

  async function deleteLineNow(line) {
    setBusy(true);

    try {
      await deleteCountingLine(line.id);
      setSelectedLineId(null);
      setLineForm(EMPTY_LINE_FORM);
      setMsg({ kind: "ok", text: `${line.name} deleted.` });
      await loadCameraObjects(cameraId);
    } catch (error) {
      setMsg({
        kind: "err",
        text: error?.message || "Could not delete line.",
      });
      throw error;
    } finally {
      setBusy(false);
    }
  }

  function requestDeleteLine(line = selectedLine) {
    if (!line) return;

    openConfirm({
      message: `Are you sure you want to delete line "${line.name}"?`,
      confirmText: "Confirm Delete",
      action: "delete",
      onConfirm: () => deleteLineNow(line),
    });
  }

  /* ------------------------------- geometry ------------------------------- */

  const zoneDraftPx = useMemo(
    () => zoneDraft.map(([x, y]) => [x * size.w, y * size.h]),
    [zoneDraft, size]
  );

  const lineDraftPx = useMemo(
    () => lineDraft.map(([x, y]) => [x * size.w, y * size.h]),
    [lineDraft, size]
  );

  function lineGeometry(line) {
    if (!line?.points?.[0] || !line?.points?.[1]) return null;

    const [a, b] = line.points.map(px);
    const forward = line.direction !== "rtl";
    const start = forward ? a : b;
    const end = forward ? b : a;

    return {
      a,
      b,
      start,
      end,
      midX: (a[0] + b[0]) / 2,
      midY: (a[1] + b[1]) / 2,
      angle: (Math.atan2(end[1] - start[1], end[0] - start[0]) * 180) / Math.PI,
    };
  }

  const filteredCameras = cameras.filter((c) =>
    String(c.camera_name || "")
      .toLowerCase()
      .includes(search.trim().toLowerCase())
  );

  const visibleItems = [
    ...zones.map((zone) => ({ type: "zone", item: zone })),
    ...lines.map((line) => ({ type: "line", item: line })),
  ].filter(({ type }) => filterTab === "all" || filterTab === `${type}s`);

  const directionText = countingDirectionLabel(
    lineForm.direction
  );

  /* -------------------------------- render -------------------------------- */

  return (
    <div className="w-full min-w-0 overflow-x-hidden bg-[#020817] text-white">
      <div className="w-full px-0 pb-2">
        {/* Main type tabs */}
        <div className="mb-2 grid grid-cols-2 overflow-hidden rounded-md border border-[#123250] bg-[#07182a]">
          <button
            type="button"
            onClick={() => setActiveTab("zones")}
            className={`relative flex min-w-0 gap-2 px-3 py-2.5 text-left transition 2xl:gap-4 2xl:px-4 2xl:py-3 ${
              activeTab === "zones"
                ? "bg-[#0b2238] text-white"
                : "text-slate-400 hover:bg-[#0b2238]"
            }`}
          >
            <span className="text-2xl text-emerald-400">⬡</span>
            <span>
              <span className="block font-semibold">Zones (Areas)</span>
              <span className="mt-0.5 block text-sm text-slate-400">
                Draw areas to monitor restricted zones, bays, PPE areas, etc.
              </span>
            </span>
            {activeTab === "zones" && (
              <span className="absolute inset-x-0 bottom-0 h-1 bg-emerald-400" />
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab("lines")}
            className={`relative flex min-w-0 gap-2 border-l border-[#123250] px-3 py-2.5 text-left transition 2xl:gap-4 2xl:px-4 2xl:py-3 ${
              activeTab === "lines"
                ? "bg-[#0b2238] text-slate-100"
                : "text-slate-400 hover:bg-[#0b2238]"
            }`}
          >
            <span className="text-2xl text-blue-400">↗</span>
            <span>
              <span className="block font-semibold text-blue-400">
                Lines (Counting)
              </span>
              <span className="mt-0.5 block text-sm text-slate-400">
                Draw lines with direction to count people or vehicles.
              </span>
            </span>
            {activeTab === "lines" && (
              <span className="absolute inset-x-0 bottom-0 h-1 bg-blue-500" />
            )}
          </button>
        </div>

        <div className="w-full min-w-0 overflow-x-hidden pb-1">
          <div
            className="
              grid
              h-[calc(100dvh-116px)]
              min-h-[650px]
              min-w-0
              items-stretch
              gap-2
              grid-cols-[minmax(150px,0.62fr)_minmax(0,2.35fr)_minmax(230px,0.95fr)]
              2xl:grid-cols-[minmax(190px,0.65fr)_minmax(0,2.4fr)_minmax(290px,1fr)]
            "
          >
          {/* Camera list */}
          <aside className="flex h-full min-h-0 min-w-0 flex-col overflow-hidden rounded-md border border-[#123250] bg-[#07182a] p-2 2xl:p-3">
            <h2 className="mb-3 text-sm font-semibold">Cameras</h2>

            <div className="relative mb-3">
              <span className="pointer-events-none absolute left-3 top-2.5 text-slate-500">
                ⌕
              </span>
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search cameras..."
                className="w-full min-w-0 rounded-md border border-[#123250] bg-[#020817] py-2 pl-8 pr-2 text-xs outline-none transition placeholder:text-slate-500 focus:border-blue-500 2xl:text-sm"
              />
            </div>

            <div className="min-h-0 flex-1 space-y-1 overflow-y-auto pr-1 [scrollbar-color:#334155_transparent] [scrollbar-width:thin]">
              {filteredCameras.map((c) => {
                const active = c.id === cameraId;
                const online =
                  String(c.status || "").toLowerCase() === "online";

                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => selectCamera(c.id)}
                    className={`flex w-full min-w-0 items-center justify-between gap-1 rounded-md border px-2 py-2.5 text-left transition 2xl:px-3 ${
                      active
                        ? "border-[#1686ff] bg-[#0d63e6]/20"
                        : "border-transparent hover:bg-[#0b2238]"
                    }`}
                  >
                    <span
                      className={`min-w-0 flex-1 truncate text-[13px] font-semibold 2xl:text-sm ${
                        online ? "text-slate-100" : "text-slate-400"
                      }`}
                    >
                      {c.camera_name}
                    </span>
                    <span className="shrink-0 text-[10px] font-medium text-slate-400 2xl:text-[12px]">
                      CAM-{c.id}
                    </span>
                  </button>
                );
              })}

              {!filteredCameras.length && (
                <div className="px-2 py-8 text-center text-sm text-slate-500">
                  No cameras found.
                </div>
              )}
            </div>
          </aside>

          {/* Centre workspace */}
          <section className="flex h-full min-h-0 min-w-0 flex-col gap-2 overflow-hidden">
            <div className="min-w-0 shrink-0 rounded-md border border-[#123250] bg-[#07182a] p-3">
              <div className="mb-2 flex min-w-0 flex-wrap items-center gap-1.5 2xl:gap-2">
                <button
                  type="button"
                  onClick={beginZone}
                  disabled={!camera || busy}
                  className={`rounded-md border px-2.5 py-2 text-[11px] font-semibold 2xl:px-3 2xl:text-xs transition disabled:cursor-not-allowed disabled:opacity-40 ${
                    activeTab === "zones"
                      ? "border-emerald-400 bg-emerald-500 text-[#02130d] shadow-[0_0_0_1px_rgba(52,211,153,.25),0_0_14px_rgba(16,185,129,.18)]"
                      : "border-emerald-500/70 bg-[#071426] text-emerald-400 hover:bg-emerald-950/40"
                  }`}
                >
                  ＋ Add Zone
                </button>

                <button
                  type="button"
                  onClick={beginLine}
                  disabled={!camera || busy}
                  className={`rounded-md border px-2.5 py-2 text-[11px] font-semibold 2xl:px-3 2xl:text-xs transition disabled:cursor-not-allowed disabled:opacity-40 ${
                    activeTab === "lines"
                      ? "border-blue-400 bg-[#0d63e6] text-white shadow-[0_0_0_1px_rgba(96,165,250,.25),0_0_14px_rgba(13,99,230,.22)]"
                      : "border-blue-700 bg-[#071426] text-blue-400 hover:bg-blue-950/40"
                  }`}
                >
                  ↗ Add Line
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setPicOk(true);
                    setStamp(Date.now());
                  }}
                  disabled={!camera}
                  className="rounded-md border border-[#123250] bg-[#071426] px-4 py-2 text-xs font-medium transition hover:border-slate-500 hover:bg-[#17283d] disabled:opacity-40"
                >
                  ▣ New Picture
                </button>

                {(drawingZone || drawingLine) && (
                  <button
                    type="button"
                    onClick={() => {
                      cancelDrawing();
                      setMsg({ kind: "", text: "" });
                    }}
                    className="rounded-md border border-[#123250] bg-slate-800 px-4 py-2 text-xs font-medium text-slate-300"
                  >
                    Esc Cancel
                  </button>
                )}

                <div className="ml-auto hidden items-center gap-2 lg:flex">
                  <button
                    type="button"
                    onClick={() =>
                      setMsg({
                        kind: "",
                        text: "Undo can be connected to your preferred history implementation.",
                      })
                    }
                    className="h-10 w-10 rounded-md border border-[#123250] bg-[#071426] text-lg text-slate-400"
                    title="Undo"
                  >
                    ↶
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setMsg({
                        kind: "",
                        text: "Redo can be connected to your preferred history implementation.",
                      })
                    }
                    className="h-10 w-10 rounded-md border border-[#123250] bg-[#071426] text-lg text-slate-400"
                    title="Redo"
                  >
                    ↷
                  </button>
                </div>
              </div>

              {/* Camera stage */}
              <div
                ref={stageRef}
                onClick={onStageClick}
                onPointerMove={onStageMove}
                onPointerUp={onStageUp}
                onPointerCancel={onStageUp}
                className={`relative aspect-video w-full overflow-hidden rounded-md border border-[#123250] bg-[repeating-linear-gradient(45deg,#152236_0_7px,#101b2b_7px_14px)] select-none touch-none ${
                  drawingZone || drawingLine ? "cursor-crosshair" : ""
                }`}
              >
                {camera && picOk && (
                  <img
                    src={getCameraSnapshotUrl(camera.id, stamp)}
                    alt=""
                    onError={() => setPicOk(false)}
                    className="pointer-events-none absolute inset-0 h-full w-full object-fill"
                  />
                )}

                {camera && !picOk && (
                  <div className="absolute inset-0 grid place-items-center px-8 text-center text-sm text-slate-400">
                    No picture from {camera.camera_name} right now. The camera
                    may be offline. Press New Picture to retry.
                  </div>
                )}

                {!camera && (
                  <div className="absolute inset-0 grid place-items-center text-sm text-slate-500">
                    Choose a camera to begin.
                  </div>
                )}

                {size.w > 0 && (
                  <svg
                    width={size.w}
                    height={size.h}
                    viewBox={`0 0 ${size.w} ${size.h}`}
                    className="absolute inset-0 h-full w-full"
                  >
                    <defs>
                      {LINE_COLORS.map((color, index) => (
                        <marker
                          key={color}
                          id={`arrow-${index}`}
                          markerWidth="12"
                          markerHeight="12"
                          refX="9"
                          refY="4"
                          orient="auto"
                          markerUnits="strokeWidth"
                        >
                          <path d="M0,0 L0,8 L10,4 z" fill={color} />
                        </marker>
                      ))}
                    </defs>

                    {/* Saved zones */}
                    {zones.map((zone) => {
                      const pts = zone.polygon.map(px);
                      const [cx, cy] = px(centroid(zone.polygon));
                      const color = zoneColour(zone.zone_type);
                      const selected = zone.id === selectedZoneId;

                      return (
                        <g key={`zone-${zone.id}`}>
                          <polygon
                            points={pts.map((p) => p.join(",")).join(" ")}
                            fill={color}
                            fillOpacity={selected ? 0.3 : 0.18}
                            stroke={color}
                            strokeWidth={selected ? 3 : 2}
                            vectorEffect="non-scaling-stroke"
                            className="cursor-pointer"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (!drawingZone && !drawingLine) selectZone(zone);
                            }}
                          />

                          <text
                            x={cx}
                            y={cy}
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fill="white"
                            stroke="rgba(0,0,0,.75)"
                            strokeWidth="4"
                            paintOrder="stroke"
                            fontSize="14"
                            fontWeight="700"
                            className="pointer-events-none"
                          >
                            {zone.name}
                          </text>

                          {selected &&
                            pts.map((p, index) => (
                              <circle
                                key={index}
                                cx={p[0]}
                                cy={p[1]}
                                r="7"
                                fill="#07111e"
                                stroke={color}
                                strokeWidth="3"
                                className="cursor-grab"
                                onPointerDown={(e) =>
                                  onVertexDown(e, "zone", zone.id, index)
                                }
                              />
                            ))}
                        </g>
                      );
                    })}

                    {/* Saved counting lines */}
                    {lines.map((line) => {
                      const geometry = lineGeometry(line);
                      if (!geometry) return null;

                      const color = line.color || "#1683ff";
                      const selected = line.id === selectedLineId;
                      const colorIndex = Math.max(
                        0,
                        LINE_COLORS.findIndex((item) => item === color)
                      );
                      const markerId = `arrow-${
                        colorIndex >= 0 ? colorIndex : 0
                      }`;

                      return (
                        <g
                          key={`line-${line.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            if (!drawingZone && !drawingLine) selectLine(line);
                          }}
                          className="cursor-pointer"
                        >
                          {/* invisible wider hit area */}
                          <line
                            x1={geometry.a[0]}
                            y1={geometry.a[1]}
                            x2={geometry.b[0]}
                            y2={geometry.b[1]}
                            stroke="transparent"
                            strokeWidth="22"
                          />

                          <line
                            x1={geometry.start[0]}
                            y1={geometry.start[1]}
                            x2={geometry.end[0]}
                            y2={geometry.end[1]}
                            stroke="rgba(0,0,0,.75)"
                            strokeWidth={Number(line.width || 4) + 5}
                            strokeLinecap="round"
                          />

                          <line
                            x1={geometry.start[0]}
                            y1={geometry.start[1]}
                            x2={geometry.end[0]}
                            y2={geometry.end[1]}
                            stroke={color}
                            strokeWidth={selected ? Number(line.width || 4) + 2 : Number(line.width || 4)}
                            strokeLinecap="round"
                            markerEnd={
                              line.showArrows !== false
                                ? `url(#${markerId})`
                                : undefined
                            }
                          />

                          {line.showLabel !== false && (
                            <g
                              transform={`translate(${geometry.midX}, ${
                                geometry.midY - 22
                              })`}
                              className="pointer-events-none"
                            >
                              <rect
                                x="-38"
                                y="-15"
                                width="76"
                                height="28"
                                rx="6"
                                fill="#10145d"
                              />
                              <text
                                x="0"
                                y="0"
                                dominantBaseline="middle"
                                textAnchor="middle"
                                fill="white"
                                fontSize="13"
                                fontWeight="700"
                              >
                                {line.name}
                              </text>
                            </g>
                          )}

                          {selected &&
                            line.points.map((point, index) => {
                              const p = px(point);
                              return (
                                <circle
                                  key={index}
                                  cx={p[0]}
                                  cy={p[1]}
                                  r="7"
                                  fill="white"
                                  stroke={color}
                                  strokeWidth="3"
                                  className="cursor-grab"
                                  onPointerDown={(e) =>
                                    onVertexDown(e, "line", line.id, index)
                                  }
                                />
                              );
                            })}
                        </g>
                      );
                    })}

                    {/* Zone draft */}
                    {!!zoneDraftPx.length && (
                      <g>
                        <polyline
                          points={zoneDraftPx
                            .map((p) => p.join(","))
                            .join(" ")}
                          fill="none"
                          stroke="#2dd4bf"
                          strokeWidth="2"
                          strokeDasharray="7 5"
                        />
                        {zoneDraftPx.map((p, index) => (
                          <circle
                            key={index}
                            cx={p[0]}
                            cy={p[1]}
                            r={index === 0 ? 8 : 6}
                            fill={index === 0 ? "#2dd4bf" : "#07111e"}
                            stroke="#2dd4bf"
                            strokeWidth="3"
                            onPointerDown={(e) =>
                              onVertexDown(e, "zone-draft", "draft", index)
                            }
                          />
                        ))}
                      </g>
                    )}

                    {/* Line draft */}
                    {!!lineDraftPx.length && (
                      <g>
                        {lineDraftPx.length === 2 && (
                          <line
                            x1={lineDraftPx[0][0]}
                            y1={lineDraftPx[0][1]}
                            x2={lineDraftPx[1][0]}
                            y2={lineDraftPx[1][1]}
                            stroke={lineForm.color}
                            strokeWidth={Number(lineForm.width || 4)}
                            strokeLinecap="round"
                          />
                        )}

                        {lineDraftPx.map((p, index) => (
                          <circle
                            key={index}
                            cx={p[0]}
                            cy={p[1]}
                            r="8"
                            fill="white"
                            stroke={lineForm.color}
                            strokeWidth="3"
                            onPointerDown={(e) =>
                              onVertexDown(e, "line-draft", "draft", index)
                            }
                          />
                        ))}
                      </g>
                    )}
                  </svg>
                )}

                {/* small bottom-left camera badge */}
                {camera && (
                  <div className="pointer-events-none absolute bottom-3 left-3 rounded-lg bg-black/55 px-3 py-1 text-sm font-bold text-white backdrop-blur">
                    CAM-{camera.id}
                  </div>
                )}
              </div>

              {/* Stage help bar */}
              <div className="mt-2 grid gap-2 text-xs text-slate-400 sm:grid-cols-2 lg:grid-cols-4">
                <div className="rounded-lg bg-[#020817] px-3 py-2">
                  ✣ Click to add points
                </div>
                <div className="rounded-lg bg-[#020817] px-3 py-2">
                  ✥ Drag points to adjust
                </div>
                <div className="rounded-lg bg-[#020817] px-3 py-2">
                  ✓ Enter to finish zone
                </div>
                <div className="rounded-lg bg-[#020817] px-3 py-2">
                  Esc to cancel
                </div>
              </div>
            </div>

            {/* Configured table */}
            <div className="flex min-h-0 flex-1 flex-col overflow-hidden rounded-md border border-[#123250] bg-[#07182a]">
              <div className="flex flex-wrap items-center gap-2 border-b border-[#123250] px-4 py-3">
                <h3 className="mr-auto font-semibold">
                  Configured Zones &amp; Lines
                  {camera ? ` (${camera.camera_name} · CAM-${camera.id})` : ""}
                </h3>

                {[
                  ["all", `All (${zones.length + lines.length})`],
                  ["zones", `Zones (${zones.length})`],
                  ["lines", `Lines (${lines.length})`],
                ].map(([key, label]) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setFilterTab(key)}
                    className={`rounded-lg px-3 py-1.5 text-xs font-medium ${
                      filterTab === key
                        ? "bg-blue-500/20 text-blue-300"
                        : "bg-[#071426] text-slate-400"
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>

              <div className="min-h-0 w-full min-w-0 flex-1 overflow-x-hidden overflow-y-auto [scrollbar-color:#334155_transparent] [scrollbar-width:thin]">
                <table className="w-full table-fixed text-left text-xs 2xl:text-sm">
                  <thead className="bg-[#020817] text-xs uppercase tracking-wide text-slate-500">
                    <tr>
                      <th className="w-[18%] px-2 py-3 2xl:px-4">Type</th>
                      <th className="w-[24%] px-2 py-3 2xl:px-4">Name</th>
                      <th className="hidden w-[14%] px-2 py-3 xl:table-cell 2xl:px-4">Preview</th>
                      <th className="w-[34%] px-2 py-3 2xl:px-4">Direction / Details</th>
                      <th className="hidden w-[14%] px-2 py-3 2xl:table-cell 2xl:px-4">Time Limit</th>
                      <th className="w-[24%] px-2 py-3 2xl:px-4">Actions</th>
                    </tr>
                  </thead>

                  <tbody className="divide-y divide-slate-800">
                    {visibleItems.map(({ type, item }) => {
                      const isZone = type === "zone";

                      return (
                        <tr
                          key={`${type}-${item.id}`}
                          className="hover:bg-[#0b2238]/30"
                        >
                          <td className="px-2 py-3 2xl:px-4">
                            <span
                              className={`font-medium ${
                                isZone ? "text-emerald-400" : "text-blue-400"
                              }`}
                            >
                              {isZone ? "⬡ Zone" : "↗ Line"}
                            </span>
                          </td>

                          <td className="truncate px-2 py-3 font-medium text-slate-200 2xl:px-4">
                            {item.name}
                          </td>

                          <td className="hidden px-2 py-3 xl:table-cell 2xl:px-4">
                            {isZone ? (
                              <span
                                className="inline-block h-6 w-8 rounded border-2"
                                style={{
                                  borderColor: zoneColour(item.zone_type),
                                  backgroundColor: `${zoneColour(
                                    item.zone_type
                                  )}33`,
                                }}
                              />
                            ) : (
                              <span className="flex w-14 items-center">
                                <span
                                  className="h-1 flex-1 rounded"
                                  style={{ background: item.color }}
                                />
                                <span style={{ color: item.color }}>●</span>
                              </span>
                            )}
                          </td>

                          <td className="break-words px-2 py-3 text-slate-300 2xl:px-4">
                            {isZone
                              ? zoneTypeLabel(item.zone_type)
                              : countingDirectionLabel(
                                  item.direction
                                )}
                          </td>

                          <td className="hidden px-2 py-3 text-slate-400 2xl:table-cell 2xl:px-4">
                            {isZone && item.limit_sec
                              ? `${Math.round(item.limit_sec / 60)} min`
                              : "–"}
                          </td>

                          <td className="px-2 py-3 2xl:px-4">
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                title={isZone ? "Edit zone" : "Edit line"}
                                aria-label={isZone ? "Edit zone" : "Edit line"}
                                onClick={() =>
                                  isZone ? selectZone(item) : selectLine(item)
                                }
                                className="grid h-8 w-8 place-items-center rounded-md border border-[#123250] bg-[#071426] text-slate-300 transition hover:border-blue-500 hover:bg-[#0b2238] hover:text-blue-300"
                              >
                                <Pencil size={14} strokeWidth={2} />
                              </button>

                              <button
                                type="button"
                                title={isZone ? "Delete zone" : "Delete line"}
                                aria-label={isZone ? "Delete zone" : "Delete line"}
                                onClick={() =>
                                  isZone
                                    ? requestDeleteZone(item)
                                    : requestDeleteLine(item)
                                }
                                className="grid h-8 w-8 place-items-center rounded-md border border-red-500/40 bg-red-500/5 text-red-400 transition hover:border-red-500 hover:bg-red-500/10"
                              >
                                <Trash2 size={14} strokeWidth={2} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}

                    {!visibleItems.length && (
                      <tr>
                        <td
                          colSpan="6"
                          className="px-4 py-10 text-center text-sm text-slate-500"
                        >
                          Nothing configured for this camera yet.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          {/* Right settings panel */}
          <aside className="h-full min-h-0 min-w-0 overflow-hidden rounded-md border border-[#123250] bg-[#07182a]">
            {activeTab === "lines" ? (
              <form onSubmit={saveLine} className="flex h-full min-h-0 flex-col">
                <div className="flex min-w-0 items-center justify-between gap-2 border-b border-[#123250] px-2.5 py-3 2xl:px-4 2xl:py-4">
                  <h2 className="text-sm font-semibold">↗ Line Details</h2>
                  <span className="rounded-full bg-emerald-500/15 px-2.5 py-1 text-xs font-medium text-emerald-400">
                    ● Line Mode
                  </span>
                </div>

                <div className="min-h-0 min-w-0 flex-1 space-y-3 overflow-y-auto p-2.5 pr-2 [scrollbar-color:#334155_transparent] [scrollbar-width:thin] 2xl:space-y-4 2xl:p-4">
                  <label className="block">
                    <span className="mb-1.5 block text-sm text-slate-300">
                      Name
                    </span>
                    <input
                      value={lineForm.name}
                      onChange={(e) =>
                        setLineForm((f) => ({ ...f, name: e.target.value }))
                      }
                      className="w-full min-w-0 rounded-md border border-[#123250] bg-[#020817] px-2.5 py-2 text-xs 2xl:px-3 2xl:py-2.5 2xl:text-sm outline-none focus:border-blue-500"
                      placeholder="Enter line name"
                      required
                    />
                  </label>

                  <div>
                    <span className="mb-1.5 block text-sm text-slate-300">
                      Color
                    </span>
                    <div className="grid grid-cols-7 gap-2">
                      {LINE_COLORS.map((color) => (
                        <button
                          key={color}
                          type="button"
                          onClick={() =>
                            setLineForm((f) => ({ ...f, color }))
                          }
                          className={`h-9 rounded-lg border-2 ${
                            lineForm.color === color
                              ? "border-white"
                              : "border-transparent"
                          }`}
                          style={{ backgroundColor: color }}
                          title={color}
                        />
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="mb-2 block text-sm font-semibold text-slate-200">
                      Counting Direction
                    </span>

                    <div className="grid min-w-0 grid-cols-2 gap-1.5 2xl:gap-2">
                      {COUNTING_DIRECTIONS.map((item) => {
                        const selectedDirection =
                          lineForm.direction === item.key;

                        return (
                          <button
                            key={item.key}
                            type="button"
                            onClick={() =>
                              setLineForm((f) => ({
                                ...f,
                                direction: item.key,
                              }))
                            }
                            className={`rounded-md border p-3 text-center transition ${
                              selectedDirection
                                ? "border-blue-500 bg-blue-500/10"
                                : "border-[#123250] bg-[#020817]"
                            }`}
                          >
                            <span className="block text-2xl 2xl:text-3xl">
                              {item.key === "rtl" ? "←" : "→"}
                            </span>

                            <span className="mt-1 block text-[11px] font-semibold 2xl:text-sm">
                              {item.label}
                            </span>

                            <span className="mt-1 block text-[9px] leading-3 text-slate-400 2xl:text-xs 2xl:leading-normal">
                              {item.key === "rtl"
                                ? "Count when crossing from right to left"
                                : "Count when crossing from left to right"}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <label className="block">
                    <div className="mb-2 flex items-center justify-between">
                      <span className="text-sm text-slate-300">
                        Line Width (pixels)
                      </span>
                      <span className="rounded-lg border border-[#123250] bg-[#020817] px-3 py-1 text-sm">
                        {lineForm.width}
                      </span>
                    </div>
                    <input
                      type="range"
                      min="2"
                      max="10"
                      value={lineForm.width}
                      onChange={(e) =>
                        setLineForm((f) => ({
                          ...f,
                          width: Number(e.target.value),
                        }))
                      }
                      className="w-full accent-blue-500"
                    />
                  </label>

                  <Toggle
                    label="Show Direction Arrows"
                    checked={lineForm.showArrows}
                    onChange={(checked) =>
                      setLineForm((f) => ({ ...f, showArrows: checked }))
                    }
                  />

                  <Toggle
                    label="Show Line Label"
                    checked={lineForm.showLabel}
                    onChange={(checked) =>
                      setLineForm((f) => ({ ...f, showLabel: checked }))
                    }
                  />

                  <div className="rounded-md border border-blue-500/40 bg-blue-500/10 p-3 text-sm text-blue-200">
                    ⓘ This line will count people/vehicles crossing in the{" "}
                    <b>{directionText}</b> direction only.
                  </div>

                  {msg.text && (
                    <div
                      className={`rounded-md border p-3 text-sm ${
                        msg.kind === "err"
                          ? "border-red-500/40 bg-red-500/10 text-red-300"
                          : msg.kind === "ok"
                          ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
                          : "border-[#123250] bg-[#071426] text-slate-300"
                      }`}
                    >
                      {msg.text}
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => requestDeleteLine()}
                      disabled={!selectedLine || busy}
                      className="rounded-md border border-red-500 px-4 py-2.5 text-sm font-semibold text-red-400 transition hover:bg-red-500/10 disabled:cursor-not-allowed disabled:opacity-35"
                    >
                      Delete Line
                    </button>

                    <button
                      type="submit"
                      disabled={
                        busy || (!selectedLine && lineDraft.length !== 2)
                      }
                      className="rounded-md bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      Save Line
                    </button>
                  </div>
                </div>
              </form>
            ) : (
              <form onSubmit={saveZone} className="flex h-full min-h-0 flex-col">
                <div className="flex min-w-0 items-center justify-between gap-2 border-b border-[#123250] px-2.5 py-3 2xl:px-4 2xl:py-4">
                  <h2 className="text-sm font-semibold">⬡ Zone Details</h2>
                  <span className="rounded-full bg-emerald-500/15 px-2.5 py-1 text-xs font-medium text-emerald-400">
                    ● Zone Mode
                  </span>
                </div>

                <div className="min-h-0 min-w-0 flex-1 space-y-3 overflow-y-auto p-2.5 pr-2 [scrollbar-color:#334155_transparent] [scrollbar-width:thin] 2xl:space-y-4 2xl:p-4">
                  <label className="block">
                    <span className="mb-1.5 block text-sm text-slate-300">
                      Name
                    </span>
                    <input
                      value={zoneForm.name}
                      onChange={(e) =>
                        setZoneForm((f) => ({ ...f, name: e.target.value }))
                      }
                      placeholder="e.g. Loading Bay 3"
                      required
                      className="w-full min-w-0 rounded-md border border-[#123250] bg-[#020817] px-2.5 py-2 text-xs 2xl:px-3 2xl:py-2.5 2xl:text-sm outline-none focus:border-emerald-500"
                    />
                  </label>

                  <label className="block">
                    <span className="mb-1.5 block text-sm text-slate-300">
                      Type
                    </span>
                    <select
                      value={zoneForm.zone_type}
                      onChange={(e) =>
                        setZoneForm((f) => ({
                          ...f,
                          zone_type: e.target.value,
                        }))
                      }
                      className="w-full min-w-0 rounded-md border border-[#123250] bg-[#020817] px-2.5 py-2 text-xs 2xl:px-3 2xl:py-2.5 2xl:text-sm outline-none focus:border-emerald-500"
                    >
                      {ZONE_TYPES.map(([key, label]) => (
                        <option key={key} value={key}>
                          {label}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label className="block">
                    <span className="mb-1.5 block text-sm text-slate-300">
                      Time limit (minutes, blank = none)
                    </span>
                    <input
                      type="number"
                      min="0"
                      step="1"
                      value={zoneForm.limit_min}
                      onChange={(e) =>
                        setZoneForm((f) => ({
                          ...f,
                          limit_min: e.target.value,
                        }))
                      }
                      placeholder="e.g. 30"
                      className="w-full min-w-0 rounded-md border border-[#123250] bg-[#020817] px-2.5 py-2 text-xs 2xl:px-3 2xl:py-2.5 2xl:text-sm outline-none focus:border-emerald-500"
                    />
                  </label>

                  <div className="rounded-md border border-[#123250] bg-[#020817] p-3 text-xs leading-5 text-slate-400">
                    <b className="text-red-400">Restricted:</b> anyone inside can
                    raise a critical alert.
                    <br />
                    <b className="text-emerald-400">Bay / yard / gate:</b>{" "}
                    vehicles inside can use time limits.
                    <br />
                    <b className="text-blue-400">PPE:</b> helmet/vest checks are
                    applied inside the selected area.
                  </div>

                  {msg.text && (
                    <div
                      className={`rounded-md border p-3 text-sm ${
                        msg.kind === "err"
                          ? "border-red-500/40 bg-red-500/10 text-red-300"
                          : msg.kind === "ok"
                          ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
                          : "border-[#123250] bg-[#071426] text-slate-300"
                      }`}
                    >
                      {msg.text}
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => requestDeleteZone()}
                      disabled={!selectedZone || busy}
                      className="rounded-md border border-red-500 px-4 py-2.5 text-sm font-semibold text-red-400 transition hover:bg-red-500/10 disabled:cursor-not-allowed disabled:opacity-35"
                    >
                      Delete Zone
                    </button>

                    <button
                      type="submit"
                      disabled={
                        busy || (!selectedZone && zoneDraft.length < 3)
                      }
                      className="rounded-md bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-500 disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      Save Zone
                    </button>
                  </div>
                </div>
              </form>
            )}
          </aside>
          </div>
        </div>

        {confirmModal && (
          <div
            className="fixed inset-0 z-[100] grid place-items-center bg-black/60 p-4 backdrop-blur-[1px]"
            role="dialog"
            aria-modal="true"
            aria-labelledby="zone-confirm-title"
          >
            <div className="w-full max-w-[590px] overflow-hidden rounded-2xl border border-blue-400/20 bg-[#3d82f2] shadow-[0_24px_80px_rgba(0,0,0,.55)]">
              <div className="bg-[#1f4382] px-6 py-5 text-center">
                <h2
                  id="zone-confirm-title"
                  className="text-xl font-bold text-white sm:text-2xl"
                >
                  {confirmModal.title}
                </h2>
              </div>

              <div className="px-6 py-8 text-center">
                <p className="text-base font-semibold text-white sm:text-lg">
                  {confirmModal.message}
                </p>

                <div className="mt-7 grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    disabled={confirmBusy}
                    onClick={runConfirm}
                    className={`rounded-xl px-4 py-3 text-base font-bold text-white transition disabled:cursor-wait disabled:opacity-60 ${
                      confirmModal.action === "delete"
                        ? "bg-[#1e3f78] hover:bg-[#173766]"
                        : "bg-[#1e3f78] hover:bg-[#173766]"
                    }`}
                  >
                    {confirmBusy ? "Please wait..." : confirmModal.confirmText}
                  </button>

                  <button
                    type="button"
                    disabled={confirmBusy}
                    onClick={closeConfirm}
                    className="rounded-xl bg-[#1e3f78] px-4 py-3 text-base font-bold text-white transition hover:bg-[#173766] disabled:opacity-60"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function Toggle({ label, checked, onChange }) {
  return (
    <label className="flex cursor-pointer items-center gap-3">
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={`relative h-6 w-11 rounded-full transition ${
          checked ? "bg-blue-500" : "bg-slate-700"
        }`}
      >
        <span
          className={`absolute top-1 h-4 w-4 rounded-full bg-white transition ${
            checked ? "left-6" : "left-1"
          }`}
        />
      </button>
      <span className="text-sm text-slate-300">{label}</span>
    </label>
  );
}
