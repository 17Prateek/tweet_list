// Zone types shared by the Zones & Lines editor
// and the Ops Board plant map.

export const ZONE_TYPES = [
  ["gate", "Gate", "#14b8a6"],
  ["weighbridge", "Weighbridge", "#14b8a6"],
  ["yard", "Yard / parking", "#14b8a6"],

  ["bay", "Loading bay", "#22c55e"],

  ["unloading_bay", "Unloading bay (tanker)", "#f59e0b"],

  ["restricted", "Restricted area", "#ef4444"],

  ["ppe", "PPE required here", "#3b82f6"],

  ["custom", "Other", "#94a3b8"],
];

// Order used by the Ops Board / plant map.
// This keeps the operational flow consistent.
export const ZONE_ORDER = ZONE_TYPES.map(([key]) => key);

/**
 * Return the display colour for a zone type.
 */
export function zoneColour(type) {
  const zone = ZONE_TYPES.find(([key]) => key === type);

  return zone
    ? zone[2]
    : ZONE_TYPES[ZONE_TYPES.length - 1][2];
}

/**
 * Return the readable label for a zone type.
 */
export function zoneTypeLabel(type) {
  const zone = ZONE_TYPES.find(([key]) => key === type);

  return zone
    ? zone[1]
    : type || "Other";
}

/**
 * Optional helper.
 * Useful when you want the complete zone type object
 * without repeatedly searching ZONE_TYPES.
 */
export function getZoneType(type) {
  const zone =
    ZONE_TYPES.find(([key]) => key === type) ||
    ZONE_TYPES[ZONE_TYPES.length - 1];

  return {
    key: zone[0],
    label: zone[1],
    color: zone[2],
  };
}


// =========================================================
// Counting line directions
// =========================================================
//
// IMPORTANT:
// We only use:
//   ltr = Left -> Right
//   rtl = Right -> Left
//
// No top-to-bottom / bottom-to-top directions.
//

export const COUNTING_DIRECTIONS = [
  {
    key: "ltr",
    label: "Left → Right",
    shortLabel: "L → R",
  },
  {
    key: "rtl",
    label: "Right → Left",
    shortLabel: "R → L",
  },
];


/**
 * Return readable counting direction label.
 *
 * Examples:
 *   countingDirectionLabel("ltr")
 *   -> "Left → Right"
 *
 *   countingDirectionLabel("rtl")
 *   -> "Right → Left"
 */
export function countingDirectionLabel(direction) {
  const normalized = String(
    direction || "",
  )
    .trim()
    .toLowerCase();

  const item = COUNTING_DIRECTIONS.find(
    (entry) => entry.key === normalized,
  );

  return item
    ? item.label
    : "Left → Right";
}


/**
 * Return short direction label.
 *
 * ltr -> L → R
 * rtl -> R → L
 */
export function countingDirectionShortLabel(direction) {
  const normalized = String(
    direction || "",
  )
    .trim()
    .toLowerCase();

  const item = COUNTING_DIRECTIONS.find(
    (entry) => entry.key === normalized,
  );

  return item
    ? item.shortLabel
    : "L → R";
}


/**
 * Validate counting direction.
 *
 * Only these values are allowed:
 *   ltr
 *   rtl
 */
export function isValidCountingDirection(direction) {
  const normalized = String(
    direction || "",
  )
    .trim()
    .toLowerCase();

  return normalized === "ltr" || normalized === "rtl";
}


/**
 * Normalize any incoming direction value.
 *
 * Invalid / empty values fall back to "ltr".
 */
export function normalizeCountingDirection(direction) {
  const normalized = String(
    direction || "",
  )
    .trim()
    .toLowerCase();

  return normalized === "rtl"
    ? "rtl"
    : "ltr";
}